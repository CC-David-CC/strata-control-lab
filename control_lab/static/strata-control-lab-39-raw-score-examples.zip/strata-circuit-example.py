# -*- coding: utf-8 -*-
"""Downloaded Strata example: Python 3 standard library; offline by default.

Windows: py strata-example.py
Ubuntu:  python3 strata-example.py
Show a request: python strata-example.py --request 1 --show
Replay all recorded calls: python strata-example.py --all
Recalculate the panel: python strata-example.py --lesson-only
Change its knob: python strata-example.py --lesson-only --value NUMBER
Try ONE request live: python strata-example.py --request 1 --live-url http://127.0.0.1:8080
An optional STRATA_API_KEY environment variable supplies authentication.

CAPTURED is inserted above this runner by the page. It contains this exact run,
with requests, GBNF/JSON settings, responses, streaming chunks and the page result.
Mock mode returns those responses; it performs no inference and opens no socket.
Live mode runs only a selected request. It does not execute tools or adapt a saved
multi-step trace to new answers. No captured API key or authorization header exists.
"""
CAPTURED = {
    "experiment": "circuit",
    "score_view": {
        "raw": "Each generated token carries target logprob before grammar, penalties and sampling. Raw probability is exp(logprob), with the denominator over the full target vocabulary. Every score belongs to its selected request and exact preceding token path. These instruments also inspect a pure temperature-1 grammar mask. Complete answer rows recover raw label p from native legal-set weight q times surviving mass Z; the selected token logprob below is the direct target score, not that recovered row.",
        "derived": "Complete legal-set weights define finite semantic conditionals. Circuit products and marginals follow those declared variable dependencies; they are not raw vocabulary probabilities or independent truth evidence.",
        "scope": "The raw receipt stays attached to the captured request. Page dials recalculate derived views; they do not rerun the model or replace token scores. Neither model probability nor a derived weight is calibrated truth. Missing top-N alternatives stay unknown.",
        "raw_kind": "native"
    },
    "type": "result",
    "result": {
        "cases": [
            {
                "original": "Parcel 17 weighs 4 kg.",
                "edited": "Please note that parcel 17 weighs 4 kg.",
                "measurement": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Neither F nor S",
                            "weight": 0.005307257014794141,
                            "logprob": -5.2417462284329694,
                            "token_id": 32,
                            "bytes": [
                                65
                            ]
                        },
                        {
                            "label": "B",
                            "description": "F only: facts preserved, no requested style",
                            "weight": 0.2140605119293163,
                            "logprob": -1.5445626194241804,
                            "token_id": 33,
                            "bytes": [
                                66
                            ]
                        },
                        {
                            "label": "C",
                            "description": "S only: style changed, facts changed",
                            "weight": 0.013883898607649766,
                            "logprob": -4.280091565347032,
                            "token_id": 34,
                            "bytes": [
                                67
                            ]
                        },
                        {
                            "label": "D",
                            "description": "Both F and S",
                            "weight": 0.7667483324482397,
                            "logprob": -0.26866273233921956,
                            "token_id": 35,
                            "bytes": [
                                68
                            ]
                        }
                    ],
                    "pressure": {
                        "log_mass": -0.003066081517959729,
                        "mass": 0.9969386141096926,
                        "pressure_nats": 0.003066081517959729,
                        "pressure_bits": 0.004423420600921806,
                        "selected_raw_logprob": -0.26866273233921956,
                        "selected_probability": 0.7667483324482397,
                        "support": 4
                    },
                    "selected": "D",
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "prompt": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Please note that parcel 17 weighs 4 kg.\nF: parcel number and weight are preserved. S: the edit explicitly uses the polite word please.\nQUESTION: Which joint state describes the edit?\nANSWERS:\nA: Neither F nor S\nB: F only: facts preserved, no requested style\nC: S only: style changed, facts changed\nD: Both F and S\nReturn exactly one answer code. No explanation or whitespace.",
                    "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                },
                "operations": {
                    "F": 0.980808844377556,
                    "S": 0.7806322310558894,
                    "AND": 0.7667483324482397,
                    "OR": 0.9946927429852058,
                    "F_given_S": 0.9822145460367807,
                    "marginal_product": 0.7656509964258001,
                    "dependence": 0.0010973360224395545
                }
            },
            {
                "original": "Parcel 17 weighs 4 kg.",
                "edited": "Parcel 17 weighs 4 kg.",
                "measurement": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Neither F nor S",
                            "weight": 0.01836352294786483,
                            "logprob": -4.001385314314332,
                            "token_id": 32,
                            "bytes": [
                                65
                            ]
                        },
                        {
                            "label": "B",
                            "description": "F only: facts preserved, no requested style",
                            "weight": 0.4933899610852112,
                            "logprob": -0.7104517053055425,
                            "token_id": 33,
                            "bytes": [
                                66
                            ]
                        },
                        {
                            "label": "C",
                            "description": "S only: style changed, facts changed",
                            "weight": 0.02361302973993604,
                            "logprob": -3.7499528954910897,
                            "token_id": 34,
                            "bytes": [
                                67
                            ]
                        },
                        {
                            "label": "D",
                            "description": "Both F and S",
                            "weight": 0.464633486226988,
                            "logprob": -0.7705026696610113,
                            "token_id": 35,
                            "bytes": [
                                68
                            ]
                        }
                    ],
                    "pressure": {
                        "log_mass": -0.003996283809585832,
                        "mass": 0.9960116907062114,
                        "pressure_nats": 0.003996283809585832,
                        "pressure_bits": 0.005765418834074335,
                        "selected_raw_logprob": -0.7705026696610113,
                        "selected_probability": 0.464633486226988,
                        "support": 4
                    },
                    "selected": "D",
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "prompt": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Parcel 17 weighs 4 kg.\nF: parcel number and weight are preserved. S: the edit explicitly uses the polite word please.\nQUESTION: Which joint state describes the edit?\nANSWERS:\nA: Neither F nor S\nB: F only: facts preserved, no requested style\nC: S only: style changed, facts changed\nD: Both F and S\nReturn exactly one answer code. No explanation or whitespace.",
                    "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                },
                "operations": {
                    "F": 0.9580234473121992,
                    "S": 0.4882465159669241,
                    "AND": 0.464633486226988,
                    "OR": 0.9816364770521352,
                    "F_given_S": 0.9516370747814292,
                    "marginal_product": 0.46775161036480334,
                    "dependence": -0.0031181241378153146
                }
            },
            {
                "original": "Parcel 17 weighs 4 kg.",
                "edited": "Please note that parcel 17 weighs 40 kg.",
                "measurement": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Neither F nor S",
                            "weight": 0.03426785554158461,
                            "logprob": -3.3789276896880347,
                            "token_id": 32,
                            "bytes": [
                                65
                            ]
                        },
                        {
                            "label": "B",
                            "description": "F only: facts preserved, no requested style",
                            "weight": 0.3495294510853903,
                            "logprob": -1.056547623770066,
                            "token_id": 33,
                            "bytes": [
                                66
                            ]
                        },
                        {
                            "label": "C",
                            "description": "S only: style changed, facts changed",
                            "weight": 0.3067127233487208,
                            "logprob": -1.1872238933013157,
                            "token_id": 34,
                            "bytes": [
                                67
                            ]
                        },
                        {
                            "label": "D",
                            "description": "Both F and S",
                            "weight": 0.30948997002430434,
                            "logprob": -1.178209763662644,
                            "token_id": 35,
                            "bytes": [
                                68
                            ]
                        }
                    ],
                    "pressure": {
                        "log_mass": -0.005380169250327249,
                        "mass": 0.9946342779392,
                        "pressure_nats": 0.005380169250327249,
                        "pressure_bits": 0.007761943496590415,
                        "selected_raw_logprob": -1.1872238933013157,
                        "selected_probability": 0.3067127233487208,
                        "support": 4
                    },
                    "selected": "C",
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "prompt": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Please note that parcel 17 weighs 40 kg.\nF: parcel number and weight are preserved. S: the edit explicitly uses the polite word please.\nQUESTION: Which joint state describes the edit?\nANSWERS:\nA: Neither F nor S\nB: F only: facts preserved, no requested style\nC: S only: style changed, facts changed\nD: Both F and S\nReturn exactly one answer code. No explanation or whitespace.",
                    "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                },
                "operations": {
                    "F": 0.6590194211096947,
                    "S": 0.6162026933730251,
                    "AND": 0.30948997002430434,
                    "OR": 0.9657321444584154,
                    "F_given_S": 0.5022535171506483,
                    "marginal_product": 0.4060895422729257,
                    "dependence": -0.09659957224862137
                }
            },
            {
                "original": "Parcel 17 weighs 4 kg.",
                "edited": "PARCEL 17 IS 40 KG.",
                "measurement": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Neither F nor S",
                            "weight": 0.09496388254090679,
                            "logprob": -2.357746482051402,
                            "token_id": 32,
                            "bytes": [
                                65
                            ]
                        },
                        {
                            "label": "B",
                            "description": "F only: facts preserved, no requested style",
                            "weight": 0.43083969850974463,
                            "logprob": -0.845507025874644,
                            "token_id": 33,
                            "bytes": [
                                66
                            ]
                        },
                        {
                            "label": "C",
                            "description": "S only: style changed, facts changed",
                            "weight": 0.43566561356083955,
                            "logprob": -0.8343681098590191,
                            "token_id": 34,
                            "bytes": [
                                67
                            ]
                        },
                        {
                            "label": "D",
                            "description": "Both F and S",
                            "weight": 0.03853080538850901,
                            "logprob": -3.259785056270152,
                            "token_id": 35,
                            "bytes": [
                                68
                            ]
                        }
                    ],
                    "pressure": {
                        "log_mass": -0.003487838601701432,
                        "mass": 0.9965182368419129,
                        "pressure_nats": 0.003487838601701432,
                        "pressure_bits": 0.005031887454095752,
                        "selected_raw_logprob": -0.845507025874644,
                        "selected_probability": 0.43083969850974463,
                        "support": 4
                    },
                    "selected": "B",
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "prompt": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: PARCEL 17 IS 40 KG.\nF: parcel number and weight are preserved. S: the edit explicitly uses the polite word please.\nQUESTION: Which joint state describes the edit?\nANSWERS:\nA: Neither F nor S\nB: F only: facts preserved, no requested style\nC: S only: style changed, facts changed\nD: Both F and S\nReturn exactly one answer code. No explanation or whitespace.",
                    "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                },
                "operations": {
                    "F": 0.46937050389825363,
                    "S": 0.47419641894934855,
                    "AND": 0.03853080538850901,
                    "OR": 0.9050361174590932,
                    "F_given_S": 0.08125494805270701,
                    "marginal_product": 0.22257381210900312,
                    "dependence": -0.18404300672049412
                }
            }
        ],
        "separate": {
            "values": [
                0.9859123918488581,
                0.9860470190189092,
                0.9629526271982507
            ],
            "measurements": [
                {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Yes: the proposition is true",
                            "weight": 0.9859123918488581,
                            "logprob": -0.015083015955309116,
                            "token_id": 32,
                            "bytes": [
                                65
                            ]
                        },
                        {
                            "label": "B",
                            "description": "No: the proposition is false",
                            "weight": 0.014087608151141913,
                            "logprob": -4.263354958093982,
                            "token_id": 33,
                            "bytes": [
                                66
                            ]
                        }
                    ],
                    "pressure": {
                        "log_mass": -0.0008952355479619929,
                        "mass": 0.9991051650558274,
                        "pressure_nats": 0.0008952355479619929,
                        "pressure_bits": 0.001291551885472281,
                        "selected_raw_logprob": -0.015083015955309116,
                        "selected_probability": 0.9859123918488581,
                        "support": 2
                    },
                    "selected": "A",
                    "grammar": "root ::= \"A\" | \"B\"",
                    "prompt": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Please note that parcel 17 weighs 4 kg.\nQUESTION: Are the original parcel number and weight preserved?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                    "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                },
                {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Yes: the proposition is true",
                            "weight": 0.9860470190189092,
                            "logprob": -0.016210248843368906,
                            "token_id": 32,
                            "bytes": [
                                65
                            ]
                        },
                        {
                            "label": "B",
                            "description": "No: the proposition is false",
                            "weight": 0.013952980981090775,
                            "logprob": -4.274221113101182,
                            "token_id": 33,
                            "bytes": [
                                66
                            ]
                        }
                    ],
                    "pressure": {
                        "log_mass": -0.0021590099586497775,
                        "mass": 0.9978433190269484,
                        "pressure_nats": 0.0021590099586497775,
                        "pressure_bits": 0.0031147929605739202,
                        "selected_raw_logprob": -0.016210248843368906,
                        "selected_probability": 0.9860470190189092,
                        "support": 2
                    },
                    "selected": "A",
                    "grammar": "root ::= \"A\" | \"B\"",
                    "prompt": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Please note that parcel 17 weighs 4 kg.\nQUESTION: Does the edit explicitly use the polite word please?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                    "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                },
                {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Yes: the proposition is true",
                            "weight": 0.9629526271982507,
                            "logprob": -0.03985392941737003,
                            "token_id": 32,
                            "bytes": [
                                65
                            ]
                        },
                        {
                            "label": "B",
                            "description": "No: the proposition is false",
                            "weight": 0.03704737280174922,
                            "logprob": -3.2976607073714717,
                            "token_id": 33,
                            "bytes": [
                                66
                            ]
                        }
                    ],
                    "pressure": {
                        "log_mass": -0.0021028680827965135,
                        "mass": 0.9978993413952719,
                        "pressure_nats": 0.0021028680827965135,
                        "pressure_bits": 0.0030337973546942123,
                        "selected_raw_logprob": -0.03985392941737003,
                        "selected_probability": 0.9629526271982507,
                        "support": 2
                    },
                    "selected": "A",
                    "grammar": "root ::= \"A\" | \"B\"",
                    "prompt": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Please note that parcel 17 weighs 4 kg.\nQUESTION: Are the original parcel number and weight preserved AND is the polite word please used?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                    "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                }
            ],
            "lower": 0.9719594108677674,
            "upper": 0.9859123918488581,
            "violation": 0.009006783669516683
        },
        "hypothetical": {
            "joint": [
                0.1,
                0.1,
                0.2,
                0.6
            ],
            "inconsistent": [
                0.9,
                0.9,
                0.1
            ]
        },
        "semantics": "Arithmetic is exact relative to each supplied distribution. Different prompts need not form one coherent joint belief. A violated bound identifies an inconsistency, not which estimate is wrong."
    },
    "lesson": {
        "question": "Can we compute AND without assuming independence?",
        "rule": "Start with four joint worlds. Optionally condition on noisy evidence of style, then add worlds for each logical operation.",
        "knob": "Reliability of observing style",
        "default": 0.5,
        "compare": 1,
        "low": 0.5,
        "high": 1,
        "integer": False,
        "states": [
            {
                "value": 0.5,
                "summary": "Facts AND style: 76.67%; multiplying the marginals would give 76.57%.",
                "rows": [
                    {
                        "label": "Neither",
                        "value": 0.005307257014794143
                    },
                    {
                        "label": "Facts only",
                        "value": 0.21406051192931633
                    },
                    {
                        "label": "Style only",
                        "value": 0.013883898607649768
                    },
                    {
                        "label": "Both",
                        "value": 0.7667483324482398
                    }
                ],
                "unit": "weight",
                "metrics": {
                    "F": 0.9808088443775561,
                    "S": 0.7806322310558895,
                    "AND": 0.7667483324482398,
                    "OR": 0.9946927429852058,
                    "F_given_S": 0.9822145460367807,
                    "marginal_product": 0.7656509964258004
                },
                "note": "At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world."
            },
            {
                "value": 1,
                "summary": "Facts AND style: 98.22%; multiplying the marginals would give 98.22%.",
                "rows": [
                    {
                        "label": "Neither",
                        "value": 0
                    },
                    {
                        "label": "Facts only",
                        "value": 0
                    },
                    {
                        "label": "Style only",
                        "value": 0.017785453963219393
                    },
                    {
                        "label": "Both",
                        "value": 0.9822145460367807
                    }
                ],
                "unit": "weight",
                "metrics": {
                    "F": 0.9822145460367807,
                    "S": 1,
                    "AND": 0.9822145460367807,
                    "OR": 1,
                    "F_given_S": 0.9822145460367807,
                    "marginal_product": 0.9822145460367807
                },
                "note": "At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world."
            }
        ],
        "input_excerpt": "",
        "scope": "This panel and its Python calculation reproduce saved measurements. Other page controls are independent views."
    },
    "receipt": {
        "mode": "recorded",
        "requests": 7,
        "summed_request_ms": 6667.552200029604,
        "prompt_tokens": 822,
        "completion_tokens": 7,
        "calls": [
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Please note that parcel 17 weighs 4 kg.\nF: parcel number and weight are preserved. S: the edit explicitly uses the polite word please.\nQUESTION: Which joint state describes the edit?\nANSWERS:\nA: Neither F nor S\nB: F only: facts preserved, no requested style\nC: S only: style changed, facts changed\nD: Both F and S\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-178796aa29274639bcdd291c",
                    "object": "chat.completion",
                    "created": 1791087281,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "D"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "D",
                                        "logprob": -0.26866273233921956,
                                        "bytes": [
                                            68
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "D",
                                                "logprob": -0.26866273233921956,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.5445626194241804,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -4.280091565347032,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -5.2417462284329694,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "F",
                                                "logprob": -7.387290280556993,
                                                "bytes": [
                                                    70
                                                ]
                                            },
                                            {
                                                "token": " D",
                                                "logprob": -8.071137707925157,
                                                "bytes": [
                                                    32,
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -8.078139584756212,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.024783414101915,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "d",
                                                "logprob": -9.071101468301134,
                                                "bytes": [
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Both",
                                                "logprob": -9.673029225564317,
                                                "bytes": [
                                                    66,
                                                    111,
                                                    116,
                                                    104
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.951062482095079,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "S",
                                                "logprob": -9.99196366617711,
                                                "bytes": [
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.140986722207384,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -10.224747937417344,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "(D",
                                                "logprob": -10.316693585610704,
                                                "bytes": [
                                                    40,
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -10.363613408303575,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "K",
                                                "logprob": -10.366742413735704,
                                                "bytes": [
                                                    75
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.520922940469102,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "H",
                                                "logprob": -10.677410405373887,
                                                "bytes": [
                                                    72
                                                ]
                                            },
                                            {
                                                "token": "DD",
                                                "logprob": -10.686696332192735,
                                                "bytes": [
                                                    68,
                                                    68
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 35,
                                            "probability": 0.7667483324482397,
                                            "support": 4,
                                            "entropy": 0.6208041372803071,
                                            "selection_ms": 0.122028,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 4,
                                                    "entropy": 0.6208041372803071
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 4,
                                                    "entropy": 0.6208041372803071
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 35,
                                                    "probability": 0.7667483324482397,
                                                    "bytes": [
                                                        68
                                                    ],
                                                    "token": "D"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.2140605119293163,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 34,
                                                    "probability": 0.013883898607649766,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.005307257014794141,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 133,
                        "completion_tokens": 1,
                        "total_tokens": 134,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 133,
                        "prompt_ms": 893.3,
                        "prompt_per_token_ms": 6.717,
                        "prompt_per_second": 148.9,
                        "predicted_n": 1,
                        "predicted_ms": 26.4,
                        "predicted_per_token_ms": 26.4,
                        "predicted_per_second": 37.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1132.8981999540702,
                "captured_at": "2026-10-04T04:14:43Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Parcel 17 weighs 4 kg.\nF: parcel number and weight are preserved. S: the edit explicitly uses the polite word please.\nQUESTION: Which joint state describes the edit?\nANSWERS:\nA: Neither F nor S\nB: F only: facts preserved, no requested style\nC: S only: style changed, facts changed\nD: Both F and S\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-faa466b1f0fc4b60b2339e6b",
                    "object": "chat.completion",
                    "created": 1791087282,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "D"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "D",
                                        "logprob": -0.7705026696610113,
                                        "bytes": [
                                            68
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7104517053055426,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -0.7705026696610113,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -3.7499528954910897,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.001385314314332,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "F",
                                                "logprob": -7.281105620710816,
                                                "bytes": [
                                                    70
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -7.453263861982789,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.62032471403357,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " D",
                                                "logprob": -8.661005599348512,
                                                "bytes": [
                                                    32,
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "d",
                                                "logprob": -9.114284140913453,
                                                "bytes": [
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.44218693479773,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.543397528974976,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "(D",
                                                "logprob": -9.926909072248902,
                                                "bytes": [
                                                    40,
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "S",
                                                "logprob": -9.997488601057496,
                                                "bytes": [
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -10.012985808699097,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.077319724409547,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "DD",
                                                "logprob": -10.106918914167847,
                                                "bytes": [
                                                    68,
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.17868481382605,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Which",
                                                "logprob": -10.294353110640015,
                                                "bytes": [
                                                    87,
                                                    104,
                                                    105,
                                                    99,
                                                    104
                                                ]
                                            },
                                            {
                                                "token": "H",
                                                "logprob": -10.322901351301637,
                                                "bytes": [
                                                    72
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.359381301252808,
                                                "bytes": [
                                                    88
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 35,
                                            "probability": 0.464633486226988,
                                            "support": 4,
                                            "entropy": 0.8665620772630857,
                                            "selection_ms": 0.112539,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 4,
                                                    "entropy": 0.8665620772630857
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 4,
                                                    "entropy": 0.8665620772630857
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.4933899610852112,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 35,
                                                    "probability": 0.464633486226988,
                                                    "bytes": [
                                                        68
                                                    ],
                                                    "token": "D"
                                                },
                                                {
                                                    "id": 34,
                                                    "probability": 0.02361302973993604,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.01836352294786483,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 130,
                        "completion_tokens": 1,
                        "total_tokens": 131,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 130,
                        "prompt_ms": 830,
                        "prompt_per_token_ms": 6.385,
                        "prompt_per_second": 156.6,
                        "predicted_n": 1,
                        "predicted_ms": 23.6,
                        "predicted_per_token_ms": 23.6,
                        "predicted_per_second": 42.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 880.2132999990135,
                "captured_at": "2026-10-04T04:14:44Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Please note that parcel 17 weighs 40 kg.\nF: parcel number and weight are preserved. S: the edit explicitly uses the polite word please.\nQUESTION: Which joint state describes the edit?\nANSWERS:\nA: Neither F nor S\nB: F only: facts preserved, no requested style\nC: S only: style changed, facts changed\nD: Both F and S\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-15a2db666f804a5f9d9f602f",
                    "object": "chat.completion",
                    "created": 1791087283,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "C"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "C",
                                        "logprob": -1.1872238933013157,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -1.0565476237700657,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -1.1782097636626438,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.1872238933013157,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.3789276896880347,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -6.748556595938035,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "F",
                                                "logprob": -7.900628548757859,
                                                "bytes": [
                                                    70
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.388271790640182,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "S",
                                                "logprob": -8.389189225332565,
                                                "bytes": [
                                                    83
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -8.526653748647995,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": " D",
                                                "logprob": -8.554081421987838,
                                                "bytes": [
                                                    32,
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.785939675466842,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.240833741323776,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -9.397545319692917,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "d",
                                                "logprob": -9.408085328237838,
                                                "bytes": [
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -9.599731904165573,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -9.604698640005417,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.70817611803276,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "c",
                                                "logprob": -9.904598694937057,
                                                "bytes": [
                                                    99
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -9.93623016466362,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Which",
                                                "logprob": -9.962112885610885,
                                                "bytes": [
                                                    87,
                                                    104,
                                                    105,
                                                    99,
                                                    104
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 34,
                                            "probability": 0.3067127233487208,
                                            "support": 4,
                                            "entropy": 1.2084837256646992,
                                            "selection_ms": 0.113472,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 4,
                                                    "entropy": 1.2084837256646992
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 4,
                                                    "entropy": 1.2084837256646992
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.3495294510853903,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 35,
                                                    "probability": 0.30948997002430434,
                                                    "bytes": [
                                                        68
                                                    ],
                                                    "token": "D"
                                                },
                                                {
                                                    "id": 34,
                                                    "probability": 0.3067127233487208,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.03426785554158461,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 134,
                        "completion_tokens": 1,
                        "total_tokens": 135,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 134,
                        "prompt_ms": 844.5,
                        "prompt_per_token_ms": 6.302,
                        "prompt_per_second": 158.7,
                        "predicted_n": 1,
                        "predicted_ms": 26,
                        "predicted_per_token_ms": 26,
                        "predicted_per_second": 38.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 891.0319000133313,
                "captured_at": "2026-10-04T04:14:45Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: PARCEL 17 IS 40 KG.\nF: parcel number and weight are preserved. S: the edit explicitly uses the polite word please.\nQUESTION: Which joint state describes the edit?\nANSWERS:\nA: Neither F nor S\nB: F only: facts preserved, no requested style\nC: S only: style changed, facts changed\nD: Both F and S\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-dd343c29e4ea4b35ba91d873",
                    "object": "chat.completion",
                    "created": 1791087284,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.845507025874644,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "C",
                                                "logprob": -0.834368109859019,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -0.845507025874644,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.357746482051402,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -3.259785056270152,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -7.728285193599254,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.532905936397105,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -8.61578786388734,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -8.87366902843812,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "c",
                                                "logprob": -9.08143556133607,
                                                "bytes": [
                                                    99
                                                ]
                                            },
                                            {
                                                "token": "F",
                                                "logprob": -9.08820760265687,
                                                "bytes": [
                                                    70
                                                ]
                                            },
                                            {
                                                "token": "S",
                                                "logprob": -9.230013251460582,
                                                "bytes": [
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.260249495662242,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.459522605098277,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -9.559555411494761,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.723106742061168,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.834923148311168,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.034271598018199,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "None",
                                                "logprob": -10.182736754573375,
                                                "bytes": [
                                                    78,
                                                    111,
                                                    110,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "d",
                                                "logprob": -10.204550147212535,
                                                "bytes": [
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.208372473872691,
                                                "bytes": [
                                                    84
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.43083969850974463,
                                            "support": 4,
                                            "entropy": 1.0737985516256092,
                                            "selection_ms": 0.11286,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 4,
                                                    "entropy": 1.0737985516256092
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 4,
                                                    "entropy": 1.0737985516256092
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 34,
                                                    "probability": 0.43566561356083955,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.43083969850974463,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.09496388254090679,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 35,
                                                    "probability": 0.03853080538850901,
                                                    "bytes": [
                                                        68
                                                    ],
                                                    "token": "D"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 132,
                        "completion_tokens": 1,
                        "total_tokens": 133,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 132,
                        "prompt_ms": 862.3,
                        "prompt_per_token_ms": 6.533,
                        "prompt_per_second": 153.1,
                        "predicted_n": 1,
                        "predicted_ms": 23.6,
                        "predicted_per_token_ms": 23.6,
                        "predicted_per_second": 42.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1117.4796000123024,
                "captured_at": "2026-10-04T04:14:46Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Please note that parcel 17 weighs 4 kg.\nQUESTION: Are the original parcel number and weight preserved?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-7bff8fb4da3b48949957267c",
                    "object": "chat.completion",
                    "created": 1791087285,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.015083015955309116,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.015083015955309116,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -4.263354958093981,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.10498207906566,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -9.231488884485582,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -9.872809113062242,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.331578911341051,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.4063526997932,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.416157425440172,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.445827187097887,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.685777367151598,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -10.717902840174059,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.86242836812816,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -11.028910339868883,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.13094872335277,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -11.31920212606273,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -11.466657341516832,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.517028511560778,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -11.531322182215074,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -11.553193748987535,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -11.63615769246898,
                                                "bytes": [
                                                    98
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9859123918488581,
                                            "support": 2,
                                            "entropy": 0.07403577084768737,
                                            "selection_ms": 0.11302,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.07403577084768737
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.07403577084768737
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9859123918488581,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.014087608151141913,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 95,
                        "completion_tokens": 1,
                        "total_tokens": 96,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 95,
                        "prompt_ms": 756.7,
                        "prompt_per_token_ms": 7.965,
                        "prompt_per_second": 125.5,
                        "predicted_n": 1,
                        "predicted_ms": 25.9,
                        "predicted_per_token_ms": 25.9,
                        "predicted_per_second": 38.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 830.7466999976896,
                "captured_at": "2026-10-04T04:14:47Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Please note that parcel 17 weighs 4 kg.\nQUESTION: Does the edit explicitly use the polite word please?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-d6b5911b169040c0ba604c55",
                    "object": "chat.completion",
                    "created": 1791087286,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.016210248843368906,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.016210248843368906,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -4.274221113101182,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -8.04271476544493,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.136480024233993,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.219616582766708,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -9.416009595767196,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.539187124148544,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -9.56090610303038,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -9.611266782656845,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.645522764102157,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -9.914457013980087,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.040887525454696,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.263942411318954,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.393158605471786,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -10.439187696353134,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Please",
                                                "logprob": -10.489682844058212,
                                                "bytes": [
                                                    80,
                                                    108,
                                                    101,
                                                    97,
                                                    115,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -10.609414747134384,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.638034513369735,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.669604947940048,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.709204366580185,
                                                "bytes": [
                                                    69
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9860470190189092,
                                            "support": 2,
                                            "entropy": 0.07346318349098628,
                                            "selection_ms": 0.113241,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.07346318349098628
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.07346318349098628
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9860470190189092,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.013952980981090775,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 96,
                        "completion_tokens": 1,
                        "total_tokens": 97,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 96,
                        "prompt_ms": 772.2,
                        "prompt_per_token_ms": 8.044,
                        "prompt_per_second": 124.3,
                        "predicted_n": 1,
                        "predicted_ms": 25.7,
                        "predicted_per_token_ms": 25.7,
                        "predicted_per_second": 38.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 820.6672000233084,
                "captured_at": "2026-10-04T04:14:48Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nORIGINAL: Parcel 17 weighs 4 kg.\nEDIT: Please note that parcel 17 weighs 4 kg.\nQUESTION: Are the original parcel number and weight preserved AND is the polite word please used?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-1b64a6a5446f451c82d422c5",
                    "object": "chat.completion",
                    "created": 1791087287,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.03985392941737003,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.03985392941737003,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -3.2976607073714717,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.147863267796277,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -8.41805159940028,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -9.105913995640515,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.547705530064343,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.676216005223035,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.712508081333874,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -9.874776719944714,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.89382350339198,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.894556878941296,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -9.911092637913464,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Original",
                                                "logprob": -9.970728753941296,
                                                "bytes": [
                                                    79,
                                                    114,
                                                    105,
                                                    103,
                                                    105,
                                                    110,
                                                    97,
                                                    108
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.04266440762782,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -10.135392068760632,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.177926896946667,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.279756425755261,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -10.511670946018933,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.62502467526698,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -10.880802034275769,
                                                "bytes": [
                                                    91
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9629526271982507,
                                            "support": 2,
                                            "entropy": 0.15844424355350456,
                                            "selection_ms": 0.11239,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.15844424355350456
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.15844424355350456
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9629526271982507,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.03704737280174922,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 102,
                        "completion_tokens": 1,
                        "total_tokens": 103,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 102,
                        "prompt_ms": 778,
                        "prompt_per_token_ms": 7.627,
                        "prompt_per_second": 131.1,
                        "predicted_n": 1,
                        "predicted_ms": 24,
                        "predicted_per_token_ms": 24,
                        "predicted_per_second": 41.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 994.5153000298887,
                "captured_at": "2026-10-04T04:14:49Z"
            }
        ]
    },
    "wall_ms": 104.04569999082014,
    "lesson_view": {
        "index": 0,
        "value": 0.5,
        "scope": "Reproduce the selected question/rule/result panel. Other page dials are independent."
    }
}
import argparse
import copy
import hashlib
import json
import math
import os
import sys
from pathlib import Path
import urllib.error
import urllib.request

"""Small, portable calculations behind the question/rule/result panels.

Standard library only. This exact source is included in every Python download.
Inputs are the captured experiment, never an invented new model response. A knob
changes a disclosed calculation on those inputs; it does not rescore a new prompt.
"""
import itertools
import math
import statistics


def _spec(question, rule, knob, default, compare, low, high, integer=False):
    return dict(question=question, rule=rule, knob=knob, default=default,
                compare=compare, low=low, high=high, integer=integer)


LESSON_SPECS = {
    'choice': _spec('Which ticket queue gets this message?', 'Compare the three saved label scores. Heat flattens their relative weights; it adds no evidence.', 'Reweighting temperature', 1, 2, .1, 3),
    'boolean': _spec('Does this message ask to cancel?', 'Normalize the saved Yes and No scores. A number near one is a strong preference, not proof.', 'Reweighting temperature', 1, 2, .1, 3),
    'score': _spec('How serious is the outage?', 'Multiply each rubric value by its answer weight, then add. The rating comes from the whole distribution.', 'Reweighting temperature', 1, 2, .1, 3),
    'candidates': _spec('Read the failure first, or start changing things?', 'Add token logprobs along each saved path, then sum path mass inside each finite group. A length penalty changes the objective.', 'Length penalty exponent', 0, 1, 0, 1),
    'controller': _spec('May the simulated repair take its next step?', 'Keep only state-legal actions. Hold the recorded action if its relative legal weight falls below the threshold.', 'Required legal-action weight', 0, .999, 0, 1),
    'rerank': _spec('Which sources help explain cancellation?', 'Compute each source’s expected relevance separately, then keep those above the cutoff.', 'Minimum relevance', 0, .9, 0, 1),
    'graph': _spec('Which text links can coexist?', 'Search every small edge subset. Reject cycles and competing attachments, then maximize useful edge weight.', 'Edge cost / threshold', .5, .9, .01, .99),
    'scene': _spec('Which valid drawing best fits the instruction?', 'Average the three saved text probes. Optionally charge for disagreement between them; code still checks geometry.', 'Disagreement penalty', 0, 1, 0, 2),
    'wire': _spec('What did the model assign to this actual token?', 'Exponentiate its raw logprob. Sum only the reported alternatives; their top-N list may omit probability mass.', 'Visible token index (zero-based)', 0, 5, 0, 10000, True),
    'speculation': _spec('Why can a draft be rejected?', 'Compare the proposal head and target verification on the same proposed token. They are different distributions.', 'Proposal position (zero-based)', 0, 2, 0, 10000, True),
    'performance': _spec('What did each API path cost on this setup?', 'Recalculate a latency percentile from the original wall-time samples. Different output tasks remain separate.', 'Latency percentile', 50, 90, 0, 100),
    'samplers': _spec('How much did this recipe change the selected token’s weight?', 'Compare its raw target probability with its post-sampler probability. Read support and entropy from the complete native row.', 'Recorded recipe index (zero-based)', 0, 1, 0, 10000, True),
    'sampler-sandbox': _spec('Can we add heat without admitting implausible tokens?', 'Remove logits below max + log(0.05), then divide the survivors by temperature and normalize.', 'Temperature after Min-P', 1.5, .7, .1, 3),
    'tictactoe': _spec('Did a legal move give away a winnable outcome?', 'Solve the saved position by exhaustive minimax. Compare the best legal outcome with the recorded model move.', 'Recorded turn index (zero-based)', 0, 1, 0, 10000, True),
    'chess': _spec('Did the shortlist favor a mating move?', 'Add the saved label weights attached to code-checked mating moves. The separately generated UCI move uses a different prompt.', 'Shortlist temperature', 1, 3, .1, 3),
    'poker': _spec('Should this hand check or bet?', 'Average exact chip payoffs over the two possible opponent cards using the stated calling policy.', 'Opponent call-rate multiplier', 1, 0, 0, 2),
    'thermal': _spec('What happens if we replay the fan commands differently?', 'Step the disclosed thermal equation through the same loads. A fan offset is an open-loop counterfactual, not a new model policy.', 'Fan offset', 0, 20, -60, 60),
    'scheduler': _spec('How much lateness did this legal schedule cause?', 'Add job durations in the recorded order and check dependencies. Charge for finishing after the adjusted deadline.', 'Deadline shift', 0, -3, -10, 10),
    'context': _spec('Did replacing old text change the current-state answer?', 'Recalculate each saved Yes/No distribution and compare the selected wording with the original append-only prompt.', 'Context variant index (zero-based)', 0, 2, 0, 10000, True),
    'observer': _spec('Which action follows from these three semantic measurements?', 'Apply the same explicit threshold rule to every saved report: inspect, verify, finish, or ask.', 'Decision threshold', .5, .999, 0, 1),
    'calibration': _spec('Does demanding stronger answers leave enough coverage?', 'Recalculate Brier error on all six examples and accuracy only on retained examples. Empty coverage has no accuracy.', 'Required answer weight', .5, 1, .5, 1),
    'information': _spec('Which observation is worth buying?', 'Use the stated sensor likelihoods to compute both Bayesian posteriors and expected entropy reduction.', 'Test index (zero-based)', 0, 1, 0, 10000, True),
    'search': _spec('Which valid scene survives a cost penalty?', 'Subtract the chosen cost charge from each saved semantic weight. Reject invalid geometry before ranking.', 'Cost weight', .1, 1, 0, 1),
    'frontier': _spec('Would faster score transfer matter here?', 'Add assumed forward time, a transfer lower bound, and the measured selector. This is a serial cost sketch.', 'Assumed transfer GB/s', 12, 2, .1, 128),
    'research-map': _spec('What would make this research idea testable?', 'Count the disclosed implementation categories, then reveal one branch’s next gate. A proposal is not a native result.', 'Branch index (zero-based)', 0, 12, 0, 10000, True),
    'pressure': _spec('How much original mass did this boundary throw away?', 'At temperature 1 with pure masking, log Z = raw selected logprob − log(selected masked probability). Pressure is −log Z.', 'Native grammar index (zero-based)', 0, 1, 0, 10000, True),
    'circuit': _spec('Can we compute AND without assuming independence?', 'Start with four joint worlds. Optionally condition on noisy evidence of style, then add worlds for each logical operation.', 'Reliability of observing style', .5, 1, .5, 1),
    'control': _spec('Can preference change while forbidden actions stay forbidden?', 'Normalize log(base) + strength × [log(desired) − log(undesired)] inside the legal set.', 'Control strength', 0, 2, 0, 3),
    'future': _spec('Can a less likely first move have a better future?', 'Weight the root policy by exact future success raised to strength. At strength zero use the base policy.', 'Future-value strength', 0, 1, 0, 2),
    'sensitivity': _spec('Which prompt intervention moves this measurement?', 'Rebuild the central finite-difference matrix. Predict a change in hours, with load fixed at +5 points; preserve the measured holdout error.', 'Change in hours remaining', -1, -2, -2, 2),
    'counterexamples': _spec('Can equivalent algebra confuse the observer?', 'Find the equivalent pair with the largest measured log-odds distance. Evaluate its exact coefficients at the chosen integer.', 'Integer x', 2, -2, -10, 10, True),
}


def normalize_logs(logs):
    finite = [x for x in logs if math.isfinite(x)]
    if not finite:
        raise ValueError('No candidate has positive mass')
    maximum = max(finite)
    weights = [math.exp(x-maximum) if math.isfinite(x) else 0. for x in logs]
    total = math.fsum(weights)
    return [w/total for w in weights]


def weights(rows, temperature=1):
    if any(r.get('logprob') is None for r in rows):
        raise ValueError('A complete label measurement is required; missing top-N entries stay unknown')
    return normalize_logs([r['logprob']/temperature for r in rows])


def entropy(p):
    return -math.fsum(x*math.log2(x) for x in p if x)


def _pick(items, value):
    if not 0 <= value < len(items):
        raise ValueError('Index must be 0..'+str(len(items)-1))
    return items[int(value)]


def _rows(names, values):
    return [dict(label=str(n), value=float(v)) for n,v in zip(names,values)]


def _graph(edges, threshold):
    if len(edges)>12:
        raise ValueError('This exact demonstration supports at most 12 edges')
    best, score = [], 0.
    for bits in itertools.product((False,True), repeat=len(edges)):
        selected=[e for e,yes in zip(edges,bits) if yes]
        out, incoming, captions = {}, set(), set()
        good=True
        for e in selected:
            a,b=e['source'],e['target']
            if a==b:good=False;break
            if e['relation']=='caption':
                if a in captions:good=False;break
                captions.add(a)
            else:
                if a in out or b in incoming:good=False;break
                out[a]=b;incoming.add(b)
        for start in out:
            node,visited=start,set()
            while node in out:
                if node in visited:good=False;break
                visited.add(node);node=out[node]
        utility=math.fsum(e['weight']-threshold for e in selected)
        if good and utility>score:best,score=selected,utility
    return best,score


def _ttt(board, turn):
    lines=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
    for a,b,c in lines:
        if board[a]!='.' and board[a]==board[b]==board[c]:return 1 if board[a]=='X' else -1
    if '.' not in board:return 0
    values=[_ttt(board[:i]+turn+board[i+1:],'O' if turn=='X' else 'X') for i,s in enumerate(board) if s=='.']
    return (max if turn=='X' else min)(values)


def calculate_lesson(name, data, value=None):
    spec=LESSON_SPECS[name]
    v=spec['default'] if value is None else value
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not spec['low']<=v<=spec['high'] or (spec['integer'] and int(v)!=v):
        raise ValueError(f"{spec['knob']} must be {'an integer' if spec['integer'] else 'finite'} in [{spec['low']}, {spec['high']}]")
    rows=[];metrics={};note='Calculation on saved inputs; changing this setting makes no new model request.'
    summary='';unit='weight'
    if name in ('choice','boolean','score'):
        p=weights(data['rows'],v);at=max(range(len(p)),key=p.__getitem__)
        rows=_rows([r['label']+' · '+r.get('description','') for r in data['rows']],p)
        metrics=dict(winner=data['rows'][at]['label'],top_weight=p[at],entropy_bits=entropy(p))
        if name in ('boolean','score'):
            metrics['expected_value']=math.fsum(q*r['value'] for q,r in zip(p,data['rows']))
        summary=f"Answer {metrics['winner']} leads with {p[at]:.2%} of the listed-label weight."
        if name=='score':summary=f"Expected rubric value: {metrics['expected_value']:.4f} on the stated 0–1 scale."
    elif name=='candidates':
        paths=data['paths'];logs=[math.fsum(t['logprob'] for t in r['tokens'])/len(r['tokens'])**v for r in paths]
        p=normalize_logs(logs);names=list(dict.fromkeys(r['group'] for r in paths))
        values=[math.fsum(q for q,r in zip(p,paths) if r['group']==g) for g in names];rows=_rows(names,values)
        metrics=dict(winner=names[values.index(max(values))],group_weights=values)
        summary=metrics['winner']+' carries the most relative group weight.'
        note='Only these emitted token paths, with their saved terminators and no EOS. A nonzero length penalty produces preference scores, not path probability.'
    elif name=='controller':
        labels=data['measure']['rows'];p=weights(labels);legal=[i for i,r in enumerate(labels) if r['allowed']]
        mass=math.fsum(p[i] for i in legal);pick=next(i for i,r in enumerate(labels) if r['action']==data['action'])
        q=p[pick]/mass;held=q<v
        rows=_rows([labels[i]['action'] for i in legal],[p[i]/mass for i in legal])
        metrics=dict(held=held,selected_weight=q,next_state=data['state'] if held else data['next_state'])
        summary=('Hold the action.' if held else 'Apply '+data['action']+'.')+' State: '+metrics['next_state']+'.'
    elif name=='rerank':
        values=[math.fsum(q*r['value'] for q,r in zip(weights(s['measure']['rows']),s['measure']['rows'])) for s in data['sources']]
        rows=_rows([s['id'] for s in data['sources']],values);kept=[r['label'] for r in rows if r['value']>=v]
        metrics=dict(retained=kept,scores=values);summary='Retain '+(', '.join(kept) or 'no sources')+' at this cutoff.'
    elif name=='graph':
        selected,utility=_graph(data['edges'],v);rows=_rows([e['source']+' → '+e['target'] for e in selected],[e['weight']-v for e in selected]);unit='utility'
        metrics=dict(selected=[(e['source'],e['target'],e['relation']) for e in selected],utility=utility)
        summary=f'{len(selected)} compatible links, total utility {utility:.4f}.'
        note='Global code constraints select links; utility is not the probability that the document graph is correct.'
    elif name=='scene':
        valid=[c for c in data['candidates'] if c['valid']];values=[]
        for c in valid:
            p=[weights(x['measure']['rows'])[0] for x in c['vector']]
            values.append(statistics.mean(p)-v*statistics.pvariance(p))
        rows=_rows([c['name'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['name'],utilities=values)
        summary='Retain '+metrics['retained']+' among geometry-valid candidates.'
        note='These are saved text judgments. This calculation cannot see the drawing or measure visual appeal.'
    elif name=='wire':
        entry=_pick(data['entries'],v);p=math.exp(entry['logprob']);top=entry.get('top_logprobs',[])
        rows=_rows([x['token'] for x in top],[math.exp(x['logprob']) for x in top]);unit='raw probability'
        metrics=dict(token=entry['token'],raw_probability=p,reported_top_mass=math.fsum(r['value'] for r in rows))
        summary=f"Token {entry['token']!r}: raw probability {p:.6g}."
        note='This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary.'
    elif name=='speculation':
        window=data['oracle']['example_rejection'];r=_pick(window['proposal'],v)
        rows=_rows(['Draft head','Target verification'],[r['draft_probability'],math.exp(r['target_logprob'])]);unit='probability / distinct heads'
        metrics=dict(token_id=r['token_id'],target_sequence_logprob=math.fsum(x['target_logprob'] for x in window['proposal']),draft_target_logprob_gap=r['draft_logprob']-r['target_logprob'])
        summary=f"Proposal token {r['token_id']}: the two heads differ by {metrics['draft_target_logprob_gap']:.4f} log units."
        note='Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability.'
    elif name=='performance':
        values=[]
        for r in data['rows']:
            xs=sorted(x['wall_ms'] for x in r['runs']);a=(len(xs)-1)*v/100;lo=math.floor(a);hi=math.ceil(a)
            values.append(xs[lo]+(xs[hi]-xs[lo])*(a-lo))
        rows=_rows([r['name'] for r in data['rows']],values);unit='ms';metrics=dict(percentile=v,times_ms=values)
        summary=f'Percentile {v:g}, recalculated from {data["repeats"]} samples per path.'
        note='Small same-setup samples include network and API cost. JSON answers a different task; this is no universal speed ranking.'
    elif name=='samplers':
        run=_pick(data['runs'],v);token=run['tokens'][0];sample=token['strata_sampling']
        raw=math.exp(token['logprob']);post=sample['probability']
        rows=_rows(['Raw target','After recipe'],[raw,post]);unit='selected token probability'
        metrics=dict(recipe=run['name'],support=sample['support'],raw=raw,selected=post,log_weight_change=math.log(post)-token['logprob'],entropy_bits=sample['entropy']/math.log(2))
        summary=f"{run['name']}: {sample['support']} native tokens remain eligible."
        note='Recipes are separate generations. Entropy and support are full-row native measurements; a top-N slice cannot recover them.'
    elif name=='sampler-sandbox':
        cut=max(data['logits'])+math.log(.05);logs=[x/v if x>=cut else -math.inf for x in data['logits']];p=normalize_logs(logs)
        rows=_rows(data['tokens'],p);metrics=dict(support=sum(x>0 for x in p),entropy_bits=entropy(p),probabilities=p)
        summary=f"{metrics['support']} credible tokens survive; entropy {metrics['entropy_bits']:.3f} bits."
        note='All eight logits are synthetic and visible. This is exact finite-row arithmetic, not a new native receipt.'
    elif name=='tictactoe':
        f=_pick(data['frames'],v);b=f['before'];legal=[i for i,c in enumerate(b) if c=='.'];oracle={i:_ttt(b[:i]+'X'+b[i+1:],'O') for i in legal}
        regret=max(oracle.values())-oracle[f['square']];rows=_rows([str(i+1) for i in legal],list(oracle.values()));unit='X outcome: lose −1 / draw 0 / win 1'
        metrics=dict(regret=regret,square=f['square']+1,oracle=oracle);summary=f"Recorded move: square {f['square']+1}; exact outcome regret {regret}."
    elif name=='chess':
        p=weights(data['measure']['rows'],v);mass=math.fsum(q for q,m in zip(p,data['shortlist']) if m['mate'])
        rows=_rows([m['san'] for m in data['shortlist']],p);metrics=dict(mating_shortlist_weight=mass,generated_uci=data['chosen']['text'],generated_mate=data['mate'])
        summary=f'{mass:.2%} of shortlist weight favors mate; the separate UCI generation '+('mated.' if data['mate'] else 'did not mate.')
        note='The saved legal/mate flags came from python-chess. This portable calculation aggregates them; it is not a replacement chess engine.'
    elif name=='poker':
        ranks=['J','Q','K'];rates={c:min(1,max(0,r*v)) for c,r in data['call_rates'].items()};values={}
        for own in ranks:
            opponents=[c for c in ranks if c!=own];sign=lambda c:1 if ranks.index(own)>ranks.index(c) else -1
            values[own]=dict(check=statistics.mean(sign(c) for c in opponents),bet=statistics.mean((1-rates[c])+rates[c]*2*sign(c) for c in opponents))
        rows=_rows([c+' bet − check' for c in ranks],[values[c]['bet']-values[c]['check'] for c in ranks]);unit='expected chips'
        metrics=dict(values=values,call_rates=rates);summary='Bet when the bar is positive; check when it is negative.'
        note='Uniform remaining-card prior and explicitly assumed opponent policy. Answer weights are not hidden-card beliefs or equilibrium probabilities.'
    elif name=='thermal':
        t=data['frames'][0]['temperature'];temperatures=[]
        for f in data['frames']:
            fan=min(60,max(0,f['fan']+v));t=round(t+.22*f['load']-.32*fan-.04*(t-25),3);temperatures.append(t)
        rows=_rows(range(1,len(temperatures)+1),temperatures);unit='°C';metrics=dict(temperatures=temperatures,mean_error=statistics.mean(abs(t-data['target']) for t in temperatures),violations=sum(t>data['limit'] for t in temperatures))
        summary=f"Mean distance from target: {metrics['mean_error']:.2f}°C; {metrics['violations']} limit violations."
        note='Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control.'
    elif name=='scheduler':
        done=set();clock=0;late=[]
        for f in data['frames']:
            j=f['job']
            if not set(j['after'])<=done:raise ValueError('Saved schedule violates dependencies')
            clock+=j['duration'];late.append(max(0,clock-j['deadline']-v));done.add(j['id'])
        rows=_rows([f['job']['id'] for f in data['frames']],late);unit='late time units';metrics=dict(total_lateness=sum(late),finish_time=clock)
        summary=f'Total lateness {sum(late):g}; the same dependency-valid order ends at time {clock}.'
    elif name=='context':
        selected=_pick(data['runs'],v);all_weights=[weights(r['measure']['rows'])[1] for r in data['runs']];p=all_weights[int(v)]
        rows=_rows([r['name'] for r in data['runs']],all_weights);metrics=dict(variant=selected['name'],no_weight=p,delta_from_append=p-all_weights[0])
        summary=f"{selected['name']}: keep-still answer weight {p:.3%}."
        note='Saved prompt interventions, not KV tensor mutation. This calculation compares their recorded measurements.'
    elif name=='observer':
        actions=[];triples=[]
        for f in data['frames']:
            p=[weights(x['measure']['rows'])[0] for x in f['vector']];triples.append(p)
            actions.append('inspect failure' if p[0]>v else 'verify' if p[1]>v else 'finish' if p[2]>v else 'ask')
        rows=_rows(['Fault','Missing check','Verified'],triples[0]);metrics=dict(actions=actions,vectors=triples)
        summary=' → '.join(actions)+'.';note='Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability.'
    elif name=='calibration':
        p=[weights(r['measure']['rows'])[0] for r in data['rows']];truth=[r['truth'] for r in data['rows']];kept=[i for i,q in enumerate(p) if max(q,1-q)>=v]
        brier=statistics.mean((q-y)**2 for q,y in zip(p,truth));accuracy=statistics.mean(int(p[i]>=.5)==truth[i] for i in kept) if kept else None
        rows=_rows([str(i+1) for i in range(len(p))],p);metrics=dict(brier=brier,retained=len(kept),coverage=len(kept)/len(p),accuracy=accuracy)
        summary=f'{len(kept)}/{len(p)} retained; '+(f'{accuracy:.1%} correct in those cases.' if accuracy is not None else 'accuracy is undefined with zero coverage.')
        note='Six disclosed teaching examples, not a held-out calibration benchmark. Brier error still counts every example.'
    elif name=='information':
        t=_pick(data['tests'],v);prior=data['prior'];py=math.fsum(p*l for p,l in zip(prior,t['likelihood']));yes=[p*l/py for p,l in zip(prior,t['likelihood'])];no=[p*(1-l)/(1-py) for p,l in zip(prior,t['likelihood'])]
        gain=entropy(prior)-py*entropy(yes)-(1-py)*entropy(no);rows=_rows(data['faults'],yes)
        metrics=dict(test=t['name'],gain_bits=gain,gain_per_cost=gain/t['cost'],yes=yes,no=no)
        summary=t['name']+f': {gain:.3f} expected bits; {gain/t["cost"]:.3f} bits per cost unit.'
        note='Prior and likelihoods are stated synthetic sensor assumptions. Bars condition on a positive result; no test was actually purchased.'
    elif name=='search':
        valid=[c for c in data['candidates'] if c['valid']];values=[weights(c['measure']['rows'])[0]-v*c['cost']/3 for c in valid]
        rows=_rows([c['id'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['id'],utilities=values)
        summary='Retain '+metrics['retained']+' after charging for cost; invalid geometry is excluded.'
    elif name=='frontier':
        selector=sorted(r['selection_ms'] for r in data['measurements'])[len(data['measurements'])//2];transfer=data['vocabulary']*data['bytes_per_logit']/(v*1e6);total=60+transfer+selector
        rows=_rows(['Assumed forward','Transfer lower bound','Measured host selector'],[60,transfer,selector]);unit='ms'
        metrics=dict(transfer_ms=transfer,serial_ms=total,tokens_per_second=1000/total)
        summary=f'Serial estimate: {total:.3f} ms/token; {1000/total:.2f} tokens/s.'
        note='Forward time is assumed 60 ms. Selector uses the upper-middle measured sample to match the chart. Queue, prefill and network are excluded.'
    elif name=='research-map':
        branch=_pick(data['branches'],v);categories={}
        for b in data['branches']:categories[b['status']]=categories.get(b['status'],0)+1
        rows=_rows(list(categories),list(categories.values()));unit='branches';metrics=dict(branch=branch['name'],gate=branch['gate'],categories=categories)
        summary=branch['name']+': '+branch['gate'];note='This page recomputes an agenda inventory, not an experiment result. Each implemented branch links to its own evidence.'
    elif name=='pressure':
        case=_pick(data['cases'],v);r=case['rows'][0];token=r['token'];q=token['strata_sampling']['probability'];logz=token['logprob']-math.log(q)
        if logz>1e-6:raise ValueError('Pure-mask mass exceeds one')
        z=math.exp(min(0,logz));rows=_rows(['Survived','Removed'],[z,1-z]);unit='original probability mass'
        metrics=dict(grammar=case['name'],mass=z,pressure_nats=-logz,pressure_bits=-logz/math.log(2))
        summary=f"{case['name']}: {z:.4%} survives; pressure {-logz:.4f} nats."
        note='First actual prefix of this native grammar. Exact only for pure masking at temperature 1, not arbitrary sampler recipes or entire grammar languages.'
    elif name=='circuit':
        p=weights(data['cases'][0]['measurement']['rows']);weighted=[p[0]*(1-v),p[1]*(1-v),p[2]*v,p[3]*v];z=math.fsum(weighted);p=[x/z for x in weighted]
        f=p[1]+p[3];s=p[2]+p[3];rows=_rows(['Neither','Facts only','Style only','Both'],p)
        metrics=dict(F=f,S=s,AND=p[3],OR=1-p[0],F_given_S=p[3]/s if s else None,marginal_product=f*s)
        summary=f'Facts AND style: {p[3]:.2%}; multiplying the marginals would give {f*s:.2%}.'
        note='At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world.'
    elif name=='control':
        logs=[math.log(b)+v*(math.log(d)-math.log(u)) if i in data['allowed'] else -math.inf for i,(b,d,u) in enumerate(zip(data['base'],data['desired'],data['undesired']))];p=normalize_logs(logs)
        rows=_rows(list('ABCD'),p);pick=max(range(len(p)),key=p.__getitem__);metrics=dict(probabilities=p,selected=pick,forbidden_mass=math.fsum(p[i] for i in range(len(p)) if i not in data['allowed']))
        summary=f"Action {'ABCD'[pick]} leads; forbidden-action mass stays zero."
        note='Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook.'
    elif name=='future':
        root=weights(data['policy'][0]['rows']);child=weights(data['policy'][2]['rows']);h=[0,child[1]];p=normalize_logs([math.log(r)+(v*math.log(x) if x else -math.inf) if v else math.log(r) for r,x in zip(root,h)])
        rows=_rows(['A: dead end','B: viable route'],p);success=p[1]*child[1];metrics=dict(root_weights=p,exact_h=h,success_root_only=success,base_success=root[1]*child[1])
        summary=f'{p[1]:.2%} chooses B; leaving the next policy unchanged succeeds {success:.2%} of the time.'
        note='Only BB succeeds in this exact two-step toy. Conditioning both steps is different from steering only the root. No native future-value decoder is claimed.'
    elif name=='sensitivity':
        o=data['observations'];zs=[[math.log(p/(1-p)) for p in row['probabilities']] for row in o]
        matrix=[[(zs[2][i]-zs[1][i])/(2*data['epsilon'][0]),(zs[4][i]-zs[3][i])/(2*data['epsilon'][1])] for i in range(3)]
        delta=[r[0]*v+r[1]*5 for r in matrix];rows=_rows(['Urgency','Load','Damage'],delta);unit='predicted log-odds change'
        observed=[zs[6][i]-zs[0][i] for i in range(3)];held=[r[0]*-1+r[1]*5 for r in matrix]
        metrics=dict(matrix=matrix,predicted_delta=delta,holdout_residual=[a-b for a,b in zip(observed,held)])
        summary=f'Predicted urgency shift {delta[0]:+.3f}; the measured −1h/+5 holdout had error {metrics["holdout_residual"][0]:+.3f}.'
        note='The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses.'
    elif name=='counterexamples':
        nodes=data['nodes'];pairs=[]
        for i,a in enumerate(nodes):
            za=[math.log(p/(1-p)) for p in a['p_yes']]
            for j,b in enumerate(nodes[i+1:],i+1):
                if a['coefficients']!=b['coefficients']:continue
                zb=[math.log(p/(1-p)) for p in b['p_yes']];distance=math.sqrt(math.fsum((x-y)**2 for x,y in zip(za,zb)));pairs.append((distance,i,j))
        distance,i,j=max(pairs);a,b=nodes[i],nodes[j];evaluate=lambda c:sum(x*v**k for k,x in enumerate(c))
        rows=_rows([a['expression'],b['expression']],[a['p_yes'][1],b['p_yes'][1]])
        metrics=dict(left=a['expression'],right=b['expression'],margin_distance=distance,left_value=evaluate(a['coefficients']),right_value=evaluate(b['coefficients']))
        summary=f'Equal exact values at x={v:g}: {metrics["left_value"]:g}; observer distance {distance:.3f}.'
        note='Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe.'
    else:
        raise ValueError('No portable calculation for '+name)
    return dict(value=v,summary=summary,rows=rows,unit=unit,metrics=metrics,note=note)


def make_lesson(name, data):
    spec=LESSON_SPECS[name]
    try:
        first=calculate_lesson(name,data)
        compare=spec['compare']
        # An edited run can have fewer tokens/turns than the recorded default.
        lengths={'wire':len(data.get('entries',[])), 'samplers':len(data.get('runs',[])),
                 'tictactoe':len(data.get('frames',[])), 'context':len(data.get('runs',[])),
                 'information':len(data.get('tests',[])), 'research-map':len(data.get('branches',[])),
                 'pressure':len(data.get('cases',[]))}
        if name in lengths:compare=min(compare,lengths[name]-1)
        second=calculate_lesson(name,data,compare)
        context=data.get('prompt','').partition('STATE:\n')[2].partition('\nQUESTION:')[0]
        return dict(**spec,states=[first,second],input_excerpt=context[:320]+('…' if len(context)>320 else ''),scope='This panel and its Python calculation reproduce saved measurements. Other page controls are independent views.')
    except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:
        # A genuinely incomplete score or a tool-only wire response stays usable.
        # Do not turn an unavailable lesson into fabricated measurement data.
        return dict(**spec,states=[],unavailable=str(error),scope='This run has no complete inputs for this calculation. Inspect its exact request and result below.')



def mock_post(request, fixture):
    if request != fixture['request']:
        raise ValueError('No mock matches the edited request. Supply a new fixture or explicitly choose --live-url.')
    return copy.deepcopy(fixture['response'])


def live_post(base_url, request):
    if not base_url.startswith(('http://', 'https://')):
        raise ValueError('--live-url must be an http(s) Strata address')
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('STRATA_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['STRATA_API_KEY']
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    body = json.dumps(request, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base_url.rstrip('/')+'/v1/chat/completions', data=body, headers=headers)
    with opener.open(req, timeout=600) as response:
        wire = response.read().decode('utf-8')
    if request.get('stream'):
        events = [line[5:].strip() for line in wire.splitlines() if line.startswith('data:')]
        if not events or events[-1] != '[DONE]':
            raise ValueError('Stream closed without [DONE]')
        chunks = [json.loads(line) for line in events[:-1]]
        if any('error' in chunk for chunk in chunks):
            raise ValueError('Stream reported an error: '+repr(chunks))
        return {'sse_events': chunks, 'wire': wire}
    reply = json.loads(wire)
    if 'error' in reply:
        raise ValueError('Strata reported an error: '+repr(reply['error']))
    return reply


def summarize(response):
    if 'sse_events' in response:
        return str(len(response['sse_events']))+' SSE events; inspect the saved wire response'
    choice = (response.get('choices') or [{}])[0]
    message = choice.get('message', {})
    text = message.get('content') or json.dumps(message.get('tool_calls') or message, ensure_ascii=False)
    entries = (choice.get('logprobs') or {}).get('content') or []
    if entries:
        text += '\n  First visible token raw logprob: '+repr(entries[0]['logprob'])
        text += '\n  First visible token raw probability: '+format(math.exp(entries[0]['logprob']), '.7g')
    return text


def raw_tokens(response):
    if 'sse_events' in response:
        return [token for chunk in response['sse_events'] for choice in chunk.get('choices', [])
                for token in (choice.get('logprobs') or {}).get('content') or []]
    choices = response.get('choices') or []
    return ((choices[0].get('logprobs') or {}).get('content') or []) if choices else []


def print_raw_tokens(response):
    entries = raw_tokens(response)
    if not entries:
        print('No scored answer tokens returned; no raw probabilities are invented.')
    for i, token in enumerate(entries):
        lp = token['logprob']
        p = math.exp(lp)
        shown = format(p, '.9g') if p else 'underflows; use the finite logprob'
        print('  Token '+str(i)+': '+repr(token['token'])+' bytes='+repr(token['bytes'])+
              ' raw ln p='+repr(lp)+' raw p='+shown)
        sampling = token.get('strata_sampling')
        if sampling:
            print('    Final native selection weight q='+repr(sampling['probability'])+' (separate from raw p)')


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=int, default=1, help='1-based request index (default 1)')
    parser.add_argument('--all', action='store_true', help='Replay every mock in this captured run')
    parser.add_argument('--show', action='store_true', help='Print exact selected HTTP request JSON')
    parser.add_argument('--tokens', action='store_true', help='Print every original token raw logprob/probability and available native sampling weight')
    parser.add_argument('--lesson-only', action='store_true', help='Recalculate the captured question/rule/result panel without printing mocked calls')
    parser.add_argument('--value', type=float, help='Change the panel parameter within its documented bounds; offline calculation only')
    parser.add_argument('--live-url', help='Explicitly send ONE request to your compatible Strata server')
    parser.add_argument('--output', type=Path, help='Write responses and their provenance as JSON')
    args = parser.parse_args()
    if args.all and args.live_url:
        parser.error('--all is offline only; saved dependent requests are not a live adaptive controller')
    if args.live_url and (args.lesson_only or args.value is not None):
        parser.error('Lesson calculations use captured evidence. Do not mix --live-url with --lesson-only or --value.')
    calls = CAPTURED['receipt']['calls']
    print('Strata Control Lab / '+CAPTURED['experiment'])
    print('LIVE selected request' if args.live_url else 'OFFLINE MOCK / recorded responses, no inference or network')
    view = CAPTURED.get('score_view')
    if view:
        print('\nRAW LAYER: '+view['raw'])
        print('DERIVED VIEW: '+view['derived'])
        print('SCOPE: '+view['scope'])
    calculation=None
    if not args.live_url:
        spec=CAPTURED.get('lesson')
        if spec and spec.get('states'):
            knob=args.value if args.value is not None else (CAPTURED.get('lesson_view') or {}).get('value',spec['default'])
            try:calculation=calculate_lesson(CAPTURED['experiment'],CAPTURED['result'],knob)
            except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:parser.error(str(error))
            print('\nQUESTION: '+spec['question']+'\nRULE: '+spec['rule'])
            print(spec['knob']+' = '+str(knob)+f" (allowed {spec['low']}..{spec['high']})")
            print('RESULT: '+calculation['summary'])
            print('BOUNDARY: '+calculation['note'])
            print('Reproduces the selected question/rule/result panel; other page dials are independent.')
            print(json.dumps(calculation,ensure_ascii=True,indent=2))
        elif args.lesson_only or args.value is not None:
            parser.error('This captured run has no complete lesson inputs: '+str((spec or {}).get('unavailable','missing calculation')))
    if args.lesson_only:
        result=dict(mode='offline-calculation',calculation=calculation)
    elif not calls:
        if args.live_url:
            parser.error('This page has no HTTP requests: it is analytical or recorded diagnostic evidence')
        print('No HTTP request, GBNF or JSON output constraint was used by this page.')
        print('The included result is a calculation/diagnostic snapshot, not a new model answer.')
        result = dict(mode='offline-snapshot', result=CAPTURED['result'])
        print(json.dumps(result, ensure_ascii=True, indent=2))
    else:
        indexes = range(len(calls)) if args.all else [args.request-1]
        if any(i < 0 or i >= len(calls) for i in indexes):
            parser.error('Request index must be 1..'+str(len(calls)))
        results = []
        for i in indexes:
            fixture = calls[i]
            request = copy.deepcopy(fixture['request'])  # Edit here to try your own live request.
            if args.show:
                print(json.dumps(request, ensure_ascii=True, indent=2))
            response = live_post(args.live_url, request) if args.live_url else mock_post(request, fixture)
            print('Request '+str(i+1)+' / '+str(len(calls))+': '+summarize(response))
            if args.tokens:
                print_raw_tokens(response)
            results.append(dict(request=request, response=response,
                                provenance='live-request' if args.live_url else 'mocked-native-recording'))
        result = dict(mode='live' if args.live_url else 'offline-mock', calls=results)
        print('GBNF and JSON settings are in each request. Use --show to inspect them.')
        print('The saved page result is in CAPTURED["result"]; live responses do not recompute that snapshot.')
    if calculation is not None:result['calculation']=calculation
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
