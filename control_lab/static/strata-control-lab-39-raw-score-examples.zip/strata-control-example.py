# -*- coding: utf-8 -*-
"""Downloaded Strata example: Python 3 standard library; offline by default.

Windows: py strata-example.py
Ubuntu:  python3 strata-example.py
Show a request: python strata-example.py --request 1 --show
Replay all recorded calls: python strata-example.py --all
Recalculate the panel: python strata-example.py --lesson-only
Change its knob: python strata-example.py --lesson-only --value NUMBER
Try ONE request live: python strata-example.py --request 1 --live-url http://127.0.0.1:8080
An optional STRATA_API_KEY environment variable supplies authentication.

CAPTURED is inserted above this runner by the page. It contains this exact run,
with requests, GBNF/JSON settings, responses, streaming chunks and the page result.
Mock mode returns those responses; it performs no inference and opens no socket.
Live mode runs only a selected request. It does not execute tools or adapt a saved
multi-step trace to new answers. No captured API key or authorization header exists.
"""
CAPTURED = {
    "experiment": "control",
    "score_view": {
        "raw": "Each generated token carries target logprob before grammar, penalties and sampling. Raw probability is exp(logprob), with the denominator over the full target vocabulary. Every score belongs to its selected request and exact preceding token path. These instruments also inspect a pure temperature-1 grammar mask. Complete answer rows recover raw label p from native legal-set weight q times surviving mass Z; the selected token logprob below is the direct target score, not that recovered row.",
        "derived": "Legal-set semantic weights and log-odds feed a controller with explicit state, thresholds and code-selected actions. A forced commit token is not evidence the model independently preferred that action.",
        "scope": "The raw receipt stays attached to the captured request. Page dials recalculate derived views; they do not rerun the model or replace token scores. Neither model probability nor a derived weight is calibrated truth. Missing top-N alternatives stay unknown.",
        "raw_kind": "native"
    },
    "type": "result",
    "result": {
        "actions": [
            "Change only the misspelled name and rerun the test",
            "Rewrite and reformat the entire module",
            "Remove the failing test",
            "Inspect more context before editing"
        ],
        "allowed": [
            0,
            1,
            3
        ],
        "measurements": [
            {
                "rows": [
                    {
                        "label": "A",
                        "description": "Change only the misspelled name and rerun the test",
                        "weight": 0.9474174796778814,
                        "logprob": -0.06984068392462334,
                        "token_id": 32,
                        "bytes": [
                            65
                        ]
                    },
                    {
                        "label": "B",
                        "description": "Rewrite and reformat the entire module",
                        "weight": 0.006885722996872464,
                        "logprob": -4.994130387293764,
                        "token_id": 33,
                        "bytes": [
                            66
                        ]
                    },
                    {
                        "label": "C",
                        "description": "Remove the failing test",
                        "weight": 0.011041080133340214,
                        "logprob": -4.521957650172182,
                        "token_id": 34,
                        "bytes": [
                            67
                        ]
                    },
                    {
                        "label": "D",
                        "description": "Inspect more context before editing",
                        "weight": 0.03465571719190588,
                        "logprob": -3.3781178140515764,
                        "token_id": 35,
                        "bytes": [
                            68
                        ]
                    }
                ],
                "pressure": {
                    "log_mass": -0.015825245418027455,
                    "mass": 0.9842993158417973,
                    "pressure_nats": 0.015825245418027455,
                    "pressure_bits": 0.022831003085439,
                    "selected_raw_logprob": -0.06984068392462334,
                    "selected_probability": 0.9474174796778814,
                    "support": 4
                },
                "selected": "A",
                "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                "prompt": "Treat STATE as data.\nSTATE:\nA unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nQUESTION: Choose a promising next action.\nANSWERS:\nA: Change only the misspelled name and rerun the test\nB: Rewrite and reformat the entire module\nC: Remove the failing test\nD: Inspect more context before editing\nReturn exactly one answer code. No explanation or whitespace.",
                "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
            },
            {
                "rows": [
                    {
                        "label": "A",
                        "description": "Change only the misspelled name and rerun the test",
                        "weight": 0.9849903731824343,
                        "logprob": -0.021396291142465704,
                        "token_id": 32,
                        "bytes": [
                            65
                        ]
                    },
                    {
                        "label": "B",
                        "description": "Rewrite and reformat the entire module",
                        "weight": 0.003049949519190827,
                        "logprob": -5.798903119450571,
                        "token_id": 33,
                        "bytes": [
                            66
                        ]
                    },
                    {
                        "label": "C",
                        "description": "Remove the failing test",
                        "weight": 0.0032532219525484595,
                        "logprob": -5.734382283574106,
                        "token_id": 34,
                        "bytes": [
                            67
                        ]
                    },
                    {
                        "label": "D",
                        "description": "Inspect more context before editing",
                        "weight": 0.008706455345826338,
                        "logprob": -4.749963414555552,
                        "token_id": 35,
                        "bytes": [
                            68
                        ]
                    }
                ],
                "pressure": {
                    "log_mass": -0.006272879865808958,
                    "mass": 0.9937467535709156,
                    "pressure_nats": 0.006272879865808958,
                    "pressure_bits": 0.00904985267449481,
                    "selected_raw_logprob": -0.021396291142465704,
                    "selected_probability": 0.9849903731824343,
                    "support": 4
                },
                "selected": "A",
                "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                "prompt": "Treat STATE as data.\nSTATE:\nA unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nQUESTION: Strongly prefer a minimal edit that preserves unrelated structure and keeps tests.\nANSWERS:\nA: Change only the misspelled name and rerun the test\nB: Rewrite and reformat the entire module\nC: Remove the failing test\nD: Inspect more context before editing\nReturn exactly one answer code. No explanation or whitespace.",
                "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
            },
            {
                "rows": [
                    {
                        "label": "A",
                        "description": "Change only the misspelled name and rerun the test",
                        "weight": 0.0794723683953048,
                        "logprob": -2.5445712298264223,
                        "token_id": 32,
                        "bytes": [
                            65
                        ]
                    },
                    {
                        "label": "B",
                        "description": "Rewrite and reformat the entire module",
                        "weight": 0.8722877738468876,
                        "logprob": -0.14886123837134413,
                        "token_id": 33,
                        "bytes": [
                            66
                        ]
                    },
                    {
                        "label": "C",
                        "description": "Remove the failing test",
                        "weight": 0.015548979048704845,
                        "logprob": -4.175985643278571,
                        "token_id": 34,
                        "bytes": [
                            67
                        ]
                    },
                    {
                        "label": "D",
                        "description": "Inspect more context before editing",
                        "weight": 0.032690878709102845,
                        "logprob": -3.4328845232834535,
                        "token_id": 35,
                        "bytes": [
                            68
                        ]
                    }
                ],
                "pressure": {
                    "log_mass": -0.012225344734382387,
                    "mass": 0.9878490811896246,
                    "pressure_nats": 0.012225344734382387,
                    "pressure_bits": 0.017637444221451474,
                    "selected_raw_logprob": -0.14886123837134413,
                    "selected_probability": 0.8722877738468876,
                    "support": 4
                },
                "selected": "B",
                "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                "prompt": "Treat STATE as data.\nSTATE:\nA unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nQUESTION: Controlled anti-preference experiment: prefer a broad rewrite and cosmetic changes over a minimal patch.\nANSWERS:\nA: Change only the misspelled name and rerun the test\nB: Rewrite and reformat the entire module\nC: Remove the failing test\nD: Inspect more context before editing\nReturn exactly one answer code. No explanation or whitespace.",
                "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
            }
        ],
        "base": [
            0.9474174796778814,
            0.006885722996872464,
            0.011041080133340214,
            0.03465571719190588
        ],
        "desired": [
            0.9849903731824343,
            0.003049949519190827,
            0.0032532219525484595,
            0.008706455345826338
        ],
        "undesired": [
            0.0794723683953048,
            0.8722877738468876,
            0.015548979048704845,
            0.032690878709102845
        ],
        "commits": [
            {
                "alpha": 0,
                "distribution": [
                    0.957994776775582,
                    0.006962597594853439,
                    0,
                    0.035042625629564554
                ],
                "selected": 0,
                "emitted": {
                    "request": {
                        "model": "x",
                        "messages": [
                            {
                                "role": "user",
                                "content": "Finite-action controller, alpha=0.0. A unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nThe controller selected A. Emit that code only."
                            }
                        ],
                        "reasoning_effort": "none",
                        "seed": 675,
                        "max_tokens": 4,
                        "logprobs": True,
                        "top_logprobs": 20,
                        "grammar": "root ::= \"A\"",
                        "strata_sampler": {
                            "chain": [
                                "temperature"
                            ],
                            "temperature": 1,
                            "inspect": True
                        }
                    },
                    "output": {
                        "text": "A",
                        "tokens": [
                            {
                                "token": "A",
                                "logprob": -4.3174793615541445,
                                "bytes": [
                                    65
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "```",
                                        "logprob": -0.3914272680482852,
                                        "bytes": [
                                            96,
                                            96,
                                            96
                                        ]
                                    },
                                    {
                                        "token": "I",
                                        "logprob": -2.481740225811957,
                                        "bytes": [
                                            73
                                        ]
                                    },
                                    {
                                        "token": "The",
                                        "logprob": -2.959290732403754,
                                        "bytes": [
                                            84,
                                            104,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "Looking",
                                        "logprob": -3.115336646100043,
                                        "bytes": [
                                            76,
                                            111,
                                            111,
                                            107,
                                            105,
                                            110,
                                            103
                                        ]
                                    },
                                    {
                                        "token": "Selected",
                                        "logprob": -3.237883795758246,
                                        "bytes": [
                                            83,
                                            101,
                                            108,
                                            101,
                                            99,
                                            116,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -4.3174793615541445,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "**",
                                        "logprob": -4.921477545758246,
                                        "bytes": [
                                            42,
                                            42
                                        ]
                                    },
                                    {
                                        "token": "Based",
                                        "logprob": -5.415953864117621,
                                        "bytes": [
                                            66,
                                            97,
                                            115,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "Option",
                                        "logprob": -5.614836920758246,
                                        "bytes": [
                                            79,
                                            112,
                                            116,
                                            105,
                                            111,
                                            110
                                        ]
                                    },
                                    {
                                        "token": "Choosing",
                                        "logprob": -5.644540061017035,
                                        "bytes": [
                                            67,
                                            104,
                                            111,
                                            111,
                                            115,
                                            105,
                                            110,
                                            103
                                        ]
                                    },
                                    {
                                        "token": "<",
                                        "logprob": -5.684245337506293,
                                        "bytes": [
                                            60
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -5.841691245099066,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "Choice",
                                        "logprob": -6.057410468121527,
                                        "bytes": [
                                            67,
                                            104,
                                            111,
                                            105,
                                            99,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "SELECT",
                                        "logprob": -6.093661536236762,
                                        "bytes": [
                                            83,
                                            69,
                                            76,
                                            69,
                                            67,
                                            84
                                        ]
                                    },
                                    {
                                        "token": "Select",
                                        "logprob": -6.10771869566059,
                                        "bytes": [
                                            83,
                                            101,
                                            108,
                                            101,
                                            99,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "Since",
                                        "logprob": -6.224530447979926,
                                        "bytes": [
                                            83,
                                            105,
                                            110,
                                            99,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "`",
                                        "logprob": -6.231388319989203,
                                        "bytes": [
                                            96
                                        ]
                                    },
                                    {
                                        "token": "Prop",
                                        "logprob": -6.23482822324848,
                                        "bytes": [
                                            80,
                                            114,
                                            111,
                                            112
                                        ]
                                    },
                                    {
                                        "token": "##",
                                        "logprob": -6.480000723858832,
                                        "bytes": [
                                            35,
                                            35
                                        ]
                                    },
                                    {
                                        "token": "<tool_call>",
                                        "logprob": -6.5471336736879335,
                                        "bytes": None
                                    }
                                ],
                                "strata_sampling": {
                                    "index": 0,
                                    "id": 32,
                                    "probability": 1,
                                    "support": 1,
                                    "entropy": 0,
                                    "selection_ms": 0.138758,
                                    "stages": [
                                        {
                                            "operator": "grammar",
                                            "support": 1,
                                            "entropy": 0
                                        },
                                        {
                                            "operator": "temperature",
                                            "support": 1,
                                            "entropy": 0
                                        }
                                    ],
                                    "top": [
                                        {
                                            "id": 32,
                                            "probability": 1,
                                            "bytes": [
                                                65
                                            ],
                                            "token": "A"
                                        }
                                    ]
                                }
                            }
                        ],
                        "token_count": 1,
                        "logprob": -4.3174793615541445,
                        "path_probability": 0.013333450026939529,
                        "mean_logprob": -4.3174793615541445,
                        "finish_reason": "stop"
                    },
                    "owner": "The lab selected the action; native GBNF enforces its exact emitted code."
                }
            },
            {
                "alpha": 1,
                "distribution": [
                    0.9992125523005273,
                    0.0000020487221901628253,
                    0,
                    0.000785398977282702
                ],
                "selected": 0,
                "emitted": {
                    "request": {
                        "model": "x",
                        "messages": [
                            {
                                "role": "user",
                                "content": "Finite-action controller, alpha=1.0. A unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nThe controller selected A. Emit that code only."
                            }
                        ],
                        "reasoning_effort": "none",
                        "seed": 675,
                        "max_tokens": 4,
                        "logprobs": True,
                        "top_logprobs": 20,
                        "grammar": "root ::= \"A\"",
                        "strata_sampler": {
                            "chain": [
                                "temperature"
                            ],
                            "temperature": 1,
                            "inspect": True
                        }
                    },
                    "output": {
                        "text": "A",
                        "tokens": [
                            {
                                "token": "A",
                                "logprob": -3.435758086883272,
                                "bytes": [
                                    65
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "```",
                                        "logprob": -0.36628100558444376,
                                        "bytes": [
                                            96,
                                            96,
                                            96
                                        ]
                                    },
                                    {
                                        "token": "I",
                                        "logprob": -2.417478057586397,
                                        "bytes": [
                                            73
                                        ]
                                    },
                                    {
                                        "token": "The",
                                        "logprob": -2.867461654388155,
                                        "bytes": [
                                            84,
                                            104,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -3.435758086883272,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "Selected",
                                        "logprob": -3.7422938077084673,
                                        "bytes": [
                                            83,
                                            101,
                                            108,
                                            101,
                                            99,
                                            116,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "Looking",
                                        "logprob": -4.591089698516573,
                                        "bytes": [
                                            76,
                                            111,
                                            111,
                                            107,
                                            105,
                                            110,
                                            103
                                        ]
                                    },
                                    {
                                        "token": "Based",
                                        "logprob": -4.815434905730928,
                                        "bytes": [
                                            66,
                                            97,
                                            115,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "**",
                                        "logprob": -5.259200545989717,
                                        "bytes": [
                                            42,
                                            42
                                        ]
                                    },
                                    {
                                        "token": "`",
                                        "logprob": -5.405437919341768,
                                        "bytes": [
                                            96
                                        ]
                                    },
                                    {
                                        "token": "SELECT",
                                        "logprob": -5.533030959808077,
                                        "bytes": [
                                            83,
                                            69,
                                            76,
                                            69,
                                            67,
                                            84
                                        ]
                                    },
                                    {
                                        "token": "To",
                                        "logprob": -5.576741668426241,
                                        "bytes": [
                                            84,
                                            111
                                        ]
                                    },
                                    {
                                        "token": "\"",
                                        "logprob": -5.8242668835751665,
                                        "bytes": [
                                            34
                                        ]
                                    },
                                    {
                                        "token": "Choosing",
                                        "logprob": -6.01208445712253,
                                        "bytes": [
                                            67,
                                            104,
                                            111,
                                            111,
                                            115,
                                            105,
                                            110,
                                            103
                                        ]
                                    },
                                    {
                                        "token": "selected",
                                        "logprob": -6.2906927792660845,
                                        "bytes": [
                                            115,
                                            101,
                                            108,
                                            101,
                                            99,
                                            116,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "<",
                                        "logprob": -6.418945762359346,
                                        "bytes": [
                                            60
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -6.535281631194795,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "Since",
                                        "logprob": -6.568378898345674,
                                        "bytes": [
                                            83,
                                            105,
                                            110,
                                            99,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "Under",
                                        "logprob": -6.6056694714657915,
                                        "bytes": [
                                            85,
                                            110,
                                            100,
                                            101,
                                            114
                                        ]
                                    },
                                    {
                                        "token": "<tool_call>",
                                        "logprob": -6.718596908294405,
                                        "bytes": None
                                    },
                                    {
                                        "token": "Choice",
                                        "logprob": -6.736027213775362,
                                        "bytes": [
                                            67,
                                            104,
                                            111,
                                            105,
                                            99,
                                            101
                                        ]
                                    }
                                ],
                                "strata_sampling": {
                                    "index": 0,
                                    "id": 32,
                                    "probability": 1,
                                    "support": 1,
                                    "entropy": 0,
                                    "selection_ms": 0.111297,
                                    "stages": [
                                        {
                                            "operator": "grammar",
                                            "support": 1,
                                            "entropy": 0
                                        },
                                        {
                                            "operator": "temperature",
                                            "support": 1,
                                            "entropy": 0
                                        }
                                    ],
                                    "top": [
                                        {
                                            "id": 32,
                                            "probability": 1,
                                            "bytes": [
                                                65
                                            ],
                                            "token": "A"
                                        }
                                    ]
                                }
                            }
                        ],
                        "token_count": 1,
                        "logprob": -3.435758086883272,
                        "path_probability": 0.03220098982867514,
                        "mean_logprob": -3.435758086883272,
                        "finish_reason": "stop"
                    },
                    "owner": "The lab selected the action; native GBNF enforces its exact emitted code."
                }
            },
            {
                "alpha": 2,
                "distribution": [
                    0.9999831096386839,
                    5.78408798505251e-10,
                    0,
                    0.000016889782907495236
                ],
                "selected": 0,
                "emitted": {
                    "request": {
                        "model": "x",
                        "messages": [
                            {
                                "role": "user",
                                "content": "Finite-action controller, alpha=2.0. A unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nThe controller selected A. Emit that code only."
                            }
                        ],
                        "reasoning_effort": "none",
                        "seed": 675,
                        "max_tokens": 4,
                        "logprobs": True,
                        "top_logprobs": 20,
                        "grammar": "root ::= \"A\"",
                        "strata_sampler": {
                            "chain": [
                                "temperature"
                            ],
                            "temperature": 1,
                            "inspect": True
                        }
                    },
                    "output": {
                        "text": "A",
                        "tokens": [
                            {
                                "token": "A",
                                "logprob": -3.345767471874275,
                                "bytes": [
                                    65
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "```",
                                        "logprob": -0.761540863597908,
                                        "bytes": [
                                            96,
                                            96,
                                            96
                                        ]
                                    },
                                    {
                                        "token": "I",
                                        "logprob": -1.7382292486076736,
                                        "bytes": [
                                            73
                                        ]
                                    },
                                    {
                                        "token": "Selected",
                                        "logprob": -2.7681956029777908,
                                        "bytes": [
                                            83,
                                            101,
                                            108,
                                            101,
                                            99,
                                            116,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "The",
                                        "logprob": -2.905269119823494,
                                        "bytes": [
                                            84,
                                            104,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "Based",
                                        "logprob": -3.0576796270256423,
                                        "bytes": [
                                            66,
                                            97,
                                            115,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -3.345767471874275,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "Looking",
                                        "logprob": -4.180845711315193,
                                        "bytes": [
                                            76,
                                            111,
                                            111,
                                            107,
                                            105,
                                            110,
                                            103
                                        ]
                                    },
                                    {
                                        "token": "**",
                                        "logprob": -4.32664630183033,
                                        "bytes": [
                                            42,
                                            42
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -5.199843857372322,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "SELECT",
                                        "logprob": -5.2447104192619705,
                                        "bytes": [
                                            83,
                                            69,
                                            76,
                                            69,
                                            67,
                                            84
                                        ]
                                    },
                                    {
                                        "token": "<tool_call>",
                                        "logprob": -5.261014435375252,
                                        "bytes": None
                                    },
                                    {
                                        "token": "Option",
                                        "logprob": -5.5058893895988845,
                                        "bytes": [
                                            79,
                                            112,
                                            116,
                                            105,
                                            111,
                                            110
                                        ]
                                    },
                                    {
                                        "token": "selected",
                                        "logprob": -5.511836502635994,
                                        "bytes": [
                                            115,
                                            101,
                                            108,
                                            101,
                                            99,
                                            116,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "Action",
                                        "logprob": -5.521176788890877,
                                        "bytes": [
                                            65,
                                            99,
                                            116,
                                            105,
                                            111,
                                            110
                                        ]
                                    },
                                    {
                                        "token": "\"",
                                        "logprob": -5.550067398632088,
                                        "bytes": [
                                            34
                                        ]
                                    },
                                    {
                                        "token": "Choice",
                                        "logprob": -5.651694748485603,
                                        "bytes": [
                                            67,
                                            104,
                                            111,
                                            105,
                                            99,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "`",
                                        "logprob": -5.799909088695564,
                                        "bytes": [
                                            96
                                        ]
                                    },
                                    {
                                        "token": "Here",
                                        "logprob": -6.071988556469002,
                                        "bytes": [
                                            72,
                                            101,
                                            114,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "<",
                                        "logprob": -6.231146309459724,
                                        "bytes": [
                                            60
                                        ]
                                    },
                                    {
                                        "token": "To",
                                        "logprob": -6.241500351512947,
                                        "bytes": [
                                            84,
                                            111
                                        ]
                                    }
                                ],
                                "strata_sampling": {
                                    "index": 0,
                                    "id": 32,
                                    "probability": 1,
                                    "support": 1,
                                    "entropy": 0,
                                    "selection_ms": 0.11309,
                                    "stages": [
                                        {
                                            "operator": "grammar",
                                            "support": 1,
                                            "entropy": 0
                                        },
                                        {
                                            "operator": "temperature",
                                            "support": 1,
                                            "entropy": 0
                                        }
                                    ],
                                    "top": [
                                        {
                                            "id": 32,
                                            "probability": 1,
                                            "bytes": [
                                                65
                                            ],
                                            "token": "A"
                                        }
                                    ]
                                }
                            }
                        ],
                        "token_count": 1,
                        "logprob": -3.345767471874275,
                        "path_probability": 0.03523316431590763,
                        "mean_logprob": -3.345767471874275,
                        "finish_reason": "stop"
                    },
                    "owner": "The lab selected the action; native GBNF enforces its exact emitted code."
                }
            }
        ],
        "hypothetical": {
            "base": [
                0.2,
                0.55,
                0.05,
                0.2
            ],
            "desired": [
                0.65,
                0.2,
                0.01,
                0.14
            ],
            "undesired": [
                0.05,
                0.75,
                0.15,
                0.05
            ]
        },
        "semantics": "Native rows measure preferences. The lab owns the finite-action combination and choice; native GBNF enforces its emitted code. Alpha controls in the browser recompute that arithmetic. Only the recorded alpha=0,1,2 commitments were sent to the model."
    },
    "lesson": {
        "question": "Can preference change while forbidden actions stay forbidden?",
        "rule": "Normalize log(base) + strength × [log(desired) − log(undesired)] inside the legal set.",
        "knob": "Control strength",
        "default": 0,
        "compare": 2,
        "low": 0,
        "high": 3,
        "integer": False,
        "states": [
            {
                "value": 0,
                "summary": "Action A leads; forbidden-action mass stays zero.",
                "rows": [
                    {
                        "label": "A",
                        "value": 0.957994776775582
                    },
                    {
                        "label": "B",
                        "value": 0.0069625975948534435
                    },
                    {
                        "label": "C",
                        "value": 0
                    },
                    {
                        "label": "D",
                        "value": 0.03504262562956456
                    }
                ],
                "unit": "weight",
                "metrics": {
                    "probabilities": [
                        0.957994776775582,
                        0.0069625975948534435,
                        0,
                        0.03504262562956456
                    ],
                    "selected": 0,
                    "forbidden_mass": 0
                },
                "note": "Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook."
            },
            {
                "value": 2,
                "summary": "Action A leads; forbidden-action mass stays zero.",
                "rows": [
                    {
                        "label": "A",
                        "value": 0.9999831096386838
                    },
                    {
                        "label": "B",
                        "value": 5.784087985052494e-10
                    },
                    {
                        "label": "C",
                        "value": 0
                    },
                    {
                        "label": "D",
                        "value": 0.00001688978290749525
                    }
                ],
                "unit": "weight",
                "metrics": {
                    "probabilities": [
                        0.9999831096386838,
                        5.784087985052494e-10,
                        0,
                        0.00001688978290749525
                    ],
                    "selected": 0,
                    "forbidden_mass": 0
                },
                "note": "Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook."
            }
        ],
        "input_excerpt": "",
        "scope": "This panel and its Python calculation reproduce saved measurements. Other page controls are independent views."
    },
    "receipt": {
        "mode": "recorded",
        "requests": 6,
        "summed_request_ms": 6871.0757999215275,
        "prompt_tokens": 536,
        "completion_tokens": 9,
        "calls": [
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nA unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nQUESTION: Choose a promising next action.\nANSWERS:\nA: Change only the misspelled name and rerun the test\nB: Rewrite and reformat the entire module\nC: Remove the failing test\nD: Inspect more context before editing\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-2567844698a24ccbbbed58b4",
                    "object": "chat.completion",
                    "created": 1791087467,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.06984068392462334,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.06984068392462334,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -3.3781178140515764,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -4.521957650172182,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -4.994130387293764,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -5.540082230555483,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.392466797816225,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -7.143222107874819,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -7.426805748927065,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.472007050501772,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -7.947233452784487,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "d",
                                                "logprob": -8.207350029932924,
                                                "bytes": [
                                                    100
                                                ]
                                            },
                                            {
                                                "token": " D",
                                                "logprob": -8.25990225313849,
                                                "bytes": [
                                                    32,
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.34114290713019,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -8.395909562098451,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "AAA",
                                                "logprob": -8.428693070399232,
                                                "bytes": [
                                                    65,
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -8.609232201563783,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -8.700852646815248,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Option",
                                                "logprob": -8.814903511988588,
                                                "bytes": [
                                                    79,
                                                    112,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -8.857156052576967,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "DDD",
                                                "logprob": -8.918883576380678,
                                                "bytes": [
                                                    68,
                                                    68,
                                                    68
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9474174796778814,
                                            "support": 4,
                                            "entropy": 0.2517296301618196,
                                            "selection_ms": 0.126626,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 4,
                                                    "entropy": 0.2517296301618196
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 4,
                                                    "entropy": 0.2517296301618196
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9474174796778814,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 35,
                                                    "probability": 0.03465571719190588,
                                                    "bytes": [
                                                        68
                                                    ],
                                                    "token": "D"
                                                },
                                                {
                                                    "id": 34,
                                                    "probability": 0.011041080133340214,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.006885722996872464,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 114,
                        "completion_tokens": 1,
                        "total_tokens": 115,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 114,
                        "prompt_ms": 716.6,
                        "prompt_per_token_ms": 6.286,
                        "prompt_per_second": 159.1,
                        "predicted_n": 1,
                        "predicted_ms": 24.1,
                        "predicted_per_token_ms": 24.1,
                        "predicted_per_second": 41.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 982.0195999927819,
                "captured_at": "2026-10-04T04:17:49Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nA unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nQUESTION: Strongly prefer a minimal edit that preserves unrelated structure and keeps tests.\nANSWERS:\nA: Change only the misspelled name and rerun the test\nB: Rewrite and reformat the entire module\nC: Remove the failing test\nD: Inspect more context before editing\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-bbdea90bf8a14655b27690d9",
                    "object": "chat.completion",
                    "created": 1791087468,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.021396291142465704,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.021396291142465704,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -4.749963414555552,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -5.7343822835741065,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -5.798903119450571,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.306984555607798,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.712875020390513,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -7.921945226078989,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.244383466130259,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -8.35926975000477,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -8.501199376469614,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -8.666905057316782,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Change",
                                                "logprob": -8.763095509892466,
                                                "bytes": [
                                                    67,
                                                    104,
                                                    97,
                                                    110,
                                                    103,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.021144521122935,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Just",
                                                "logprob": -9.024939191227915,
                                                "bytes": [
                                                    74,
                                                    117,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Return",
                                                "logprob": -9.161178243046763,
                                                "bytes": [
                                                    82,
                                                    101,
                                                    116,
                                                    117,
                                                    114,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -9.161942136174204,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Option",
                                                "logprob": -9.23044837701893,
                                                "bytes": [
                                                    79,
                                                    112,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -9.300795209294321,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "An",
                                                "logprob": -9.452930104619028,
                                                "bytes": [
                                                    65,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -9.60935462701893,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9849903731824343,
                                            "support": 4,
                                            "entropy": 0.09249918540469576,
                                            "selection_ms": 0.117679,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 4,
                                                    "entropy": 0.09249918540469576
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 4,
                                                    "entropy": 0.09249918540469576
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9849903731824343,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 35,
                                                    "probability": 0.008706455345826338,
                                                    "bytes": [
                                                        68
                                                    ],
                                                    "token": "D"
                                                },
                                                {
                                                    "id": 34,
                                                    "probability": 0.0032532219525484595,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.003049949519190827,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 122,
                        "completion_tokens": 1,
                        "total_tokens": 123,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 122,
                        "prompt_ms": 697.9,
                        "prompt_per_token_ms": 5.72,
                        "prompt_per_second": 174.8,
                        "predicted_n": 1,
                        "predicted_ms": 25.2,
                        "predicted_per_token_ms": 25.2,
                        "predicted_per_second": 39.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 816.0431999713182,
                "captured_at": "2026-10-04T04:17:49Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nA unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nQUESTION: Controlled anti-preference experiment: prefer a broad rewrite and cosmetic changes over a minimal patch.\nANSWERS:\nA: Change only the misspelled name and rerun the test\nB: Rewrite and reformat the entire module\nC: Remove the failing test\nD: Inspect more context before editing\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-a800ae1a659f4c8591c029b6",
                    "object": "chat.completion",
                    "created": 1791087469,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.14886123837134413,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.14886123837134413,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.5445712298264223,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -3.4328845232834535,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -4.175985643278571,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.365782091032477,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -6.535969087492438,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "d",
                                                "logprob": -6.877199479948493,
                                                "bytes": [
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -7.18242103756568,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -7.337590524565192,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "c",
                                                "logprob": -8.022079774748297,
                                                "bytes": [
                                                    99
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -8.067168542753668,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -8.229555436979743,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -8.29207451046607,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " D",
                                                "logprob": -8.321905443083258,
                                                "bytes": [
                                                    32,
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.437146493803473,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.610181161772223,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.049116441618414,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.103647539030524,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -9.104205438505621,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "DD",
                                                "logprob": -9.131019899260016,
                                                "bytes": [
                                                    68,
                                                    68
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.8722877738468876,
                                            "support": 4,
                                            "entropy": 0.4970039205295539,
                                            "selection_ms": 0.111998,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 4,
                                                    "entropy": 0.4970039205295539
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 4,
                                                    "entropy": 0.4970039205295539
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.8722877738468876,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.0794723683953048,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 35,
                                                    "probability": 0.032690878709102845,
                                                    "bytes": [
                                                        68
                                                    ],
                                                    "token": "D"
                                                },
                                                {
                                                    "id": 34,
                                                    "probability": 0.015548979048704845,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 126,
                        "completion_tokens": 1,
                        "total_tokens": 127,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 126,
                        "prompt_ms": 703.9,
                        "prompt_per_token_ms": 5.587,
                        "prompt_per_second": 179,
                        "predicted_n": 1,
                        "predicted_ms": 22.7,
                        "predicted_per_token_ms": 22.7,
                        "predicted_per_second": 44.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 807.1272999513894,
                "captured_at": "2026-10-04T04:17:50Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Finite-action controller, alpha=0.0. A unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nThe controller selected A. Emit that code only."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-7c3ed4330d19440bb271fd2a",
                    "object": "chat.completion",
                    "created": 1791087470,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -4.3174793615541445,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "```",
                                                "logprob": -0.3914272680482852,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -2.481740225811957,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -2.959290732403754,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -3.115336646100043,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "Selected",
                                                "logprob": -3.237883795758246,
                                                "bytes": [
                                                    83,
                                                    101,
                                                    108,
                                                    101,
                                                    99,
                                                    116,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.3174793615541445,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -4.921477545758246,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -5.415953864117621,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Option",
                                                "logprob": -5.614836920758246,
                                                "bytes": [
                                                    79,
                                                    112,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "Choosing",
                                                "logprob": -5.644540061017035,
                                                "bytes": [
                                                    67,
                                                    104,
                                                    111,
                                                    111,
                                                    115,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -5.684245337506293,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.841691245099066,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Choice",
                                                "logprob": -6.057410468121527,
                                                "bytes": [
                                                    67,
                                                    104,
                                                    111,
                                                    105,
                                                    99,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "SELECT",
                                                "logprob": -6.093661536236762,
                                                "bytes": [
                                                    83,
                                                    69,
                                                    76,
                                                    69,
                                                    67,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Select",
                                                "logprob": -6.10771869566059,
                                                "bytes": [
                                                    83,
                                                    101,
                                                    108,
                                                    101,
                                                    99,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Since",
                                                "logprob": -6.224530447979926,
                                                "bytes": [
                                                    83,
                                                    105,
                                                    110,
                                                    99,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "`",
                                                "logprob": -6.231388319989203,
                                                "bytes": [
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "Prop",
                                                "logprob": -6.23482822324848,
                                                "bytes": [
                                                    80,
                                                    114,
                                                    111,
                                                    112
                                                ]
                                            },
                                            {
                                                "token": "##",
                                                "logprob": -6.480000723858832,
                                                "bytes": [
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "<tool_call>",
                                                "logprob": -6.5471336736879335,
                                                "bytes": None
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 1,
                                            "support": 1,
                                            "entropy": 0,
                                            "selection_ms": 0.138758,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 1,
                                                    "entropy": 0
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 1,
                                                    "entropy": 0
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 1,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 58,
                        "completion_tokens": 2,
                        "total_tokens": 60,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 58,
                        "prompt_ms": 1344.6,
                        "prompt_per_token_ms": 23.183,
                        "prompt_per_second": 43.1,
                        "predicted_n": 2,
                        "predicted_ms": 38.6,
                        "predicted_per_token_ms": 19.3,
                        "predicted_per_second": 51.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1444.707099988591,
                "captured_at": "2026-10-04T04:17:52Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Finite-action controller, alpha=1.0. A unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nThe controller selected A. Emit that code only."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-5fd85c228ca846f7801f442d",
                    "object": "chat.completion",
                    "created": 1791087471,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -3.435758086883272,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "```",
                                                "logprob": -0.36628100558444376,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -2.417478057586397,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -2.867461654388155,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.435758086883272,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Selected",
                                                "logprob": -3.7422938077084673,
                                                "bytes": [
                                                    83,
                                                    101,
                                                    108,
                                                    101,
                                                    99,
                                                    116,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -4.591089698516573,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -4.815434905730928,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.259200545989717,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "`",
                                                "logprob": -5.405437919341768,
                                                "bytes": [
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "SELECT",
                                                "logprob": -5.533030959808077,
                                                "bytes": [
                                                    83,
                                                    69,
                                                    76,
                                                    69,
                                                    67,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -5.576741668426241,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -5.8242668835751665,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "Choosing",
                                                "logprob": -6.01208445712253,
                                                "bytes": [
                                                    67,
                                                    104,
                                                    111,
                                                    111,
                                                    115,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "selected",
                                                "logprob": -6.2906927792660845,
                                                "bytes": [
                                                    115,
                                                    101,
                                                    108,
                                                    101,
                                                    99,
                                                    116,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -6.418945762359346,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.535281631194795,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Since",
                                                "logprob": -6.568378898345674,
                                                "bytes": [
                                                    83,
                                                    105,
                                                    110,
                                                    99,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Under",
                                                "logprob": -6.6056694714657915,
                                                "bytes": [
                                                    85,
                                                    110,
                                                    100,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "<tool_call>",
                                                "logprob": -6.718596908294405,
                                                "bytes": None
                                            },
                                            {
                                                "token": "Choice",
                                                "logprob": -6.736027213775362,
                                                "bytes": [
                                                    67,
                                                    104,
                                                    111,
                                                    105,
                                                    99,
                                                    101
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 1,
                                            "support": 1,
                                            "entropy": 0,
                                            "selection_ms": 0.111297,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 1,
                                                    "entropy": 0
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 1,
                                                    "entropy": 0
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 1,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 58,
                        "completion_tokens": 2,
                        "total_tokens": 60,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 58,
                        "prompt_ms": 1345.7,
                        "prompt_per_token_ms": 23.202,
                        "prompt_per_second": 43.1,
                        "predicted_n": 2,
                        "predicted_ms": 36,
                        "predicted_per_token_ms": 18,
                        "predicted_per_second": 55.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1408.3248000242747,
                "captured_at": "2026-10-04T04:17:53Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Finite-action controller, alpha=2.0. A unit test fails because a variable name was misspelled. The surrounding module otherwise works. Choose a next editing action.\nThe controller selected A. Emit that code only."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-2de4f22165404881b882d8bd",
                    "object": "chat.completion",
                    "created": 1791087473,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -3.345767471874275,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "```",
                                                "logprob": -0.761540863597908,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -1.7382292486076736,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Selected",
                                                "logprob": -2.7681956029777908,
                                                "bytes": [
                                                    83,
                                                    101,
                                                    108,
                                                    101,
                                                    99,
                                                    116,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -2.905269119823494,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -3.0576796270256423,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.345767471874275,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -4.180845711315193,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -4.32664630183033,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.199843857372322,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "SELECT",
                                                "logprob": -5.2447104192619705,
                                                "bytes": [
                                                    83,
                                                    69,
                                                    76,
                                                    69,
                                                    67,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "<tool_call>",
                                                "logprob": -5.261014435375252,
                                                "bytes": None
                                            },
                                            {
                                                "token": "Option",
                                                "logprob": -5.5058893895988845,
                                                "bytes": [
                                                    79,
                                                    112,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "selected",
                                                "logprob": -5.511836502635994,
                                                "bytes": [
                                                    115,
                                                    101,
                                                    108,
                                                    101,
                                                    99,
                                                    116,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Action",
                                                "logprob": -5.521176788890877,
                                                "bytes": [
                                                    65,
                                                    99,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -5.550067398632088,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "Choice",
                                                "logprob": -5.651694748485603,
                                                "bytes": [
                                                    67,
                                                    104,
                                                    111,
                                                    105,
                                                    99,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "`",
                                                "logprob": -5.799909088695564,
                                                "bytes": [
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "Here",
                                                "logprob": -6.071988556469002,
                                                "bytes": [
                                                    72,
                                                    101,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -6.231146309459724,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.241500351512947,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 1,
                                            "support": 1,
                                            "entropy": 0,
                                            "selection_ms": 0.11309,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 1,
                                                    "entropy": 0
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 1,
                                                    "entropy": 0
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 1,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 58,
                        "completion_tokens": 2,
                        "total_tokens": 60,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 58,
                        "prompt_ms": 1356,
                        "prompt_per_token_ms": 23.379,
                        "prompt_per_second": 42.8,
                        "predicted_n": 2,
                        "predicted_ms": 35.2,
                        "predicted_per_token_ms": 17.6,
                        "predicted_per_second": 56.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1412.8537999931723,
                "captured_at": "2026-10-04T04:17:54Z"
            }
        ]
    },
    "wall_ms": 36.08290001284331,
    "lesson_view": {
        "index": 0,
        "value": 0,
        "scope": "Reproduce the selected question/rule/result panel. Other page dials are independent."
    }
}
import argparse
import copy
import hashlib
import json
import math
import os
import sys
from pathlib import Path
import urllib.error
import urllib.request

"""Small, portable calculations behind the question/rule/result panels.

Standard library only. This exact source is included in every Python download.
Inputs are the captured experiment, never an invented new model response. A knob
changes a disclosed calculation on those inputs; it does not rescore a new prompt.
"""
import itertools
import math
import statistics


def _spec(question, rule, knob, default, compare, low, high, integer=False):
    return dict(question=question, rule=rule, knob=knob, default=default,
                compare=compare, low=low, high=high, integer=integer)


LESSON_SPECS = {
    'choice': _spec('Which ticket queue gets this message?', 'Compare the three saved label scores. Heat flattens their relative weights; it adds no evidence.', 'Reweighting temperature', 1, 2, .1, 3),
    'boolean': _spec('Does this message ask to cancel?', 'Normalize the saved Yes and No scores. A number near one is a strong preference, not proof.', 'Reweighting temperature', 1, 2, .1, 3),
    'score': _spec('How serious is the outage?', 'Multiply each rubric value by its answer weight, then add. The rating comes from the whole distribution.', 'Reweighting temperature', 1, 2, .1, 3),
    'candidates': _spec('Read the failure first, or start changing things?', 'Add token logprobs along each saved path, then sum path mass inside each finite group. A length penalty changes the objective.', 'Length penalty exponent', 0, 1, 0, 1),
    'controller': _spec('May the simulated repair take its next step?', 'Keep only state-legal actions. Hold the recorded action if its relative legal weight falls below the threshold.', 'Required legal-action weight', 0, .999, 0, 1),
    'rerank': _spec('Which sources help explain cancellation?', 'Compute each source’s expected relevance separately, then keep those above the cutoff.', 'Minimum relevance', 0, .9, 0, 1),
    'graph': _spec('Which text links can coexist?', 'Search every small edge subset. Reject cycles and competing attachments, then maximize useful edge weight.', 'Edge cost / threshold', .5, .9, .01, .99),
    'scene': _spec('Which valid drawing best fits the instruction?', 'Average the three saved text probes. Optionally charge for disagreement between them; code still checks geometry.', 'Disagreement penalty', 0, 1, 0, 2),
    'wire': _spec('What did the model assign to this actual token?', 'Exponentiate its raw logprob. Sum only the reported alternatives; their top-N list may omit probability mass.', 'Visible token index (zero-based)', 0, 5, 0, 10000, True),
    'speculation': _spec('Why can a draft be rejected?', 'Compare the proposal head and target verification on the same proposed token. They are different distributions.', 'Proposal position (zero-based)', 0, 2, 0, 10000, True),
    'performance': _spec('What did each API path cost on this setup?', 'Recalculate a latency percentile from the original wall-time samples. Different output tasks remain separate.', 'Latency percentile', 50, 90, 0, 100),
    'samplers': _spec('How much did this recipe change the selected token’s weight?', 'Compare its raw target probability with its post-sampler probability. Read support and entropy from the complete native row.', 'Recorded recipe index (zero-based)', 0, 1, 0, 10000, True),
    'sampler-sandbox': _spec('Can we add heat without admitting implausible tokens?', 'Remove logits below max + log(0.05), then divide the survivors by temperature and normalize.', 'Temperature after Min-P', 1.5, .7, .1, 3),
    'tictactoe': _spec('Did a legal move give away a winnable outcome?', 'Solve the saved position by exhaustive minimax. Compare the best legal outcome with the recorded model move.', 'Recorded turn index (zero-based)', 0, 1, 0, 10000, True),
    'chess': _spec('Did the shortlist favor a mating move?', 'Add the saved label weights attached to code-checked mating moves. The separately generated UCI move uses a different prompt.', 'Shortlist temperature', 1, 3, .1, 3),
    'poker': _spec('Should this hand check or bet?', 'Average exact chip payoffs over the two possible opponent cards using the stated calling policy.', 'Opponent call-rate multiplier', 1, 0, 0, 2),
    'thermal': _spec('What happens if we replay the fan commands differently?', 'Step the disclosed thermal equation through the same loads. A fan offset is an open-loop counterfactual, not a new model policy.', 'Fan offset', 0, 20, -60, 60),
    'scheduler': _spec('How much lateness did this legal schedule cause?', 'Add job durations in the recorded order and check dependencies. Charge for finishing after the adjusted deadline.', 'Deadline shift', 0, -3, -10, 10),
    'context': _spec('Did replacing old text change the current-state answer?', 'Recalculate each saved Yes/No distribution and compare the selected wording with the original append-only prompt.', 'Context variant index (zero-based)', 0, 2, 0, 10000, True),
    'observer': _spec('Which action follows from these three semantic measurements?', 'Apply the same explicit threshold rule to every saved report: inspect, verify, finish, or ask.', 'Decision threshold', .5, .999, 0, 1),
    'calibration': _spec('Does demanding stronger answers leave enough coverage?', 'Recalculate Brier error on all six examples and accuracy only on retained examples. Empty coverage has no accuracy.', 'Required answer weight', .5, 1, .5, 1),
    'information': _spec('Which observation is worth buying?', 'Use the stated sensor likelihoods to compute both Bayesian posteriors and expected entropy reduction.', 'Test index (zero-based)', 0, 1, 0, 10000, True),
    'search': _spec('Which valid scene survives a cost penalty?', 'Subtract the chosen cost charge from each saved semantic weight. Reject invalid geometry before ranking.', 'Cost weight', .1, 1, 0, 1),
    'frontier': _spec('Would faster score transfer matter here?', 'Add assumed forward time, a transfer lower bound, and the measured selector. This is a serial cost sketch.', 'Assumed transfer GB/s', 12, 2, .1, 128),
    'research-map': _spec('What would make this research idea testable?', 'Count the disclosed implementation categories, then reveal one branch’s next gate. A proposal is not a native result.', 'Branch index (zero-based)', 0, 12, 0, 10000, True),
    'pressure': _spec('How much original mass did this boundary throw away?', 'At temperature 1 with pure masking, log Z = raw selected logprob − log(selected masked probability). Pressure is −log Z.', 'Native grammar index (zero-based)', 0, 1, 0, 10000, True),
    'circuit': _spec('Can we compute AND without assuming independence?', 'Start with four joint worlds. Optionally condition on noisy evidence of style, then add worlds for each logical operation.', 'Reliability of observing style', .5, 1, .5, 1),
    'control': _spec('Can preference change while forbidden actions stay forbidden?', 'Normalize log(base) + strength × [log(desired) − log(undesired)] inside the legal set.', 'Control strength', 0, 2, 0, 3),
    'future': _spec('Can a less likely first move have a better future?', 'Weight the root policy by exact future success raised to strength. At strength zero use the base policy.', 'Future-value strength', 0, 1, 0, 2),
    'sensitivity': _spec('Which prompt intervention moves this measurement?', 'Rebuild the central finite-difference matrix. Predict a change in hours, with load fixed at +5 points; preserve the measured holdout error.', 'Change in hours remaining', -1, -2, -2, 2),
    'counterexamples': _spec('Can equivalent algebra confuse the observer?', 'Find the equivalent pair with the largest measured log-odds distance. Evaluate its exact coefficients at the chosen integer.', 'Integer x', 2, -2, -10, 10, True),
}


def normalize_logs(logs):
    finite = [x for x in logs if math.isfinite(x)]
    if not finite:
        raise ValueError('No candidate has positive mass')
    maximum = max(finite)
    weights = [math.exp(x-maximum) if math.isfinite(x) else 0. for x in logs]
    total = math.fsum(weights)
    return [w/total for w in weights]


def weights(rows, temperature=1):
    if any(r.get('logprob') is None for r in rows):
        raise ValueError('A complete label measurement is required; missing top-N entries stay unknown')
    return normalize_logs([r['logprob']/temperature for r in rows])


def entropy(p):
    return -math.fsum(x*math.log2(x) for x in p if x)


def _pick(items, value):
    if not 0 <= value < len(items):
        raise ValueError('Index must be 0..'+str(len(items)-1))
    return items[int(value)]


def _rows(names, values):
    return [dict(label=str(n), value=float(v)) for n,v in zip(names,values)]


def _graph(edges, threshold):
    if len(edges)>12:
        raise ValueError('This exact demonstration supports at most 12 edges')
    best, score = [], 0.
    for bits in itertools.product((False,True), repeat=len(edges)):
        selected=[e for e,yes in zip(edges,bits) if yes]
        out, incoming, captions = {}, set(), set()
        good=True
        for e in selected:
            a,b=e['source'],e['target']
            if a==b:good=False;break
            if e['relation']=='caption':
                if a in captions:good=False;break
                captions.add(a)
            else:
                if a in out or b in incoming:good=False;break
                out[a]=b;incoming.add(b)
        for start in out:
            node,visited=start,set()
            while node in out:
                if node in visited:good=False;break
                visited.add(node);node=out[node]
        utility=math.fsum(e['weight']-threshold for e in selected)
        if good and utility>score:best,score=selected,utility
    return best,score


def _ttt(board, turn):
    lines=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
    for a,b,c in lines:
        if board[a]!='.' and board[a]==board[b]==board[c]:return 1 if board[a]=='X' else -1
    if '.' not in board:return 0
    values=[_ttt(board[:i]+turn+board[i+1:],'O' if turn=='X' else 'X') for i,s in enumerate(board) if s=='.']
    return (max if turn=='X' else min)(values)


def calculate_lesson(name, data, value=None):
    spec=LESSON_SPECS[name]
    v=spec['default'] if value is None else value
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not spec['low']<=v<=spec['high'] or (spec['integer'] and int(v)!=v):
        raise ValueError(f"{spec['knob']} must be {'an integer' if spec['integer'] else 'finite'} in [{spec['low']}, {spec['high']}]")
    rows=[];metrics={};note='Calculation on saved inputs; changing this setting makes no new model request.'
    summary='';unit='weight'
    if name in ('choice','boolean','score'):
        p=weights(data['rows'],v);at=max(range(len(p)),key=p.__getitem__)
        rows=_rows([r['label']+' · '+r.get('description','') for r in data['rows']],p)
        metrics=dict(winner=data['rows'][at]['label'],top_weight=p[at],entropy_bits=entropy(p))
        if name in ('boolean','score'):
            metrics['expected_value']=math.fsum(q*r['value'] for q,r in zip(p,data['rows']))
        summary=f"Answer {metrics['winner']} leads with {p[at]:.2%} of the listed-label weight."
        if name=='score':summary=f"Expected rubric value: {metrics['expected_value']:.4f} on the stated 0–1 scale."
    elif name=='candidates':
        paths=data['paths'];logs=[math.fsum(t['logprob'] for t in r['tokens'])/len(r['tokens'])**v for r in paths]
        p=normalize_logs(logs);names=list(dict.fromkeys(r['group'] for r in paths))
        values=[math.fsum(q for q,r in zip(p,paths) if r['group']==g) for g in names];rows=_rows(names,values)
        metrics=dict(winner=names[values.index(max(values))],group_weights=values)
        summary=metrics['winner']+' carries the most relative group weight.'
        note='Only these emitted token paths, with their saved terminators and no EOS. A nonzero length penalty produces preference scores, not path probability.'
    elif name=='controller':
        labels=data['measure']['rows'];p=weights(labels);legal=[i for i,r in enumerate(labels) if r['allowed']]
        mass=math.fsum(p[i] for i in legal);pick=next(i for i,r in enumerate(labels) if r['action']==data['action'])
        q=p[pick]/mass;held=q<v
        rows=_rows([labels[i]['action'] for i in legal],[p[i]/mass for i in legal])
        metrics=dict(held=held,selected_weight=q,next_state=data['state'] if held else data['next_state'])
        summary=('Hold the action.' if held else 'Apply '+data['action']+'.')+' State: '+metrics['next_state']+'.'
    elif name=='rerank':
        values=[math.fsum(q*r['value'] for q,r in zip(weights(s['measure']['rows']),s['measure']['rows'])) for s in data['sources']]
        rows=_rows([s['id'] for s in data['sources']],values);kept=[r['label'] for r in rows if r['value']>=v]
        metrics=dict(retained=kept,scores=values);summary='Retain '+(', '.join(kept) or 'no sources')+' at this cutoff.'
    elif name=='graph':
        selected,utility=_graph(data['edges'],v);rows=_rows([e['source']+' → '+e['target'] for e in selected],[e['weight']-v for e in selected]);unit='utility'
        metrics=dict(selected=[(e['source'],e['target'],e['relation']) for e in selected],utility=utility)
        summary=f'{len(selected)} compatible links, total utility {utility:.4f}.'
        note='Global code constraints select links; utility is not the probability that the document graph is correct.'
    elif name=='scene':
        valid=[c for c in data['candidates'] if c['valid']];values=[]
        for c in valid:
            p=[weights(x['measure']['rows'])[0] for x in c['vector']]
            values.append(statistics.mean(p)-v*statistics.pvariance(p))
        rows=_rows([c['name'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['name'],utilities=values)
        summary='Retain '+metrics['retained']+' among geometry-valid candidates.'
        note='These are saved text judgments. This calculation cannot see the drawing or measure visual appeal.'
    elif name=='wire':
        entry=_pick(data['entries'],v);p=math.exp(entry['logprob']);top=entry.get('top_logprobs',[])
        rows=_rows([x['token'] for x in top],[math.exp(x['logprob']) for x in top]);unit='raw probability'
        metrics=dict(token=entry['token'],raw_probability=p,reported_top_mass=math.fsum(r['value'] for r in rows))
        summary=f"Token {entry['token']!r}: raw probability {p:.6g}."
        note='This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary.'
    elif name=='speculation':
        window=data['oracle']['example_rejection'];r=_pick(window['proposal'],v)
        rows=_rows(['Draft head','Target verification'],[r['draft_probability'],math.exp(r['target_logprob'])]);unit='probability / distinct heads'
        metrics=dict(token_id=r['token_id'],target_sequence_logprob=math.fsum(x['target_logprob'] for x in window['proposal']),draft_target_logprob_gap=r['draft_logprob']-r['target_logprob'])
        summary=f"Proposal token {r['token_id']}: the two heads differ by {metrics['draft_target_logprob_gap']:.4f} log units."
        note='Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability.'
    elif name=='performance':
        values=[]
        for r in data['rows']:
            xs=sorted(x['wall_ms'] for x in r['runs']);a=(len(xs)-1)*v/100;lo=math.floor(a);hi=math.ceil(a)
            values.append(xs[lo]+(xs[hi]-xs[lo])*(a-lo))
        rows=_rows([r['name'] for r in data['rows']],values);unit='ms';metrics=dict(percentile=v,times_ms=values)
        summary=f'Percentile {v:g}, recalculated from {data["repeats"]} samples per path.'
        note='Small same-setup samples include network and API cost. JSON answers a different task; this is no universal speed ranking.'
    elif name=='samplers':
        run=_pick(data['runs'],v);token=run['tokens'][0];sample=token['strata_sampling']
        raw=math.exp(token['logprob']);post=sample['probability']
        rows=_rows(['Raw target','After recipe'],[raw,post]);unit='selected token probability'
        metrics=dict(recipe=run['name'],support=sample['support'],raw=raw,selected=post,log_weight_change=math.log(post)-token['logprob'],entropy_bits=sample['entropy']/math.log(2))
        summary=f"{run['name']}: {sample['support']} native tokens remain eligible."
        note='Recipes are separate generations. Entropy and support are full-row native measurements; a top-N slice cannot recover them.'
    elif name=='sampler-sandbox':
        cut=max(data['logits'])+math.log(.05);logs=[x/v if x>=cut else -math.inf for x in data['logits']];p=normalize_logs(logs)
        rows=_rows(data['tokens'],p);metrics=dict(support=sum(x>0 for x in p),entropy_bits=entropy(p),probabilities=p)
        summary=f"{metrics['support']} credible tokens survive; entropy {metrics['entropy_bits']:.3f} bits."
        note='All eight logits are synthetic and visible. This is exact finite-row arithmetic, not a new native receipt.'
    elif name=='tictactoe':
        f=_pick(data['frames'],v);b=f['before'];legal=[i for i,c in enumerate(b) if c=='.'];oracle={i:_ttt(b[:i]+'X'+b[i+1:],'O') for i in legal}
        regret=max(oracle.values())-oracle[f['square']];rows=_rows([str(i+1) for i in legal],list(oracle.values()));unit='X outcome: lose −1 / draw 0 / win 1'
        metrics=dict(regret=regret,square=f['square']+1,oracle=oracle);summary=f"Recorded move: square {f['square']+1}; exact outcome regret {regret}."
    elif name=='chess':
        p=weights(data['measure']['rows'],v);mass=math.fsum(q for q,m in zip(p,data['shortlist']) if m['mate'])
        rows=_rows([m['san'] for m in data['shortlist']],p);metrics=dict(mating_shortlist_weight=mass,generated_uci=data['chosen']['text'],generated_mate=data['mate'])
        summary=f'{mass:.2%} of shortlist weight favors mate; the separate UCI generation '+('mated.' if data['mate'] else 'did not mate.')
        note='The saved legal/mate flags came from python-chess. This portable calculation aggregates them; it is not a replacement chess engine.'
    elif name=='poker':
        ranks=['J','Q','K'];rates={c:min(1,max(0,r*v)) for c,r in data['call_rates'].items()};values={}
        for own in ranks:
            opponents=[c for c in ranks if c!=own];sign=lambda c:1 if ranks.index(own)>ranks.index(c) else -1
            values[own]=dict(check=statistics.mean(sign(c) for c in opponents),bet=statistics.mean((1-rates[c])+rates[c]*2*sign(c) for c in opponents))
        rows=_rows([c+' bet − check' for c in ranks],[values[c]['bet']-values[c]['check'] for c in ranks]);unit='expected chips'
        metrics=dict(values=values,call_rates=rates);summary='Bet when the bar is positive; check when it is negative.'
        note='Uniform remaining-card prior and explicitly assumed opponent policy. Answer weights are not hidden-card beliefs or equilibrium probabilities.'
    elif name=='thermal':
        t=data['frames'][0]['temperature'];temperatures=[]
        for f in data['frames']:
            fan=min(60,max(0,f['fan']+v));t=round(t+.22*f['load']-.32*fan-.04*(t-25),3);temperatures.append(t)
        rows=_rows(range(1,len(temperatures)+1),temperatures);unit='°C';metrics=dict(temperatures=temperatures,mean_error=statistics.mean(abs(t-data['target']) for t in temperatures),violations=sum(t>data['limit'] for t in temperatures))
        summary=f"Mean distance from target: {metrics['mean_error']:.2f}°C; {metrics['violations']} limit violations."
        note='Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control.'
    elif name=='scheduler':
        done=set();clock=0;late=[]
        for f in data['frames']:
            j=f['job']
            if not set(j['after'])<=done:raise ValueError('Saved schedule violates dependencies')
            clock+=j['duration'];late.append(max(0,clock-j['deadline']-v));done.add(j['id'])
        rows=_rows([f['job']['id'] for f in data['frames']],late);unit='late time units';metrics=dict(total_lateness=sum(late),finish_time=clock)
        summary=f'Total lateness {sum(late):g}; the same dependency-valid order ends at time {clock}.'
    elif name=='context':
        selected=_pick(data['runs'],v);all_weights=[weights(r['measure']['rows'])[1] for r in data['runs']];p=all_weights[int(v)]
        rows=_rows([r['name'] for r in data['runs']],all_weights);metrics=dict(variant=selected['name'],no_weight=p,delta_from_append=p-all_weights[0])
        summary=f"{selected['name']}: keep-still answer weight {p:.3%}."
        note='Saved prompt interventions, not KV tensor mutation. This calculation compares their recorded measurements.'
    elif name=='observer':
        actions=[];triples=[]
        for f in data['frames']:
            p=[weights(x['measure']['rows'])[0] for x in f['vector']];triples.append(p)
            actions.append('inspect failure' if p[0]>v else 'verify' if p[1]>v else 'finish' if p[2]>v else 'ask')
        rows=_rows(['Fault','Missing check','Verified'],triples[0]);metrics=dict(actions=actions,vectors=triples)
        summary=' → '.join(actions)+'.';note='Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability.'
    elif name=='calibration':
        p=[weights(r['measure']['rows'])[0] for r in data['rows']];truth=[r['truth'] for r in data['rows']];kept=[i for i,q in enumerate(p) if max(q,1-q)>=v]
        brier=statistics.mean((q-y)**2 for q,y in zip(p,truth));accuracy=statistics.mean(int(p[i]>=.5)==truth[i] for i in kept) if kept else None
        rows=_rows([str(i+1) for i in range(len(p))],p);metrics=dict(brier=brier,retained=len(kept),coverage=len(kept)/len(p),accuracy=accuracy)
        summary=f'{len(kept)}/{len(p)} retained; '+(f'{accuracy:.1%} correct in those cases.' if accuracy is not None else 'accuracy is undefined with zero coverage.')
        note='Six disclosed teaching examples, not a held-out calibration benchmark. Brier error still counts every example.'
    elif name=='information':
        t=_pick(data['tests'],v);prior=data['prior'];py=math.fsum(p*l for p,l in zip(prior,t['likelihood']));yes=[p*l/py for p,l in zip(prior,t['likelihood'])];no=[p*(1-l)/(1-py) for p,l in zip(prior,t['likelihood'])]
        gain=entropy(prior)-py*entropy(yes)-(1-py)*entropy(no);rows=_rows(data['faults'],yes)
        metrics=dict(test=t['name'],gain_bits=gain,gain_per_cost=gain/t['cost'],yes=yes,no=no)
        summary=t['name']+f': {gain:.3f} expected bits; {gain/t["cost"]:.3f} bits per cost unit.'
        note='Prior and likelihoods are stated synthetic sensor assumptions. Bars condition on a positive result; no test was actually purchased.'
    elif name=='search':
        valid=[c for c in data['candidates'] if c['valid']];values=[weights(c['measure']['rows'])[0]-v*c['cost']/3 for c in valid]
        rows=_rows([c['id'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['id'],utilities=values)
        summary='Retain '+metrics['retained']+' after charging for cost; invalid geometry is excluded.'
    elif name=='frontier':
        selector=sorted(r['selection_ms'] for r in data['measurements'])[len(data['measurements'])//2];transfer=data['vocabulary']*data['bytes_per_logit']/(v*1e6);total=60+transfer+selector
        rows=_rows(['Assumed forward','Transfer lower bound','Measured host selector'],[60,transfer,selector]);unit='ms'
        metrics=dict(transfer_ms=transfer,serial_ms=total,tokens_per_second=1000/total)
        summary=f'Serial estimate: {total:.3f} ms/token; {1000/total:.2f} tokens/s.'
        note='Forward time is assumed 60 ms. Selector uses the upper-middle measured sample to match the chart. Queue, prefill and network are excluded.'
    elif name=='research-map':
        branch=_pick(data['branches'],v);categories={}
        for b in data['branches']:categories[b['status']]=categories.get(b['status'],0)+1
        rows=_rows(list(categories),list(categories.values()));unit='branches';metrics=dict(branch=branch['name'],gate=branch['gate'],categories=categories)
        summary=branch['name']+': '+branch['gate'];note='This page recomputes an agenda inventory, not an experiment result. Each implemented branch links to its own evidence.'
    elif name=='pressure':
        case=_pick(data['cases'],v);r=case['rows'][0];token=r['token'];q=token['strata_sampling']['probability'];logz=token['logprob']-math.log(q)
        if logz>1e-6:raise ValueError('Pure-mask mass exceeds one')
        z=math.exp(min(0,logz));rows=_rows(['Survived','Removed'],[z,1-z]);unit='original probability mass'
        metrics=dict(grammar=case['name'],mass=z,pressure_nats=-logz,pressure_bits=-logz/math.log(2))
        summary=f"{case['name']}: {z:.4%} survives; pressure {-logz:.4f} nats."
        note='First actual prefix of this native grammar. Exact only for pure masking at temperature 1, not arbitrary sampler recipes or entire grammar languages.'
    elif name=='circuit':
        p=weights(data['cases'][0]['measurement']['rows']);weighted=[p[0]*(1-v),p[1]*(1-v),p[2]*v,p[3]*v];z=math.fsum(weighted);p=[x/z for x in weighted]
        f=p[1]+p[3];s=p[2]+p[3];rows=_rows(['Neither','Facts only','Style only','Both'],p)
        metrics=dict(F=f,S=s,AND=p[3],OR=1-p[0],F_given_S=p[3]/s if s else None,marginal_product=f*s)
        summary=f'Facts AND style: {p[3]:.2%}; multiplying the marginals would give {f*s:.2%}.'
        note='At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world.'
    elif name=='control':
        logs=[math.log(b)+v*(math.log(d)-math.log(u)) if i in data['allowed'] else -math.inf for i,(b,d,u) in enumerate(zip(data['base'],data['desired'],data['undesired']))];p=normalize_logs(logs)
        rows=_rows(list('ABCD'),p);pick=max(range(len(p)),key=p.__getitem__);metrics=dict(probabilities=p,selected=pick,forbidden_mass=math.fsum(p[i] for i in range(len(p)) if i not in data['allowed']))
        summary=f"Action {'ABCD'[pick]} leads; forbidden-action mass stays zero."
        note='Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook.'
    elif name=='future':
        root=weights(data['policy'][0]['rows']);child=weights(data['policy'][2]['rows']);h=[0,child[1]];p=normalize_logs([math.log(r)+(v*math.log(x) if x else -math.inf) if v else math.log(r) for r,x in zip(root,h)])
        rows=_rows(['A: dead end','B: viable route'],p);success=p[1]*child[1];metrics=dict(root_weights=p,exact_h=h,success_root_only=success,base_success=root[1]*child[1])
        summary=f'{p[1]:.2%} chooses B; leaving the next policy unchanged succeeds {success:.2%} of the time.'
        note='Only BB succeeds in this exact two-step toy. Conditioning both steps is different from steering only the root. No native future-value decoder is claimed.'
    elif name=='sensitivity':
        o=data['observations'];zs=[[math.log(p/(1-p)) for p in row['probabilities']] for row in o]
        matrix=[[(zs[2][i]-zs[1][i])/(2*data['epsilon'][0]),(zs[4][i]-zs[3][i])/(2*data['epsilon'][1])] for i in range(3)]
        delta=[r[0]*v+r[1]*5 for r in matrix];rows=_rows(['Urgency','Load','Damage'],delta);unit='predicted log-odds change'
        observed=[zs[6][i]-zs[0][i] for i in range(3)];held=[r[0]*-1+r[1]*5 for r in matrix]
        metrics=dict(matrix=matrix,predicted_delta=delta,holdout_residual=[a-b for a,b in zip(observed,held)])
        summary=f'Predicted urgency shift {delta[0]:+.3f}; the measured −1h/+5 holdout had error {metrics["holdout_residual"][0]:+.3f}.'
        note='The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses.'
    elif name=='counterexamples':
        nodes=data['nodes'];pairs=[]
        for i,a in enumerate(nodes):
            za=[math.log(p/(1-p)) for p in a['p_yes']]
            for j,b in enumerate(nodes[i+1:],i+1):
                if a['coefficients']!=b['coefficients']:continue
                zb=[math.log(p/(1-p)) for p in b['p_yes']];distance=math.sqrt(math.fsum((x-y)**2 for x,y in zip(za,zb)));pairs.append((distance,i,j))
        distance,i,j=max(pairs);a,b=nodes[i],nodes[j];evaluate=lambda c:sum(x*v**k for k,x in enumerate(c))
        rows=_rows([a['expression'],b['expression']],[a['p_yes'][1],b['p_yes'][1]])
        metrics=dict(left=a['expression'],right=b['expression'],margin_distance=distance,left_value=evaluate(a['coefficients']),right_value=evaluate(b['coefficients']))
        summary=f'Equal exact values at x={v:g}: {metrics["left_value"]:g}; observer distance {distance:.3f}.'
        note='Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe.'
    else:
        raise ValueError('No portable calculation for '+name)
    return dict(value=v,summary=summary,rows=rows,unit=unit,metrics=metrics,note=note)


def make_lesson(name, data):
    spec=LESSON_SPECS[name]
    try:
        first=calculate_lesson(name,data)
        compare=spec['compare']
        # An edited run can have fewer tokens/turns than the recorded default.
        lengths={'wire':len(data.get('entries',[])), 'samplers':len(data.get('runs',[])),
                 'tictactoe':len(data.get('frames',[])), 'context':len(data.get('runs',[])),
                 'information':len(data.get('tests',[])), 'research-map':len(data.get('branches',[])),
                 'pressure':len(data.get('cases',[]))}
        if name in lengths:compare=min(compare,lengths[name]-1)
        second=calculate_lesson(name,data,compare)
        context=data.get('prompt','').partition('STATE:\n')[2].partition('\nQUESTION:')[0]
        return dict(**spec,states=[first,second],input_excerpt=context[:320]+('…' if len(context)>320 else ''),scope='This panel and its Python calculation reproduce saved measurements. Other page controls are independent views.')
    except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:
        # A genuinely incomplete score or a tool-only wire response stays usable.
        # Do not turn an unavailable lesson into fabricated measurement data.
        return dict(**spec,states=[],unavailable=str(error),scope='This run has no complete inputs for this calculation. Inspect its exact request and result below.')



def mock_post(request, fixture):
    if request != fixture['request']:
        raise ValueError('No mock matches the edited request. Supply a new fixture or explicitly choose --live-url.')
    return copy.deepcopy(fixture['response'])


def live_post(base_url, request):
    if not base_url.startswith(('http://', 'https://')):
        raise ValueError('--live-url must be an http(s) Strata address')
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('STRATA_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['STRATA_API_KEY']
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    body = json.dumps(request, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base_url.rstrip('/')+'/v1/chat/completions', data=body, headers=headers)
    with opener.open(req, timeout=600) as response:
        wire = response.read().decode('utf-8')
    if request.get('stream'):
        events = [line[5:].strip() for line in wire.splitlines() if line.startswith('data:')]
        if not events or events[-1] != '[DONE]':
            raise ValueError('Stream closed without [DONE]')
        chunks = [json.loads(line) for line in events[:-1]]
        if any('error' in chunk for chunk in chunks):
            raise ValueError('Stream reported an error: '+repr(chunks))
        return {'sse_events': chunks, 'wire': wire}
    reply = json.loads(wire)
    if 'error' in reply:
        raise ValueError('Strata reported an error: '+repr(reply['error']))
    return reply


def summarize(response):
    if 'sse_events' in response:
        return str(len(response['sse_events']))+' SSE events; inspect the saved wire response'
    choice = (response.get('choices') or [{}])[0]
    message = choice.get('message', {})
    text = message.get('content') or json.dumps(message.get('tool_calls') or message, ensure_ascii=False)
    entries = (choice.get('logprobs') or {}).get('content') or []
    if entries:
        text += '\n  First visible token raw logprob: '+repr(entries[0]['logprob'])
        text += '\n  First visible token raw probability: '+format(math.exp(entries[0]['logprob']), '.7g')
    return text


def raw_tokens(response):
    if 'sse_events' in response:
        return [token for chunk in response['sse_events'] for choice in chunk.get('choices', [])
                for token in (choice.get('logprobs') or {}).get('content') or []]
    choices = response.get('choices') or []
    return ((choices[0].get('logprobs') or {}).get('content') or []) if choices else []


def print_raw_tokens(response):
    entries = raw_tokens(response)
    if not entries:
        print('No scored answer tokens returned; no raw probabilities are invented.')
    for i, token in enumerate(entries):
        lp = token['logprob']
        p = math.exp(lp)
        shown = format(p, '.9g') if p else 'underflows; use the finite logprob'
        print('  Token '+str(i)+': '+repr(token['token'])+' bytes='+repr(token['bytes'])+
              ' raw ln p='+repr(lp)+' raw p='+shown)
        sampling = token.get('strata_sampling')
        if sampling:
            print('    Final native selection weight q='+repr(sampling['probability'])+' (separate from raw p)')


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=int, default=1, help='1-based request index (default 1)')
    parser.add_argument('--all', action='store_true', help='Replay every mock in this captured run')
    parser.add_argument('--show', action='store_true', help='Print exact selected HTTP request JSON')
    parser.add_argument('--tokens', action='store_true', help='Print every original token raw logprob/probability and available native sampling weight')
    parser.add_argument('--lesson-only', action='store_true', help='Recalculate the captured question/rule/result panel without printing mocked calls')
    parser.add_argument('--value', type=float, help='Change the panel parameter within its documented bounds; offline calculation only')
    parser.add_argument('--live-url', help='Explicitly send ONE request to your compatible Strata server')
    parser.add_argument('--output', type=Path, help='Write responses and their provenance as JSON')
    args = parser.parse_args()
    if args.all and args.live_url:
        parser.error('--all is offline only; saved dependent requests are not a live adaptive controller')
    if args.live_url and (args.lesson_only or args.value is not None):
        parser.error('Lesson calculations use captured evidence. Do not mix --live-url with --lesson-only or --value.')
    calls = CAPTURED['receipt']['calls']
    print('Strata Control Lab / '+CAPTURED['experiment'])
    print('LIVE selected request' if args.live_url else 'OFFLINE MOCK / recorded responses, no inference or network')
    view = CAPTURED.get('score_view')
    if view:
        print('\nRAW LAYER: '+view['raw'])
        print('DERIVED VIEW: '+view['derived'])
        print('SCOPE: '+view['scope'])
    calculation=None
    if not args.live_url:
        spec=CAPTURED.get('lesson')
        if spec and spec.get('states'):
            knob=args.value if args.value is not None else (CAPTURED.get('lesson_view') or {}).get('value',spec['default'])
            try:calculation=calculate_lesson(CAPTURED['experiment'],CAPTURED['result'],knob)
            except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:parser.error(str(error))
            print('\nQUESTION: '+spec['question']+'\nRULE: '+spec['rule'])
            print(spec['knob']+' = '+str(knob)+f" (allowed {spec['low']}..{spec['high']})")
            print('RESULT: '+calculation['summary'])
            print('BOUNDARY: '+calculation['note'])
            print('Reproduces the selected question/rule/result panel; other page dials are independent.')
            print(json.dumps(calculation,ensure_ascii=True,indent=2))
        elif args.lesson_only or args.value is not None:
            parser.error('This captured run has no complete lesson inputs: '+str((spec or {}).get('unavailable','missing calculation')))
    if args.lesson_only:
        result=dict(mode='offline-calculation',calculation=calculation)
    elif not calls:
        if args.live_url:
            parser.error('This page has no HTTP requests: it is analytical or recorded diagnostic evidence')
        print('No HTTP request, GBNF or JSON output constraint was used by this page.')
        print('The included result is a calculation/diagnostic snapshot, not a new model answer.')
        result = dict(mode='offline-snapshot', result=CAPTURED['result'])
        print(json.dumps(result, ensure_ascii=True, indent=2))
    else:
        indexes = range(len(calls)) if args.all else [args.request-1]
        if any(i < 0 or i >= len(calls) for i in indexes):
            parser.error('Request index must be 1..'+str(len(calls)))
        results = []
        for i in indexes:
            fixture = calls[i]
            request = copy.deepcopy(fixture['request'])  # Edit here to try your own live request.
            if args.show:
                print(json.dumps(request, ensure_ascii=True, indent=2))
            response = live_post(args.live_url, request) if args.live_url else mock_post(request, fixture)
            print('Request '+str(i+1)+' / '+str(len(calls))+': '+summarize(response))
            if args.tokens:
                print_raw_tokens(response)
            results.append(dict(request=request, response=response,
                                provenance='live-request' if args.live_url else 'mocked-native-recording'))
        result = dict(mode='live' if args.live_url else 'offline-mock', calls=results)
        print('GBNF and JSON settings are in each request. Use --show to inspect them.')
        print('The saved page result is in CAPTURED["result"]; live responses do not recompute that snapshot.')
    if calculation is not None:result['calculation']=calculation
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
