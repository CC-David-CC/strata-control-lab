# -*- coding: utf-8 -*-
"""Downloaded Strata example: Python 3 standard library; offline by default.

Windows: py strata-example.py
Ubuntu:  python3 strata-example.py
Show a request: python strata-example.py --request 1 --show
Replay all recorded calls: python strata-example.py --all
Recalculate the panel: python strata-example.py --lesson-only
Change its knob: python strata-example.py --lesson-only --value NUMBER
Try ONE request live: python strata-example.py --request 1 --live-url http://127.0.0.1:8080
An optional STRATA_API_KEY environment variable supplies authentication.

CAPTURED is inserted above this runner by the page. It contains this exact run,
with requests, GBNF/JSON settings, responses, streaming chunks and the page result.
Mock mode returns those responses; it performs no inference and opens no socket.
Live mode runs only a selected request. It does not execute tools or adapt a saved
multi-step trace to new answers. No captured API key or authorization header exists.
"""
CAPTURED = {
    "experiment": "speculation",
    "score_view": {
        "raw": "Existing native diagnostic receipts expose raw target logprobs on retained emitted token IDs. Proposal and draft scores are separate; this page makes no new Chat request.",
        "derived": "Draft probability and raw target verification use different heads, vocabularies and prefixes. Retained target output is distinct from rejected proposal scores; suffix lookup has no draft distribution.",
        "scope": "The raw receipt stays attached to the captured request. Page dials recalculate derived views; they do not rerun the model or replace token scores. Neither model probability nor a derived weight is calibrated truth. Missing top-N alternatives stay unknown.",
        "raw_kind": "diagnostic"
    },
    "type": "result",
    "result": {
        "provenance": "Committed native llm-49 receipts from the logprobs base branch; no inference was run",
        "oracle": {
            "selected_rows": 68,
            "proposal_rows": 55,
            "rejected_or_post_rejection_rows": 7,
            "max_absolute_logprob_error": 3.821371929828288e-13,
            "raw_sha256": "850d03d19605bc4a5f3c1de7a38e007d41c31777b7e6c46dbdd11057961c75e6",
            "reference": "Python math.fsum FP64",
            "windows": 80,
            "example_rejection": {
                "type": "verification",
                "request": 1,
                "window": 2,
                "position": 227,
                "proposal_source": "mtp",
                "probability_source": "target_raw_full_vocabulary",
                "target_vocab": 248320,
                "scored_length": 3,
                "proposed_length": 3,
                "complete": True,
                "retained_outputs": 3,
                "accepted_proposals": 2,
                "termination_included": False,
                "proposal": [
                    {
                        "token_id": 1110,
                        "target_logprob": -0.00005348256011227928,
                        "draft_distribution": "raw_draft_vocabulary",
                        "draft_vocab": 40525,
                        "draft_probability": 0.999999523,
                        "draft_logprob": -4.768372718899988e-7
                    },
                    {
                        "token_id": 1850,
                        "target_logprob": -0.000004220685515302049,
                        "draft_distribution": "raw_draft_vocabulary",
                        "draft_vocab": 40525,
                        "draft_probability": 0.999999881,
                        "draft_logprob": -1.1920929665620916e-7
                    },
                    {
                        "token_id": 198,
                        "target_logprob": -12.361689907642042,
                        "draft_distribution": "raw_draft_vocabulary",
                        "draft_vocab": 40525,
                        "draft_probability": 0.523891985,
                        "draft_logprob": -0.6464697506112758
                    }
                ],
                "target_sequence_logprob": -12.361747610887669,
                "emitted": [
                    {
                        "token_id": 1110,
                        "logprob": -0.00005348256011227928
                    },
                    {
                        "token_id": 1850,
                        "logprob": -0.000004220685515302049
                    },
                    {
                        "token_id": 37705,
                        "logprob": -0.00002132091108547665
                    }
                ]
            },
            "suffix_windows": 7
        },
        "replay": {
            "window": {
                "type": "verification",
                "request": 1,
                "window": 2,
                "position": 227,
                "proposal_source": "mtp",
                "probability_source": "target_raw_full_vocabulary",
                "target_vocab": 248320,
                "scored_length": 3,
                "proposed_length": 3,
                "complete": True,
                "retained_outputs": 3,
                "accepted_proposals": 2,
                "termination_included": False,
                "proposal": [
                    {
                        "token_id": 1110,
                        "target_logprob": -0.00005348256011227928,
                        "draft_distribution": "raw_draft_vocabulary",
                        "draft_vocab": 40525,
                        "draft_probability": 0.999999523,
                        "draft_logprob": -4.768372718899988e-7
                    },
                    {
                        "token_id": 1850,
                        "target_logprob": -0.000004220685515302049,
                        "draft_distribution": "raw_draft_vocabulary",
                        "draft_vocab": 40525,
                        "draft_probability": 0.999999881,
                        "draft_logprob": -1.1920929665620916e-7
                    },
                    {
                        "token_id": 198,
                        "target_logprob": -12.361689907642042,
                        "draft_distribution": "raw_draft_vocabulary",
                        "draft_vocab": 40525,
                        "draft_probability": 0.523891985,
                        "draft_logprob": -0.6464697506112758
                    }
                ],
                "target_sequence_logprob": -12.361747610887669,
                "emitted": [
                    {
                        "token_id": 1110,
                        "logprob": -0.00005348256011227928
                    },
                    {
                        "token_id": 1850,
                        "logprob": -0.000004220685515302049
                    },
                    {
                        "token_id": 37705,
                        "logprob": -0.00002132091108547665
                    }
                ]
            },
            "comparisons": [
                {
                    "row": 0,
                    "token_id": 1110,
                    "verify_logprob": -0.00005348256011227928,
                    "teacher_forced_logprob": -0.00003456599286974542,
                    "absolute_difference": 0.000018916567242533855,
                    "absolute_probability_difference": 0.000018915734472879642
                },
                {
                    "row": 1,
                    "token_id": 1850,
                    "verify_logprob": -0.000004220685515302049,
                    "teacher_forced_logprob": -0.0000036896739422973854,
                    "absolute_difference": 5.310115730046634e-7,
                    "absolute_probability_difference": 5.310094727262182e-7
                },
                {
                    "row": 2,
                    "token_id": 198,
                    "verify_logprob": -12.361689907642042,
                    "teacher_forced_logprob": -12.796400890707666,
                    "absolute_difference": 0.4347109830656244,
                    "absolute_probability_difference": 0.0000015087067431258454
                }
            ],
            "limitation": "Cross-path replay is not numerically identical. Initial 0.05 absolute logprob tolerance failed; same-tensor checks remain strict. Replay uses an absolute probability bound of 1e-4.",
            "verify_sequence_logprob": -12.361747610887669,
            "independent_sequence_logprob": -12.796439146374478
        },
        "modes": {
            "target": [
                {
                    "name": "first-cold",
                    "status": 200,
                    "wall_seconds": 4.647606918006204,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 4570,
                        "prompt_per_token_ms": 152.333,
                        "prompt_per_second": 6.6,
                        "predicted_n": 1,
                        "predicted_ms": 44.1,
                        "predicted_per_token_ms": 44.1,
                        "predicted_per_second": 22.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "first-warm",
                    "status": 200,
                    "wall_seconds": 0.3098255629884079,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 280.5,
                        "prompt_per_token_ms": 40.071,
                        "prompt_per_second": 25,
                        "predicted_n": 1,
                        "predicted_ms": 27.5,
                        "predicted_per_token_ms": 27.5,
                        "predicted_per_second": 36.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "first-stream",
                    "status": 200,
                    "wall_seconds": 0.30433725399780087,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 275.2,
                        "prompt_per_token_ms": 39.314,
                        "prompt_per_second": 25.4,
                        "predicted_n": 1,
                        "predicted_ms": 27.5,
                        "predicted_per_token_ms": 27.5,
                        "predicted_per_second": 36.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "disabled",
                    "status": 200,
                    "wall_seconds": 0.30573718099913094,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 278.2,
                        "prompt_per_token_ms": 39.743,
                        "prompt_per_second": 25.2,
                        "predicted_n": 1,
                        "predicted_ms": 26,
                        "predicted_per_token_ms": 26,
                        "predicted_per_second": 38.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "top-zero",
                    "status": 200,
                    "wall_seconds": 0.30167157998948824,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 272.6,
                        "prompt_per_token_ms": 38.943,
                        "prompt_per_second": 25.7,
                        "predicted_n": 1,
                        "predicted_ms": 27.4,
                        "predicted_per_token_ms": 27.4,
                        "predicted_per_second": 36.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "top-twenty",
                    "status": 200,
                    "wall_seconds": 0.30125278201012406,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 270.2,
                        "prompt_per_token_ms": 38.6,
                        "prompt_per_second": 25.9,
                        "predicted_n": 1,
                        "predicted_ms": 27.2,
                        "predicted_per_token_ms": 27.2,
                        "predicted_per_second": 36.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "invalid-stream",
                    "status": 400,
                    "wall_seconds": 0.004231900005834177
                },
                {
                    "name": "long",
                    "status": 200,
                    "wall_seconds": 6.477194036007859,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 32,
                        "prompt_ms": 1897.1,
                        "prompt_per_token_ms": 59.284,
                        "prompt_per_second": 16.9,
                        "predicted_n": 40,
                        "predicted_ms": 4562.5,
                        "predicted_per_token_ms": 114.062,
                        "predicted_per_second": 8.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "long-stream",
                    "status": 200,
                    "wall_seconds": 3.0767245089955395,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 222.1,
                        "prompt_per_token_ms": 31.729,
                        "prompt_per_second": 31.5,
                        "predicted_n": 40,
                        "predicted_ms": 2853.2,
                        "predicted_per_token_ms": 71.33,
                        "predicted_per_second": 14,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "long-disabled",
                    "status": 200,
                    "wall_seconds": 2.9940796829905594,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 215.2,
                        "prompt_per_token_ms": 30.743,
                        "prompt_per_second": 32.5,
                        "predicted_n": 40,
                        "predicted_ms": 2777.2,
                        "predicted_per_token_ms": 69.43,
                        "predicted_per_second": 14.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "grammar-outside-top",
                    "status": 200,
                    "wall_seconds": 2.0253800460050115,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 1085.4,
                        "prompt_per_token_ms": 36.18,
                        "prompt_per_second": 27.6,
                        "predicted_n": 2,
                        "predicted_ms": 84.1,
                        "predicted_per_token_ms": 42.05,
                        "predicted_per_second": 23.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 2,
                        "total_tokens": 32,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "grammar-unicode",
                    "status": 200,
                    "wall_seconds": 0.7267033550015185,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 265.3,
                        "prompt_per_token_ms": 37.9,
                        "prompt_per_second": 26.4,
                        "predicted_n": 8,
                        "predicted_ms": 459.5,
                        "predicted_per_token_ms": 57.438,
                        "predicted_per_second": 17.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 8,
                        "total_tokens": 38,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-schema",
                    "status": 200,
                    "wall_seconds": 2.8973425879958086,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 106,
                        "prompt_ms": 2388.2,
                        "prompt_per_token_ms": 22.53,
                        "prompt_per_second": 44.4,
                        "predicted_n": 7,
                        "predicted_ms": 388.8,
                        "predicted_per_token_ms": 55.543,
                        "predicted_per_second": 18,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 106,
                        "completion_tokens": 7,
                        "total_tokens": 113,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-schema-stream",
                    "status": 200,
                    "wall_seconds": 0.564043018996017,
                    "timings": {
                        "cache_n": 99,
                        "prompt_n": 7,
                        "prompt_ms": 253.7,
                        "prompt_per_token_ms": 36.243,
                        "prompt_per_second": 27.6,
                        "predicted_n": 7,
                        "predicted_ms": 307.5,
                        "predicted_per_token_ms": 43.929,
                        "predicted_per_second": 22.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 106,
                        "completion_tokens": 7,
                        "total_tokens": 113,
                        "prompt_tokens_details": {
                            "cached_tokens": 99
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-object",
                    "status": 200,
                    "wall_seconds": 1.1524401630013017,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 78,
                        "prompt_ms": 803.4,
                        "prompt_per_token_ms": 10.3,
                        "prompt_per_second": 97.1,
                        "predicted_n": 7,
                        "predicted_ms": 313.1,
                        "predicted_per_token_ms": 44.729,
                        "predicted_per_second": 22.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 78,
                        "completion_tokens": 7,
                        "total_tokens": 85,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-thinking",
                    "status": 200,
                    "wall_seconds": 2.4876475690107327,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 130,
                        "prompt_ms": 1195.1,
                        "prompt_per_token_ms": 9.193,
                        "prompt_per_second": 108.8,
                        "predicted_n": 25,
                        "predicted_ms": 983.8,
                        "predicted_per_token_ms": 39.352,
                        "predicted_per_second": 25.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 130,
                        "completion_tokens": 25,
                        "total_tokens": 155,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "queued-0",
                    "status": 200,
                    "wall_seconds": 1.068337363001774,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 1037.8,
                        "prompt_per_token_ms": 34.593,
                        "prompt_per_second": 28.9,
                        "predicted_n": 1,
                        "predicted_ms": 27.7,
                        "predicted_per_token_ms": 27.7,
                        "predicted_per_second": 36.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "queued-1",
                    "status": 200,
                    "wall_seconds": 1.3679623230127618,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 271.9,
                        "prompt_per_token_ms": 38.843,
                        "prompt_per_second": 25.7,
                        "predicted_n": 1,
                        "predicted_ms": 27.5,
                        "predicted_per_token_ms": 27.5,
                        "predicted_per_second": 36.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-0",
                    "status": 200,
                    "wall_seconds": 3.718425237995689,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 32,
                        "prompt_ms": 924.3,
                        "prompt_per_token_ms": 28.884,
                        "prompt_per_second": 34.6,
                        "predicted_n": 40,
                        "predicted_ms": 2791.8,
                        "predicted_per_token_ms": 69.795,
                        "predicted_per_second": 14.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-1",
                    "status": 200,
                    "wall_seconds": 3.042744231002871,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 216.6,
                        "prompt_per_token_ms": 30.943,
                        "prompt_per_second": 32.3,
                        "predicted_n": 40,
                        "predicted_ms": 2824.2,
                        "predicted_per_token_ms": 70.605,
                        "predicted_per_second": 14.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-2",
                    "status": 200,
                    "wall_seconds": 2.9894735559937544,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 217.5,
                        "prompt_per_token_ms": 31.071,
                        "prompt_per_second": 32.2,
                        "predicted_n": 40,
                        "predicted_ms": 2770.4,
                        "predicted_per_token_ms": 69.26,
                        "predicted_per_second": 14.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-3",
                    "status": 200,
                    "wall_seconds": 3.049256616999628,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 217.7,
                        "prompt_per_token_ms": 31.1,
                        "prompt_per_second": 32.2,
                        "predicted_n": 40,
                        "predicted_ms": 2829.6,
                        "predicted_per_token_ms": 70.74,
                        "predicted_per_second": 14.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-4",
                    "status": 200,
                    "wall_seconds": 2.989480639997055,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 215.6,
                        "prompt_per_token_ms": 30.8,
                        "prompt_per_second": 32.5,
                        "predicted_n": 40,
                        "predicted_ms": 2771.4,
                        "predicted_per_token_ms": 69.285,
                        "predicted_per_second": 14.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-5",
                    "status": 200,
                    "wall_seconds": 3.0465121860033832,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 215.7,
                        "prompt_per_token_ms": 30.814,
                        "prompt_per_second": 32.5,
                        "predicted_n": 40,
                        "predicted_ms": 2828.8,
                        "predicted_per_token_ms": 70.72,
                        "predicted_per_second": 14.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                }
            ],
            "mtp": [
                {
                    "name": "first-cold",
                    "status": 200,
                    "wall_seconds": 4.335811240001931,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 4244.3,
                        "prompt_per_token_ms": 141.477,
                        "prompt_per_second": 7.1,
                        "predicted_n": 1,
                        "predicted_ms": 58.4,
                        "predicted_per_token_ms": 58.4,
                        "predicted_per_second": 17.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "first-warm",
                    "status": 200,
                    "wall_seconds": 0.2838992409961065,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 253,
                        "prompt_per_token_ms": 36.143,
                        "prompt_per_second": 27.7,
                        "predicted_n": 1,
                        "predicted_ms": 28.9,
                        "predicted_per_token_ms": 28.9,
                        "predicted_per_second": 34.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "first-stream",
                    "status": 200,
                    "wall_seconds": 0.2807564690010622,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 250.2,
                        "prompt_per_token_ms": 35.743,
                        "prompt_per_second": 28,
                        "predicted_n": 1,
                        "predicted_ms": 29,
                        "predicted_per_token_ms": 29,
                        "predicted_per_second": 34.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "disabled",
                    "status": 200,
                    "wall_seconds": 0.2816686580044916,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 252.7,
                        "prompt_per_token_ms": 36.1,
                        "prompt_per_second": 27.7,
                        "predicted_n": 1,
                        "predicted_ms": 27.3,
                        "predicted_per_token_ms": 27.3,
                        "predicted_per_second": 36.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "top-zero",
                    "status": 200,
                    "wall_seconds": 0.28944840299664065,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 258.9,
                        "prompt_per_token_ms": 36.986,
                        "prompt_per_second": 27,
                        "predicted_n": 1,
                        "predicted_ms": 28.9,
                        "predicted_per_token_ms": 28.9,
                        "predicted_per_second": 34.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "top-twenty",
                    "status": 200,
                    "wall_seconds": 0.2884112419997109,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 255.7,
                        "prompt_per_token_ms": 36.529,
                        "prompt_per_second": 27.4,
                        "predicted_n": 1,
                        "predicted_ms": 29.1,
                        "predicted_per_token_ms": 29.1,
                        "predicted_per_second": 34.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "invalid-stream",
                    "status": 400,
                    "wall_seconds": 0.004810276004718617
                },
                {
                    "name": "long",
                    "status": 200,
                    "wall_seconds": 5.34446821900201,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 32,
                        "prompt_ms": 1591.4,
                        "prompt_per_token_ms": 49.731,
                        "prompt_per_second": 20.1,
                        "predicted_n": 40,
                        "predicted_ms": 3735.2,
                        "predicted_per_token_ms": 93.38,
                        "predicted_per_second": 10.7,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "long-stream",
                    "status": 200,
                    "wall_seconds": 2.366953218996059,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 214.8,
                        "prompt_per_token_ms": 30.686,
                        "prompt_per_second": 32.6,
                        "predicted_n": 40,
                        "predicted_ms": 2150.4,
                        "predicted_per_token_ms": 53.76,
                        "predicted_per_second": 18.6,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "long-disabled",
                    "status": 200,
                    "wall_seconds": 2.2503626800025813,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 197.9,
                        "prompt_per_token_ms": 28.271,
                        "prompt_per_second": 35.4,
                        "predicted_n": 40,
                        "predicted_ms": 2050.7,
                        "predicted_per_token_ms": 51.267,
                        "predicted_per_second": 19.5,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "grammar-outside-top",
                    "status": 200,
                    "wall_seconds": 1.9066069130058168,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 970.2,
                        "prompt_per_token_ms": 32.34,
                        "prompt_per_second": 30.9,
                        "predicted_n": 2,
                        "predicted_ms": 86.2,
                        "predicted_per_token_ms": 43.1,
                        "predicted_per_second": 23.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 2,
                        "total_tokens": 32,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "grammar-unicode",
                    "status": 200,
                    "wall_seconds": 0.737644677006756,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 245.8,
                        "prompt_per_token_ms": 35.114,
                        "prompt_per_second": 28.5,
                        "predicted_n": 8,
                        "predicted_ms": 490,
                        "predicted_per_token_ms": 61.25,
                        "predicted_per_second": 16.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 8,
                        "total_tokens": 38,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-schema",
                    "status": 200,
                    "wall_seconds": 3.0187982149946038,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 106,
                        "prompt_ms": 2517.9,
                        "prompt_per_token_ms": 23.754,
                        "prompt_per_second": 42.1,
                        "predicted_n": 7,
                        "predicted_ms": 372.3,
                        "predicted_per_token_ms": 53.186,
                        "predicted_per_second": 18.8,
                        "draft_n": 4,
                        "draft_n_accepted": 4
                    },
                    "usage": {
                        "prompt_tokens": 106,
                        "completion_tokens": 7,
                        "total_tokens": 113,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-schema-stream",
                    "status": 200,
                    "wall_seconds": 0.5417176710034255,
                    "timings": {
                        "cache_n": 99,
                        "prompt_n": 7,
                        "prompt_ms": 245,
                        "prompt_per_token_ms": 35,
                        "prompt_per_second": 28.6,
                        "predicted_n": 7,
                        "predicted_ms": 293.4,
                        "predicted_per_token_ms": 41.914,
                        "predicted_per_second": 23.9,
                        "draft_n": 4,
                        "draft_n_accepted": 4
                    },
                    "usage": {
                        "prompt_tokens": 106,
                        "completion_tokens": 7,
                        "total_tokens": 113,
                        "prompt_tokens_details": {
                            "cached_tokens": 99
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-object",
                    "status": 200,
                    "wall_seconds": 1.2602861000050325,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 78,
                        "prompt_ms": 783.9,
                        "prompt_per_token_ms": 10.05,
                        "prompt_per_second": 99.5,
                        "predicted_n": 7,
                        "predicted_ms": 443.6,
                        "predicted_per_token_ms": 63.371,
                        "predicted_per_second": 15.8,
                        "draft_n": 6,
                        "draft_n_accepted": 3
                    },
                    "usage": {
                        "prompt_tokens": 78,
                        "completion_tokens": 7,
                        "total_tokens": 85,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-thinking",
                    "status": 200,
                    "wall_seconds": 2.4629064939945238,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 130,
                        "prompt_ms": 1113.6,
                        "prompt_per_token_ms": 8.566,
                        "prompt_per_second": 116.7,
                        "predicted_n": 25,
                        "predicted_ms": 1034.9,
                        "predicted_per_token_ms": 41.396,
                        "predicted_per_second": 24.2,
                        "draft_n": 23,
                        "draft_n_accepted": 13
                    },
                    "usage": {
                        "prompt_tokens": 130,
                        "completion_tokens": 25,
                        "total_tokens": 155,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "queued-0",
                    "status": 200,
                    "wall_seconds": 0.9537583180062938,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 922.3,
                        "prompt_per_token_ms": 30.743,
                        "prompt_per_second": 32.5,
                        "predicted_n": 1,
                        "predicted_ms": 28.9,
                        "predicted_per_token_ms": 28.9,
                        "predicted_per_second": 34.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "queued-1",
                    "status": 200,
                    "wall_seconds": 1.2302008350088727,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 246.8,
                        "prompt_per_token_ms": 35.257,
                        "prompt_per_second": 28.4,
                        "predicted_n": 1,
                        "predicted_ms": 28.8,
                        "predicted_per_token_ms": 28.8,
                        "predicted_per_second": 34.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-0",
                    "status": 200,
                    "wall_seconds": 2.7989499710092787,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 32,
                        "prompt_ms": 718.7,
                        "prompt_per_token_ms": 22.459,
                        "prompt_per_second": 44.5,
                        "predicted_n": 40,
                        "predicted_ms": 2078.5,
                        "predicted_per_token_ms": 51.962,
                        "predicted_per_second": 19.2,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-1",
                    "status": 200,
                    "wall_seconds": 2.3356987360020867,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 196.2,
                        "prompt_per_token_ms": 28.029,
                        "prompt_per_second": 35.7,
                        "predicted_n": 40,
                        "predicted_ms": 2137.3,
                        "predicted_per_token_ms": 53.433,
                        "predicted_per_second": 18.7,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-2",
                    "status": 200,
                    "wall_seconds": 2.289147242991021,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 200.1,
                        "prompt_per_token_ms": 28.586,
                        "prompt_per_second": 35,
                        "predicted_n": 40,
                        "predicted_ms": 2087.3,
                        "predicted_per_token_ms": 52.183,
                        "predicted_per_second": 19.2,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-3",
                    "status": 200,
                    "wall_seconds": 2.369935582013568,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 200.2,
                        "prompt_per_token_ms": 28.6,
                        "prompt_per_second": 35,
                        "predicted_n": 40,
                        "predicted_ms": 2167.6,
                        "predicted_per_token_ms": 54.19,
                        "predicted_per_second": 18.5,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-4",
                    "status": 200,
                    "wall_seconds": 2.2952523790008854,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 203.4,
                        "prompt_per_token_ms": 29.057,
                        "prompt_per_second": 34.4,
                        "predicted_n": 40,
                        "predicted_ms": 2089.8,
                        "predicted_per_token_ms": 52.245,
                        "predicted_per_second": 19.1,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-5",
                    "status": 200,
                    "wall_seconds": 2.34012413599703,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 200.1,
                        "prompt_per_token_ms": 28.586,
                        "prompt_per_second": 35,
                        "predicted_n": 40,
                        "predicted_ms": 2137.8,
                        "predicted_per_token_ms": 53.445,
                        "predicted_per_second": 18.7,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                }
            ],
            "suffix": [
                {
                    "name": "first-cold",
                    "status": 200,
                    "wall_seconds": 3.743048876989633,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 3629,
                        "prompt_per_token_ms": 120.967,
                        "prompt_per_second": 8.3,
                        "predicted_n": 1,
                        "predicted_ms": 81.8,
                        "predicted_per_token_ms": 81.8,
                        "predicted_per_second": 12.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "first-warm",
                    "status": 200,
                    "wall_seconds": 0.25664300499192905,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 214.4,
                        "prompt_per_token_ms": 30.629,
                        "prompt_per_second": 32.6,
                        "predicted_n": 1,
                        "predicted_ms": 40.2,
                        "predicted_per_token_ms": 40.2,
                        "predicted_per_second": 24.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "first-stream",
                    "status": 200,
                    "wall_seconds": 0.25379194600100163,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 211.3,
                        "prompt_per_token_ms": 30.186,
                        "prompt_per_second": 33.1,
                        "predicted_n": 1,
                        "predicted_ms": 40.9,
                        "predicted_per_token_ms": 40.9,
                        "predicted_per_second": 24.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "disabled",
                    "status": 200,
                    "wall_seconds": 0.26170475999242626,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 220.6,
                        "prompt_per_token_ms": 31.514,
                        "prompt_per_second": 31.7,
                        "predicted_n": 1,
                        "predicted_ms": 39.4,
                        "predicted_per_token_ms": 39.4,
                        "predicted_per_second": 25.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "top-zero",
                    "status": 200,
                    "wall_seconds": 0.2613056160043925,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 219.2,
                        "prompt_per_token_ms": 31.314,
                        "prompt_per_second": 31.9,
                        "predicted_n": 1,
                        "predicted_ms": 40.4,
                        "predicted_per_token_ms": 40.4,
                        "predicted_per_second": 24.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "top-twenty",
                    "status": 200,
                    "wall_seconds": 0.2554651009995723,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 211.6,
                        "prompt_per_token_ms": 30.229,
                        "prompt_per_second": 33.1,
                        "predicted_n": 1,
                        "predicted_ms": 40.9,
                        "predicted_per_token_ms": 40.9,
                        "predicted_per_second": 24.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "invalid-stream",
                    "status": 400,
                    "wall_seconds": 0.0051411029999144375
                },
                {
                    "name": "long",
                    "status": 200,
                    "wall_seconds": 5.192459993995726,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 32,
                        "prompt_ms": 1547.2,
                        "prompt_per_token_ms": 48.35,
                        "prompt_per_second": 20.7,
                        "predicted_n": 40,
                        "predicted_ms": 3627.3,
                        "predicted_per_token_ms": 90.683,
                        "predicted_per_second": 11,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "long-stream",
                    "status": 200,
                    "wall_seconds": 2.3097088340000482,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 169.3,
                        "prompt_per_token_ms": 24.186,
                        "prompt_per_second": 41.3,
                        "predicted_n": 40,
                        "predicted_ms": 2138.6,
                        "predicted_per_token_ms": 53.465,
                        "predicted_per_second": 18.7,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "long-disabled",
                    "status": 200,
                    "wall_seconds": 2.2419437170028687,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 169.9,
                        "prompt_per_token_ms": 24.271,
                        "prompt_per_second": 41.2,
                        "predicted_n": 40,
                        "predicted_ms": 2070.1,
                        "predicted_per_token_ms": 51.752,
                        "predicted_per_second": 19.3,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "grammar-outside-top",
                    "status": 200,
                    "wall_seconds": 1.7840636430046288,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 837.2,
                        "prompt_per_token_ms": 27.907,
                        "prompt_per_second": 35.8,
                        "predicted_n": 2,
                        "predicted_ms": 99.2,
                        "predicted_per_token_ms": 49.6,
                        "predicted_per_second": 20.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 2,
                        "total_tokens": 32,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "grammar-unicode",
                    "status": 200,
                    "wall_seconds": 0.6897773230011808,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 203,
                        "prompt_per_token_ms": 29,
                        "prompt_per_second": 34.5,
                        "predicted_n": 8,
                        "predicted_ms": 485,
                        "predicted_per_token_ms": 60.625,
                        "predicted_per_second": 16.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 8,
                        "total_tokens": 38,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-schema",
                    "status": 200,
                    "wall_seconds": 2.8700094149971846,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 106,
                        "prompt_ms": 2334.9,
                        "prompt_per_token_ms": 22.027,
                        "prompt_per_second": 45.4,
                        "predicted_n": 7,
                        "predicted_ms": 412,
                        "predicted_per_token_ms": 58.857,
                        "predicted_per_second": 17,
                        "draft_n": 4,
                        "draft_n_accepted": 4
                    },
                    "usage": {
                        "prompt_tokens": 106,
                        "completion_tokens": 7,
                        "total_tokens": 113,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-schema-stream",
                    "status": 200,
                    "wall_seconds": 0.5158538510004291,
                    "timings": {
                        "cache_n": 99,
                        "prompt_n": 7,
                        "prompt_ms": 199.8,
                        "prompt_per_token_ms": 28.543,
                        "prompt_per_second": 35,
                        "predicted_n": 7,
                        "predicted_ms": 313.3,
                        "predicted_per_token_ms": 44.757,
                        "predicted_per_second": 22.3,
                        "draft_n": 4,
                        "draft_n_accepted": 4
                    },
                    "usage": {
                        "prompt_tokens": 106,
                        "completion_tokens": 7,
                        "total_tokens": 113,
                        "prompt_tokens_details": {
                            "cached_tokens": 99
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-object",
                    "status": 200,
                    "wall_seconds": 1.267841558001237,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 78,
                        "prompt_ms": 765.7,
                        "prompt_per_token_ms": 9.817,
                        "prompt_per_second": 101.9,
                        "predicted_n": 7,
                        "predicted_ms": 455.8,
                        "predicted_per_token_ms": 65.114,
                        "predicted_per_second": 15.4,
                        "draft_n": 6,
                        "draft_n_accepted": 3
                    },
                    "usage": {
                        "prompt_tokens": 78,
                        "completion_tokens": 7,
                        "total_tokens": 85,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-thinking",
                    "status": 200,
                    "wall_seconds": 2.483140401993296,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 130,
                        "prompt_ms": 1123.2,
                        "prompt_per_token_ms": 8.64,
                        "prompt_per_second": 115.7,
                        "predicted_n": 25,
                        "predicted_ms": 1044.5,
                        "predicted_per_token_ms": 41.78,
                        "predicted_per_second": 23.9,
                        "draft_n": 23,
                        "draft_n_accepted": 13
                    },
                    "usage": {
                        "prompt_tokens": 130,
                        "completion_tokens": 25,
                        "total_tokens": 155,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "queued-0",
                    "status": 200,
                    "wall_seconds": 0.8836371259967564,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 836.8,
                        "prompt_per_token_ms": 27.893,
                        "prompt_per_second": 35.9,
                        "predicted_n": 1,
                        "predicted_ms": 40.5,
                        "predicted_per_token_ms": 40.5,
                        "predicted_per_second": 24.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "queued-1",
                    "status": 200,
                    "wall_seconds": 1.131297915999312,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 210.8,
                        "prompt_per_token_ms": 30.114,
                        "prompt_per_second": 33.2,
                        "predicted_n": 1,
                        "predicted_ms": 40.5,
                        "predicted_per_token_ms": 40.5,
                        "predicted_per_second": 24.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-0",
                    "status": 200,
                    "wall_seconds": 2.8493555470049614,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 32,
                        "prompt_ms": 723,
                        "prompt_per_token_ms": 22.594,
                        "prompt_per_second": 44.3,
                        "predicted_n": 40,
                        "predicted_ms": 2124.5,
                        "predicted_per_token_ms": 53.112,
                        "predicted_per_second": 18.8,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-1",
                    "status": 200,
                    "wall_seconds": 2.3505121499911183,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 174.5,
                        "prompt_per_token_ms": 24.929,
                        "prompt_per_second": 40.1,
                        "predicted_n": 40,
                        "predicted_ms": 2173.8,
                        "predicted_per_token_ms": 54.345,
                        "predicted_per_second": 18.4,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-2",
                    "status": 200,
                    "wall_seconds": 2.2554054929933045,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 173.8,
                        "prompt_per_token_ms": 24.829,
                        "prompt_per_second": 40.3,
                        "predicted_n": 40,
                        "predicted_ms": 2079.8,
                        "predicted_per_token_ms": 51.995,
                        "predicted_per_second": 19.2,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-3",
                    "status": 200,
                    "wall_seconds": 2.305316726997262,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 167.8,
                        "prompt_per_token_ms": 23.971,
                        "prompt_per_second": 41.7,
                        "predicted_n": 40,
                        "predicted_ms": 2135.4,
                        "predicted_per_token_ms": 53.385,
                        "predicted_per_second": 18.7,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-4",
                    "status": 200,
                    "wall_seconds": 2.229223522997927,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 168.1,
                        "prompt_per_token_ms": 24.014,
                        "prompt_per_second": 41.6,
                        "predicted_n": 40,
                        "predicted_ms": 2059.2,
                        "predicted_per_token_ms": 51.48,
                        "predicted_per_second": 19.4,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-5",
                    "status": 200,
                    "wall_seconds": 2.364989355992293,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 167.7,
                        "prompt_per_token_ms": 23.957,
                        "prompt_per_second": 41.7,
                        "predicted_n": 40,
                        "predicted_ms": 2194.7,
                        "predicted_per_token_ms": 54.867,
                        "predicted_per_second": 18.2,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                }
            ],
            "coupled": [
                {
                    "name": "first-cold",
                    "status": 200,
                    "wall_seconds": 4.408020898990799,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 4323.3,
                        "prompt_per_token_ms": 144.11,
                        "prompt_per_second": 6.9,
                        "predicted_n": 1,
                        "predicted_ms": 58,
                        "predicted_per_token_ms": 58,
                        "predicted_per_second": 17.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "first-warm",
                    "status": 200,
                    "wall_seconds": 0.2798958310013404,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 249.1,
                        "prompt_per_token_ms": 35.586,
                        "prompt_per_second": 28.1,
                        "predicted_n": 1,
                        "predicted_ms": 29.1,
                        "predicted_per_token_ms": 29.1,
                        "predicted_per_second": 34.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "first-stream",
                    "status": 200,
                    "wall_seconds": 0.27803557700826786,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 247.4,
                        "prompt_per_token_ms": 35.343,
                        "prompt_per_second": 28.3,
                        "predicted_n": 1,
                        "predicted_ms": 29.1,
                        "predicted_per_token_ms": 29.1,
                        "predicted_per_second": 34.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "disabled",
                    "status": 200,
                    "wall_seconds": 0.2849379490071442,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 255.5,
                        "prompt_per_token_ms": 36.5,
                        "prompt_per_second": 27.4,
                        "predicted_n": 1,
                        "predicted_ms": 27.8,
                        "predicted_per_token_ms": 27.8,
                        "predicted_per_second": 36,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "top-zero",
                    "status": 200,
                    "wall_seconds": 0.27855499400175177,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 247.9,
                        "prompt_per_token_ms": 35.414,
                        "prompt_per_second": 28.2,
                        "predicted_n": 1,
                        "predicted_ms": 29,
                        "predicted_per_token_ms": 29,
                        "predicted_per_second": 34.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "top-twenty",
                    "status": 200,
                    "wall_seconds": 0.2818963359895861,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 249.5,
                        "prompt_per_token_ms": 35.643,
                        "prompt_per_second": 28.1,
                        "predicted_n": 1,
                        "predicted_ms": 29.2,
                        "predicted_per_token_ms": 29.2,
                        "predicted_per_second": 34.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "invalid-stream",
                    "status": 400,
                    "wall_seconds": 0.003985650997492485
                },
                {
                    "name": "long",
                    "status": 200,
                    "wall_seconds": 5.988298419993953,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 32,
                        "prompt_ms": 2203.9,
                        "prompt_per_token_ms": 68.872,
                        "prompt_per_second": 14.5,
                        "predicted_n": 40,
                        "predicted_ms": 3768.1,
                        "predicted_per_token_ms": 94.203,
                        "predicted_per_second": 10.6,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "long-stream",
                    "status": 200,
                    "wall_seconds": 2.3296717850025743,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 200.5,
                        "prompt_per_token_ms": 28.643,
                        "prompt_per_second": 34.9,
                        "predicted_n": 40,
                        "predicted_ms": 2127.5,
                        "predicted_per_token_ms": 53.188,
                        "predicted_per_second": 18.8,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "long-disabled",
                    "status": 200,
                    "wall_seconds": 2.2623917710006936,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 201,
                        "prompt_per_token_ms": 28.714,
                        "prompt_per_second": 34.8,
                        "predicted_n": 40,
                        "predicted_ms": 2059.5,
                        "predicted_per_token_ms": 51.487,
                        "predicted_per_second": 19.4,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "grammar-outside-top",
                    "status": 200,
                    "wall_seconds": 1.9021561179979471,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 961.1,
                        "prompt_per_token_ms": 32.037,
                        "prompt_per_second": 31.2,
                        "predicted_n": 2,
                        "predicted_ms": 85.4,
                        "predicted_per_token_ms": 42.7,
                        "predicted_per_second": 23.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 2,
                        "total_tokens": 32,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "grammar-unicode",
                    "status": 200,
                    "wall_seconds": 0.7363968769932399,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 251.9,
                        "prompt_per_token_ms": 35.986,
                        "prompt_per_second": 27.8,
                        "predicted_n": 8,
                        "predicted_ms": 482.7,
                        "predicted_per_token_ms": 60.337,
                        "predicted_per_second": 16.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 8,
                        "total_tokens": 38,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-schema",
                    "status": 200,
                    "wall_seconds": 3.1511175930063473,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 106,
                        "prompt_ms": 2591.1,
                        "prompt_per_token_ms": 24.444,
                        "prompt_per_second": 40.9,
                        "predicted_n": 7,
                        "predicted_ms": 439.9,
                        "predicted_per_token_ms": 62.843,
                        "predicted_per_second": 15.9,
                        "draft_n": 3,
                        "draft_n_accepted": 3
                    },
                    "usage": {
                        "prompt_tokens": 106,
                        "completion_tokens": 7,
                        "total_tokens": 113,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-schema-stream",
                    "status": 200,
                    "wall_seconds": 0.5652979040023638,
                    "timings": {
                        "cache_n": 99,
                        "prompt_n": 7,
                        "prompt_ms": 250.3,
                        "prompt_per_token_ms": 35.757,
                        "prompt_per_second": 28,
                        "predicted_n": 7,
                        "predicted_ms": 311.7,
                        "predicted_per_token_ms": 44.529,
                        "predicted_per_second": 22.5,
                        "draft_n": 3,
                        "draft_n_accepted": 3
                    },
                    "usage": {
                        "prompt_tokens": 106,
                        "completion_tokens": 7,
                        "total_tokens": 113,
                        "prompt_tokens_details": {
                            "cached_tokens": 99
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-object",
                    "status": 200,
                    "wall_seconds": 1.4271969649998937,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 78,
                        "prompt_ms": 939.5,
                        "prompt_per_token_ms": 12.045,
                        "prompt_per_second": 83,
                        "predicted_n": 6,
                        "predicted_ms": 454.2,
                        "predicted_per_token_ms": 75.7,
                        "predicted_per_second": 13.2,
                        "draft_n": 6,
                        "draft_n_accepted": 2
                    },
                    "usage": {
                        "prompt_tokens": 78,
                        "completion_tokens": 6,
                        "total_tokens": 84,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "json-thinking",
                    "status": 200,
                    "wall_seconds": 2.61798802499834,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 130,
                        "prompt_ms": 1263.9,
                        "prompt_per_token_ms": 9.722,
                        "prompt_per_second": 102.9,
                        "predicted_n": 25,
                        "predicted_ms": 1039.5,
                        "predicted_per_token_ms": 41.58,
                        "predicted_per_second": 24.1,
                        "draft_n": 20,
                        "draft_n_accepted": 14
                    },
                    "usage": {
                        "prompt_tokens": 130,
                        "completion_tokens": 25,
                        "total_tokens": 155,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "stop"
                },
                {
                    "name": "queued-0",
                    "status": 200,
                    "wall_seconds": 1.0093507730052806,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 30,
                        "prompt_ms": 977.4,
                        "prompt_per_token_ms": 32.58,
                        "prompt_per_second": 30.7,
                        "predicted_n": 1,
                        "predicted_ms": 29.2,
                        "predicted_per_token_ms": 29.2,
                        "predicted_per_second": 34.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "queued-1",
                    "status": 200,
                    "wall_seconds": 1.2933108410070417,
                    "timings": {
                        "cache_n": 23,
                        "prompt_n": 7,
                        "prompt_ms": 254.9,
                        "prompt_per_token_ms": 36.414,
                        "prompt_per_second": 27.5,
                        "predicted_n": 1,
                        "predicted_ms": 29.3,
                        "predicted_per_token_ms": 29.3,
                        "predicted_per_second": 34.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    },
                    "usage": {
                        "prompt_tokens": 30,
                        "completion_tokens": 1,
                        "total_tokens": 31,
                        "prompt_tokens_details": {
                            "cached_tokens": 23
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-0",
                    "status": 200,
                    "wall_seconds": 2.9126580849988386,
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 32,
                        "prompt_ms": 805.5,
                        "prompt_per_token_ms": 25.172,
                        "prompt_per_second": 39.7,
                        "predicted_n": 40,
                        "predicted_ms": 2104.9,
                        "predicted_per_token_ms": 52.623,
                        "predicted_per_second": 19,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-1",
                    "status": 200,
                    "wall_seconds": 2.327524035994429,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 203.7,
                        "prompt_per_token_ms": 29.1,
                        "prompt_per_second": 34.4,
                        "predicted_n": 40,
                        "predicted_ms": 2121.8,
                        "predicted_per_token_ms": 53.045,
                        "predicted_per_second": 18.9,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-2",
                    "status": 200,
                    "wall_seconds": 2.2437963370030047,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 196.7,
                        "prompt_per_token_ms": 28.1,
                        "prompt_per_second": 35.6,
                        "predicted_n": 40,
                        "predicted_ms": 2045.4,
                        "predicted_per_token_ms": 51.135,
                        "predicted_per_second": 19.6,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-3",
                    "status": 200,
                    "wall_seconds": 2.3361917860020185,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 196,
                        "prompt_per_token_ms": 28,
                        "prompt_per_second": 35.7,
                        "predicted_n": 40,
                        "predicted_ms": 2138.2,
                        "predicted_per_token_ms": 53.455,
                        "predicted_per_second": 18.7,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-4",
                    "status": 200,
                    "wall_seconds": 2.2917260009999154,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 200.4,
                        "prompt_per_token_ms": 28.629,
                        "prompt_per_second": 34.9,
                        "predicted_n": 40,
                        "predicted_ms": 2089.6,
                        "predicted_per_token_ms": 52.24,
                        "predicted_per_second": 19.1,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                },
                {
                    "name": "cost-5",
                    "status": 200,
                    "wall_seconds": 2.3203978179953992,
                    "timings": {
                        "cache_n": 25,
                        "prompt_n": 7,
                        "prompt_ms": 200.7,
                        "prompt_per_token_ms": 28.671,
                        "prompt_per_second": 34.9,
                        "predicted_n": 40,
                        "predicted_ms": 2117.5,
                        "predicted_per_token_ms": 52.938,
                        "predicted_per_second": 18.9,
                        "draft_n": 29,
                        "draft_n_accepted": 29
                    },
                    "usage": {
                        "prompt_tokens": 32,
                        "completion_tokens": 40,
                        "total_tokens": 72,
                        "prompt_tokens_details": {
                            "cached_tokens": 25
                        }
                    },
                    "finish": "length"
                }
            ]
        },
        "suffix_windows": [
            {
                "type": "verification",
                "request": 1,
                "window": 3,
                "position": 230,
                "proposal_source": "suffix",
                "probability_source": "target_raw_full_vocabulary",
                "target_vocab": 248320,
                "scored_length": 5,
                "proposed_length": 5,
                "complete": True,
                "retained_outputs": 2,
                "accepted_proposals": 1,
                "termination_included": True,
                "proposal": [
                    {
                        "token_id": 17972,
                        "target_logprob": -0.00004695283380987346
                    },
                    {
                        "token_id": 248046,
                        "target_logprob": -6.401661747509954
                    },
                    {
                        "token_id": 198,
                        "target_logprob": -0.000007283372403705539
                    },
                    {
                        "token_id": 248045,
                        "target_logprob": -0.08782798921558677
                    },
                    {
                        "token_id": 74455,
                        "target_logprob": -6.35783456561247
                    }
                ],
                "target_sequence_logprob": -12.847378538544225,
                "emitted": [
                    {
                        "token_id": 17972,
                        "logprob": -0.00004695283380987346
                    },
                    {
                        "token_id": 198,
                        "logprob": -0.010306232983586613
                    }
                ]
            },
            {
                "type": "verification",
                "request": 1,
                "window": 5,
                "position": 236,
                "proposal_source": "suffix",
                "probability_source": "target_raw_full_vocabulary",
                "target_vocab": 248320,
                "scored_length": 5,
                "proposed_length": 5,
                "complete": True,
                "retained_outputs": 6,
                "accepted_proposals": 5,
                "termination_included": False,
                "proposal": [
                    {
                        "token_id": 30183,
                        "target_logprob": -0.000005859300842602124
                    },
                    {
                        "token_id": 1110,
                        "target_logprob": -0.000006448221039338068
                    },
                    {
                        "token_id": 1850,
                        "target_logprob": -0.0000021042220500667507
                    },
                    {
                        "token_id": 37705,
                        "target_logprob": -0.000007464756741085219
                    },
                    {
                        "token_id": 17972,
                        "target_logprob": -0.000014317656518479983
                    }
                ],
                "target_sequence_logprob": -0.00003619415719157215,
                "emitted": [
                    {
                        "token_id": 30183,
                        "logprob": -0.000005859300842602124
                    },
                    {
                        "token_id": 1110,
                        "logprob": -0.000006448221039338068
                    },
                    {
                        "token_id": 1850,
                        "logprob": -0.0000021042220500667507
                    },
                    {
                        "token_id": 37705,
                        "logprob": -0.000007464756741085219
                    },
                    {
                        "token_id": 17972,
                        "logprob": -0.000014317656518479983
                    },
                    {
                        "token_id": 198,
                        "logprob": -0.0018230463573914852
                    }
                ]
            },
            {
                "type": "verification",
                "request": 1,
                "window": 6,
                "position": 242,
                "proposal_source": "suffix",
                "probability_source": "target_raw_full_vocabulary",
                "target_vocab": 248320,
                "scored_length": 5,
                "proposed_length": 5,
                "complete": True,
                "retained_outputs": 6,
                "accepted_proposals": 5,
                "termination_included": False,
                "proposal": [
                    {
                        "token_id": 6918,
                        "target_logprob": -0.000016784419523075086
                    },
                    {
                        "token_id": 13053,
                        "target_logprob": -0.000003898082630626486
                    },
                    {
                        "token_id": 20956,
                        "target_logprob": -0.000007741537565692548
                    },
                    {
                        "token_id": 9197,
                        "target_logprob": -0.00000592198336845741
                    },
                    {
                        "token_id": 30183,
                        "target_logprob": -0.000008235113527112893
                    }
                ],
                "target_sequence_logprob": -0.00004258113661496442,
                "emitted": [
                    {
                        "token_id": 6918,
                        "logprob": -0.000016784419523075086
                    },
                    {
                        "token_id": 13053,
                        "logprob": -0.000003898082630626486
                    },
                    {
                        "token_id": 20956,
                        "logprob": -0.000007741537565692548
                    },
                    {
                        "token_id": 9197,
                        "logprob": -0.00000592198336845741
                    },
                    {
                        "token_id": 30183,
                        "logprob": -0.000008235113527112893
                    },
                    {
                        "token_id": 1110,
                        "logprob": -0.000006995662283961121
                    }
                ]
            },
            {
                "type": "verification",
                "request": 1,
                "window": 7,
                "position": 248,
                "proposal_source": "suffix",
                "probability_source": "target_raw_full_vocabulary",
                "target_vocab": 248320,
                "scored_length": 5,
                "proposed_length": 5,
                "complete": True,
                "retained_outputs": 4,
                "accepted_proposals": 3,
                "termination_included": True,
                "proposal": [
                    {
                        "token_id": 1850,
                        "target_logprob": -0.000002845705945289656
                    },
                    {
                        "token_id": 37705,
                        "target_logprob": -0.000011000037974127575
                    },
                    {
                        "token_id": 17972,
                        "target_logprob": -0.000010416635089986065
                    },
                    {
                        "token_id": 248046,
                        "target_logprob": -6.658037102266969
                    },
                    {
                        "token_id": 198,
                        "target_logprob": -0.0000063871202451313645
                    }
                ],
                "target_sequence_logprob": -6.6580677517662235,
                "emitted": [
                    {
                        "token_id": 1850,
                        "logprob": -0.000002845705945289656
                    },
                    {
                        "token_id": 37705,
                        "logprob": -0.000011000037974127575
                    },
                    {
                        "token_id": 17972,
                        "logprob": -0.000010416635089986065
                    },
                    {
                        "token_id": 198,
                        "logprob": -0.001333153292359517
                    }
                ]
            },
            {
                "type": "verification",
                "request": 2,
                "window": 41,
                "position": 234,
                "proposal_source": "suffix",
                "probability_source": "target_raw_full_vocabulary",
                "target_vocab": 248320,
                "scored_length": 5,
                "proposed_length": 5,
                "complete": True,
                "retained_outputs": 6,
                "accepted_proposals": 5,
                "termination_included": False,
                "proposal": [
                    {
                        "token_id": 20956,
                        "target_logprob": -0.000009819354236470439
                    },
                    {
                        "token_id": 9197,
                        "target_logprob": -0.000010652092801142392
                    },
                    {
                        "token_id": 30183,
                        "target_logprob": -0.000006486933955186751
                    },
                    {
                        "token_id": 1110,
                        "target_logprob": -0.000007565864636673216
                    },
                    {
                        "token_id": 1850,
                        "target_logprob": -0.000002586288925897593
                    }
                ],
                "target_sequence_logprob": -0.00003711053455537039,
                "emitted": [
                    {
                        "token_id": 20956,
                        "logprob": -0.000009819354236470439
                    },
                    {
                        "token_id": 9197,
                        "logprob": -0.000010652092801142392
                    },
                    {
                        "token_id": 30183,
                        "logprob": -0.000006486933955186751
                    },
                    {
                        "token_id": 1110,
                        "logprob": -0.000007565864636673216
                    },
                    {
                        "token_id": 1850,
                        "logprob": -0.000002586288925897593
                    },
                    {
                        "token_id": 37705,
                        "logprob": -0.000007591863108629031
                    }
                ]
            },
            {
                "type": "verification",
                "request": 2,
                "window": 42,
                "position": 240,
                "proposal_source": "suffix",
                "probability_source": "target_raw_full_vocabulary",
                "target_vocab": 248320,
                "scored_length": 1,
                "proposed_length": 5,
                "complete": False,
                "retained_outputs": 2,
                "accepted_proposals": 1,
                "termination_included": False,
                "proposal": [
                    {
                        "token_id": 17972,
                        "target_logprob": -0.000015941286119641792
                    }
                ],
                "target_sequence_logprob": -0.000015941286119641792,
                "emitted": [
                    {
                        "token_id": 17972,
                        "logprob": -0.000015941286119641792
                    },
                    {
                        "token_id": 198,
                        "logprob": -0.0019540052234433706
                    }
                ]
            },
            {
                "type": "verification",
                "request": 2,
                "window": 43,
                "position": 242,
                "proposal_source": "suffix",
                "probability_source": "target_raw_full_vocabulary",
                "target_vocab": 248320,
                "scored_length": 5,
                "proposed_length": 5,
                "complete": True,
                "retained_outputs": 6,
                "accepted_proposals": 5,
                "termination_included": False,
                "proposal": [
                    {
                        "token_id": 6918,
                        "target_logprob": -0.000013483135745301728
                    },
                    {
                        "token_id": 13053,
                        "target_logprob": -0.000003421312884731189
                    },
                    {
                        "token_id": 20956,
                        "target_logprob": -0.000007147982202372404
                    },
                    {
                        "token_id": 9197,
                        "target_logprob": -0.000006235390233618862
                    },
                    {
                        "token_id": 30183,
                        "target_logprob": -0.000008624354503393812
                    }
                ],
                "target_sequence_logprob": -0.000038912175569417995,
                "emitted": [
                    {
                        "token_id": 6918,
                        "logprob": -0.000013483135745301728
                    },
                    {
                        "token_id": 13053,
                        "logprob": -0.000003421312884731189
                    },
                    {
                        "token_id": 20956,
                        "logprob": -0.000007147982202372404
                    },
                    {
                        "token_id": 9197,
                        "logprob": -0.000006235390233618862
                    },
                    {
                        "token_id": 30183,
                        "logprob": -0.000008624354503393812
                    },
                    {
                        "token_id": 1110,
                        "logprob": -0.0000069804879138810346
                    }
                ]
            }
        ],
        "evidence": "/api/evidence/speculation"
    },
    "lesson": {
        "question": "Why can a draft be rejected?",
        "rule": "Compare the proposal head and target verification on the same proposed token. They are different distributions.",
        "knob": "Proposal position (zero-based)",
        "default": 0,
        "compare": 2,
        "low": 0,
        "high": 10000,
        "integer": True,
        "states": [
            {
                "value": 0,
                "summary": "Proposal token 1110: the two heads differ by 0.0001 log units.",
                "rows": [
                    {
                        "label": "Draft head",
                        "value": 0.999999523
                    },
                    {
                        "label": "Target verification",
                        "value": 0.9999465188700544
                    }
                ],
                "unit": "probability / distinct heads",
                "metrics": {
                    "token_id": 1110,
                    "target_sequence_logprob": -12.361747610887669,
                    "draft_target_logprob_gap": 0.00005300572284038928
                },
                "note": "Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability."
            },
            {
                "value": 2,
                "summary": "Proposal token 198: the two heads differ by 11.7152 log units.",
                "rows": [
                    {
                        "label": "Draft head",
                        "value": 0.523891985
                    },
                    {
                        "label": "Target verification",
                        "value": 0.000004279433539807052
                    }
                ],
                "unit": "probability / distinct heads",
                "metrics": {
                    "token_id": 198,
                    "target_sequence_logprob": -12.361747610887669,
                    "draft_target_logprob_gap": 11.715220157030766
                },
                "note": "Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability."
            }
        ],
        "input_excerpt": "",
        "scope": "This panel and its Python calculation reproduce saved measurements. Other page controls are independent views."
    },
    "receipt": {
        "mode": "recorded",
        "requests": 0,
        "summed_request_ms": 0,
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "calls": []
    },
    "wall_ms": 6.01240003015846,
    "lesson_view": {
        "index": 0,
        "value": 0,
        "scope": "Reproduce the selected question/rule/result panel. Other page dials are independent."
    }
}
import argparse
import copy
import hashlib
import json
import math
import os
import sys
from pathlib import Path
import urllib.error
import urllib.request

"""Small, portable calculations behind the question/rule/result panels.

Standard library only. This exact source is included in every Python download.
Inputs are the captured experiment, never an invented new model response. A knob
changes a disclosed calculation on those inputs; it does not rescore a new prompt.
"""
import itertools
import math
import statistics


def _spec(question, rule, knob, default, compare, low, high, integer=False):
    return dict(question=question, rule=rule, knob=knob, default=default,
                compare=compare, low=low, high=high, integer=integer)


LESSON_SPECS = {
    'choice': _spec('Which ticket queue gets this message?', 'Compare the three saved label scores. Heat flattens their relative weights; it adds no evidence.', 'Reweighting temperature', 1, 2, .1, 3),
    'boolean': _spec('Does this message ask to cancel?', 'Normalize the saved Yes and No scores. A number near one is a strong preference, not proof.', 'Reweighting temperature', 1, 2, .1, 3),
    'score': _spec('How serious is the outage?', 'Multiply each rubric value by its answer weight, then add. The rating comes from the whole distribution.', 'Reweighting temperature', 1, 2, .1, 3),
    'candidates': _spec('Read the failure first, or start changing things?', 'Add token logprobs along each saved path, then sum path mass inside each finite group. A length penalty changes the objective.', 'Length penalty exponent', 0, 1, 0, 1),
    'controller': _spec('May the simulated repair take its next step?', 'Keep only state-legal actions. Hold the recorded action if its relative legal weight falls below the threshold.', 'Required legal-action weight', 0, .999, 0, 1),
    'rerank': _spec('Which sources help explain cancellation?', 'Compute each source’s expected relevance separately, then keep those above the cutoff.', 'Minimum relevance', 0, .9, 0, 1),
    'graph': _spec('Which text links can coexist?', 'Search every small edge subset. Reject cycles and competing attachments, then maximize useful edge weight.', 'Edge cost / threshold', .5, .9, .01, .99),
    'scene': _spec('Which valid drawing best fits the instruction?', 'Average the three saved text probes. Optionally charge for disagreement between them; code still checks geometry.', 'Disagreement penalty', 0, 1, 0, 2),
    'wire': _spec('What did the model assign to this actual token?', 'Exponentiate its raw logprob. Sum only the reported alternatives; their top-N list may omit probability mass.', 'Visible token index (zero-based)', 0, 5, 0, 10000, True),
    'speculation': _spec('Why can a draft be rejected?', 'Compare the proposal head and target verification on the same proposed token. They are different distributions.', 'Proposal position (zero-based)', 0, 2, 0, 10000, True),
    'performance': _spec('What did each API path cost on this setup?', 'Recalculate a latency percentile from the original wall-time samples. Different output tasks remain separate.', 'Latency percentile', 50, 90, 0, 100),
    'samplers': _spec('How much did this recipe change the selected token’s weight?', 'Compare its raw target probability with its post-sampler probability. Read support and entropy from the complete native row.', 'Recorded recipe index (zero-based)', 0, 1, 0, 10000, True),
    'sampler-sandbox': _spec('Can we add heat without admitting implausible tokens?', 'Remove logits below max + log(0.05), then divide the survivors by temperature and normalize.', 'Temperature after Min-P', 1.5, .7, .1, 3),
    'tictactoe': _spec('Did a legal move give away a winnable outcome?', 'Solve the saved position by exhaustive minimax. Compare the best legal outcome with the recorded model move.', 'Recorded turn index (zero-based)', 0, 1, 0, 10000, True),
    'chess': _spec('Did the shortlist favor a mating move?', 'Add the saved label weights attached to code-checked mating moves. The separately generated UCI move uses a different prompt.', 'Shortlist temperature', 1, 3, .1, 3),
    'poker': _spec('Should this hand check or bet?', 'Average exact chip payoffs over the two possible opponent cards using the stated calling policy.', 'Opponent call-rate multiplier', 1, 0, 0, 2),
    'thermal': _spec('What happens if we replay the fan commands differently?', 'Step the disclosed thermal equation through the same loads. A fan offset is an open-loop counterfactual, not a new model policy.', 'Fan offset', 0, 20, -60, 60),
    'scheduler': _spec('How much lateness did this legal schedule cause?', 'Add job durations in the recorded order and check dependencies. Charge for finishing after the adjusted deadline.', 'Deadline shift', 0, -3, -10, 10),
    'context': _spec('Did replacing old text change the current-state answer?', 'Recalculate each saved Yes/No distribution and compare the selected wording with the original append-only prompt.', 'Context variant index (zero-based)', 0, 2, 0, 10000, True),
    'observer': _spec('Which action follows from these three semantic measurements?', 'Apply the same explicit threshold rule to every saved report: inspect, verify, finish, or ask.', 'Decision threshold', .5, .999, 0, 1),
    'calibration': _spec('Does demanding stronger answers leave enough coverage?', 'Recalculate Brier error on all six examples and accuracy only on retained examples. Empty coverage has no accuracy.', 'Required answer weight', .5, 1, .5, 1),
    'information': _spec('Which observation is worth buying?', 'Use the stated sensor likelihoods to compute both Bayesian posteriors and expected entropy reduction.', 'Test index (zero-based)', 0, 1, 0, 10000, True),
    'search': _spec('Which valid scene survives a cost penalty?', 'Subtract the chosen cost charge from each saved semantic weight. Reject invalid geometry before ranking.', 'Cost weight', .1, 1, 0, 1),
    'frontier': _spec('Would faster score transfer matter here?', 'Add assumed forward time, a transfer lower bound, and the measured selector. This is a serial cost sketch.', 'Assumed transfer GB/s', 12, 2, .1, 128),
    'research-map': _spec('What would make this research idea testable?', 'Count the disclosed implementation categories, then reveal one branch’s next gate. A proposal is not a native result.', 'Branch index (zero-based)', 0, 12, 0, 10000, True),
    'pressure': _spec('How much original mass did this boundary throw away?', 'At temperature 1 with pure masking, log Z = raw selected logprob − log(selected masked probability). Pressure is −log Z.', 'Native grammar index (zero-based)', 0, 1, 0, 10000, True),
    'circuit': _spec('Can we compute AND without assuming independence?', 'Start with four joint worlds. Optionally condition on noisy evidence of style, then add worlds for each logical operation.', 'Reliability of observing style', .5, 1, .5, 1),
    'control': _spec('Can preference change while forbidden actions stay forbidden?', 'Normalize log(base) + strength × [log(desired) − log(undesired)] inside the legal set.', 'Control strength', 0, 2, 0, 3),
    'future': _spec('Can a less likely first move have a better future?', 'Weight the root policy by exact future success raised to strength. At strength zero use the base policy.', 'Future-value strength', 0, 1, 0, 2),
    'sensitivity': _spec('Which prompt intervention moves this measurement?', 'Rebuild the central finite-difference matrix. Predict a change in hours, with load fixed at +5 points; preserve the measured holdout error.', 'Change in hours remaining', -1, -2, -2, 2),
    'counterexamples': _spec('Can equivalent algebra confuse the observer?', 'Find the equivalent pair with the largest measured log-odds distance. Evaluate its exact coefficients at the chosen integer.', 'Integer x', 2, -2, -10, 10, True),
}


def normalize_logs(logs):
    finite = [x for x in logs if math.isfinite(x)]
    if not finite:
        raise ValueError('No candidate has positive mass')
    maximum = max(finite)
    weights = [math.exp(x-maximum) if math.isfinite(x) else 0. for x in logs]
    total = math.fsum(weights)
    return [w/total for w in weights]


def weights(rows, temperature=1):
    if any(r.get('logprob') is None for r in rows):
        raise ValueError('A complete label measurement is required; missing top-N entries stay unknown')
    return normalize_logs([r['logprob']/temperature for r in rows])


def entropy(p):
    return -math.fsum(x*math.log2(x) for x in p if x)


def _pick(items, value):
    if not 0 <= value < len(items):
        raise ValueError('Index must be 0..'+str(len(items)-1))
    return items[int(value)]


def _rows(names, values):
    return [dict(label=str(n), value=float(v)) for n,v in zip(names,values)]


def _graph(edges, threshold):
    if len(edges)>12:
        raise ValueError('This exact demonstration supports at most 12 edges')
    best, score = [], 0.
    for bits in itertools.product((False,True), repeat=len(edges)):
        selected=[e for e,yes in zip(edges,bits) if yes]
        out, incoming, captions = {}, set(), set()
        good=True
        for e in selected:
            a,b=e['source'],e['target']
            if a==b:good=False;break
            if e['relation']=='caption':
                if a in captions:good=False;break
                captions.add(a)
            else:
                if a in out or b in incoming:good=False;break
                out[a]=b;incoming.add(b)
        for start in out:
            node,visited=start,set()
            while node in out:
                if node in visited:good=False;break
                visited.add(node);node=out[node]
        utility=math.fsum(e['weight']-threshold for e in selected)
        if good and utility>score:best,score=selected,utility
    return best,score


def _ttt(board, turn):
    lines=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
    for a,b,c in lines:
        if board[a]!='.' and board[a]==board[b]==board[c]:return 1 if board[a]=='X' else -1
    if '.' not in board:return 0
    values=[_ttt(board[:i]+turn+board[i+1:],'O' if turn=='X' else 'X') for i,s in enumerate(board) if s=='.']
    return (max if turn=='X' else min)(values)


def calculate_lesson(name, data, value=None):
    spec=LESSON_SPECS[name]
    v=spec['default'] if value is None else value
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not spec['low']<=v<=spec['high'] or (spec['integer'] and int(v)!=v):
        raise ValueError(f"{spec['knob']} must be {'an integer' if spec['integer'] else 'finite'} in [{spec['low']}, {spec['high']}]")
    rows=[];metrics={};note='Calculation on saved inputs; changing this setting makes no new model request.'
    summary='';unit='weight'
    if name in ('choice','boolean','score'):
        p=weights(data['rows'],v);at=max(range(len(p)),key=p.__getitem__)
        rows=_rows([r['label']+' · '+r.get('description','') for r in data['rows']],p)
        metrics=dict(winner=data['rows'][at]['label'],top_weight=p[at],entropy_bits=entropy(p))
        if name in ('boolean','score'):
            metrics['expected_value']=math.fsum(q*r['value'] for q,r in zip(p,data['rows']))
        summary=f"Answer {metrics['winner']} leads with {p[at]:.2%} of the listed-label weight."
        if name=='score':summary=f"Expected rubric value: {metrics['expected_value']:.4f} on the stated 0–1 scale."
    elif name=='candidates':
        paths=data['paths'];logs=[math.fsum(t['logprob'] for t in r['tokens'])/len(r['tokens'])**v for r in paths]
        p=normalize_logs(logs);names=list(dict.fromkeys(r['group'] for r in paths))
        values=[math.fsum(q for q,r in zip(p,paths) if r['group']==g) for g in names];rows=_rows(names,values)
        metrics=dict(winner=names[values.index(max(values))],group_weights=values)
        summary=metrics['winner']+' carries the most relative group weight.'
        note='Only these emitted token paths, with their saved terminators and no EOS. A nonzero length penalty produces preference scores, not path probability.'
    elif name=='controller':
        labels=data['measure']['rows'];p=weights(labels);legal=[i for i,r in enumerate(labels) if r['allowed']]
        mass=math.fsum(p[i] for i in legal);pick=next(i for i,r in enumerate(labels) if r['action']==data['action'])
        q=p[pick]/mass;held=q<v
        rows=_rows([labels[i]['action'] for i in legal],[p[i]/mass for i in legal])
        metrics=dict(held=held,selected_weight=q,next_state=data['state'] if held else data['next_state'])
        summary=('Hold the action.' if held else 'Apply '+data['action']+'.')+' State: '+metrics['next_state']+'.'
    elif name=='rerank':
        values=[math.fsum(q*r['value'] for q,r in zip(weights(s['measure']['rows']),s['measure']['rows'])) for s in data['sources']]
        rows=_rows([s['id'] for s in data['sources']],values);kept=[r['label'] for r in rows if r['value']>=v]
        metrics=dict(retained=kept,scores=values);summary='Retain '+(', '.join(kept) or 'no sources')+' at this cutoff.'
    elif name=='graph':
        selected,utility=_graph(data['edges'],v);rows=_rows([e['source']+' → '+e['target'] for e in selected],[e['weight']-v for e in selected]);unit='utility'
        metrics=dict(selected=[(e['source'],e['target'],e['relation']) for e in selected],utility=utility)
        summary=f'{len(selected)} compatible links, total utility {utility:.4f}.'
        note='Global code constraints select links; utility is not the probability that the document graph is correct.'
    elif name=='scene':
        valid=[c for c in data['candidates'] if c['valid']];values=[]
        for c in valid:
            p=[weights(x['measure']['rows'])[0] for x in c['vector']]
            values.append(statistics.mean(p)-v*statistics.pvariance(p))
        rows=_rows([c['name'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['name'],utilities=values)
        summary='Retain '+metrics['retained']+' among geometry-valid candidates.'
        note='These are saved text judgments. This calculation cannot see the drawing or measure visual appeal.'
    elif name=='wire':
        entry=_pick(data['entries'],v);p=math.exp(entry['logprob']);top=entry.get('top_logprobs',[])
        rows=_rows([x['token'] for x in top],[math.exp(x['logprob']) for x in top]);unit='raw probability'
        metrics=dict(token=entry['token'],raw_probability=p,reported_top_mass=math.fsum(r['value'] for r in rows))
        summary=f"Token {entry['token']!r}: raw probability {p:.6g}."
        note='This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary.'
    elif name=='speculation':
        window=data['oracle']['example_rejection'];r=_pick(window['proposal'],v)
        rows=_rows(['Draft head','Target verification'],[r['draft_probability'],math.exp(r['target_logprob'])]);unit='probability / distinct heads'
        metrics=dict(token_id=r['token_id'],target_sequence_logprob=math.fsum(x['target_logprob'] for x in window['proposal']),draft_target_logprob_gap=r['draft_logprob']-r['target_logprob'])
        summary=f"Proposal token {r['token_id']}: the two heads differ by {metrics['draft_target_logprob_gap']:.4f} log units."
        note='Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability.'
    elif name=='performance':
        values=[]
        for r in data['rows']:
            xs=sorted(x['wall_ms'] for x in r['runs']);a=(len(xs)-1)*v/100;lo=math.floor(a);hi=math.ceil(a)
            values.append(xs[lo]+(xs[hi]-xs[lo])*(a-lo))
        rows=_rows([r['name'] for r in data['rows']],values);unit='ms';metrics=dict(percentile=v,times_ms=values)
        summary=f'Percentile {v:g}, recalculated from {data["repeats"]} samples per path.'
        note='Small same-setup samples include network and API cost. JSON answers a different task; this is no universal speed ranking.'
    elif name=='samplers':
        run=_pick(data['runs'],v);token=run['tokens'][0];sample=token['strata_sampling']
        raw=math.exp(token['logprob']);post=sample['probability']
        rows=_rows(['Raw target','After recipe'],[raw,post]);unit='selected token probability'
        metrics=dict(recipe=run['name'],support=sample['support'],raw=raw,selected=post,log_weight_change=math.log(post)-token['logprob'],entropy_bits=sample['entropy']/math.log(2))
        summary=f"{run['name']}: {sample['support']} native tokens remain eligible."
        note='Recipes are separate generations. Entropy and support are full-row native measurements; a top-N slice cannot recover them.'
    elif name=='sampler-sandbox':
        cut=max(data['logits'])+math.log(.05);logs=[x/v if x>=cut else -math.inf for x in data['logits']];p=normalize_logs(logs)
        rows=_rows(data['tokens'],p);metrics=dict(support=sum(x>0 for x in p),entropy_bits=entropy(p),probabilities=p)
        summary=f"{metrics['support']} credible tokens survive; entropy {metrics['entropy_bits']:.3f} bits."
        note='All eight logits are synthetic and visible. This is exact finite-row arithmetic, not a new native receipt.'
    elif name=='tictactoe':
        f=_pick(data['frames'],v);b=f['before'];legal=[i for i,c in enumerate(b) if c=='.'];oracle={i:_ttt(b[:i]+'X'+b[i+1:],'O') for i in legal}
        regret=max(oracle.values())-oracle[f['square']];rows=_rows([str(i+1) for i in legal],list(oracle.values()));unit='X outcome: lose −1 / draw 0 / win 1'
        metrics=dict(regret=regret,square=f['square']+1,oracle=oracle);summary=f"Recorded move: square {f['square']+1}; exact outcome regret {regret}."
    elif name=='chess':
        p=weights(data['measure']['rows'],v);mass=math.fsum(q for q,m in zip(p,data['shortlist']) if m['mate'])
        rows=_rows([m['san'] for m in data['shortlist']],p);metrics=dict(mating_shortlist_weight=mass,generated_uci=data['chosen']['text'],generated_mate=data['mate'])
        summary=f'{mass:.2%} of shortlist weight favors mate; the separate UCI generation '+('mated.' if data['mate'] else 'did not mate.')
        note='The saved legal/mate flags came from python-chess. This portable calculation aggregates them; it is not a replacement chess engine.'
    elif name=='poker':
        ranks=['J','Q','K'];rates={c:min(1,max(0,r*v)) for c,r in data['call_rates'].items()};values={}
        for own in ranks:
            opponents=[c for c in ranks if c!=own];sign=lambda c:1 if ranks.index(own)>ranks.index(c) else -1
            values[own]=dict(check=statistics.mean(sign(c) for c in opponents),bet=statistics.mean((1-rates[c])+rates[c]*2*sign(c) for c in opponents))
        rows=_rows([c+' bet − check' for c in ranks],[values[c]['bet']-values[c]['check'] for c in ranks]);unit='expected chips'
        metrics=dict(values=values,call_rates=rates);summary='Bet when the bar is positive; check when it is negative.'
        note='Uniform remaining-card prior and explicitly assumed opponent policy. Answer weights are not hidden-card beliefs or equilibrium probabilities.'
    elif name=='thermal':
        t=data['frames'][0]['temperature'];temperatures=[]
        for f in data['frames']:
            fan=min(60,max(0,f['fan']+v));t=round(t+.22*f['load']-.32*fan-.04*(t-25),3);temperatures.append(t)
        rows=_rows(range(1,len(temperatures)+1),temperatures);unit='°C';metrics=dict(temperatures=temperatures,mean_error=statistics.mean(abs(t-data['target']) for t in temperatures),violations=sum(t>data['limit'] for t in temperatures))
        summary=f"Mean distance from target: {metrics['mean_error']:.2f}°C; {metrics['violations']} limit violations."
        note='Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control.'
    elif name=='scheduler':
        done=set();clock=0;late=[]
        for f in data['frames']:
            j=f['job']
            if not set(j['after'])<=done:raise ValueError('Saved schedule violates dependencies')
            clock+=j['duration'];late.append(max(0,clock-j['deadline']-v));done.add(j['id'])
        rows=_rows([f['job']['id'] for f in data['frames']],late);unit='late time units';metrics=dict(total_lateness=sum(late),finish_time=clock)
        summary=f'Total lateness {sum(late):g}; the same dependency-valid order ends at time {clock}.'
    elif name=='context':
        selected=_pick(data['runs'],v);all_weights=[weights(r['measure']['rows'])[1] for r in data['runs']];p=all_weights[int(v)]
        rows=_rows([r['name'] for r in data['runs']],all_weights);metrics=dict(variant=selected['name'],no_weight=p,delta_from_append=p-all_weights[0])
        summary=f"{selected['name']}: keep-still answer weight {p:.3%}."
        note='Saved prompt interventions, not KV tensor mutation. This calculation compares their recorded measurements.'
    elif name=='observer':
        actions=[];triples=[]
        for f in data['frames']:
            p=[weights(x['measure']['rows'])[0] for x in f['vector']];triples.append(p)
            actions.append('inspect failure' if p[0]>v else 'verify' if p[1]>v else 'finish' if p[2]>v else 'ask')
        rows=_rows(['Fault','Missing check','Verified'],triples[0]);metrics=dict(actions=actions,vectors=triples)
        summary=' → '.join(actions)+'.';note='Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability.'
    elif name=='calibration':
        p=[weights(r['measure']['rows'])[0] for r in data['rows']];truth=[r['truth'] for r in data['rows']];kept=[i for i,q in enumerate(p) if max(q,1-q)>=v]
        brier=statistics.mean((q-y)**2 for q,y in zip(p,truth));accuracy=statistics.mean(int(p[i]>=.5)==truth[i] for i in kept) if kept else None
        rows=_rows([str(i+1) for i in range(len(p))],p);metrics=dict(brier=brier,retained=len(kept),coverage=len(kept)/len(p),accuracy=accuracy)
        summary=f'{len(kept)}/{len(p)} retained; '+(f'{accuracy:.1%} correct in those cases.' if accuracy is not None else 'accuracy is undefined with zero coverage.')
        note='Six disclosed teaching examples, not a held-out calibration benchmark. Brier error still counts every example.'
    elif name=='information':
        t=_pick(data['tests'],v);prior=data['prior'];py=math.fsum(p*l for p,l in zip(prior,t['likelihood']));yes=[p*l/py for p,l in zip(prior,t['likelihood'])];no=[p*(1-l)/(1-py) for p,l in zip(prior,t['likelihood'])]
        gain=entropy(prior)-py*entropy(yes)-(1-py)*entropy(no);rows=_rows(data['faults'],yes)
        metrics=dict(test=t['name'],gain_bits=gain,gain_per_cost=gain/t['cost'],yes=yes,no=no)
        summary=t['name']+f': {gain:.3f} expected bits; {gain/t["cost"]:.3f} bits per cost unit.'
        note='Prior and likelihoods are stated synthetic sensor assumptions. Bars condition on a positive result; no test was actually purchased.'
    elif name=='search':
        valid=[c for c in data['candidates'] if c['valid']];values=[weights(c['measure']['rows'])[0]-v*c['cost']/3 for c in valid]
        rows=_rows([c['id'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['id'],utilities=values)
        summary='Retain '+metrics['retained']+' after charging for cost; invalid geometry is excluded.'
    elif name=='frontier':
        selector=sorted(r['selection_ms'] for r in data['measurements'])[len(data['measurements'])//2];transfer=data['vocabulary']*data['bytes_per_logit']/(v*1e6);total=60+transfer+selector
        rows=_rows(['Assumed forward','Transfer lower bound','Measured host selector'],[60,transfer,selector]);unit='ms'
        metrics=dict(transfer_ms=transfer,serial_ms=total,tokens_per_second=1000/total)
        summary=f'Serial estimate: {total:.3f} ms/token; {1000/total:.2f} tokens/s.'
        note='Forward time is assumed 60 ms. Selector uses the upper-middle measured sample to match the chart. Queue, prefill and network are excluded.'
    elif name=='research-map':
        branch=_pick(data['branches'],v);categories={}
        for b in data['branches']:categories[b['status']]=categories.get(b['status'],0)+1
        rows=_rows(list(categories),list(categories.values()));unit='branches';metrics=dict(branch=branch['name'],gate=branch['gate'],categories=categories)
        summary=branch['name']+': '+branch['gate'];note='This page recomputes an agenda inventory, not an experiment result. Each implemented branch links to its own evidence.'
    elif name=='pressure':
        case=_pick(data['cases'],v);r=case['rows'][0];token=r['token'];q=token['strata_sampling']['probability'];logz=token['logprob']-math.log(q)
        if logz>1e-6:raise ValueError('Pure-mask mass exceeds one')
        z=math.exp(min(0,logz));rows=_rows(['Survived','Removed'],[z,1-z]);unit='original probability mass'
        metrics=dict(grammar=case['name'],mass=z,pressure_nats=-logz,pressure_bits=-logz/math.log(2))
        summary=f"{case['name']}: {z:.4%} survives; pressure {-logz:.4f} nats."
        note='First actual prefix of this native grammar. Exact only for pure masking at temperature 1, not arbitrary sampler recipes or entire grammar languages.'
    elif name=='circuit':
        p=weights(data['cases'][0]['measurement']['rows']);weighted=[p[0]*(1-v),p[1]*(1-v),p[2]*v,p[3]*v];z=math.fsum(weighted);p=[x/z for x in weighted]
        f=p[1]+p[3];s=p[2]+p[3];rows=_rows(['Neither','Facts only','Style only','Both'],p)
        metrics=dict(F=f,S=s,AND=p[3],OR=1-p[0],F_given_S=p[3]/s if s else None,marginal_product=f*s)
        summary=f'Facts AND style: {p[3]:.2%}; multiplying the marginals would give {f*s:.2%}.'
        note='At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world.'
    elif name=='control':
        logs=[math.log(b)+v*(math.log(d)-math.log(u)) if i in data['allowed'] else -math.inf for i,(b,d,u) in enumerate(zip(data['base'],data['desired'],data['undesired']))];p=normalize_logs(logs)
        rows=_rows(list('ABCD'),p);pick=max(range(len(p)),key=p.__getitem__);metrics=dict(probabilities=p,selected=pick,forbidden_mass=math.fsum(p[i] for i in range(len(p)) if i not in data['allowed']))
        summary=f"Action {'ABCD'[pick]} leads; forbidden-action mass stays zero."
        note='Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook.'
    elif name=='future':
        root=weights(data['policy'][0]['rows']);child=weights(data['policy'][2]['rows']);h=[0,child[1]];p=normalize_logs([math.log(r)+(v*math.log(x) if x else -math.inf) if v else math.log(r) for r,x in zip(root,h)])
        rows=_rows(['A: dead end','B: viable route'],p);success=p[1]*child[1];metrics=dict(root_weights=p,exact_h=h,success_root_only=success,base_success=root[1]*child[1])
        summary=f'{p[1]:.2%} chooses B; leaving the next policy unchanged succeeds {success:.2%} of the time.'
        note='Only BB succeeds in this exact two-step toy. Conditioning both steps is different from steering only the root. No native future-value decoder is claimed.'
    elif name=='sensitivity':
        o=data['observations'];zs=[[math.log(p/(1-p)) for p in row['probabilities']] for row in o]
        matrix=[[(zs[2][i]-zs[1][i])/(2*data['epsilon'][0]),(zs[4][i]-zs[3][i])/(2*data['epsilon'][1])] for i in range(3)]
        delta=[r[0]*v+r[1]*5 for r in matrix];rows=_rows(['Urgency','Load','Damage'],delta);unit='predicted log-odds change'
        observed=[zs[6][i]-zs[0][i] for i in range(3)];held=[r[0]*-1+r[1]*5 for r in matrix]
        metrics=dict(matrix=matrix,predicted_delta=delta,holdout_residual=[a-b for a,b in zip(observed,held)])
        summary=f'Predicted urgency shift {delta[0]:+.3f}; the measured −1h/+5 holdout had error {metrics["holdout_residual"][0]:+.3f}.'
        note='The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses.'
    elif name=='counterexamples':
        nodes=data['nodes'];pairs=[]
        for i,a in enumerate(nodes):
            za=[math.log(p/(1-p)) for p in a['p_yes']]
            for j,b in enumerate(nodes[i+1:],i+1):
                if a['coefficients']!=b['coefficients']:continue
                zb=[math.log(p/(1-p)) for p in b['p_yes']];distance=math.sqrt(math.fsum((x-y)**2 for x,y in zip(za,zb)));pairs.append((distance,i,j))
        distance,i,j=max(pairs);a,b=nodes[i],nodes[j];evaluate=lambda c:sum(x*v**k for k,x in enumerate(c))
        rows=_rows([a['expression'],b['expression']],[a['p_yes'][1],b['p_yes'][1]])
        metrics=dict(left=a['expression'],right=b['expression'],margin_distance=distance,left_value=evaluate(a['coefficients']),right_value=evaluate(b['coefficients']))
        summary=f'Equal exact values at x={v:g}: {metrics["left_value"]:g}; observer distance {distance:.3f}.'
        note='Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe.'
    else:
        raise ValueError('No portable calculation for '+name)
    return dict(value=v,summary=summary,rows=rows,unit=unit,metrics=metrics,note=note)


def make_lesson(name, data):
    spec=LESSON_SPECS[name]
    try:
        first=calculate_lesson(name,data)
        compare=spec['compare']
        # An edited run can have fewer tokens/turns than the recorded default.
        lengths={'wire':len(data.get('entries',[])), 'samplers':len(data.get('runs',[])),
                 'tictactoe':len(data.get('frames',[])), 'context':len(data.get('runs',[])),
                 'information':len(data.get('tests',[])), 'research-map':len(data.get('branches',[])),
                 'pressure':len(data.get('cases',[]))}
        if name in lengths:compare=min(compare,lengths[name]-1)
        second=calculate_lesson(name,data,compare)
        context=data.get('prompt','').partition('STATE:\n')[2].partition('\nQUESTION:')[0]
        return dict(**spec,states=[first,second],input_excerpt=context[:320]+('…' if len(context)>320 else ''),scope='This panel and its Python calculation reproduce saved measurements. Other page controls are independent views.')
    except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:
        # A genuinely incomplete score or a tool-only wire response stays usable.
        # Do not turn an unavailable lesson into fabricated measurement data.
        return dict(**spec,states=[],unavailable=str(error),scope='This run has no complete inputs for this calculation. Inspect its exact request and result below.')



def mock_post(request, fixture):
    if request != fixture['request']:
        raise ValueError('No mock matches the edited request. Supply a new fixture or explicitly choose --live-url.')
    return copy.deepcopy(fixture['response'])


def live_post(base_url, request):
    if not base_url.startswith(('http://', 'https://')):
        raise ValueError('--live-url must be an http(s) Strata address')
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('STRATA_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['STRATA_API_KEY']
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    body = json.dumps(request, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base_url.rstrip('/')+'/v1/chat/completions', data=body, headers=headers)
    with opener.open(req, timeout=600) as response:
        wire = response.read().decode('utf-8')
    if request.get('stream'):
        events = [line[5:].strip() for line in wire.splitlines() if line.startswith('data:')]
        if not events or events[-1] != '[DONE]':
            raise ValueError('Stream closed without [DONE]')
        chunks = [json.loads(line) for line in events[:-1]]
        if any('error' in chunk for chunk in chunks):
            raise ValueError('Stream reported an error: '+repr(chunks))
        return {'sse_events': chunks, 'wire': wire}
    reply = json.loads(wire)
    if 'error' in reply:
        raise ValueError('Strata reported an error: '+repr(reply['error']))
    return reply


def summarize(response):
    if 'sse_events' in response:
        return str(len(response['sse_events']))+' SSE events; inspect the saved wire response'
    choice = (response.get('choices') or [{}])[0]
    message = choice.get('message', {})
    text = message.get('content') or json.dumps(message.get('tool_calls') or message, ensure_ascii=False)
    entries = (choice.get('logprobs') or {}).get('content') or []
    if entries:
        text += '\n  First visible token raw logprob: '+repr(entries[0]['logprob'])
        text += '\n  First visible token raw probability: '+format(math.exp(entries[0]['logprob']), '.7g')
    return text


def raw_tokens(response):
    if 'sse_events' in response:
        return [token for chunk in response['sse_events'] for choice in chunk.get('choices', [])
                for token in (choice.get('logprobs') or {}).get('content') or []]
    choices = response.get('choices') or []
    return ((choices[0].get('logprobs') or {}).get('content') or []) if choices else []


def print_raw_tokens(response):
    entries = raw_tokens(response)
    if not entries:
        print('No scored answer tokens returned; no raw probabilities are invented.')
    for i, token in enumerate(entries):
        lp = token['logprob']
        p = math.exp(lp)
        shown = format(p, '.9g') if p else 'underflows; use the finite logprob'
        print('  Token '+str(i)+': '+repr(token['token'])+' bytes='+repr(token['bytes'])+
              ' raw ln p='+repr(lp)+' raw p='+shown)
        sampling = token.get('strata_sampling')
        if sampling:
            print('    Final native selection weight q='+repr(sampling['probability'])+' (separate from raw p)')


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=int, default=1, help='1-based request index (default 1)')
    parser.add_argument('--all', action='store_true', help='Replay every mock in this captured run')
    parser.add_argument('--show', action='store_true', help='Print exact selected HTTP request JSON')
    parser.add_argument('--tokens', action='store_true', help='Print every original token raw logprob/probability and available native sampling weight')
    parser.add_argument('--lesson-only', action='store_true', help='Recalculate the captured question/rule/result panel without printing mocked calls')
    parser.add_argument('--value', type=float, help='Change the panel parameter within its documented bounds; offline calculation only')
    parser.add_argument('--live-url', help='Explicitly send ONE request to your compatible Strata server')
    parser.add_argument('--output', type=Path, help='Write responses and their provenance as JSON')
    args = parser.parse_args()
    if args.all and args.live_url:
        parser.error('--all is offline only; saved dependent requests are not a live adaptive controller')
    if args.live_url and (args.lesson_only or args.value is not None):
        parser.error('Lesson calculations use captured evidence. Do not mix --live-url with --lesson-only or --value.')
    calls = CAPTURED['receipt']['calls']
    print('Strata Control Lab / '+CAPTURED['experiment'])
    print('LIVE selected request' if args.live_url else 'OFFLINE MOCK / recorded responses, no inference or network')
    view = CAPTURED.get('score_view')
    if view:
        print('\nRAW LAYER: '+view['raw'])
        print('DERIVED VIEW: '+view['derived'])
        print('SCOPE: '+view['scope'])
    calculation=None
    if not args.live_url:
        spec=CAPTURED.get('lesson')
        if spec and spec.get('states'):
            knob=args.value if args.value is not None else (CAPTURED.get('lesson_view') or {}).get('value',spec['default'])
            try:calculation=calculate_lesson(CAPTURED['experiment'],CAPTURED['result'],knob)
            except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:parser.error(str(error))
            print('\nQUESTION: '+spec['question']+'\nRULE: '+spec['rule'])
            print(spec['knob']+' = '+str(knob)+f" (allowed {spec['low']}..{spec['high']})")
            print('RESULT: '+calculation['summary'])
            print('BOUNDARY: '+calculation['note'])
            print('Reproduces the selected question/rule/result panel; other page dials are independent.')
            print(json.dumps(calculation,ensure_ascii=True,indent=2))
        elif args.lesson_only or args.value is not None:
            parser.error('This captured run has no complete lesson inputs: '+str((spec or {}).get('unavailable','missing calculation')))
    if args.lesson_only:
        result=dict(mode='offline-calculation',calculation=calculation)
    elif not calls:
        if args.live_url:
            parser.error('This page has no HTTP requests: it is analytical or recorded diagnostic evidence')
        print('No HTTP request, GBNF or JSON output constraint was used by this page.')
        print('The included result is a calculation/diagnostic snapshot, not a new model answer.')
        result = dict(mode='offline-snapshot', result=CAPTURED['result'])
        print(json.dumps(result, ensure_ascii=True, indent=2))
    else:
        indexes = range(len(calls)) if args.all else [args.request-1]
        if any(i < 0 or i >= len(calls) for i in indexes):
            parser.error('Request index must be 1..'+str(len(calls)))
        results = []
        for i in indexes:
            fixture = calls[i]
            request = copy.deepcopy(fixture['request'])  # Edit here to try your own live request.
            if args.show:
                print(json.dumps(request, ensure_ascii=True, indent=2))
            response = live_post(args.live_url, request) if args.live_url else mock_post(request, fixture)
            print('Request '+str(i+1)+' / '+str(len(calls))+': '+summarize(response))
            if args.tokens:
                print_raw_tokens(response)
            results.append(dict(request=request, response=response,
                                provenance='live-request' if args.live_url else 'mocked-native-recording'))
        result = dict(mode='live' if args.live_url else 'offline-mock', calls=results)
        print('GBNF and JSON settings are in each request. Use --show to inspect them.')
        print('The saved page result is in CAPTURED["result"]; live responses do not recompute that snapshot.')
    if calculation is not None:result['calculation']=calculation
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
