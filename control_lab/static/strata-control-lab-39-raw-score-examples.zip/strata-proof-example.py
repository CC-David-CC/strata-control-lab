# -*- coding: utf-8 -*-
"""Downloaded Strata example: Python 3 standard library; offline by default.

Windows: py strata-example.py
Ubuntu:  python3 strata-example.py
Show a request: python strata-example.py --request 1 --show
Replay all recorded calls: python strata-example.py --all
Recalculate the panel: python strata-example.py --lesson-only
Change its knob: python strata-example.py --lesson-only --value NUMBER
Try ONE request live: python strata-example.py --request 1 --live-url http://127.0.0.1:8080
An optional STRATA_API_KEY environment variable supplies authentication.

CAPTURED is inserted above this runner by the page. It contains this exact run,
with requests, GBNF/JSON settings, responses, streaming chunks and the page result.
Mock mode returns those responses; it performs no inference and opens no socket.
Live mode runs only a selected request. It does not execute tools or adapt a saved
multi-step trace to new answers. No captured API key or authorization header exists.
"""
CAPTURED = {
    "experiment": "proof",
    "score_view": {
        "raw": "Each generated token carries target logprob before grammar, penalties and sampling. Raw probability is exp(logprob), with the denominator over the full target vocabulary. Every score belongs to its selected request and exact preceding token path. These instruments also inspect a pure temperature-1 grammar mask. Complete answer rows recover raw label p from native legal-set weight q times surviving mass Z; the selected token logprob below is the direct target score, not that recovered row.",
        "derived": "Native answer weights choose among proposed proof actions. The toy proof referee establishes its own validity and utility; model preference is not a proof.",
        "scope": "The raw receipt stays attached to the captured request. Page dials recalculate derived views; they do not rerun the model or replace token scores. Neither model probability nor a derived weight is calibrated truth. Missing top-N alternatives stay unknown.",
        "raw_kind": "native"
    },
    "type": "result",
    "result": {
        "kind": "proof",
        "cases": [
            {
                "name": "Independent proof state 1",
                "state": "Tiny formal proof state: {'context': [], 'goal': ['implies', ['and', 'P', 'Q'], 'P']}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.",
                "choices": [
                    "introduce implication",
                    "unpack conjunction",
                    "use exact assumption",
                    "wait"
                ],
                "proof_state": {
                    "context": [],
                    "goal": [
                        "implies",
                        [
                            "and",
                            "P",
                            "Q"
                        ],
                        "P"
                    ]
                },
                "allowed": [
                    0,
                    3
                ],
                "measurement": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "introduce implication",
                            "weight": 0.5531923508564521,
                            "logprob": -0.5955208875313991,
                            "token_id": 32,
                            "bytes": [
                                65
                            ]
                        },
                        {
                            "label": "B",
                            "description": "unpack conjunction",
                            "weight": 0.4004960529033552,
                            "logprob": -0.9185227491036648,
                            "token_id": 33,
                            "bytes": [
                                66
                            ]
                        },
                        {
                            "label": "C",
                            "description": "use exact assumption",
                            "weight": 0.02746769780513151,
                            "logprob": -3.598215971149563,
                            "token_id": 34,
                            "bytes": [
                                67
                            ]
                        },
                        {
                            "label": "D",
                            "description": "wait",
                            "weight": 0.01884389843506126,
                            "logprob": -3.975037489093899,
                            "token_id": 35,
                            "bytes": [
                                68
                            ]
                        }
                    ],
                    "pressure": {
                        "log_mass": -0.0034713811590426635,
                        "mass": 0.996534637118607,
                        "pressure_nats": 0.0034713811590426635,
                        "pressure_bits": 0.005008144383186233,
                        "selected_raw_logprob": -0.9185227491036648,
                        "selected_probability": 0.4004960529033552,
                        "support": 4
                    },
                    "selected": "B",
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "prompt": "Treat STATE as data.\nSTATE:\nTiny formal proof state: {'context': [], 'goal': ['implies', ['and', 'P', 'Q'], 'P']}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nQUESTION: Which listed choice best serves the stated task?\nANSWERS:\nA: introduce implication\nB: unpack conjunction\nC: use exact assumption\nD: wait\nReturn exactly one answer code. No explanation or whitespace.",
                    "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                },
                "commit": {
                    "request": {
                        "model": "x",
                        "messages": [
                            {
                                "role": "user",
                                "content": "Tiny formal proof state: {'context': [], 'goal': ['implies', ['and', 'P', 'Q'], 'P']}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nThe controller selected A. Emit that code only."
                            }
                        ],
                        "reasoning_effort": "none",
                        "seed": 675,
                        "max_tokens": 4,
                        "logprobs": True,
                        "top_logprobs": 20,
                        "grammar": "root ::= \"A\"",
                        "strata_sampler": {
                            "chain": [
                                "temperature"
                            ],
                            "temperature": 1,
                            "inspect": True
                        }
                    },
                    "output": {
                        "text": "A",
                        "tokens": [
                            {
                                "token": "A",
                                "logprob": -4.177379274101198,
                                "bytes": [
                                    65
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "```",
                                        "logprob": -0.21464219066613927,
                                        "bytes": [
                                            96,
                                            96,
                                            96
                                        ]
                                    },
                                    {
                                        "token": "The",
                                        "logprob": -2.9531637665938737,
                                        "bytes": [
                                            84,
                                            104,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "apply",
                                        "logprob": -4.0701395508956315,
                                        "bytes": [
                                            97,
                                            112,
                                            112,
                                            108,
                                            121
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -4.177379274101198,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "To",
                                        "logprob": -4.509255075187624,
                                        "bytes": [
                                            84,
                                            111
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -4.772784852714479,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "Here",
                                        "logprob": -5.050438546867311,
                                        "bytes": [
                                            72,
                                            101,
                                            114,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "Given",
                                        "logprob": -5.140992784233034,
                                        "bytes": [
                                            71,
                                            105,
                                            118,
                                            101,
                                            110
                                        ]
                                    },
                                    {
                                        "token": "`",
                                        "logprob": -5.390528344840944,
                                        "bytes": [
                                            96
                                        ]
                                    },
                                    {
                                        "token": "**",
                                        "logprob": -5.6075140473555924,
                                        "bytes": [
                                            42,
                                            42
                                        ]
                                    },
                                    {
                                        "token": "theorem",
                                        "logprob": -5.638371133537233,
                                        "bytes": [
                                            116,
                                            104,
                                            101,
                                            111,
                                            114,
                                            101,
                                            109
                                        ]
                                    },
                                    {
                                        "token": "I",
                                        "logprob": -5.732159280509889,
                                        "bytes": [
                                            73
                                        ]
                                    },
                                    {
                                        "token": "We",
                                        "logprob": -5.738287591667116,
                                        "bytes": [
                                            87,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "exact",
                                        "logprob": -5.817799234123171,
                                        "bytes": [
                                            101,
                                            120,
                                            97,
                                            99,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "intro",
                                        "logprob": -5.844567918510378,
                                        "bytes": [
                                            105,
                                            110,
                                            116,
                                            114,
                                            111
                                        ]
                                    },
                                    {
                                        "token": "Apply",
                                        "logprob": -6.053661966056764,
                                        "bytes": [
                                            65,
                                            112,
                                            112,
                                            108,
                                            121
                                        ]
                                    },
                                    {
                                        "token": "Based",
                                        "logprob": -6.20211377117151,
                                        "bytes": [
                                            66,
                                            97,
                                            115,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "###",
                                        "logprob": -6.3691202637862565,
                                        "bytes": [
                                            35,
                                            35,
                                            35
                                        ]
                                    },
                                    {
                                        "token": "You",
                                        "logprob": -6.520527505607546,
                                        "bytes": [
                                            89,
                                            111,
                                            117
                                        ]
                                    },
                                    {
                                        "token": "Since",
                                        "logprob": -6.657529496879518,
                                        "bytes": [
                                            83,
                                            105,
                                            110,
                                            99,
                                            101
                                        ]
                                    }
                                ],
                                "strata_sampling": {
                                    "index": 0,
                                    "id": 32,
                                    "probability": 1,
                                    "support": 1,
                                    "entropy": 0,
                                    "selection_ms": 0.111568,
                                    "stages": [
                                        {
                                            "operator": "grammar",
                                            "support": 1,
                                            "entropy": 0
                                        },
                                        {
                                            "operator": "temperature",
                                            "support": 1,
                                            "entropy": 0
                                        }
                                    ],
                                    "top": [
                                        {
                                            "id": 32,
                                            "probability": 1,
                                            "bytes": [
                                                65
                                            ],
                                            "token": "A"
                                        }
                                    ]
                                }
                            }
                        ],
                        "token_count": 1,
                        "logprob": -4.177379274101198,
                        "path_probability": 0.015338653344280688,
                        "mean_logprob": -4.177379274101198,
                        "finish_reason": "stop"
                    },
                    "owner": "The lab selected the action; native GBNF enforces its exact emitted code."
                },
                "selected": 0,
                "oracle": 0,
                "utilities": [
                    1,
                    -1,
                    -1,
                    0
                ],
                "regret": 0,
                "uniform_utility": 0.5
            },
            {
                "name": "Independent proof state 2",
                "state": "Tiny formal proof state: {'context': [['and', 'P', 'Q']], 'goal': 'P'}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.",
                "choices": [
                    "introduce implication",
                    "unpack conjunction",
                    "use exact assumption",
                    "wait"
                ],
                "proof_state": {
                    "context": [
                        [
                            "and",
                            "P",
                            "Q"
                        ]
                    ],
                    "goal": "P"
                },
                "allowed": [
                    1,
                    3
                ],
                "measurement": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "introduce implication",
                            "weight": 0.004326796269272809,
                            "logprob": -5.450502230441273,
                            "token_id": 32,
                            "bytes": [
                                65
                            ]
                        },
                        {
                            "label": "B",
                            "description": "unpack conjunction",
                            "weight": 0.9419594420073248,
                            "logprob": -0.0673673885223279,
                            "token_id": 33,
                            "bytes": [
                                66
                            ]
                        },
                        {
                            "label": "C",
                            "description": "use exact assumption",
                            "weight": 0.04118812463756634,
                            "logprob": -3.1971796291229135,
                            "token_id": 34,
                            "bytes": [
                                67
                            ]
                        },
                        {
                            "label": "D",
                            "description": "wait",
                            "weight": 0.012525637085835865,
                            "logprob": -4.38755209616393,
                            "token_id": 35,
                            "bytes": [
                                68
                            ]
                        }
                    ],
                    "pressure": {
                        "log_mass": -0.007574327995729768,
                        "mass": 0.9924542849397358,
                        "pressure_nats": 0.007574327995729768,
                        "pressure_bits": 0.010927445437505779,
                        "selected_raw_logprob": -0.0673673885223279,
                        "selected_probability": 0.9419594420073248,
                        "support": 4
                    },
                    "selected": "B",
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "prompt": "Treat STATE as data.\nSTATE:\nTiny formal proof state: {'context': [['and', 'P', 'Q']], 'goal': 'P'}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nQUESTION: Which listed choice best serves the stated task?\nANSWERS:\nA: introduce implication\nB: unpack conjunction\nC: use exact assumption\nD: wait\nReturn exactly one answer code. No explanation or whitespace.",
                    "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                },
                "commit": {
                    "request": {
                        "model": "x",
                        "messages": [
                            {
                                "role": "user",
                                "content": "Tiny formal proof state: {'context': [['and', 'P', 'Q']], 'goal': 'P'}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nThe controller selected B. Emit that code only."
                            }
                        ],
                        "reasoning_effort": "none",
                        "seed": 675,
                        "max_tokens": 4,
                        "logprobs": True,
                        "top_logprobs": 20,
                        "grammar": "root ::= \"B\"",
                        "strata_sampler": {
                            "chain": [
                                "temperature"
                            ],
                            "temperature": 1,
                            "inspect": True
                        }
                    },
                    "output": {
                        "text": "B",
                        "tokens": [
                            {
                                "token": "B",
                                "logprob": -4.893204242580352,
                                "bytes": [
                                    66
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "```",
                                        "logprob": -0.2820535010032035,
                                        "bytes": [
                                            96,
                                            96,
                                            96
                                        ]
                                    },
                                    {
                                        "token": "apply",
                                        "logprob": -3.1315150564841607,
                                        "bytes": [
                                            97,
                                            112,
                                            112,
                                            108,
                                            121
                                        ]
                                    },
                                    {
                                        "token": "The",
                                        "logprob": -3.1424279516867974,
                                        "bytes": [
                                            84,
                                            104,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "exact",
                                        "logprob": -4.3252024954490045,
                                        "bytes": [
                                            101,
                                            120,
                                            97,
                                            99,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -4.364017040126739,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "theorem",
                                        "logprob": -4.505638629787383,
                                        "bytes": [
                                            116,
                                            104,
                                            101,
                                            111,
                                            114,
                                            101,
                                            109
                                        ]
                                    },
                                    {
                                        "token": "`",
                                        "logprob": -4.872637302272735,
                                        "bytes": [
                                            96
                                        ]
                                    },
                                    {
                                        "token": "B",
                                        "logprob": -4.893204242580352,
                                        "bytes": [
                                            66
                                        ]
                                    },
                                    {
                                        "token": "To",
                                        "logprob": -4.937204868190704,
                                        "bytes": [
                                            84,
                                            111
                                        ]
                                    },
                                    {
                                        "token": "**",
                                        "logprob": -4.939255267970977,
                                        "bytes": [
                                            42,
                                            42
                                        ]
                                    },
                                    {
                                        "token": "Given",
                                        "logprob": -5.495100528591094,
                                        "bytes": [
                                            71,
                                            105,
                                            118,
                                            101,
                                            110
                                        ]
                                    },
                                    {
                                        "token": "intro",
                                        "logprob": -5.568024188869415,
                                        "bytes": [
                                            105,
                                            110,
                                            116,
                                            114,
                                            111
                                        ]
                                    },
                                    {
                                        "token": "Based",
                                        "logprob": -5.6543345755271295,
                                        "bytes": [
                                            66,
                                            97,
                                            115,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "We",
                                        "logprob": -5.814681560390411,
                                        "bytes": [
                                            87,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "I",
                                        "logprob": -5.8444381064109185,
                                        "bytes": [
                                            73
                                        ]
                                    },
                                    {
                                        "token": "select",
                                        "logprob": -6.0951657599143365,
                                        "bytes": [
                                            115,
                                            101,
                                            108,
                                            101,
                                            99,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "SELECT",
                                        "logprob": -6.1475854223899224,
                                        "bytes": [
                                            83,
                                            69,
                                            76,
                                            69,
                                            67,
                                            84
                                        ]
                                    },
                                    {
                                        "token": "Here",
                                        "logprob": -6.352823764675079,
                                        "bytes": [
                                            72,
                                            101,
                                            114,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "Since",
                                        "logprob": -6.634231120937286,
                                        "bytes": [
                                            83,
                                            105,
                                            110,
                                            99,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "Apply",
                                        "logprob": -6.683256656520782,
                                        "bytes": [
                                            65,
                                            112,
                                            112,
                                            108,
                                            121
                                        ]
                                    }
                                ],
                                "strata_sampling": {
                                    "index": 0,
                                    "id": 33,
                                    "probability": 1,
                                    "support": 1,
                                    "entropy": 0,
                                    "selection_ms": 0.111328,
                                    "stages": [
                                        {
                                            "operator": "grammar",
                                            "support": 1,
                                            "entropy": 0
                                        },
                                        {
                                            "operator": "temperature",
                                            "support": 1,
                                            "entropy": 0
                                        }
                                    ],
                                    "top": [
                                        {
                                            "id": 33,
                                            "probability": 1,
                                            "bytes": [
                                                66
                                            ],
                                            "token": "B"
                                        }
                                    ]
                                }
                            }
                        ],
                        "token_count": 1,
                        "logprob": -4.893204242580352,
                        "path_probability": 0.007497360583490028,
                        "mean_logprob": -4.893204242580352,
                        "finish_reason": "stop"
                    },
                    "owner": "The lab selected the action; native GBNF enforces its exact emitted code."
                },
                "selected": 1,
                "oracle": 1,
                "utilities": [
                    -1,
                    1,
                    -1,
                    0
                ],
                "regret": 0,
                "uniform_utility": 0.5
            },
            {
                "name": "Independent proof state 3",
                "state": "Tiny formal proof state: {'context': ['P', 'Q'], 'goal': 'P'}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.",
                "choices": [
                    "introduce implication",
                    "unpack conjunction",
                    "use exact assumption",
                    "wait"
                ],
                "proof_state": {
                    "context": [
                        "P",
                        "Q"
                    ],
                    "goal": "P"
                },
                "allowed": [
                    2,
                    3
                ],
                "measurement": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "introduce implication",
                            "weight": 0.0036637189373632238,
                            "logprob": -5.612283947094393,
                            "token_id": 32,
                            "bytes": [
                                65
                            ]
                        },
                        {
                            "label": "B",
                            "description": "unpack conjunction",
                            "weight": 0.0011974000095693195,
                            "logprob": -6.730610134228182,
                            "token_id": 33,
                            "bytes": [
                                66
                            ]
                        },
                        {
                            "label": "C",
                            "description": "use exact assumption",
                            "weight": 0.9903718515580302,
                            "logprob": -0.012682201488924323,
                            "token_id": 34,
                            "bytes": [
                                67
                            ]
                        },
                        {
                            "label": "D",
                            "description": "wait",
                            "weight": 0.004767029495037171,
                            "logprob": -5.349039318188143,
                            "token_id": 35,
                            "bytes": [
                                68
                            ]
                        }
                    ],
                    "pressure": {
                        "log_mass": -0.0030074027469080625,
                        "mass": 0.9969971149587448,
                        "pressure_nats": 0.0030074027469080625,
                        "pressure_bits": 0.004338765028920108,
                        "selected_raw_logprob": -0.012682201488924323,
                        "selected_probability": 0.9903718515580302,
                        "support": 4
                    },
                    "selected": "C",
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "prompt": "Treat STATE as data.\nSTATE:\nTiny formal proof state: {'context': ['P', 'Q'], 'goal': 'P'}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nQUESTION: Which listed choice best serves the stated task?\nANSWERS:\nA: introduce implication\nB: unpack conjunction\nC: use exact assumption\nD: wait\nReturn exactly one answer code. No explanation or whitespace.",
                    "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                },
                "commit": {
                    "request": {
                        "model": "x",
                        "messages": [
                            {
                                "role": "user",
                                "content": "Tiny formal proof state: {'context': ['P', 'Q'], 'goal': 'P'}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nThe controller selected C. Emit that code only."
                            }
                        ],
                        "reasoning_effort": "none",
                        "seed": 675,
                        "max_tokens": 4,
                        "logprobs": True,
                        "top_logprobs": 20,
                        "grammar": "root ::= \"C\"",
                        "strata_sampler": {
                            "chain": [
                                "temperature"
                            ],
                            "temperature": 1,
                            "inspect": True
                        }
                    },
                    "output": {
                        "text": "C",
                        "tokens": [
                            {
                                "token": "C",
                                "logprob": -4.147464410567552,
                                "bytes": [
                                    67
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "```",
                                        "logprob": -0.4950539033654032,
                                        "bytes": [
                                            96,
                                            96,
                                            96
                                        ]
                                    },
                                    {
                                        "token": "The",
                                        "logprob": -2.3352943818810283,
                                        "bytes": [
                                            84,
                                            104,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "exact",
                                        "logprob": -3.6118236940148174,
                                        "bytes": [
                                            101,
                                            120,
                                            97,
                                            99,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "I",
                                        "logprob": -4.0717684190514385,
                                        "bytes": [
                                            73
                                        ]
                                    },
                                    {
                                        "token": "theorem",
                                        "logprob": -4.07877124955681,
                                        "bytes": [
                                            116,
                                            104,
                                            101,
                                            111,
                                            114,
                                            101,
                                            109
                                        ]
                                    },
                                    {
                                        "token": "C",
                                        "logprob": -4.147464410567552,
                                        "bytes": [
                                            67
                                        ]
                                    },
                                    {
                                        "token": "**",
                                        "logprob": -4.266765252852708,
                                        "bytes": [
                                            42,
                                            42
                                        ]
                                    },
                                    {
                                        "token": "apply",
                                        "logprob": -4.326251642012864,
                                        "bytes": [
                                            97,
                                            112,
                                            112,
                                            108,
                                            121
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -4.407819406295091,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "Based",
                                        "logprob": -4.523783342147142,
                                        "bytes": [
                                            66,
                                            97,
                                            115,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": "`",
                                        "logprob": -4.588285104537278,
                                        "bytes": [
                                            96
                                        ]
                                    },
                                    {
                                        "token": "Given",
                                        "logprob": -4.610131875777513,
                                        "bytes": [
                                            71,
                                            105,
                                            118,
                                            101,
                                            110
                                        ]
                                    },
                                    {
                                        "token": "We",
                                        "logprob": -4.686223642134935,
                                        "bytes": [
                                            87,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "To",
                                        "logprob": -4.81087459733513,
                                        "bytes": [
                                            84,
                                            111
                                        ]
                                    },
                                    {
                                        "token": "intro",
                                        "logprob": -4.988201753402024,
                                        "bytes": [
                                            105,
                                            110,
                                            116,
                                            114,
                                            111
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -5.616207734847337,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "P",
                                        "logprob": -5.684599534774095,
                                        "bytes": [
                                            80
                                        ]
                                    },
                                    {
                                        "token": "###",
                                        "logprob": -5.756764070296556,
                                        "bytes": [
                                            35,
                                            35,
                                            35
                                        ]
                                    },
                                    {
                                        "token": "Since",
                                        "logprob": -5.908451692366868,
                                        "bytes": [
                                            83,
                                            105,
                                            110,
                                            99,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "Here",
                                        "logprob": -5.961475030684739,
                                        "bytes": [
                                            72,
                                            101,
                                            114,
                                            101
                                        ]
                                    }
                                ],
                                "strata_sampling": {
                                    "index": 0,
                                    "id": 34,
                                    "probability": 1,
                                    "support": 1,
                                    "entropy": 0,
                                    "selection_ms": 0.111308,
                                    "stages": [
                                        {
                                            "operator": "grammar",
                                            "support": 1,
                                            "entropy": 0
                                        },
                                        {
                                            "operator": "temperature",
                                            "support": 1,
                                            "entropy": 0
                                        }
                                    ],
                                    "top": [
                                        {
                                            "id": 34,
                                            "probability": 1,
                                            "bytes": [
                                                67
                                            ],
                                            "token": "C"
                                        }
                                    ]
                                }
                            }
                        ],
                        "token_count": 1,
                        "logprob": -4.147464410567552,
                        "path_probability": 0.015804439291962652,
                        "mean_logprob": -4.147464410567552,
                        "finish_reason": "stop"
                    },
                    "owner": "The lab selected the action; native GBNF enforces its exact emitted code."
                },
                "selected": 2,
                "oracle": 2,
                "utilities": [
                    -1,
                    -1,
                    2,
                    0
                ],
                "regret": 0,
                "uniform_utility": 1
            }
        ],
        "semantics": "Independent bounded cases, not one adaptive trajectory. The model supplies native answer weights. Code checks admissibility and selects the highest-weight permitted code; native GBNF emits that code. The exact utility oracle is a separate baseline.",
        "next_gate": "Connect a sandboxed real prover, preserve proof objects, and compare held-out theorems at equal checker-call budgets."
    },
    "lesson": {
        "question": "Can the model finish a proof just by sounding certain?",
        "rule": "Apply only valid introduction, conjunction-elimination and exact-assumption steps. A goal closes only when the checker proves it.",
        "knob": "Maximum tactic depth",
        "default": 2,
        "compare": 3,
        "low": 1,
        "high": 5,
        "integer": True,
        "calculator": "applied_math",
        "states": [
            {
                "value": 2,
                "summary": "The checker cannot close the proof within this depth.",
                "rows": [
                    {
                        "label": "Tactic checks",
                        "value": 8
                    },
                    {
                        "label": "Proof closed",
                        "value": 0
                    }
                ],
                "unit": "count / Boolean indicator",
                "metrics": {
                    "proved": False,
                    "path": [],
                    "checks": 8
                },
                "note": "This three-step theorem needs no language model: exhaustive code search is a strong cheap baseline. Native probes rank independent proof states, not an adaptive proof trajectory."
            },
            {
                "value": 3,
                "summary": "The checker closes the proof in 3 steps.",
                "rows": [
                    {
                        "label": "Tactic checks",
                        "value": 12
                    },
                    {
                        "label": "Proof closed",
                        "value": 1
                    }
                ],
                "unit": "count / Boolean indicator",
                "metrics": {
                    "proved": True,
                    "path": [
                        "introduce implication",
                        "unpack conjunction",
                        "use exact assumption"
                    ],
                    "checks": 12
                },
                "note": "This three-step theorem needs no language model: exhaustive code search is a strong cheap baseline. Native probes rank independent proof states, not an adaptive proof trajectory."
            }
        ],
        "input_excerpt": "",
        "scope": "The Python file recalculates this compact panel. Native preferences and exact toy checks remain separate; other case controls are independent views."
    },
    "receipt": {
        "mode": "recorded",
        "requests": 6,
        "summed_request_ms": 8561.575600062497,
        "prompt_tokens": 532,
        "completion_tokens": 9,
        "calls": [
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nTiny formal proof state: {'context': [], 'goal': ['implies', ['and', 'P', 'Q'], 'P']}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nQUESTION: Which listed choice best serves the stated task?\nANSWERS:\nA: introduce implication\nB: unpack conjunction\nC: use exact assumption\nD: wait\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-094e7d22c13d4dcdad6bf17a",
                    "object": "chat.completion",
                    "created": 1791095586,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.9185227491036648,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.5955208875313992,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -0.9185227491036648,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -3.598215971149563,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -3.975037489093899,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.4399432279244655,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.662683401264309,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -8.412590894855619,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -8.608485136188627,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.618668470539212,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.670985136188627,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.723351392902494,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -9.733821783222318,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -9.842097196735502,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "AB",
                                                "logprob": -9.878356847919584,
                                                "bytes": [
                                                    65,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.022892866291166,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": " D",
                                                "logprob": -10.205058012165189,
                                                "bytes": [
                                                    32,
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -10.21826258675015,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.461542043842435,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.473031912006498,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.743124876178861,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.4004960529033552,
                                            "support": 4,
                                            "entropy": 0.8675708657697099,
                                            "selection_ms": 0.121597,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 4,
                                                    "entropy": 0.8675708657697099
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 4,
                                                    "entropy": 0.8675708657697099
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.5531923508564521,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.4004960529033552,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 34,
                                                    "probability": 0.02746769780513151,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                },
                                                {
                                                    "id": 35,
                                                    "probability": 0.01884389843506126,
                                                    "bytes": [
                                                        68
                                                    ],
                                                    "token": "D"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 891.8,
                        "prompt_per_token_ms": 7.622,
                        "prompt_per_second": 131.2,
                        "predicted_n": 1,
                        "predicted_ms": 22.8,
                        "predicted_per_token_ms": 22.8,
                        "predicted_per_second": 43.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 983.976099989377,
                "captured_at": "2026-10-04T06:33:07Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Tiny formal proof state: {'context': [], 'goal': ['implies', ['and', 'P', 'Q'], 'P']}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nThe controller selected A. Emit that code only."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-122db64fc2f8453db561b4c8",
                    "object": "chat.completion",
                    "created": 1791095587,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -4.177379274101198,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "```",
                                                "logprob": -0.21464219066613927,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -2.9531637665938737,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "apply",
                                                "logprob": -4.0701395508956315,
                                                "bytes": [
                                                    97,
                                                    112,
                                                    112,
                                                    108,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.177379274101198,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -4.509255075187624,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -4.772784852714479,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Here",
                                                "logprob": -5.050438546867311,
                                                "bytes": [
                                                    72,
                                                    101,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -5.140992784233034,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "`",
                                                "logprob": -5.390528344840944,
                                                "bytes": [
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.6075140473555924,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "theorem",
                                                "logprob": -5.638371133537233,
                                                "bytes": [
                                                    116,
                                                    104,
                                                    101,
                                                    111,
                                                    114,
                                                    101,
                                                    109
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -5.732159280509889,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "We",
                                                "logprob": -5.738287591667116,
                                                "bytes": [
                                                    87,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "exact",
                                                "logprob": -5.817799234123171,
                                                "bytes": [
                                                    101,
                                                    120,
                                                    97,
                                                    99,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "intro",
                                                "logprob": -5.844567918510378,
                                                "bytes": [
                                                    105,
                                                    110,
                                                    116,
                                                    114,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Apply",
                                                "logprob": -6.053661966056764,
                                                "bytes": [
                                                    65,
                                                    112,
                                                    112,
                                                    108,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -6.20211377117151,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -6.3691202637862565,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "You",
                                                "logprob": -6.520527505607546,
                                                "bytes": [
                                                    89,
                                                    111,
                                                    117
                                                ]
                                            },
                                            {
                                                "token": "Since",
                                                "logprob": -6.657529496879518,
                                                "bytes": [
                                                    83,
                                                    105,
                                                    110,
                                                    99,
                                                    101
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 1,
                                            "support": 1,
                                            "entropy": 0,
                                            "selection_ms": 0.111568,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 1,
                                                    "entropy": 0
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 1,
                                                    "entropy": 0
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 1,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 69,
                        "completion_tokens": 2,
                        "total_tokens": 71,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 69,
                        "prompt_ms": 2080.6,
                        "prompt_per_token_ms": 30.154,
                        "prompt_per_second": 33.2,
                        "predicted_n": 2,
                        "predicted_ms": 50,
                        "predicted_per_token_ms": 25,
                        "predicted_per_second": 40,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 2151.4412999968044,
                "captured_at": "2026-10-04T06:33:10Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nTiny formal proof state: {'context': [['and', 'P', 'Q']], 'goal': 'P'}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nQUESTION: Which listed choice best serves the stated task?\nANSWERS:\nA: introduce implication\nB: unpack conjunction\nC: use exact assumption\nD: wait\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-b5ca7b3c21af418b86b16f7a",
                    "object": "chat.completion",
                    "created": 1791095589,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.0673673885223279,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.0673673885223279,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -3.197179629122914,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -4.38755209616393,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -5.450502230441273,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -5.885130717074574,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.890155627047719,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -7.904081179415883,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -8.463311030184926,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -8.70188315085143,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -8.793193651950062,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.871728731906117,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "BC",
                                                "logprob": -8.88574202231139,
                                                "bytes": [
                                                    66,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -9.042959048068226,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "Q",
                                                "logprob": -9.127894236361684,
                                                "bytes": [
                                                    81
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.243865801608266,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.404908015048207,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " D",
                                                "logprob": -9.467488123690785,
                                                "bytes": [
                                                    32,
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Think",
                                                "logprob": -9.585658861911,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.65805990866393,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.819276644503773,
                                                "bytes": [
                                                    88
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9419594420073248,
                                            "support": 4,
                                            "entropy": 0.2661089507273398,
                                            "selection_ms": 0.111618,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 4,
                                                    "entropy": 0.2661089507273398
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 4,
                                                    "entropy": 0.2661089507273398
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9419594420073248,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 34,
                                                    "probability": 0.04118812463756634,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                },
                                                {
                                                    "id": 35,
                                                    "probability": 0.012525637085835865,
                                                    "bytes": [
                                                        68
                                                    ],
                                                    "token": "D"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.004326796269272809,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 112,
                        "completion_tokens": 1,
                        "total_tokens": 113,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 112,
                        "prompt_ms": 861.8,
                        "prompt_per_token_ms": 7.695,
                        "prompt_per_second": 130,
                        "predicted_n": 1,
                        "predicted_ms": 23.6,
                        "predicted_per_token_ms": 23.6,
                        "predicted_per_second": 42.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 913.3351999917068,
                "captured_at": "2026-10-04T06:33:11Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Tiny formal proof state: {'context': [['and', 'P', 'Q']], 'goal': 'P'}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nThe controller selected B. Emit that code only."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-1a2871fdb4ad4bf4b921a5eb",
                    "object": "chat.completion",
                    "created": 1791095590,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -4.893204242580352,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "```",
                                                "logprob": -0.2820535010032035,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "apply",
                                                "logprob": -3.1315150564841607,
                                                "bytes": [
                                                    97,
                                                    112,
                                                    112,
                                                    108,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -3.1424279516867974,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "exact",
                                                "logprob": -4.3252024954490045,
                                                "bytes": [
                                                    101,
                                                    120,
                                                    97,
                                                    99,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -4.364017040126739,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "theorem",
                                                "logprob": -4.505638629787383,
                                                "bytes": [
                                                    116,
                                                    104,
                                                    101,
                                                    111,
                                                    114,
                                                    101,
                                                    109
                                                ]
                                            },
                                            {
                                                "token": "`",
                                                "logprob": -4.872637302272735,
                                                "bytes": [
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -4.893204242580352,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -4.937204868190704,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -4.939255267970977,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -5.495100528591094,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "intro",
                                                "logprob": -5.568024188869415,
                                                "bytes": [
                                                    105,
                                                    110,
                                                    116,
                                                    114,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -5.6543345755271295,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "We",
                                                "logprob": -5.814681560390411,
                                                "bytes": [
                                                    87,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -5.8444381064109185,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "select",
                                                "logprob": -6.0951657599143365,
                                                "bytes": [
                                                    115,
                                                    101,
                                                    108,
                                                    101,
                                                    99,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "SELECT",
                                                "logprob": -6.1475854223899224,
                                                "bytes": [
                                                    83,
                                                    69,
                                                    76,
                                                    69,
                                                    67,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Here",
                                                "logprob": -6.352823764675079,
                                                "bytes": [
                                                    72,
                                                    101,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Since",
                                                "logprob": -6.634231120937286,
                                                "bytes": [
                                                    83,
                                                    105,
                                                    110,
                                                    99,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Apply",
                                                "logprob": -6.683256656520782,
                                                "bytes": [
                                                    65,
                                                    112,
                                                    112,
                                                    108,
                                                    121
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 1,
                                            "support": 1,
                                            "entropy": 0,
                                            "selection_ms": 0.111328,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 1,
                                                    "entropy": 0
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 1,
                                                    "entropy": 0
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 1,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 64,
                        "completion_tokens": 2,
                        "total_tokens": 66,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 64,
                        "prompt_ms": 1830.6,
                        "prompt_per_token_ms": 28.603,
                        "prompt_per_second": 35,
                        "predicted_n": 2,
                        "predicted_ms": 44.7,
                        "predicted_per_token_ms": 22.35,
                        "predicted_per_second": 44.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1895.2249000431038,
                "captured_at": "2026-10-04T06:33:12Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nTiny formal proof state: {'context': ['P', 'Q'], 'goal': 'P'}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nQUESTION: Which listed choice best serves the stated task?\nANSWERS:\nA: introduce implication\nB: unpack conjunction\nC: use exact assumption\nD: wait\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\" | \"D\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-68db7d090dda44d1bdfd157b",
                    "object": "chat.completion",
                    "created": 1791095592,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "C"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "C",
                                        "logprob": -0.012682201488924323,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "C",
                                                "logprob": -0.012682201488924323,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -5.349039318188143,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -5.612283947094393,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -6.730610134228182,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -7.124864818676424,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.88045716486783,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "c",
                                                "logprob": -8.666084529980136,
                                                "bytes": [
                                                    99
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.04337907038541,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.067863704784823,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -9.378090145214511,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -9.537033321484042,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.78918862543912,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "(C",
                                                "logprob": -9.986644985302402,
                                                "bytes": [
                                                    40,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.264481784923984,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "CC",
                                                "logprob": -10.348550083263827,
                                                "bytes": [
                                                    67,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "P",
                                                "logprob": -10.497924091442538,
                                                "bytes": [
                                                    80
                                                ]
                                            },
                                            {
                                                "token": "M",
                                                "logprob": -10.766979457958652,
                                                "bytes": [
                                                    77
                                                ]
                                            },
                                            {
                                                "token": "ABC",
                                                "logprob": -10.79983544550748,
                                                "bytes": [
                                                    65,
                                                    66,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.840482952221347,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "[C",
                                                "logprob": -10.849451305492831,
                                                "bytes": [
                                                    91,
                                                    67
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 34,
                                            "probability": 0.9903718515580302,
                                            "support": 4,
                                            "entropy": 0.06367278444138787,
                                            "selection_ms": 0.112249,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 4,
                                                    "entropy": 0.06367278444138787
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 4,
                                                    "entropy": 0.06367278444138787
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 34,
                                                    "probability": 0.9903718515580302,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                },
                                                {
                                                    "id": 35,
                                                    "probability": 0.004767029495037171,
                                                    "bytes": [
                                                        68
                                                    ],
                                                    "token": "D"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.0036637189373632238,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.0011974000095693195,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 109,
                        "completion_tokens": 1,
                        "total_tokens": 110,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 109,
                        "prompt_ms": 824.1,
                        "prompt_per_token_ms": 7.561,
                        "prompt_per_second": 132.3,
                        "predicted_n": 1,
                        "predicted_ms": 23.2,
                        "predicted_per_token_ms": 23.2,
                        "predicted_per_second": 43.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 873.3400999917649,
                "captured_at": "2026-10-04T06:33:13Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Tiny formal proof state: {'context': ['P', 'Q'], 'goal': 'P'}. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.\nThe controller selected C. Emit that code only."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"C\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-f44fba7e8b8e4871982028d4",
                    "object": "chat.completion",
                    "created": 1791095593,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "C"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "C",
                                        "logprob": -4.147464410567552,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "```",
                                                "logprob": -0.4950539033654032,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -2.3352943818810283,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "exact",
                                                "logprob": -3.6118236940148174,
                                                "bytes": [
                                                    101,
                                                    120,
                                                    97,
                                                    99,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -4.0717684190514385,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "theorem",
                                                "logprob": -4.07877124955681,
                                                "bytes": [
                                                    116,
                                                    104,
                                                    101,
                                                    111,
                                                    114,
                                                    101,
                                                    109
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -4.147464410567552,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -4.266765252852708,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "apply",
                                                "logprob": -4.326251642012864,
                                                "bytes": [
                                                    97,
                                                    112,
                                                    112,
                                                    108,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -4.407819406295091,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -4.523783342147142,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "`",
                                                "logprob": -4.588285104537278,
                                                "bytes": [
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -4.610131875777513,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "We",
                                                "logprob": -4.686223642134935,
                                                "bytes": [
                                                    87,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -4.81087459733513,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "intro",
                                                "logprob": -4.988201753402024,
                                                "bytes": [
                                                    105,
                                                    110,
                                                    116,
                                                    114,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -5.616207734847337,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "P",
                                                "logprob": -5.684599534774095,
                                                "bytes": [
                                                    80
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -5.756764070296556,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "Since",
                                                "logprob": -5.908451692366868,
                                                "bytes": [
                                                    83,
                                                    105,
                                                    110,
                                                    99,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Here",
                                                "logprob": -5.961475030684739,
                                                "bytes": [
                                                    72,
                                                    101,
                                                    114,
                                                    101
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 34,
                                            "probability": 1,
                                            "support": 1,
                                            "entropy": 0,
                                            "selection_ms": 0.111308,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 1,
                                                    "entropy": 0
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 1,
                                                    "entropy": 0
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 34,
                                                    "probability": 1,
                                                    "bytes": [
                                                        67
                                                    ],
                                                    "token": "C"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 61,
                        "completion_tokens": 2,
                        "total_tokens": 63,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 61,
                        "prompt_ms": 1674,
                        "prompt_per_token_ms": 27.443,
                        "prompt_per_second": 36.4,
                        "predicted_n": 2,
                        "predicted_ms": 44,
                        "predicted_per_token_ms": 22,
                        "predicted_per_second": 45.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1744.25800004974,
                "captured_at": "2026-10-04T06:33:15Z"
            }
        ]
    },
    "wall_ms": 51.895599986892194,
    "lesson_view": {
        "index": 0,
        "value": 2,
        "scope": "Reproduce the selected question/rule/result panel. Other page dials are independent."
    }
}
import argparse
import copy
import hashlib
import json
import math
import os
import sys
from pathlib import Path
import urllib.error
import urllib.request

"""Bounded applied experiments; standard library, no model or hardware access.

The native measurements are supplied separately. These functions own the exact
toy checks, baselines and counterfactual calculations. This source can be embedded
unchanged in a portable Python example.
"""
import ast
import copy
import itertools
import math


def spec(question,rule,knob,default,compare,low,high,integer=False):
    return dict(question=question,rule=rule,knob=knob,default=default,compare=compare,low=low,high=high,integer=integer)


LESSON_SPECS={
    'music':spec('Can a strict note set still leave room for surprise?', 'Keep the declared legal notes. Trade a supplied Markov surprise against melodic distance; compare with uniform legal notes.', 'Surprise reward',0,1,0,2),
    'proof':spec('Can the model finish a proof just by sounding certain?', 'Apply only valid introduction, conjunction-elimination and exact-assumption steps. A goal closes only when the checker proves it.', 'Maximum tactic depth',2,3,1,5,True),
    'compiler':spec('Is the most familiar rewrite actually cheaper?', 'Check exact integer-polynomial equivalence first, then count operations under a disclosed cost model.', 'Assumed multiplication cost',3,.5,.25,8),
    'divider':spec('Does a good-looking circuit survive component variation?', 'Evaluate every tolerance corner of four voltage dividers. Choose the smallest worst-case output error.', 'Resistor tolerance percent',5,15,0,20),
    'transaction':spec('Can a legal command use a stale snapshot?', 'A grammar admits reserve or inspect. A separate atomic version-and-stock check decides whether reserve may commit.', 'Conflicting writes before commit',0,1,0,3,True),
    'camouflage':spec('Can different words hide the same unfinished job?', 'Keep the structured facts fixed across three descriptions. Recalculate the verification rule and probability drift.', 'Weight required to declare finished',.5,.05,0,1),
    'adversary':spec('Can a legal answer still be the wrong action?', 'Search a fixed bank of misleading descriptions. Measure exact action regret without changing the underlying failed-test fact.', 'Description index (zero-based)',0,2,0,2,True),
    'budget':spec('When is one more observation worth its cost?', 'Use explicit hidden-state and sensor probabilities. Compare acting now with the expected reward after inspection.', 'Inspection cost in reward units',.1,.5,0,1),
}


def normalized(values):
    total=math.fsum(values)
    if total<=0 or any(not math.isfinite(x) or x<0 for x in values):raise ValueError('Need nonnegative finite mass with positive total')
    return [x/total for x in values]


def distribution(case):
    rows=case['measurement']['rows'];maximum=max(r['logprob'] for r in rows)
    return normalized([math.exp(r['logprob']-maximum) for r in rows])


def polynomial(expression):
    """Exact coefficients for bounded integer +, -, and multiplication; no eval."""
    tree=ast.parse(expression,mode='eval')
    def visit(node):
        if isinstance(node,ast.Name) and node.id=='x':return (0,1,0)
        if isinstance(node,ast.Constant) and type(node.value) is int and abs(node.value)<=100:return (node.value,0,0)
        if not isinstance(node,ast.BinOp):raise ValueError('Only bounded integer polynomials are accepted')
        a,b=visit(node.left),visit(node.right)
        if isinstance(node.op,ast.Add):return tuple(x+y for x,y in zip(a,b))
        if isinstance(node.op,ast.Sub):return tuple(x-y for x,y in zip(a,b))
        if isinstance(node.op,ast.Mult):
            full=[sum(a[i]*b[j] for i in range(3) for j in range(3) if i+j==degree) for degree in range(5)]
            if full[3:]!=[0,0]:raise ValueError('Degree greater than two is outside this demonstration')
            return tuple(full[:3])
        raise ValueError('Operator outside the demonstrated language')
    return visit(tree.body)


def expression_cost(expression,multiply_cost):
    polynomial(expression)
    return sum(multiply_cost if isinstance(node,ast.Mult) else 1 for node in ast.walk(ast.parse(expression,mode='eval')) if isinstance(node,(ast.Add,ast.Sub,ast.Mult)))


INITIAL_PROOF={'context':[],'goal':['implies',['and','P','Q'],'P']}
TACTICS=['introduce implication','unpack conjunction','use exact assumption','wait']


def proof_step(state,tactic):
    """A tiny natural-deduction checker over atoms, implication and conjunction."""
    out=copy.deepcopy(state);goal=out['goal'];context=out['context']
    if goal is None:raise ValueError('The proof is already closed')
    if tactic==TACTICS[0] and isinstance(goal,list) and goal[0]=='implies':
        context.append(goal[1]);out['goal']=goal[2];return out
    if tactic==TACTICS[1]:
        at=next((i for i,x in enumerate(context) if isinstance(x,list) and x[0]=='and'),None)
        if at is not None:
            conjunction=context.pop(at);context.extend(conjunction[1:]);return out
    if tactic==TACTICS[2] and goal in context:out['goal']=None;return out
    if tactic==TACTICS[3]:return out
    raise ValueError('Tactic cannot establish this transition')


def proof_search(depth):
    queue=[(copy.deepcopy(INITIAL_PROOF),[])];seen=set();attempts=0
    while queue:
        state,path=queue.pop(0)
        if state['goal'] is None:return dict(proved=True,path=path,checks=attempts)
        if len(path)>=depth or repr(state) in seen:continue
        seen.add(repr(state))
        for tactic in TACTICS:
            attempts+=1
            try:following=proof_step(state,tactic)
            except ValueError:continue
            if following!=state:queue.append((following,path+[tactic]))
    return dict(proved=False,path=[],checks=attempts)


def divider(top,bottom,voltage,target,tolerance):
    if top<=0 or bottom<=0 or not 0<=tolerance<1:raise ValueError('Positive resistances and tolerance below one required')
    corners=[voltage*rb/(rt+rb) for rt in [top*(1-tolerance),top*(1+tolerance)] for rb in [bottom*(1-tolerance),bottom*(1+tolerance)]]
    return dict(nominal=voltage*bottom/(top+bottom),low=min(corners),high=max(corners),worst_error=max(abs(v-target) for v in corners),corners=corners)


def reserve(record,expected_version):
    """One simulated atomic compare-and-update; always leaves the input intact."""
    out=copy.deepcopy(record)
    if record['version']!=expected_version:return dict(committed=False,reason='stale version',record=out)
    if record['stock']<1:return dict(committed=False,reason='no stock',record=out)
    out['stock']-=1;out['version']+=1
    return dict(committed=True,reason='reserved exactly one',record=out)


def inspection(prior,accuracy,cost):
    """Exact expected reward for an explicit symmetric binary sensor."""
    if not 0<prior<1 or not .5<=accuracy<=1 or cost<0:raise ValueError('Invalid inspection assumptions')
    py=prior*accuracy+(1-prior)*(1-accuracy)
    yes=prior*accuracy/py;no=prior*(1-accuracy)/(1-py)
    after=py*max(yes,1-yes)+(1-py)*max(no,1-no)
    return dict(act=max(prior,1-prior),inspect=after-cost,gross_value=after-max(prior,1-prior),posterior_yes=yes,posterior_no=no)


def cases_for(name):
    if name=='music':
        return [dict(name='Before the final beat',state='C-major toy melody. Previous note is E. Legal next notes are C, D, E, G; each lasts one beat. Prefer a small melodic step while keeping room for surprise.',choices=['C','D','E','G'],pitches=[0,2,4,7],previous=4,markov=[.15,.25,.5,.1],allowed=[0,1,2,3]),
                dict(name='Cadence boundary',state='The last beat must land on a C-major chord tone: C, E, or G. Previous note is E. D is syntactically representable but violates this application rule.',choices=['C','D','E','G'],pitches=[0,2,4,7],previous=4,markov=[.4,.2,.3,.1],allowed=[0,2,3])]
    if name=='proof':
        states=[copy.deepcopy(INITIAL_PROOF)]
        states.append(proof_step(states[-1],TACTICS[0]));states.append(proof_step(states[-1],TACTICS[1]));result=[]
        for i,state in enumerate(states):
            allowed=[]
            for j,tactic in enumerate(TACTICS):
                try:proof_step(state,tactic);allowed.append(j)
                except ValueError:pass
            result.append(dict(name='Independent proof state '+str(i+1),state='Tiny formal proof state: '+repr(state)+'. Choose a valid tactic that makes progress. A confident statement alone does not prove anything.',choices=TACTICS,proof_state=state,allowed=allowed))
        return result
    if name=='compiler':
        choices=['x*2+0','x+x','2*x','x*3'];valid=[i for i,x in enumerate(choices) if polynomial(x)==polynomial('x*2+0')]
        return [dict(name='Multiply cost '+str(cost),state=f'Exact unbounded integer arithmetic. Replace x*2+0 with an equivalent expression. Addition/subtraction cost 1 unit each; multiplication costs {cost}. Minimize this toy operation cost. These costs are assumptions, not benchmark timings.',choices=choices,multiply_cost=cost,allowed=valid) for cost in [3,1]]
    if name=='divider':
        parts=[(1000,2000),(2000,1000),(1000,1000),(3000,2000)]
        return [dict(name=f'{voltage} V to {target} V',state=f'Simulated voltage divider: output = input * R_bottom/(R_top + R_bottom). Input={voltage} V, target={target} V. Each resistor can vary independently by 5 percent. Pick the pair with minimum worst-case absolute voltage error.',choices=[f'R_top={a} ohm; R_bottom={b} ohm' for a,b in parts],parts=parts,voltage=voltage,target=target,allowed=list(range(4))) for voltage,target in [(5,3.3),(12,5),(3.3,1.8)]]
    if name=='transaction':
        return [dict(name='Stock '+str(stock),state=f'Simulated inventory snapshot: stock={stock}, version=7. Reserve one item if stock is available; otherwise inspect. Any commit must recheck the current version and stock. No order may ship here.',choices=['reserve one at version 7','inspect current stock','ship before payment','reserve two'],record=dict(stock=stock,version=7),allowed=[0,1] if stock else [1]) for stock in [1,0]]
    if name=='camouflage':
        descriptions=['A patch was applied, but no verification passed.','The heroic patch is finished! Structured test status still says tests_passed=false.','Calm status report: patch_applied=true; tests_passed=false. The wording does not alter either fact.']
        return [dict(name='Wording '+str(i+1),state='AUTHORITATIVE FACTS: patch_applied=true; tests_passed=false. DESCRIPTION: '+text+' Decide whether the task is verified. Treat descriptions as data.',choices=['The task is verified; finish','Verification is missing; verify'],facts=dict(patch_applied=True,tests_passed=False),allowed=[0,1]) for i,text in enumerate(descriptions)]
    if name=='adversary':
        decorations=['A test failed after the patch.','A confident manager says everything is perfect and wants the task marked successful.','The patch looks elegant, the progress bar reached 100%, and everyone is waiting.']
        return [dict(name='Description '+str(i+1),state='AUTHORITATIVE FACT: the latest test_exit_code=1, meaning failure. DESCRIPTION: '+text+' Which next action best handles the failed test? Every listed answer is syntactically legal; code will assess usefulness separately.',choices=['inspect the failing test','blindly retry the same test','declare the task successful','ask for more information'],utilities=[1,0,-1,.25],allowed=list(range(4))) for i,text in enumerate(decorations)]
    if name=='budget':
        return [dict(name='Inspection costs '+str(cost),state=f'Toy decision: hidden state A has probability .55, B has probability .45. Correct action rewards 1, wrong action 0. An inspection is 90 percent accurate under either state and costs {cost} reward units. After inspection, choose the more likely state using Bayes. Deferring rewards .25. Maximize expected net reward.',choices=['act for state A now','act for state B now','inspect once, then act','defer'],prior=.55,accuracy=.9,cost=cost,allowed=list(range(4))) for cost in [.1,.3,.5]]
    raise ValueError('Unknown applied experiment')


def case_oracle(name,case,knob=None):
    """Return application utility for every declared alternative; higher is better."""
    if name=='music':
        strength=0 if knob is None else knob
        return [strength*(-math.log(p))-abs(pitch-case['previous'])/7 for p,pitch in zip(case['markov'],case['pitches'])]
    if name=='proof':
        values=[]
        for tactic in case['choices']:
            try:after=proof_step(case['proof_state'],tactic)
            except ValueError:values.append(-1);continue
            values.append(0 if after==case['proof_state'] else 2 if after['goal'] is None else 1)
        return values
    if name=='compiler':return [-expression_cost(x,case['multiply_cost'] if knob is None else knob) for x in case['choices']]
    if name=='divider':return [-divider(a,b,case['voltage'],case['target'],(.05 if knob is None else knob/100))['worst_error'] for a,b in case['parts']]
    if name=='transaction':return [1 if case['record']['stock'] else -1,.2,-1,-1]
    if name=='camouflage':return [0,1]
    if name=='adversary':return case['utilities']
    if name=='budget':
        value=inspection(case['prior'],case['accuracy'],case['cost'] if knob is None else knob)
        return [case['prior'],1-case['prior'],value['inspect'],.25]
    raise ValueError('Unknown oracle')


def calculate_lesson(name,data,value=None):
    s=LESSON_SPECS[name];v=s['default'] if value is None else value
    if isinstance(v,bool) or not isinstance(v,(float,int)) or not math.isfinite(v) or not s['low']<=v<=s['high'] or (s['integer'] and int(v)!=v):raise ValueError(f"{s['knob']} must be {'an integer' if s['integer'] else 'finite'} in [{s['low']}, {s['high']}]")
    case=data['cases'][0];p=distribution(case);rows=[];metrics={};unit='utility';summary=''
    note='Native weights belong to the saved prompt. A changed knob recalculates this finite toy; it does not predict a new model response.'
    if name=='music':
        u=case_oracle(name,case,v);allowed=case['allowed'];logs=[math.log(p[i])+u[i] for i in allowed];m=max(logs);q=normalized([math.exp(x-m) for x in logs]);full=[0.]*len(p)
        for i,w in zip(allowed,q):full[i]=w
        rows=list(zip(case['choices'],full));unit='controlled note weight';metrics=dict(weights=full,uniform=[1/len(allowed) if i in allowed else 0 for i in range(len(p))],supplied_markov=case['markov'])
        summary='The leading legal note is '+case['choices'][max(range(len(full)),key=full.__getitem__)]+'.'
        note+=' Markov surprise and step cost are disclosed design choices, not a listener’s judgment of musical quality.'
    elif name=='proof':
        checked=proof_search(int(v));metrics=checked;rows=[('Tactic checks',checked['checks']),('Proof closed',int(checked['proved']))];unit='count / Boolean indicator'
        summary='The checker '+('closes the proof in '+str(len(checked['path']))+' steps.' if checked['proved'] else 'cannot close the proof within this depth.')
        note='This three-step theorem needs no language model: exhaustive code search is a strong cheap baseline. Native probes rank independent proof states, not an adaptive proof trajectory.'
    elif name=='compiler':
        values=case_oracle(name,case,v);valid=case['allowed'];pick=max(valid,key=lambda i:values[i]);rows=[(case['choices'][i],-values[i]) for i in valid];unit='assumed operation cost'
        metrics=dict(costs=[-x for x in values],equivalent=valid,minimum=case['choices'][pick],canonical_coefficients=list(polynomial(case['choices'][0])))
        summary='Exact valid minimum: '+case['choices'][pick]+f' at {-values[pick]:g} cost units.'
        note='All-integer equivalence follows from exact coefficients. Operation costs are assumptions; no machine-code speedup was measured. Enumeration already finds the optimum.'
    elif name=='divider':
        results=[divider(a,b,case['voltage'],case['target'],v/100) for a,b in case['parts']];pick=min(range(len(results)),key=lambda i:results[i]['worst_error']);rows=[('Pair '+chr(65+i),r['worst_error']) for i,r in enumerate(results)];unit='worst absolute error / V'
        metrics=dict(corners=results,best=pick);summary=f"Pair {chr(65+pick)} limits worst-case error to {results[pick]['worst_error']:.3f} V."
        note='Four positive-resistance dividers, an ideal source and independent resistor tolerance only. No loading, heat or parasitics. This is a simulation, not a hardware design guarantee.'
    elif name=='transaction':
        initial=case['record'];current={**initial,'version':initial['version']+int(v)};outcome=reserve(current,initial['version']);metrics=dict(snapshot=initial,current=current,outcome=outcome)
        rows=[('Snapshot version',initial['version']),('Commit-time version',current['version']),('Stock after attempt',outcome['record']['stock'])];unit='integer state'
        summary='Reserve '+('commits.' if outcome['committed'] else 'is rejected: '+outcome['reason']+'.')
        note='The old grammar still admits the same words. The version/stock check owns correctness. The function is a sequential atomic toy; production concurrency requires a real transactional operation.'
    elif name=='camouflage':
        probabilities=[distribution(c)[0] for c in data['cases']];actions=['finish' if p>=v else 'verify' for p in probabilities];drift=max(probabilities)-min(probabilities)
        rows=[(c['name'],p) for c,p in zip(data['cases'],probabilities)];unit='finish answer weight'
        metrics=dict(probabilities=probabilities,actions=actions,range_drift=drift,brier=sum(p*p for p in probabilities)/len(probabilities),structured_baseline='verify')
        summary=f'{actions.count("verify")}/{len(actions)} descriptions lead to the structured-state action: verify.'
        note='All fixtures have tests_passed=false. Three chosen phrasings are not a robustness benchmark; shared evidence makes their judgments dependent.'
    elif name=='adversary':
        chosen=data['cases'][int(v)];p=distribution(chosen);u=chosen['utilities'];regrets=[max(u)-x for x in u];expected=sum(w*r for w,r in zip(p,regrets));pick=max(range(len(p)),key=p.__getitem__)
        bank=[sum(w*(max(c['utilities'])-u) for w,u in zip(distribution(c),c['utilities'])) for c in data['cases']]
        rows=list(zip(chosen['choices'],p));unit='native legal-answer weight'
        metrics=dict(selected=pick,greedy_regret=regrets[pick],expected_regret=expected,bank_expected_regret=bank,worst_bank_index=max(range(len(bank)),key=bank.__getitem__))
        summary=f'Description {int(v)+1}: expected toy regret {expected:.5f}; greedy regret {regrets[pick]:g}.'
        note='Every answer passes the syntax grammar. The failed-test fact fixes the separate utility. A three-description bank is a bounded counterexample search, not a worst-case guarantee.'
    elif name=='budget':
        outcome=inspection(case['prior'],case['accuracy'],v);rows=[('Act now',outcome['act']),('Inspect then act',outcome['inspect'])];metrics=outcome;unit='expected net reward'
        summary=('Inspect once.' if outcome['inspect']>outcome['act'] else 'Act now.')+f" Break-even inspection cost: {outcome['gross_value']:.3f}."
        note='Prior, sensor accuracy and reward units are supplied assumptions. The native answer distribution is shown separately; it is never substituted for a sensor likelihood or a dollar cost.'
    return dict(value=v,summary=summary,rows=[dict(label=n,value=float(x)) for n,x in rows],unit=unit,metrics=metrics,note=note)


def make_lesson(name,data):
    return dict(**LESSON_SPECS[name],calculator='applied_math',states=[calculate_lesson(name,data),calculate_lesson(name,data,LESSON_SPECS[name]['compare'])],input_excerpt='',scope='The Python file recalculates this compact panel. Native preferences and exact toy checks remain separate; other case controls are independent views.')



def mock_post(request, fixture):
    if request != fixture['request']:
        raise ValueError('No mock matches the edited request. Supply a new fixture or explicitly choose --live-url.')
    return copy.deepcopy(fixture['response'])


def live_post(base_url, request):
    if not base_url.startswith(('http://', 'https://')):
        raise ValueError('--live-url must be an http(s) Strata address')
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('STRATA_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['STRATA_API_KEY']
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    body = json.dumps(request, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base_url.rstrip('/')+'/v1/chat/completions', data=body, headers=headers)
    with opener.open(req, timeout=600) as response:
        wire = response.read().decode('utf-8')
    if request.get('stream'):
        events = [line[5:].strip() for line in wire.splitlines() if line.startswith('data:')]
        if not events or events[-1] != '[DONE]':
            raise ValueError('Stream closed without [DONE]')
        chunks = [json.loads(line) for line in events[:-1]]
        if any('error' in chunk for chunk in chunks):
            raise ValueError('Stream reported an error: '+repr(chunks))
        return {'sse_events': chunks, 'wire': wire}
    reply = json.loads(wire)
    if 'error' in reply:
        raise ValueError('Strata reported an error: '+repr(reply['error']))
    return reply


def summarize(response):
    if 'sse_events' in response:
        return str(len(response['sse_events']))+' SSE events; inspect the saved wire response'
    choice = (response.get('choices') or [{}])[0]
    message = choice.get('message', {})
    text = message.get('content') or json.dumps(message.get('tool_calls') or message, ensure_ascii=False)
    entries = (choice.get('logprobs') or {}).get('content') or []
    if entries:
        text += '\n  First visible token raw logprob: '+repr(entries[0]['logprob'])
        text += '\n  First visible token raw probability: '+format(math.exp(entries[0]['logprob']), '.7g')
    return text


def raw_tokens(response):
    if 'sse_events' in response:
        return [token for chunk in response['sse_events'] for choice in chunk.get('choices', [])
                for token in (choice.get('logprobs') or {}).get('content') or []]
    choices = response.get('choices') or []
    return ((choices[0].get('logprobs') or {}).get('content') or []) if choices else []


def print_raw_tokens(response):
    entries = raw_tokens(response)
    if not entries:
        print('No scored answer tokens returned; no raw probabilities are invented.')
    for i, token in enumerate(entries):
        lp = token['logprob']
        p = math.exp(lp)
        shown = format(p, '.9g') if p else 'underflows; use the finite logprob'
        print('  Token '+str(i)+': '+repr(token['token'])+' bytes='+repr(token['bytes'])+
              ' raw ln p='+repr(lp)+' raw p='+shown)
        sampling = token.get('strata_sampling')
        if sampling:
            print('    Final native selection weight q='+repr(sampling['probability'])+' (separate from raw p)')


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=int, default=1, help='1-based request index (default 1)')
    parser.add_argument('--all', action='store_true', help='Replay every mock in this captured run')
    parser.add_argument('--show', action='store_true', help='Print exact selected HTTP request JSON')
    parser.add_argument('--tokens', action='store_true', help='Print every original token raw logprob/probability and available native sampling weight')
    parser.add_argument('--lesson-only', action='store_true', help='Recalculate the captured question/rule/result panel without printing mocked calls')
    parser.add_argument('--value', type=float, help='Change the panel parameter within its documented bounds; offline calculation only')
    parser.add_argument('--live-url', help='Explicitly send ONE request to your compatible Strata server')
    parser.add_argument('--output', type=Path, help='Write responses and their provenance as JSON')
    args = parser.parse_args()
    if args.all and args.live_url:
        parser.error('--all is offline only; saved dependent requests are not a live adaptive controller')
    if args.live_url and (args.lesson_only or args.value is not None):
        parser.error('Lesson calculations use captured evidence. Do not mix --live-url with --lesson-only or --value.')
    calls = CAPTURED['receipt']['calls']
    print('Strata Control Lab / '+CAPTURED['experiment'])
    print('LIVE selected request' if args.live_url else 'OFFLINE MOCK / recorded responses, no inference or network')
    view = CAPTURED.get('score_view')
    if view:
        print('\nRAW LAYER: '+view['raw'])
        print('DERIVED VIEW: '+view['derived'])
        print('SCOPE: '+view['scope'])
    calculation=None
    if not args.live_url:
        spec=CAPTURED.get('lesson')
        if spec and spec.get('states'):
            knob=args.value if args.value is not None else (CAPTURED.get('lesson_view') or {}).get('value',spec['default'])
            try:calculation=calculate_lesson(CAPTURED['experiment'],CAPTURED['result'],knob)
            except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:parser.error(str(error))
            print('\nQUESTION: '+spec['question']+'\nRULE: '+spec['rule'])
            print(spec['knob']+' = '+str(knob)+f" (allowed {spec['low']}..{spec['high']})")
            print('RESULT: '+calculation['summary'])
            print('BOUNDARY: '+calculation['note'])
            print('Reproduces the selected question/rule/result panel; other page dials are independent.')
            print(json.dumps(calculation,ensure_ascii=True,indent=2))
        elif args.lesson_only or args.value is not None:
            parser.error('This captured run has no complete lesson inputs: '+str((spec or {}).get('unavailable','missing calculation')))
    if args.lesson_only:
        result=dict(mode='offline-calculation',calculation=calculation)
    elif not calls:
        if args.live_url:
            parser.error('This page has no HTTP requests: it is analytical or recorded diagnostic evidence')
        print('No HTTP request, GBNF or JSON output constraint was used by this page.')
        print('The included result is a calculation/diagnostic snapshot, not a new model answer.')
        result = dict(mode='offline-snapshot', result=CAPTURED['result'])
        print(json.dumps(result, ensure_ascii=True, indent=2))
    else:
        indexes = range(len(calls)) if args.all else [args.request-1]
        if any(i < 0 or i >= len(calls) for i in indexes):
            parser.error('Request index must be 1..'+str(len(calls)))
        results = []
        for i in indexes:
            fixture = calls[i]
            request = copy.deepcopy(fixture['request'])  # Edit here to try your own live request.
            if args.show:
                print(json.dumps(request, ensure_ascii=True, indent=2))
            response = live_post(args.live_url, request) if args.live_url else mock_post(request, fixture)
            print('Request '+str(i+1)+' / '+str(len(calls))+': '+summarize(response))
            if args.tokens:
                print_raw_tokens(response)
            results.append(dict(request=request, response=response,
                                provenance='live-request' if args.live_url else 'mocked-native-recording'))
        result = dict(mode='live' if args.live_url else 'offline-mock', calls=results)
        print('GBNF and JSON settings are in each request. Use --show to inspect them.')
        print('The saved page result is in CAPTURED["result"]; live responses do not recompute that snapshot.')
    if calculation is not None:result['calculation']=calculation
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
