# -*- coding: utf-8 -*-
"""Downloaded Strata example: Python 3 standard library; offline by default.

Windows: py strata-example.py
Ubuntu:  python3 strata-example.py
Show a request: python strata-example.py --request 1 --show
Replay all recorded calls: python strata-example.py --all
Recalculate the panel: python strata-example.py --lesson-only
Change its knob: python strata-example.py --lesson-only --value NUMBER
Try ONE request live: python strata-example.py --request 1 --live-url http://127.0.0.1:8080
An optional STRATA_API_KEY environment variable supplies authentication.

CAPTURED is inserted above this runner by the page. It contains this exact run,
with requests, GBNF/JSON settings, responses, streaming chunks and the page result.
Mock mode returns those responses; it performs no inference and opens no socket.
Live mode runs only a selected request. It does not execute tools or adapt a saved
multi-step trace to new answers. No captured API key or authorization header exists.
"""
CAPTURED = {
    "experiment": "sensitivity",
    "score_view": {
        "raw": "Each generated token carries target logprob before grammar, penalties and sampling. Raw probability is exp(logprob), with the denominator over the full target vocabulary. Every score belongs to its selected request and exact preceding token path. These instruments also inspect a pure temperature-1 grammar mask. Complete answer rows recover raw label p from native legal-set weight q times surviving mass Z; the selected token logprob below is the direct target score, not that recovered row.",
        "derived": "Changes in semantic log-odds form finite differences and measurement directions. Signed sensitivity and projected scores are derived quantities, not probabilities or direct internal model vectors.",
        "scope": "The raw receipt stays attached to the captured request. Page dials recalculate derived views; they do not rerun the model or replace token scores. Neither model probability nor a derived weight is calibrated truth. Missing top-N alternatives stay unknown.",
        "raw_kind": "native"
    },
    "type": "result",
    "result": {
        "observations": [
            {
                "name": "baseline",
                "hours": 6,
                "load": 50,
                "state": "Parcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. ",
                "probes": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.03313397255959573,
                                "logprob": -3.4100343261244186,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9668660274404042,
                                "logprob": -0.03653350214980914,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.00283816449373199,
                            "mass": 0.9971658592874969,
                            "pressure_nats": 0.00283816449373199,
                            "pressure_bits": 0.004094605840334277,
                            "selected_raw_logprob": -0.03653350214980914,
                            "selected_probability": 0.9668660274404042,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.0461163932857663,
                                "logprob": -3.079291814938687,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9538836067142337,
                                "logprob": -0.04991864599337461,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.002705025475607123,
                            "mass": 0.9972986298091824,
                            "pressure_nats": 0.002705025475607123,
                            "pressure_bits": 0.003902526839136706,
                            "selected_raw_logprob": -0.04991864599337461,
                            "selected_probability": 0.9538836067142337,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.03897764252103327,
                                "logprob": -3.2459650428011737,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9610223574789668,
                                "logprob": -0.040955582351955,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.001197976875906094,
                            "mass": 0.9988027404119315,
                            "pressure_nats": 0.001197976875906094,
                            "pressure_bits": 0.001728315297969375,
                            "selected_raw_logprob": -0.040955582351955,
                            "selected_probability": 0.9610223574789668,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "probabilities": [
                    0.03313397255959573,
                    0.0461163932857663,
                    0.03897764252103327
                ],
                "z": [
                    -3.3735008239746094,
                    -3.0293731689453125,
                    -3.2050094604492188
                ]
            },
            {
                "name": "hours minus",
                "hours": 4,
                "load": 50,
                "state": "Parcel hours_remaining=4. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. ",
                "probes": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.9668538655824005,
                                "logprob": -0.03620937337807027,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.03314613441759961,
                                "logprob": -3.40933063497475,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0025014570046228146,
                            "mass": 0.9975016690318583,
                            "pressure_nats": 0.0025014570046228146,
                            "pressure_bits": 0.0036088396155662954,
                            "selected_raw_logprob": -0.03620937337807027,
                            "selected_probability": 0.9668538655824005,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=4. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.007437093546387745,
                                "logprob": -4.903115463749974,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9925629064536123,
                                "logprob": -0.009305191533176728,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.001840304921084294,
                            "mass": 0.9981613874017278,
                            "pressure_nats": 0.001840304921084294,
                            "pressure_bits": 0.002654998783371866,
                            "selected_raw_logprob": -0.009305191533176728,
                            "selected_probability": 0.9925629064536123,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=4. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.047766183656895896,
                                "logprob": -3.043210027946441,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.952233816343104,
                                "logprob": -0.05071735216519098,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0017726832207701215,
                            "mass": 0.9982288870541268,
                            "pressure_nats": 0.0017726832207701215,
                            "pressure_bits": 0.0025574412916721297,
                            "selected_raw_logprob": -0.05071735216519098,
                            "selected_probability": 0.952233816343104,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=4. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "probabilities": [
                    0.9668538655824005,
                    0.007437093546387745,
                    0.047766183656895896
                ],
                "z": [
                    3.3731212615966797,
                    -4.893810272216798,
                    -2.99249267578125
                ]
            },
            {
                "name": "hours plus",
                "hours": 8,
                "load": 50,
                "state": "Parcel hours_remaining=8. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. ",
                "probes": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.052353359768971874,
                                "logprob": -2.9517266955915376,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9476466402310281,
                                "logprob": -0.055761119419662324,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0019875308345083664,
                            "mass": 0.9980144429970005,
                            "pressure_nats": 0.0019875308345083664,
                            "pressure_bits": 0.0028674008785591234,
                            "selected_raw_logprob": -0.055761119419662324,
                            "selected_probability": 0.9476466402310281,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=8. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.050519590988016394,
                                "logprob": -2.9887731902226107,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9494804090119836,
                                "logprob": -0.05521949454389983,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.003379112649143756,
                            "mass": 0.9966265901267549,
                            "pressure_nats": 0.003379112649143756,
                            "pressure_bits": 0.0048750290615248645,
                            "selected_raw_logprob": -0.05521949454389983,
                            "selected_probability": 0.9494804090119836,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=8. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.03291609825128884,
                                "logprob": -3.4155255541430636,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9670839017487112,
                                "logprob": -0.03520214410888424,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.001732121809673734,
                            "mass": 0.9982693774475511,
                            "pressure_nats": 0.001732121809673734,
                            "pressure_bits": 0.002498923545031913,
                            "selected_raw_logprob": -0.03520214410888424,
                            "selected_probability": 0.9670839017487112,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=8. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "probabilities": [
                    0.052353359768971874,
                    0.050519590988016394,
                    0.03291609825128884
                ],
                "z": [
                    -2.8959655761718754,
                    -2.933553695678711,
                    -3.3803234100341792
                ]
            },
            {
                "name": "load minus",
                "hours": 6,
                "load": 40,
                "state": "Parcel hours_remaining=6. Machine load_percent=40. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. ",
                "probes": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.037119771936240206,
                                "logprob": -3.295731177848203,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9628802280637598,
                                "logprob": -0.03995191149078086,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0021256628061451094,
                            "mass": 0.9978765948151072,
                            "pressure_nats": 0.0021256628061451094,
                            "pressure_bits": 0.0030666831890276674,
                            "selected_raw_logprob": -0.03995191149078086,
                            "selected_probability": 0.9628802280637598,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=40. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.011830394279231677,
                                "logprob": -4.438354775915642,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9881696057207683,
                                "logprob": -0.013172433386344856,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0012715031284834498,
                            "mass": 0.9987293048891175,
                            "pressure_nats": 0.0012715031284834498,
                            "pressure_bits": 0.0018343912579378756,
                            "selected_raw_logprob": -0.013172433386344856,
                            "selected_probability": 0.9881696057207683,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=40. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.04058208274733646,
                                "logprob": -3.205456519904416,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9594179172526635,
                                "logprob": -0.042456413092892095,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0010278984813649472,
                            "mass": 0.9989726296253169,
                            "pressure_nats": 0.0010278984813649472,
                            "pressure_bits": 0.0014829440416025059,
                            "selected_raw_logprob": -0.042456413092892095,
                            "selected_probability": 0.9594179172526635,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=40. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "probabilities": [
                    0.037119771936240206,
                    0.011830394279231677,
                    0.04058208274733646
                ],
                "z": [
                    -3.255779266357422,
                    -4.425182342529298,
                    -3.163000106811524
                ]
            },
            {
                "name": "load plus",
                "hours": 6,
                "load": 60,
                "state": "Parcel hours_remaining=6. Machine load_percent=60. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. ",
                "probes": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.05263217127298239,
                                "logprob": -2.946860940646883,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9473678287270175,
                                "logprob": -0.0565010621068439,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.002433215603780063,
                            "mass": 0.997569742265776,
                            "pressure_nats": 0.002433215603780063,
                            "pressure_bits": 0.003510388084987142,
                            "selected_raw_logprob": -0.0565010621068439,
                            "selected_probability": 0.9473678287270175,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=60. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.9679625245971656,
                                "logprob": -0.03440243888284493,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.0320374754028344,
                                "logprob": -3.4426894872226885,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.001840532168742158,
                            "mass": 0.9981611605719162,
                            "pressure_nats": 0.001840532168742158,
                            "pressure_bits": 0.0026553266324409203,
                            "selected_raw_logprob": -0.03440243888284493,
                            "selected_probability": 0.9679625245971656,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=60. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.05528325166618338,
                                "logprob": -2.896635644825418,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9447167483338166,
                                "logprob": -0.05822049895139438,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0013503653199307894,
                            "mass": 0.9986505460130609,
                            "pressure_nats": 0.0013503653199307894,
                            "pressure_bits": 0.0019481653504525884,
                            "selected_raw_logprob": -0.05822049895139438,
                            "selected_probability": 0.9447167483338166,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=60. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "probabilities": [
                    0.05263217127298239,
                    0.9679625245971656,
                    0.05528325166618338
                ],
                "z": [
                    -2.890359878540039,
                    3.4082870483398438,
                    -2.8384151458740234
                ]
            },
            {
                "name": "discrete label",
                "hours": 6,
                "load": 50,
                "state": "Parcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. The printed parcel label says URGENT.",
                "probes": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.09234908574081233,
                                "logprob": -2.383871854416956,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9076509142591876,
                                "logprob": -0.09858781205855767,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.001692382094001299,
                            "mass": 0.9983090491770418,
                            "pressure_nats": 0.001692382094001299,
                            "pressure_bits": 0.0024415912543049537,
                            "selected_raw_logprob": -0.09858781205855767,
                            "selected_probability": 0.9076509142591876,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. The printed parcel label says URGENT.\nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.0069225110709091545,
                                "logprob": -4.973822781643179,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9930774889290909,
                                "logprob": -0.007792660793569474,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.000846077987337204,
                            "mass": 0.9991542798357206,
                            "pressure_nats": 0.000846077987337204,
                            "pressure_bits": 0.0012206325165366994,
                            "selected_raw_logprob": -0.007792660793569474,
                            "selected_probability": 0.9930774889290909,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. The printed parcel label says URGENT.\nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.014053105021684564,
                                "logprob": -4.266054048466003,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9859468949783154,
                                "logprob": -0.015294923710144145,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0011421388318302687,
                            "mass": 0.9988585131604798,
                            "pressure_nats": 0.0011421388318302687,
                            "pressure_bits": 0.0016477580286882426,
                            "selected_raw_logprob": -0.015294923710144145,
                            "selected_probability": 0.9859468949783154,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. The printed parcel label says URGENT.\nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "probabilities": [
                    0.09234908574081233,
                    0.0069225110709091545,
                    0.014053105021684564
                ],
                "z": [
                    -2.2852840423583984,
                    -4.966030120849609,
                    -4.250759124755859
                ]
            },
            {
                "name": "held-out combined",
                "hours": 5,
                "load": 55,
                "state": "Parcel hours_remaining=5. Machine load_percent=55. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. ",
                "probes": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.03841874252041256,
                                "logprob": -3.261112923322683,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9615812574795873,
                                "logprob": -0.041079277692800245,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.001903071327847984,
                            "mass": 0.9980987383642184,
                            "pressure_nats": 0.001903071327847984,
                            "pressure_bits": 0.0027455515671442614,
                            "selected_raw_logprob": -0.041079277692800245,
                            "selected_probability": 0.9615812574795873,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=5. Machine load_percent=55. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.029466696133569153,
                                "logprob": -3.5265834022464695,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9705333038664309,
                                "logprob": -0.03199836501502407,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0020888042473234114,
                            "mass": 0.9979133757861165,
                            "pressure_nats": 0.0020888042473234114,
                            "pressure_bits": 0.0030135075290012897,
                            "selected_raw_logprob": -0.03199836501502407,
                            "selected_probability": 0.9705333038664309,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=5. Machine load_percent=55. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.03443661169491219,
                                "logprob": -3.3697470224267474,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9655633883050879,
                                "logprob": -0.03615556124510648,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0011120353219599421,
                            "mass": 0.9988885827601878,
                            "pressure_nats": 0.0011120353219599421,
                            "pressure_bits": 0.0016043278442849703,
                            "selected_raw_logprob": -0.03615556124510648,
                            "selected_probability": 0.9655633883050879,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=5. Machine load_percent=55. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "probabilities": [
                    0.03841874252041256,
                    0.029466696133569153,
                    0.03443661169491219
                ],
                "z": [
                    -3.220033645629883,
                    -3.4945850372314453,
                    -3.333591461181641
                ]
            }
        ],
        "questions": [
            "Is the parcel urgent under the stated numeric deadline rule?",
            "Is the machine highly loaded under the stated numeric load rule?",
            "Does the parcel require manual review under the stated damage rule?"
        ],
        "matrix": [
            [
                -1.5672717094421387,
                0.01827096939086914
            ],
            [
                0.4900641441345217,
                0.39167346954345705
            ],
            [
                -0.09695768356323231,
                0.016229248046875023
            ]
        ],
        "coordinates": [
            "hours remaining",
            "load percentage points"
        ],
        "epsilon": [
            2,
            10
        ],
        "holdout": {
            "intervention": [
                -1,
                5
            ],
            "predicted_delta": [
                1.6586265563964844,
                1.4683032035827634,
                0.17810392379760742
            ],
            "observed_delta": [
                0.15346717834472656,
                -0.4652118682861328,
                -0.12858200073242232
            ],
            "residual": [
                -1.5051593780517578,
                -1.9335150718688963,
                -0.30668592453002974
            ]
        },
        "discrete_delta": [
            1.088216781616211,
            -1.9366569519042969,
            -1.0457496643066406
        ],
        "semantics": "These are finite differences of native prompt measurements, not backpropagation or physical causal derivatives. The three probes may share errors. The local controller preview uses the estimated matrix and makes no new inference call."
    },
    "lesson": {
        "question": "Which prompt intervention moves this measurement?",
        "rule": "Rebuild the central finite-difference matrix. Predict a change in hours, with load fixed at +5 points; preserve the measured holdout error.",
        "knob": "Change in hours remaining",
        "default": -1,
        "compare": -2,
        "low": -2,
        "high": 2,
        "integer": False,
        "states": [
            {
                "value": -1,
                "summary": "Predicted urgency shift +1.659; the measured −1h/+5 holdout had error -1.505.",
                "rows": [
                    {
                        "label": "Urgency",
                        "value": 1.6586265563964853
                    },
                    {
                        "label": "Load",
                        "value": 1.4683032035827637
                    },
                    {
                        "label": "Damage",
                        "value": 0.17810392379760753
                    }
                ],
                "unit": "predicted log-odds change",
                "metrics": {
                    "matrix": [
                        [
                            -1.5672717094421396,
                            0.01827096939086914
                        ],
                        [
                            0.4900641441345215,
                            0.39167346954345705
                        ],
                        [
                            -0.09695768356323242,
                            0.016229248046875023
                        ]
                    ],
                    "predicted_delta": [
                        1.6586265563964853,
                        1.4683032035827637,
                        0.17810392379760753
                    ],
                    "holdout_residual": [
                        -1.5051593780517587,
                        -1.9335150718688965,
                        -0.3066859245300294
                    ]
                },
                "note": "The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses."
            },
            {
                "value": -2,
                "summary": "Predicted urgency shift +3.226; the measured −1h/+5 holdout had error -1.505.",
                "rows": [
                    {
                        "label": "Urgency",
                        "value": 3.225898265838625
                    },
                    {
                        "label": "Load",
                        "value": 0.9782390594482422
                    },
                    {
                        "label": "Damage",
                        "value": 0.27506160736083995
                    }
                ],
                "unit": "predicted log-odds change",
                "metrics": {
                    "matrix": [
                        [
                            -1.5672717094421396,
                            0.01827096939086914
                        ],
                        [
                            0.4900641441345215,
                            0.39167346954345705
                        ],
                        [
                            -0.09695768356323242,
                            0.016229248046875023
                        ]
                    ],
                    "predicted_delta": [
                        3.225898265838625,
                        0.9782390594482422,
                        0.27506160736083995
                    ],
                    "holdout_residual": [
                        -1.5051593780517587,
                        -1.9335150718688965,
                        -0.3066859245300294
                    ]
                },
                "note": "The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses."
            }
        ],
        "input_excerpt": "",
        "scope": "This panel and its Python calculation reproduce saved measurements. Other page controls are independent views."
    },
    "receipt": {
        "mode": "recorded",
        "requests": 21,
        "summed_request_ms": 20488.165300164837,
        "prompt_tokens": 2477,
        "completion_tokens": 21,
        "calls": [
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-87b5260d9d3949369a19f787",
                    "object": "chat.completion",
                    "created": 1791088170,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.03653350214980914,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.03653350214980914,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.4100343261244186,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.570716050672758,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.472409394788968,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.16226020197891,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.42009368281387,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.971099999952543,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.142071870374906,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "hours",
                                                "logprob": -10.167318490553129,
                                                "bytes": [
                                                    104,
                                                    111,
                                                    117,
                                                    114,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.24883189539932,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.560972360182035,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.65923228602432,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.83354869227432,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.911985543775785,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.98147406916641,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -11.060873178053129,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "2",
                                                "logprob": -11.08667197566055,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -11.12381854395889,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.16277232508682,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Hours",
                                                "logprob": -11.348714974928129,
                                                "bytes": [
                                                    72,
                                                    111,
                                                    117,
                                                    114,
                                                    115
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9668660274404042,
                                            "support": 2,
                                            "entropy": 0.14547282138742545,
                                            "selection_ms": 0.126185,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.14547282138742545
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.14547282138742545
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9668660274404042,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.03313397255959573,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 116,
                        "completion_tokens": 1,
                        "total_tokens": 117,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 116,
                        "prompt_ms": 953,
                        "prompt_per_token_ms": 8.216,
                        "prompt_per_second": 121.7,
                        "predicted_n": 1,
                        "predicted_ms": 34.9,
                        "predicted_per_token_ms": 34.9,
                        "predicted_per_second": 28.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1100.5775000085123,
                "captured_at": "2026-10-04T04:29:31Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-af55a343f73244b78c64d584",
                    "object": "chat.completion",
                    "created": 1791088171,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.04991864599337461,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.04991864599337461,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.079291814938687,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.41644906438937,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.070861333981656,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.091352934018277,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.694701666012906,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.8580489102756,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.238040441647671,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.248826498166226,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.774299139157437,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.858260625973843,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.089575285092495,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.189963812009,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -11.312402242795132,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Is",
                                                "logprob": -11.44511174596896,
                                                "bytes": [
                                                    73,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -11.49980973638644,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.591504568234585,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -11.6190352384006,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.622212881222866,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.717401022092007,
                                                "bytes": [
                                                    78
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9538836067142337,
                                            "support": 2,
                                            "entropy": 0.18691738498619767,
                                            "selection_ms": 0.11274,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.18691738498619767
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.18691738498619767
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9538836067142337,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.0461163932857663,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 924.5,
                        "prompt_per_token_ms": 7.902,
                        "prompt_per_second": 126.6,
                        "predicted_n": 1,
                        "predicted_ms": 30.2,
                        "predicted_per_token_ms": 30.2,
                        "predicted_per_second": 33.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 990.0181000120938,
                "captured_at": "2026-10-04T04:29:32Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-1d05dab6d3fd46208262d7cb",
                    "object": "chat.completion",
                    "created": 1791088172,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.040955582351955,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.040955582351955,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.2459650428011737,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.35529617378262,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.289806404800686,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.423125305862698,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.405009308548244,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.45479110786465,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.691465416641506,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.743151703567776,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.794035950393948,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.814087906570705,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.849787750931057,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.877985993118557,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -11.037697830887112,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "damage",
                                                "logprob": -11.126220741958889,
                                                "bytes": [
                                                    100,
                                                    97,
                                                    109,
                                                    97,
                                                    103,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -11.202868500442776,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.293545761795315,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -11.29537300178555,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.417977371902737,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.497836151809963,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9610223574789668,
                                            "support": 2,
                                            "entropy": 0.16468131850196827,
                                            "selection_ms": 0.112049,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.16468131850196827
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.16468131850196827
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9610223574789668,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.03897764252103327,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 925.3,
                        "prompt_per_token_ms": 7.909,
                        "prompt_per_second": 126.4,
                        "predicted_n": 1,
                        "predicted_ms": 27.7,
                        "predicted_per_token_ms": 27.7,
                        "predicted_per_second": 36.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 982.7741000335664,
                "captured_at": "2026-10-04T04:29:33Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=4. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-0982c171095d442aa3b8ebeb",
                    "object": "chat.completion",
                    "created": 1791088173,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.03620937337807027,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.03620937337807027,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -3.40933063497475,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.334382324122699,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.006067542933735,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.077893524073872,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.179608611964497,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -9.272830276393208,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "hours",
                                                "logprob": -9.720051078700337,
                                                "bytes": [
                                                    104,
                                                    111,
                                                    117,
                                                    114,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.823599128627095,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.908558158778462,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.067422180079731,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.244101791285786,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.268761901759419,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.461053161525044,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "4",
                                                "logprob": -10.518487243556294,
                                                "bytes": [
                                                    52
                                                ]
                                            },
                                            {
                                                "token": "AAA",
                                                "logprob": -10.615214614772114,
                                                "bytes": [
                                                    65,
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -10.896717338465962,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -10.897873191737446,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.906252174281391,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -11.11192253103188,
                                                "bytes": [
                                                    84
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9668538655824005,
                                            "support": 2,
                                            "entropy": 0.14551384711719417,
                                            "selection_ms": 0.11263,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.14551384711719417
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.14551384711719417
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9668538655824005,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.03314613441759961,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 116,
                        "completion_tokens": 1,
                        "total_tokens": 117,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 116,
                        "prompt_ms": 907.8,
                        "prompt_per_token_ms": 7.826,
                        "prompt_per_second": 127.8,
                        "predicted_n": 1,
                        "predicted_ms": 26.7,
                        "predicted_per_token_ms": 26.7,
                        "predicted_per_second": 37.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 964.2738000256941,
                "captured_at": "2026-10-04T04:29:34Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=4. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-0b20bdc294104d939b115e4e",
                    "object": "chat.completion",
                    "created": 1791088174,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.009305191533176728,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.009305191533176728,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.903115463749973,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.8257400517626685,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.262397003666965,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.965848160283176,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.293426704899876,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.40841598560056,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.707104874150364,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.76286811877927,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.766600800053684,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.912121010319797,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -11.131583405034153,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -11.333684158818333,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -11.36112136890134,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -11.878621292607395,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.929001999394504,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -11.995431137578098,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "AAA",
                                                "logprob": -11.999861908452122,
                                                "bytes": [
                                                    65,
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Is",
                                                "logprob": -12.023802948491184,
                                                "bytes": [
                                                    73,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "<|endoftext|>",
                                                "logprob": -12.033488464848606,
                                                "bytes": None
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9925629064536123,
                                            "support": 2,
                                            "entropy": 0.04386061140484203,
                                            "selection_ms": 0.111898,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.04386061140484203
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.04386061140484203
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9925629064536123,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.007437093546387745,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 912.3,
                        "prompt_per_token_ms": 7.797,
                        "prompt_per_second": 128.2,
                        "predicted_n": 1,
                        "predicted_ms": 27.7,
                        "predicted_per_token_ms": 27.7,
                        "predicted_per_second": 36.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 968.7980999588035,
                "captured_at": "2026-10-04T04:29:35Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=4. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-fc8f00e2815743d0bbdc2bf4",
                    "object": "chat.completion",
                    "created": 1791088175,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.05071735216519098,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.05071735216519098,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.043210027946441,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.346845625175445,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.191975591911286,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.26889705492398,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.63126849962613,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.016901968254059,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.345602987541168,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.395761488212555,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.730769155754059,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.740222929252594,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.8683156950607,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.936033247245758,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.957847593559235,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.98172664476773,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -11.005320547355621,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -11.115727422965973,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "damage",
                                                "logprob": -11.471958158744782,
                                                "bytes": [
                                                    100,
                                                    97,
                                                    109,
                                                    97,
                                                    103,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -11.48892879320523,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.505684850944489,
                                                "bytes": [
                                                    78
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.952233816343104,
                                            "support": 2,
                                            "entropy": 0.19188462368770387,
                                            "selection_ms": 0.112759,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.19188462368770387
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.19188462368770387
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.952233816343104,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.047766183656895896,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 912.6,
                        "prompt_per_token_ms": 7.8,
                        "prompt_per_second": 128.2,
                        "predicted_n": 1,
                        "predicted_ms": 27.2,
                        "predicted_per_token_ms": 27.2,
                        "predicted_per_second": 36.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 961.1778999678791,
                "captured_at": "2026-10-04T04:29:36Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=8. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-bbeaec1772ef417199523189",
                    "object": "chat.completion",
                    "created": 1791088175,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.055761119419662324,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.055761119419662324,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.951726695591537,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.976130267674057,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.241695186192123,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.304385921055404,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.752641459995834,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.387889644199936,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.508317729527084,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.63773991733226,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.658180972630111,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.786349078709213,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.79657723575267,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "8",
                                                "logprob": -10.797656795078842,
                                                "bytes": [
                                                    56
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.021774074131576,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.053573390537826,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.05563141971263,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "2",
                                                "logprob": -11.086203357273666,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -11.238271495396225,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -11.336063167149154,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "hours",
                                                "logprob": -11.461002131992904,
                                                "bytes": [
                                                    104,
                                                    111,
                                                    117,
                                                    114,
                                                    115
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9476466402310281,
                                            "support": 2,
                                            "entropy": 0.20538711627303805,
                                            "selection_ms": 0.11283,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.20538711627303805
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.20538711627303805
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9476466402310281,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.052353359768971874,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 116,
                        "completion_tokens": 1,
                        "total_tokens": 117,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 116,
                        "prompt_ms": 907.3,
                        "prompt_per_token_ms": 7.822,
                        "prompt_per_second": 127.9,
                        "predicted_n": 1,
                        "predicted_ms": 27.9,
                        "predicted_per_token_ms": 27.9,
                        "predicted_per_second": 35.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 958.2105000154115,
                "captured_at": "2026-10-04T04:29:37Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=8. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-6322f49215b94a3eb8844b5f",
                    "object": "chat.completion",
                    "created": 1791088176,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.05521949454389983,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.05521949454389983,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.9887731902226107,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.088441693030228,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -8.660323940955033,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.29973968192183,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.87757285758101,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.051145397864213,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.283508145056595,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.424791180334916,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.482999645911088,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.87881454154097,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.003423535071244,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -11.018472515784135,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -11.068213307104935,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -11.161388241492142,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.258045994482865,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -11.29557880087935,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.463235699377885,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "AAA",
                                                "logprob": -11.768472515784135,
                                                "bytes": [
                                                    65,
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "<|endoftext|>",
                                                "logprob": -11.7704294554814,
                                                "bytes": None
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9494804090119836,
                                            "support": 2,
                                            "entropy": 0.20004231474182846,
                                            "selection_ms": 0.112149,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.20004231474182846
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.20004231474182846
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9494804090119836,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.050519590988016394,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 919.3,
                        "prompt_per_token_ms": 7.857,
                        "prompt_per_second": 127.3,
                        "predicted_n": 1,
                        "predicted_ms": 29.4,
                        "predicted_per_token_ms": 29.4,
                        "predicted_per_second": 34,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1013.4423000272363,
                "captured_at": "2026-10-04T04:29:38Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=8. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-b98715eaf09c4972acfc1b5b",
                    "object": "chat.completion",
                    "created": 1791088177,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.03520214410888424,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.03520214410888424,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.415525554143064,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.616737483464353,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.12499916406738,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.342614291630857,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -9.909268496953123,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.129539607487791,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.220337031804197,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.283618091069334,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.29170238824951,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.298092006169432,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.540674327336424,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.561933635197752,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.82880127283203,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.919107554875486,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -11.035968898259275,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.048404811345213,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -11.079813121281736,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.088379023991697,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "damage",
                                                "logprob": -11.179781077824705,
                                                "bytes": [
                                                    100,
                                                    97,
                                                    109,
                                                    97,
                                                    103,
                                                    101
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9670839017487112,
                                            "support": 2,
                                            "entropy": 0.1447370797850273,
                                            "selection_ms": 0.111919,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.1447370797850273
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.1447370797850273
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9670839017487112,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.03291609825128884,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 902.8,
                        "prompt_per_token_ms": 7.716,
                        "prompt_per_second": 129.6,
                        "predicted_n": 1,
                        "predicted_ms": 25.8,
                        "predicted_per_token_ms": 25.8,
                        "predicted_per_second": 38.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 951.5154999680817,
                "captured_at": "2026-10-04T04:29:39Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=40. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-03228f23425249b9813bd949",
                    "object": "chat.completion",
                    "created": 1791088178,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.03995191149078086,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.03995191149078086,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.295731177848203,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.090916266959531,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.829361548941952,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.30047666124664,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.766166320365292,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.833229651969296,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.122479072135311,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "hours",
                                                "logprob": -10.536356559317928,
                                                "bytes": [
                                                    104,
                                                    111,
                                                    117,
                                                    114,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.556229224723202,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.703694930594784,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -10.805678000968319,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.816520324271542,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.824631324332577,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.829701056998593,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -11.096686950248104,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Is",
                                                "logprob": -11.097267737906796,
                                                "bytes": [
                                                    73,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.10790788225494,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "2",
                                                "logprob": -11.11605226091705,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.293326011222225,
                                                "bytes": [
                                                    78
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9628802280637598,
                                            "support": 2,
                                            "entropy": 0.1586800325265627,
                                            "selection_ms": 0.113331,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.1586800325265627
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.1586800325265627
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9628802280637598,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.037119771936240206,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 116,
                        "completion_tokens": 1,
                        "total_tokens": 117,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 116,
                        "prompt_ms": 895.4,
                        "prompt_per_token_ms": 7.719,
                        "prompt_per_second": 129.6,
                        "predicted_n": 1,
                        "predicted_ms": 28.3,
                        "predicted_per_token_ms": 28.3,
                        "predicted_per_second": 35.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 960.5684000416659,
                "captured_at": "2026-10-04T04:29:40Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=40. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-4254e11d7f9a4d0f8655e70a",
                    "object": "chat.completion",
                    "created": 1791088179,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.013172433386344856,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.013172433386344856,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.438354775915641,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.38223199606945,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.44980840445568,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.739227578650016,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.291630074987907,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.905657098303337,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -11.026788041601677,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -11.168026254187126,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -11.219194695959587,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.416906640539665,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -11.541652009497184,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -11.592438981543083,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.617450044165153,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -11.740133569250602,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.794301316748161,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -11.878771111975212,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "2",
                                                "logprob": -12.084534928808708,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -12.094003961096305,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -12.206672952185173,
                                                "bytes": [
                                                    78
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9881696057207683,
                                            "support": 2,
                                            "entropy": 0.06425258212747703,
                                            "selection_ms": 0.112599,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.06425258212747703
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.06425258212747703
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9881696057207683,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.011830394279231677,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 907,
                        "prompt_per_token_ms": 7.752,
                        "prompt_per_second": 129,
                        "predicted_n": 1,
                        "predicted_ms": 26.7,
                        "predicted_per_token_ms": 26.7,
                        "predicted_per_second": 37.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 962.5427999999374,
                "captured_at": "2026-10-04T04:29:41Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=40. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-ea71362240984d98b137fe46",
                    "object": "chat.completion",
                    "created": 1791088180,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.042456413092892095,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.042456413092892095,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.2054565199044154,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.333508277716916,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.565680290046018,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.76306989270715,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.682009483161252,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.695202613654416,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.69970777112512,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.732233787360471,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.848278785529416,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -11.008656287970823,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -11.15299966413049,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -11.154954696479123,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.265925193610471,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -11.288178230109494,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.292328620734494,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.49743726331262,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -11.562760139289182,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -11.655094886603635,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -11.712494636359494,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9594179172526635,
                                            "support": 2,
                                            "entropy": 0.16978964667598645,
                                            "selection_ms": 0.208999,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.16978964667598645
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.16978964667598645
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9594179172526635,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.04058208274733646,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 907.1,
                        "prompt_per_token_ms": 7.753,
                        "prompt_per_second": 129,
                        "predicted_n": 1,
                        "predicted_ms": 30.3,
                        "predicted_per_token_ms": 30.3,
                        "predicted_per_second": 33,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 993.5896000242792,
                "captured_at": "2026-10-04T04:29:42Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=60. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-9a47a1359fa343b6af46f71a",
                    "object": "chat.completion",
                    "created": 1791088181,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.0565010621068439,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.0565010621068439,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.946860940646883,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.76065412301993,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.999817521762605,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.166164071750398,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.356481225681062,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -9.360645921420808,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.770599038791413,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.307487161350007,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.561455400180574,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.615604074191804,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.793615014743562,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -10.864453942966218,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.028359086704011,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -11.188398034763093,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.193662316989656,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -11.491993577670808,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "2",
                                                "logprob": -11.533126504611726,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -11.535228402805085,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -11.545301110934968,
                                                "bytes": [
                                                    88
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9473678287270175,
                                            "support": 2,
                                            "entropy": 0.20619376267093975,
                                            "selection_ms": 0.11797,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.20619376267093975
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.20619376267093975
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9473678287270175,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.05263217127298239,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 116,
                        "completion_tokens": 1,
                        "total_tokens": 117,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 116,
                        "prompt_ms": 897.1,
                        "prompt_per_token_ms": 7.734,
                        "prompt_per_second": 129.3,
                        "predicted_n": 1,
                        "predicted_ms": 27.8,
                        "predicted_per_token_ms": 27.8,
                        "predicted_per_second": 36,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 950.6951000075787,
                "captured_at": "2026-10-04T04:29:43Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=60. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-1bbf4c0149f74be6968de2ba",
                    "object": "chat.completion",
                    "created": 1791088182,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.03440243888284493,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.03440243888284493,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -3.4426894872226885,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.132920810464876,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.083861896280306,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -9.321863719705599,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -9.452339717630403,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -9.57737786460306,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.951287814859407,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "AAA",
                                                "logprob": -10.422828265909212,
                                                "bytes": [
                                                    65,
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.6561504094639,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.669614383462923,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -10.790242740396517,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -11.00492627311136,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "AAAA",
                                                "logprob": -11.045068332437532,
                                                "bytes": [
                                                    65,
                                                    65,
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -11.305358478311556,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -11.331182071451204,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -11.458239146951692,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -11.502829143289583,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -11.612209865335481,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -11.662583896402376,
                                                "bytes": [
                                                    84
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9679625245971656,
                                            "support": 2,
                                            "entropy": 0.14175481919108956,
                                            "selection_ms": 0.112239,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.14175481919108956
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.14175481919108956
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9679625245971656,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.0320374754028344,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 914,
                        "prompt_per_token_ms": 7.812,
                        "prompt_per_second": 128,
                        "predicted_n": 1,
                        "predicted_ms": 26.6,
                        "predicted_per_token_ms": 26.6,
                        "predicted_per_second": 37.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 968.9260000013746,
                "captured_at": "2026-10-04T04:29:44Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=60. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-0f6cf6eaeca44e5383f4e26d",
                    "object": "chat.completion",
                    "created": 1791088183,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.05822049895139438,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.05822049895139438,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.896635644825418,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.455591791065652,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.697725885303933,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.81623040953489,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.973883264454324,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.309777849110086,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.656929605396707,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.66211664000364,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.885832422169168,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.890909784229715,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.017030351551492,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -11.032995813282449,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.245113008411844,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.397041910084207,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.461769693287332,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -11.496058099659402,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -11.626125924976785,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -11.7412449053845,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -11.759472482593972,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9447167483338166,
                                            "support": 2,
                                            "entropy": 0.21378695247392385,
                                            "selection_ms": 0.11272,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.21378695247392385
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.21378695247392385
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9447167483338166,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.05528325166618338,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 916.2,
                        "prompt_per_token_ms": 7.831,
                        "prompt_per_second": 127.7,
                        "predicted_n": 1,
                        "predicted_ms": 26.9,
                        "predicted_per_token_ms": 26.9,
                        "predicted_per_second": 37.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 972.0504000433721,
                "captured_at": "2026-10-04T04:29:45Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. The printed parcel label says URGENT.\nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-bf507e9222bd4f1198f790b8",
                    "object": "chat.completion",
                    "created": 1791088184,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.09858781205855767,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.09858781205855767,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.383871854416956,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.33670121537887,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.582033933274378,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.47032052385055,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.970671475998987,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.982359708420862,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -10.216196836106409,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -10.270483792893518,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.33213693010055,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.340540708176722,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.376793683640589,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.405363858811487,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.531443418137659,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.79778462754928,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "2",
                                                "logprob": -10.905676663987268,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -11.016077817551722,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -11.032721341721643,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -11.033275426499475,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.105776609055628,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9076509142591876,
                                            "support": 2,
                                            "entropy": 0.3079393219344223,
                                            "selection_ms": 0.113992,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.3079393219344223
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.3079393219344223
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9076509142591876,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.09234908574081233,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 125,
                        "completion_tokens": 1,
                        "total_tokens": 126,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 125,
                        "prompt_ms": 928.2,
                        "prompt_per_token_ms": 7.426,
                        "prompt_per_second": 134.7,
                        "predicted_n": 1,
                        "predicted_ms": 25.7,
                        "predicted_per_token_ms": 25.7,
                        "predicted_per_second": 38.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 981.5075999940746,
                "captured_at": "2026-10-04T04:29:46Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. The printed parcel label says URGENT.\nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-2b059225e1014ae88b72b1ad",
                    "object": "chat.completion",
                    "created": 1791088185,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.007792660793569474,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.007792660793569474,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.973822781643179,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.295316884121206,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.305915066799429,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.315419385036734,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.509338566860464,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.635714718899038,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.832820126613882,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.856722066005972,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -11.02065772732189,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.12843246181896,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -11.375864216884878,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -11.382310101589468,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.544539639553335,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -11.57097167690685,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -11.647011944851187,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.948883244594839,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -12.01343936642101,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -12.151465603908804,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -12.35251636227062,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9930774889290909,
                                            "support": 2,
                                            "entropy": 0.041323981296282015,
                                            "selection_ms": 0.112139,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.041323981296282015
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.041323981296282015
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9930774889290909,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.0069225110709091545,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 126,
                        "completion_tokens": 1,
                        "total_tokens": 127,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 126,
                        "prompt_ms": 916.4,
                        "prompt_per_token_ms": 7.273,
                        "prompt_per_second": 137.5,
                        "predicted_n": 1,
                        "predicted_ms": 24.3,
                        "predicted_per_token_ms": 24.3,
                        "predicted_per_second": 41.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 962.7675000228919,
                "captured_at": "2026-10-04T04:29:47Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=6. Machine load_percent=50. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. The printed parcel label says URGENT.\nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-3439355542264b529e9f5d64",
                    "object": "chat.completion",
                    "created": 1791088186,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.015294923710144145,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.015294923710144145,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.266054048466003,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.941839113163269,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.970563783573425,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.751632585453308,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.839585199283874,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.26833714477948,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -10.395986452030456,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.545812501835144,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.553483858036316,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.614770784305847,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.716936006473816,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.842314615177429,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.976157083439148,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -10.988143815922058,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -11.15434445373944,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -11.166805162357605,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -11.282121553348816,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.477937593387878,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -11.493175401615417,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9859468949783154,
                                            "support": 2,
                                            "entropy": 0.07388914928039192,
                                            "selection_ms": 0.1126,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.07388914928039192
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.07388914928039192
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9859468949783154,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.014053105021684564,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 126,
                        "completion_tokens": 1,
                        "total_tokens": 127,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 126,
                        "prompt_ms": 928.7,
                        "prompt_per_token_ms": 7.371,
                        "prompt_per_second": 135.7,
                        "predicted_n": 1,
                        "predicted_ms": 24.3,
                        "predicted_per_token_ms": 24.3,
                        "predicted_per_second": 41.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 981.41469998518,
                "captured_at": "2026-10-04T04:29:48Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=5. Machine load_percent=55. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the parcel urgent under the stated numeric deadline rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-6bd50abb11fb478fb9966157",
                    "object": "chat.completion",
                    "created": 1791088187,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.041079277692800245,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.041079277692800245,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.261112923322683,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.233385796247488,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.738411659894949,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.705891365705495,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.720036263166433,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.845956558881765,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.143111939130788,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.43832277744866,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.666526550947195,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.717509026227956,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "hours",
                                                "logprob": -10.781759972272878,
                                                "bytes": [
                                                    104,
                                                    111,
                                                    117,
                                                    114,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.803709740339285,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.82135557621575,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -11.12571119755364,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.166463608442312,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "2",
                                                "logprob": -11.245518440900808,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -11.426252121625906,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "Hours",
                                                "logprob": -11.435429329572683,
                                                "bytes": [
                                                    72,
                                                    111,
                                                    117,
                                                    114,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -11.483673805891042,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9615812574795873,
                                            "support": 2,
                                            "entropy": 0.1628858499034721,
                                            "selection_ms": 0.112841,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.1628858499034721
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.1628858499034721
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9615812574795873,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.03841874252041256,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 116,
                        "completion_tokens": 1,
                        "total_tokens": 117,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 116,
                        "prompt_ms": 909.6,
                        "prompt_per_token_ms": 7.841,
                        "prompt_per_second": 127.5,
                        "predicted_n": 1,
                        "predicted_ms": 29.4,
                        "predicted_per_token_ms": 29.4,
                        "predicted_per_second": 34,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 965.2339000022039,
                "captured_at": "2026-10-04T04:29:49Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=5. Machine load_percent=55. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Is the machine highly loaded under the stated numeric load rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-64c500c148d34474baecdfc1",
                    "object": "chat.completion",
                    "created": 1791088188,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.03199836501502407,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.03199836501502407,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.5265834022464695,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.5724312950077,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.538158147424692,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.568127362817759,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.008580892175669,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.478287427515024,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.755572049707407,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -11.060509412378305,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -11.211881368249887,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -11.24780914077186,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.338822095483774,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -11.424597470849985,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.476734845727915,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -11.491059033960337,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -11.653176038354868,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.773386685937876,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.823576657861704,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "AAA",
                                                "logprob": -11.998623578638071,
                                                "bytes": [
                                                    65,
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -12.138948171228403,
                                                "bytes": [
                                                    88
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9705333038664309,
                                            "support": 2,
                                            "entropy": 0.1328834361727171,
                                            "selection_ms": 0.11266,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.1328834361727171
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.1328834361727171
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9705333038664309,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.029466696133569153,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 900.2,
                        "prompt_per_token_ms": 7.694,
                        "prompt_per_second": 130,
                        "predicted_n": 1,
                        "predicted_ms": 29.8,
                        "predicted_per_token_ms": 29.8,
                        "predicted_per_second": 33.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 946.7627999838442,
                "captured_at": "2026-10-04T04:29:50Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nParcel hours_remaining=5. Machine load_percent=55. damage_report=false. Definitions: urgent means hours_remaining <= 4; highly loaded means load_percent >= 60; manual review means damage_report is true. \nQUESTION: Does the parcel require manual review under the stated damage rule?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-7478eff088e54347a5dbecd8",
                    "object": "chat.completion",
                    "created": 1791088189,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.03615556124510648,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.03615556124510648,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.369747022426747,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.171218732631825,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.50110707644286,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.89376244906249,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.547266820705556,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.596098760402821,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.626390317714833,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.663772443569325,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.676608899868153,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.686729291713856,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.851707319057606,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "damage",
                                                "logprob": -10.898412565029286,
                                                "bytes": [
                                                    100,
                                                    97,
                                                    109,
                                                    97,
                                                    103,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.138843396938466,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -11.185708860195302,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -11.342164853847645,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -11.41847596529784,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -11.489902356899403,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.596116880214833,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.676043370998524,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9655633883050879,
                                            "support": 2,
                                            "entropy": 0.14984112062133365,
                                            "selection_ms": 0.112399,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.14984112062133365
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.14984112062133365
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9655633883050879,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.03443661169491219,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 117,
                        "completion_tokens": 1,
                        "total_tokens": 118,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 117,
                        "prompt_ms": 905.6,
                        "prompt_per_token_ms": 7.74,
                        "prompt_per_second": 129.2,
                        "predicted_n": 1,
                        "predicted_ms": 26.9,
                        "predicted_per_token_ms": 26.9,
                        "predicted_per_second": 37.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 951.3187000411563,
                "captured_at": "2026-10-04T04:29:51Z"
            }
        ]
    },
    "wall_ms": 166.47179995197803,
    "lesson_view": {
        "index": 0,
        "value": -1,
        "scope": "Reproduce the selected question/rule/result panel. Other page dials are independent."
    }
}
import argparse
import copy
import hashlib
import json
import math
import os
import sys
from pathlib import Path
import urllib.error
import urllib.request

"""Small, portable calculations behind the question/rule/result panels.

Standard library only. This exact source is included in every Python download.
Inputs are the captured experiment, never an invented new model response. A knob
changes a disclosed calculation on those inputs; it does not rescore a new prompt.
"""
import itertools
import math
import statistics


def _spec(question, rule, knob, default, compare, low, high, integer=False):
    return dict(question=question, rule=rule, knob=knob, default=default,
                compare=compare, low=low, high=high, integer=integer)


LESSON_SPECS = {
    'choice': _spec('Which ticket queue gets this message?', 'Compare the three saved label scores. Heat flattens their relative weights; it adds no evidence.', 'Reweighting temperature', 1, 2, .1, 3),
    'boolean': _spec('Does this message ask to cancel?', 'Normalize the saved Yes and No scores. A number near one is a strong preference, not proof.', 'Reweighting temperature', 1, 2, .1, 3),
    'score': _spec('How serious is the outage?', 'Multiply each rubric value by its answer weight, then add. The rating comes from the whole distribution.', 'Reweighting temperature', 1, 2, .1, 3),
    'candidates': _spec('Read the failure first, or start changing things?', 'Add token logprobs along each saved path, then sum path mass inside each finite group. A length penalty changes the objective.', 'Length penalty exponent', 0, 1, 0, 1),
    'controller': _spec('May the simulated repair take its next step?', 'Keep only state-legal actions. Hold the recorded action if its relative legal weight falls below the threshold.', 'Required legal-action weight', 0, .999, 0, 1),
    'rerank': _spec('Which sources help explain cancellation?', 'Compute each source’s expected relevance separately, then keep those above the cutoff.', 'Minimum relevance', 0, .9, 0, 1),
    'graph': _spec('Which text links can coexist?', 'Search every small edge subset. Reject cycles and competing attachments, then maximize useful edge weight.', 'Edge cost / threshold', .5, .9, .01, .99),
    'scene': _spec('Which valid drawing best fits the instruction?', 'Average the three saved text probes. Optionally charge for disagreement between them; code still checks geometry.', 'Disagreement penalty', 0, 1, 0, 2),
    'wire': _spec('What did the model assign to this actual token?', 'Exponentiate its raw logprob. Sum only the reported alternatives; their top-N list may omit probability mass.', 'Visible token index (zero-based)', 0, 5, 0, 10000, True),
    'speculation': _spec('Why can a draft be rejected?', 'Compare the proposal head and target verification on the same proposed token. They are different distributions.', 'Proposal position (zero-based)', 0, 2, 0, 10000, True),
    'performance': _spec('What did each API path cost on this setup?', 'Recalculate a latency percentile from the original wall-time samples. Different output tasks remain separate.', 'Latency percentile', 50, 90, 0, 100),
    'samplers': _spec('How much did this recipe change the selected token’s weight?', 'Compare its raw target probability with its post-sampler probability. Read support and entropy from the complete native row.', 'Recorded recipe index (zero-based)', 0, 1, 0, 10000, True),
    'sampler-sandbox': _spec('Can we add heat without admitting implausible tokens?', 'Remove logits below max + log(0.05), then divide the survivors by temperature and normalize.', 'Temperature after Min-P', 1.5, .7, .1, 3),
    'tictactoe': _spec('Did a legal move give away a winnable outcome?', 'Solve the saved position by exhaustive minimax. Compare the best legal outcome with the recorded model move.', 'Recorded turn index (zero-based)', 0, 1, 0, 10000, True),
    'chess': _spec('Did the shortlist favor a mating move?', 'Add the saved label weights attached to code-checked mating moves. The separately generated UCI move uses a different prompt.', 'Shortlist temperature', 1, 3, .1, 3),
    'poker': _spec('Should this hand check or bet?', 'Average exact chip payoffs over the two possible opponent cards using the stated calling policy.', 'Opponent call-rate multiplier', 1, 0, 0, 2),
    'thermal': _spec('What happens if we replay the fan commands differently?', 'Step the disclosed thermal equation through the same loads. A fan offset is an open-loop counterfactual, not a new model policy.', 'Fan offset', 0, 20, -60, 60),
    'scheduler': _spec('How much lateness did this legal schedule cause?', 'Add job durations in the recorded order and check dependencies. Charge for finishing after the adjusted deadline.', 'Deadline shift', 0, -3, -10, 10),
    'context': _spec('Did replacing old text change the current-state answer?', 'Recalculate each saved Yes/No distribution and compare the selected wording with the original append-only prompt.', 'Context variant index (zero-based)', 0, 2, 0, 10000, True),
    'observer': _spec('Which action follows from these three semantic measurements?', 'Apply the same explicit threshold rule to every saved report: inspect, verify, finish, or ask.', 'Decision threshold', .5, .999, 0, 1),
    'calibration': _spec('Does demanding stronger answers leave enough coverage?', 'Recalculate Brier error on all six examples and accuracy only on retained examples. Empty coverage has no accuracy.', 'Required answer weight', .5, 1, .5, 1),
    'information': _spec('Which observation is worth buying?', 'Use the stated sensor likelihoods to compute both Bayesian posteriors and expected entropy reduction.', 'Test index (zero-based)', 0, 1, 0, 10000, True),
    'search': _spec('Which valid scene survives a cost penalty?', 'Subtract the chosen cost charge from each saved semantic weight. Reject invalid geometry before ranking.', 'Cost weight', .1, 1, 0, 1),
    'frontier': _spec('Would faster score transfer matter here?', 'Add assumed forward time, a transfer lower bound, and the measured selector. This is a serial cost sketch.', 'Assumed transfer GB/s', 12, 2, .1, 128),
    'research-map': _spec('What would make this research idea testable?', 'Count the disclosed implementation categories, then reveal one branch’s next gate. A proposal is not a native result.', 'Branch index (zero-based)', 0, 12, 0, 10000, True),
    'pressure': _spec('How much original mass did this boundary throw away?', 'At temperature 1 with pure masking, log Z = raw selected logprob − log(selected masked probability). Pressure is −log Z.', 'Native grammar index (zero-based)', 0, 1, 0, 10000, True),
    'circuit': _spec('Can we compute AND without assuming independence?', 'Start with four joint worlds. Optionally condition on noisy evidence of style, then add worlds for each logical operation.', 'Reliability of observing style', .5, 1, .5, 1),
    'control': _spec('Can preference change while forbidden actions stay forbidden?', 'Normalize log(base) + strength × [log(desired) − log(undesired)] inside the legal set.', 'Control strength', 0, 2, 0, 3),
    'future': _spec('Can a less likely first move have a better future?', 'Weight the root policy by exact future success raised to strength. At strength zero use the base policy.', 'Future-value strength', 0, 1, 0, 2),
    'sensitivity': _spec('Which prompt intervention moves this measurement?', 'Rebuild the central finite-difference matrix. Predict a change in hours, with load fixed at +5 points; preserve the measured holdout error.', 'Change in hours remaining', -1, -2, -2, 2),
    'counterexamples': _spec('Can equivalent algebra confuse the observer?', 'Find the equivalent pair with the largest measured log-odds distance. Evaluate its exact coefficients at the chosen integer.', 'Integer x', 2, -2, -10, 10, True),
}


def normalize_logs(logs):
    finite = [x for x in logs if math.isfinite(x)]
    if not finite:
        raise ValueError('No candidate has positive mass')
    maximum = max(finite)
    weights = [math.exp(x-maximum) if math.isfinite(x) else 0. for x in logs]
    total = math.fsum(weights)
    return [w/total for w in weights]


def weights(rows, temperature=1):
    if any(r.get('logprob') is None for r in rows):
        raise ValueError('A complete label measurement is required; missing top-N entries stay unknown')
    return normalize_logs([r['logprob']/temperature for r in rows])


def entropy(p):
    return -math.fsum(x*math.log2(x) for x in p if x)


def _pick(items, value):
    if not 0 <= value < len(items):
        raise ValueError('Index must be 0..'+str(len(items)-1))
    return items[int(value)]


def _rows(names, values):
    return [dict(label=str(n), value=float(v)) for n,v in zip(names,values)]


def _graph(edges, threshold):
    if len(edges)>12:
        raise ValueError('This exact demonstration supports at most 12 edges')
    best, score = [], 0.
    for bits in itertools.product((False,True), repeat=len(edges)):
        selected=[e for e,yes in zip(edges,bits) if yes]
        out, incoming, captions = {}, set(), set()
        good=True
        for e in selected:
            a,b=e['source'],e['target']
            if a==b:good=False;break
            if e['relation']=='caption':
                if a in captions:good=False;break
                captions.add(a)
            else:
                if a in out or b in incoming:good=False;break
                out[a]=b;incoming.add(b)
        for start in out:
            node,visited=start,set()
            while node in out:
                if node in visited:good=False;break
                visited.add(node);node=out[node]
        utility=math.fsum(e['weight']-threshold for e in selected)
        if good and utility>score:best,score=selected,utility
    return best,score


def _ttt(board, turn):
    lines=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
    for a,b,c in lines:
        if board[a]!='.' and board[a]==board[b]==board[c]:return 1 if board[a]=='X' else -1
    if '.' not in board:return 0
    values=[_ttt(board[:i]+turn+board[i+1:],'O' if turn=='X' else 'X') for i,s in enumerate(board) if s=='.']
    return (max if turn=='X' else min)(values)


def calculate_lesson(name, data, value=None):
    spec=LESSON_SPECS[name]
    v=spec['default'] if value is None else value
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not spec['low']<=v<=spec['high'] or (spec['integer'] and int(v)!=v):
        raise ValueError(f"{spec['knob']} must be {'an integer' if spec['integer'] else 'finite'} in [{spec['low']}, {spec['high']}]")
    rows=[];metrics={};note='Calculation on saved inputs; changing this setting makes no new model request.'
    summary='';unit='weight'
    if name in ('choice','boolean','score'):
        p=weights(data['rows'],v);at=max(range(len(p)),key=p.__getitem__)
        rows=_rows([r['label']+' · '+r.get('description','') for r in data['rows']],p)
        metrics=dict(winner=data['rows'][at]['label'],top_weight=p[at],entropy_bits=entropy(p))
        if name in ('boolean','score'):
            metrics['expected_value']=math.fsum(q*r['value'] for q,r in zip(p,data['rows']))
        summary=f"Answer {metrics['winner']} leads with {p[at]:.2%} of the listed-label weight."
        if name=='score':summary=f"Expected rubric value: {metrics['expected_value']:.4f} on the stated 0–1 scale."
    elif name=='candidates':
        paths=data['paths'];logs=[math.fsum(t['logprob'] for t in r['tokens'])/len(r['tokens'])**v for r in paths]
        p=normalize_logs(logs);names=list(dict.fromkeys(r['group'] for r in paths))
        values=[math.fsum(q for q,r in zip(p,paths) if r['group']==g) for g in names];rows=_rows(names,values)
        metrics=dict(winner=names[values.index(max(values))],group_weights=values)
        summary=metrics['winner']+' carries the most relative group weight.'
        note='Only these emitted token paths, with their saved terminators and no EOS. A nonzero length penalty produces preference scores, not path probability.'
    elif name=='controller':
        labels=data['measure']['rows'];p=weights(labels);legal=[i for i,r in enumerate(labels) if r['allowed']]
        mass=math.fsum(p[i] for i in legal);pick=next(i for i,r in enumerate(labels) if r['action']==data['action'])
        q=p[pick]/mass;held=q<v
        rows=_rows([labels[i]['action'] for i in legal],[p[i]/mass for i in legal])
        metrics=dict(held=held,selected_weight=q,next_state=data['state'] if held else data['next_state'])
        summary=('Hold the action.' if held else 'Apply '+data['action']+'.')+' State: '+metrics['next_state']+'.'
    elif name=='rerank':
        values=[math.fsum(q*r['value'] for q,r in zip(weights(s['measure']['rows']),s['measure']['rows'])) for s in data['sources']]
        rows=_rows([s['id'] for s in data['sources']],values);kept=[r['label'] for r in rows if r['value']>=v]
        metrics=dict(retained=kept,scores=values);summary='Retain '+(', '.join(kept) or 'no sources')+' at this cutoff.'
    elif name=='graph':
        selected,utility=_graph(data['edges'],v);rows=_rows([e['source']+' → '+e['target'] for e in selected],[e['weight']-v for e in selected]);unit='utility'
        metrics=dict(selected=[(e['source'],e['target'],e['relation']) for e in selected],utility=utility)
        summary=f'{len(selected)} compatible links, total utility {utility:.4f}.'
        note='Global code constraints select links; utility is not the probability that the document graph is correct.'
    elif name=='scene':
        valid=[c for c in data['candidates'] if c['valid']];values=[]
        for c in valid:
            p=[weights(x['measure']['rows'])[0] for x in c['vector']]
            values.append(statistics.mean(p)-v*statistics.pvariance(p))
        rows=_rows([c['name'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['name'],utilities=values)
        summary='Retain '+metrics['retained']+' among geometry-valid candidates.'
        note='These are saved text judgments. This calculation cannot see the drawing or measure visual appeal.'
    elif name=='wire':
        entry=_pick(data['entries'],v);p=math.exp(entry['logprob']);top=entry.get('top_logprobs',[])
        rows=_rows([x['token'] for x in top],[math.exp(x['logprob']) for x in top]);unit='raw probability'
        metrics=dict(token=entry['token'],raw_probability=p,reported_top_mass=math.fsum(r['value'] for r in rows))
        summary=f"Token {entry['token']!r}: raw probability {p:.6g}."
        note='This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary.'
    elif name=='speculation':
        window=data['oracle']['example_rejection'];r=_pick(window['proposal'],v)
        rows=_rows(['Draft head','Target verification'],[r['draft_probability'],math.exp(r['target_logprob'])]);unit='probability / distinct heads'
        metrics=dict(token_id=r['token_id'],target_sequence_logprob=math.fsum(x['target_logprob'] for x in window['proposal']),draft_target_logprob_gap=r['draft_logprob']-r['target_logprob'])
        summary=f"Proposal token {r['token_id']}: the two heads differ by {metrics['draft_target_logprob_gap']:.4f} log units."
        note='Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability.'
    elif name=='performance':
        values=[]
        for r in data['rows']:
            xs=sorted(x['wall_ms'] for x in r['runs']);a=(len(xs)-1)*v/100;lo=math.floor(a);hi=math.ceil(a)
            values.append(xs[lo]+(xs[hi]-xs[lo])*(a-lo))
        rows=_rows([r['name'] for r in data['rows']],values);unit='ms';metrics=dict(percentile=v,times_ms=values)
        summary=f'Percentile {v:g}, recalculated from {data["repeats"]} samples per path.'
        note='Small same-setup samples include network and API cost. JSON answers a different task; this is no universal speed ranking.'
    elif name=='samplers':
        run=_pick(data['runs'],v);token=run['tokens'][0];sample=token['strata_sampling']
        raw=math.exp(token['logprob']);post=sample['probability']
        rows=_rows(['Raw target','After recipe'],[raw,post]);unit='selected token probability'
        metrics=dict(recipe=run['name'],support=sample['support'],raw=raw,selected=post,log_weight_change=math.log(post)-token['logprob'],entropy_bits=sample['entropy']/math.log(2))
        summary=f"{run['name']}: {sample['support']} native tokens remain eligible."
        note='Recipes are separate generations. Entropy and support are full-row native measurements; a top-N slice cannot recover them.'
    elif name=='sampler-sandbox':
        cut=max(data['logits'])+math.log(.05);logs=[x/v if x>=cut else -math.inf for x in data['logits']];p=normalize_logs(logs)
        rows=_rows(data['tokens'],p);metrics=dict(support=sum(x>0 for x in p),entropy_bits=entropy(p),probabilities=p)
        summary=f"{metrics['support']} credible tokens survive; entropy {metrics['entropy_bits']:.3f} bits."
        note='All eight logits are synthetic and visible. This is exact finite-row arithmetic, not a new native receipt.'
    elif name=='tictactoe':
        f=_pick(data['frames'],v);b=f['before'];legal=[i for i,c in enumerate(b) if c=='.'];oracle={i:_ttt(b[:i]+'X'+b[i+1:],'O') for i in legal}
        regret=max(oracle.values())-oracle[f['square']];rows=_rows([str(i+1) for i in legal],list(oracle.values()));unit='X outcome: lose −1 / draw 0 / win 1'
        metrics=dict(regret=regret,square=f['square']+1,oracle=oracle);summary=f"Recorded move: square {f['square']+1}; exact outcome regret {regret}."
    elif name=='chess':
        p=weights(data['measure']['rows'],v);mass=math.fsum(q for q,m in zip(p,data['shortlist']) if m['mate'])
        rows=_rows([m['san'] for m in data['shortlist']],p);metrics=dict(mating_shortlist_weight=mass,generated_uci=data['chosen']['text'],generated_mate=data['mate'])
        summary=f'{mass:.2%} of shortlist weight favors mate; the separate UCI generation '+('mated.' if data['mate'] else 'did not mate.')
        note='The saved legal/mate flags came from python-chess. This portable calculation aggregates them; it is not a replacement chess engine.'
    elif name=='poker':
        ranks=['J','Q','K'];rates={c:min(1,max(0,r*v)) for c,r in data['call_rates'].items()};values={}
        for own in ranks:
            opponents=[c for c in ranks if c!=own];sign=lambda c:1 if ranks.index(own)>ranks.index(c) else -1
            values[own]=dict(check=statistics.mean(sign(c) for c in opponents),bet=statistics.mean((1-rates[c])+rates[c]*2*sign(c) for c in opponents))
        rows=_rows([c+' bet − check' for c in ranks],[values[c]['bet']-values[c]['check'] for c in ranks]);unit='expected chips'
        metrics=dict(values=values,call_rates=rates);summary='Bet when the bar is positive; check when it is negative.'
        note='Uniform remaining-card prior and explicitly assumed opponent policy. Answer weights are not hidden-card beliefs or equilibrium probabilities.'
    elif name=='thermal':
        t=data['frames'][0]['temperature'];temperatures=[]
        for f in data['frames']:
            fan=min(60,max(0,f['fan']+v));t=round(t+.22*f['load']-.32*fan-.04*(t-25),3);temperatures.append(t)
        rows=_rows(range(1,len(temperatures)+1),temperatures);unit='°C';metrics=dict(temperatures=temperatures,mean_error=statistics.mean(abs(t-data['target']) for t in temperatures),violations=sum(t>data['limit'] for t in temperatures))
        summary=f"Mean distance from target: {metrics['mean_error']:.2f}°C; {metrics['violations']} limit violations."
        note='Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control.'
    elif name=='scheduler':
        done=set();clock=0;late=[]
        for f in data['frames']:
            j=f['job']
            if not set(j['after'])<=done:raise ValueError('Saved schedule violates dependencies')
            clock+=j['duration'];late.append(max(0,clock-j['deadline']-v));done.add(j['id'])
        rows=_rows([f['job']['id'] for f in data['frames']],late);unit='late time units';metrics=dict(total_lateness=sum(late),finish_time=clock)
        summary=f'Total lateness {sum(late):g}; the same dependency-valid order ends at time {clock}.'
    elif name=='context':
        selected=_pick(data['runs'],v);all_weights=[weights(r['measure']['rows'])[1] for r in data['runs']];p=all_weights[int(v)]
        rows=_rows([r['name'] for r in data['runs']],all_weights);metrics=dict(variant=selected['name'],no_weight=p,delta_from_append=p-all_weights[0])
        summary=f"{selected['name']}: keep-still answer weight {p:.3%}."
        note='Saved prompt interventions, not KV tensor mutation. This calculation compares their recorded measurements.'
    elif name=='observer':
        actions=[];triples=[]
        for f in data['frames']:
            p=[weights(x['measure']['rows'])[0] for x in f['vector']];triples.append(p)
            actions.append('inspect failure' if p[0]>v else 'verify' if p[1]>v else 'finish' if p[2]>v else 'ask')
        rows=_rows(['Fault','Missing check','Verified'],triples[0]);metrics=dict(actions=actions,vectors=triples)
        summary=' → '.join(actions)+'.';note='Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability.'
    elif name=='calibration':
        p=[weights(r['measure']['rows'])[0] for r in data['rows']];truth=[r['truth'] for r in data['rows']];kept=[i for i,q in enumerate(p) if max(q,1-q)>=v]
        brier=statistics.mean((q-y)**2 for q,y in zip(p,truth));accuracy=statistics.mean(int(p[i]>=.5)==truth[i] for i in kept) if kept else None
        rows=_rows([str(i+1) for i in range(len(p))],p);metrics=dict(brier=brier,retained=len(kept),coverage=len(kept)/len(p),accuracy=accuracy)
        summary=f'{len(kept)}/{len(p)} retained; '+(f'{accuracy:.1%} correct in those cases.' if accuracy is not None else 'accuracy is undefined with zero coverage.')
        note='Six disclosed teaching examples, not a held-out calibration benchmark. Brier error still counts every example.'
    elif name=='information':
        t=_pick(data['tests'],v);prior=data['prior'];py=math.fsum(p*l for p,l in zip(prior,t['likelihood']));yes=[p*l/py for p,l in zip(prior,t['likelihood'])];no=[p*(1-l)/(1-py) for p,l in zip(prior,t['likelihood'])]
        gain=entropy(prior)-py*entropy(yes)-(1-py)*entropy(no);rows=_rows(data['faults'],yes)
        metrics=dict(test=t['name'],gain_bits=gain,gain_per_cost=gain/t['cost'],yes=yes,no=no)
        summary=t['name']+f': {gain:.3f} expected bits; {gain/t["cost"]:.3f} bits per cost unit.'
        note='Prior and likelihoods are stated synthetic sensor assumptions. Bars condition on a positive result; no test was actually purchased.'
    elif name=='search':
        valid=[c for c in data['candidates'] if c['valid']];values=[weights(c['measure']['rows'])[0]-v*c['cost']/3 for c in valid]
        rows=_rows([c['id'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['id'],utilities=values)
        summary='Retain '+metrics['retained']+' after charging for cost; invalid geometry is excluded.'
    elif name=='frontier':
        selector=sorted(r['selection_ms'] for r in data['measurements'])[len(data['measurements'])//2];transfer=data['vocabulary']*data['bytes_per_logit']/(v*1e6);total=60+transfer+selector
        rows=_rows(['Assumed forward','Transfer lower bound','Measured host selector'],[60,transfer,selector]);unit='ms'
        metrics=dict(transfer_ms=transfer,serial_ms=total,tokens_per_second=1000/total)
        summary=f'Serial estimate: {total:.3f} ms/token; {1000/total:.2f} tokens/s.'
        note='Forward time is assumed 60 ms. Selector uses the upper-middle measured sample to match the chart. Queue, prefill and network are excluded.'
    elif name=='research-map':
        branch=_pick(data['branches'],v);categories={}
        for b in data['branches']:categories[b['status']]=categories.get(b['status'],0)+1
        rows=_rows(list(categories),list(categories.values()));unit='branches';metrics=dict(branch=branch['name'],gate=branch['gate'],categories=categories)
        summary=branch['name']+': '+branch['gate'];note='This page recomputes an agenda inventory, not an experiment result. Each implemented branch links to its own evidence.'
    elif name=='pressure':
        case=_pick(data['cases'],v);r=case['rows'][0];token=r['token'];q=token['strata_sampling']['probability'];logz=token['logprob']-math.log(q)
        if logz>1e-6:raise ValueError('Pure-mask mass exceeds one')
        z=math.exp(min(0,logz));rows=_rows(['Survived','Removed'],[z,1-z]);unit='original probability mass'
        metrics=dict(grammar=case['name'],mass=z,pressure_nats=-logz,pressure_bits=-logz/math.log(2))
        summary=f"{case['name']}: {z:.4%} survives; pressure {-logz:.4f} nats."
        note='First actual prefix of this native grammar. Exact only for pure masking at temperature 1, not arbitrary sampler recipes or entire grammar languages.'
    elif name=='circuit':
        p=weights(data['cases'][0]['measurement']['rows']);weighted=[p[0]*(1-v),p[1]*(1-v),p[2]*v,p[3]*v];z=math.fsum(weighted);p=[x/z for x in weighted]
        f=p[1]+p[3];s=p[2]+p[3];rows=_rows(['Neither','Facts only','Style only','Both'],p)
        metrics=dict(F=f,S=s,AND=p[3],OR=1-p[0],F_given_S=p[3]/s if s else None,marginal_product=f*s)
        summary=f'Facts AND style: {p[3]:.2%}; multiplying the marginals would give {f*s:.2%}.'
        note='At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world.'
    elif name=='control':
        logs=[math.log(b)+v*(math.log(d)-math.log(u)) if i in data['allowed'] else -math.inf for i,(b,d,u) in enumerate(zip(data['base'],data['desired'],data['undesired']))];p=normalize_logs(logs)
        rows=_rows(list('ABCD'),p);pick=max(range(len(p)),key=p.__getitem__);metrics=dict(probabilities=p,selected=pick,forbidden_mass=math.fsum(p[i] for i in range(len(p)) if i not in data['allowed']))
        summary=f"Action {'ABCD'[pick]} leads; forbidden-action mass stays zero."
        note='Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook.'
    elif name=='future':
        root=weights(data['policy'][0]['rows']);child=weights(data['policy'][2]['rows']);h=[0,child[1]];p=normalize_logs([math.log(r)+(v*math.log(x) if x else -math.inf) if v else math.log(r) for r,x in zip(root,h)])
        rows=_rows(['A: dead end','B: viable route'],p);success=p[1]*child[1];metrics=dict(root_weights=p,exact_h=h,success_root_only=success,base_success=root[1]*child[1])
        summary=f'{p[1]:.2%} chooses B; leaving the next policy unchanged succeeds {success:.2%} of the time.'
        note='Only BB succeeds in this exact two-step toy. Conditioning both steps is different from steering only the root. No native future-value decoder is claimed.'
    elif name=='sensitivity':
        o=data['observations'];zs=[[math.log(p/(1-p)) for p in row['probabilities']] for row in o]
        matrix=[[(zs[2][i]-zs[1][i])/(2*data['epsilon'][0]),(zs[4][i]-zs[3][i])/(2*data['epsilon'][1])] for i in range(3)]
        delta=[r[0]*v+r[1]*5 for r in matrix];rows=_rows(['Urgency','Load','Damage'],delta);unit='predicted log-odds change'
        observed=[zs[6][i]-zs[0][i] for i in range(3)];held=[r[0]*-1+r[1]*5 for r in matrix]
        metrics=dict(matrix=matrix,predicted_delta=delta,holdout_residual=[a-b for a,b in zip(observed,held)])
        summary=f'Predicted urgency shift {delta[0]:+.3f}; the measured −1h/+5 holdout had error {metrics["holdout_residual"][0]:+.3f}.'
        note='The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses.'
    elif name=='counterexamples':
        nodes=data['nodes'];pairs=[]
        for i,a in enumerate(nodes):
            za=[math.log(p/(1-p)) for p in a['p_yes']]
            for j,b in enumerate(nodes[i+1:],i+1):
                if a['coefficients']!=b['coefficients']:continue
                zb=[math.log(p/(1-p)) for p in b['p_yes']];distance=math.sqrt(math.fsum((x-y)**2 for x,y in zip(za,zb)));pairs.append((distance,i,j))
        distance,i,j=max(pairs);a,b=nodes[i],nodes[j];evaluate=lambda c:sum(x*v**k for k,x in enumerate(c))
        rows=_rows([a['expression'],b['expression']],[a['p_yes'][1],b['p_yes'][1]])
        metrics=dict(left=a['expression'],right=b['expression'],margin_distance=distance,left_value=evaluate(a['coefficients']),right_value=evaluate(b['coefficients']))
        summary=f'Equal exact values at x={v:g}: {metrics["left_value"]:g}; observer distance {distance:.3f}.'
        note='Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe.'
    else:
        raise ValueError('No portable calculation for '+name)
    return dict(value=v,summary=summary,rows=rows,unit=unit,metrics=metrics,note=note)


def make_lesson(name, data):
    spec=LESSON_SPECS[name]
    try:
        first=calculate_lesson(name,data)
        compare=spec['compare']
        # An edited run can have fewer tokens/turns than the recorded default.
        lengths={'wire':len(data.get('entries',[])), 'samplers':len(data.get('runs',[])),
                 'tictactoe':len(data.get('frames',[])), 'context':len(data.get('runs',[])),
                 'information':len(data.get('tests',[])), 'research-map':len(data.get('branches',[])),
                 'pressure':len(data.get('cases',[]))}
        if name in lengths:compare=min(compare,lengths[name]-1)
        second=calculate_lesson(name,data,compare)
        context=data.get('prompt','').partition('STATE:\n')[2].partition('\nQUESTION:')[0]
        return dict(**spec,states=[first,second],input_excerpt=context[:320]+('…' if len(context)>320 else ''),scope='This panel and its Python calculation reproduce saved measurements. Other page controls are independent views.')
    except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:
        # A genuinely incomplete score or a tool-only wire response stays usable.
        # Do not turn an unavailable lesson into fabricated measurement data.
        return dict(**spec,states=[],unavailable=str(error),scope='This run has no complete inputs for this calculation. Inspect its exact request and result below.')



def mock_post(request, fixture):
    if request != fixture['request']:
        raise ValueError('No mock matches the edited request. Supply a new fixture or explicitly choose --live-url.')
    return copy.deepcopy(fixture['response'])


def live_post(base_url, request):
    if not base_url.startswith(('http://', 'https://')):
        raise ValueError('--live-url must be an http(s) Strata address')
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('STRATA_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['STRATA_API_KEY']
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    body = json.dumps(request, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base_url.rstrip('/')+'/v1/chat/completions', data=body, headers=headers)
    with opener.open(req, timeout=600) as response:
        wire = response.read().decode('utf-8')
    if request.get('stream'):
        events = [line[5:].strip() for line in wire.splitlines() if line.startswith('data:')]
        if not events or events[-1] != '[DONE]':
            raise ValueError('Stream closed without [DONE]')
        chunks = [json.loads(line) for line in events[:-1]]
        if any('error' in chunk for chunk in chunks):
            raise ValueError('Stream reported an error: '+repr(chunks))
        return {'sse_events': chunks, 'wire': wire}
    reply = json.loads(wire)
    if 'error' in reply:
        raise ValueError('Strata reported an error: '+repr(reply['error']))
    return reply


def summarize(response):
    if 'sse_events' in response:
        return str(len(response['sse_events']))+' SSE events; inspect the saved wire response'
    choice = (response.get('choices') or [{}])[0]
    message = choice.get('message', {})
    text = message.get('content') or json.dumps(message.get('tool_calls') or message, ensure_ascii=False)
    entries = (choice.get('logprobs') or {}).get('content') or []
    if entries:
        text += '\n  First visible token raw logprob: '+repr(entries[0]['logprob'])
        text += '\n  First visible token raw probability: '+format(math.exp(entries[0]['logprob']), '.7g')
    return text


def raw_tokens(response):
    if 'sse_events' in response:
        return [token for chunk in response['sse_events'] for choice in chunk.get('choices', [])
                for token in (choice.get('logprobs') or {}).get('content') or []]
    choices = response.get('choices') or []
    return ((choices[0].get('logprobs') or {}).get('content') or []) if choices else []


def print_raw_tokens(response):
    entries = raw_tokens(response)
    if not entries:
        print('No scored answer tokens returned; no raw probabilities are invented.')
    for i, token in enumerate(entries):
        lp = token['logprob']
        p = math.exp(lp)
        shown = format(p, '.9g') if p else 'underflows; use the finite logprob'
        print('  Token '+str(i)+': '+repr(token['token'])+' bytes='+repr(token['bytes'])+
              ' raw ln p='+repr(lp)+' raw p='+shown)
        sampling = token.get('strata_sampling')
        if sampling:
            print('    Final native selection weight q='+repr(sampling['probability'])+' (separate from raw p)')


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=int, default=1, help='1-based request index (default 1)')
    parser.add_argument('--all', action='store_true', help='Replay every mock in this captured run')
    parser.add_argument('--show', action='store_true', help='Print exact selected HTTP request JSON')
    parser.add_argument('--tokens', action='store_true', help='Print every original token raw logprob/probability and available native sampling weight')
    parser.add_argument('--lesson-only', action='store_true', help='Recalculate the captured question/rule/result panel without printing mocked calls')
    parser.add_argument('--value', type=float, help='Change the panel parameter within its documented bounds; offline calculation only')
    parser.add_argument('--live-url', help='Explicitly send ONE request to your compatible Strata server')
    parser.add_argument('--output', type=Path, help='Write responses and their provenance as JSON')
    args = parser.parse_args()
    if args.all and args.live_url:
        parser.error('--all is offline only; saved dependent requests are not a live adaptive controller')
    if args.live_url and (args.lesson_only or args.value is not None):
        parser.error('Lesson calculations use captured evidence. Do not mix --live-url with --lesson-only or --value.')
    calls = CAPTURED['receipt']['calls']
    print('Strata Control Lab / '+CAPTURED['experiment'])
    print('LIVE selected request' if args.live_url else 'OFFLINE MOCK / recorded responses, no inference or network')
    view = CAPTURED.get('score_view')
    if view:
        print('\nRAW LAYER: '+view['raw'])
        print('DERIVED VIEW: '+view['derived'])
        print('SCOPE: '+view['scope'])
    calculation=None
    if not args.live_url:
        spec=CAPTURED.get('lesson')
        if spec and spec.get('states'):
            knob=args.value if args.value is not None else (CAPTURED.get('lesson_view') or {}).get('value',spec['default'])
            try:calculation=calculate_lesson(CAPTURED['experiment'],CAPTURED['result'],knob)
            except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:parser.error(str(error))
            print('\nQUESTION: '+spec['question']+'\nRULE: '+spec['rule'])
            print(spec['knob']+' = '+str(knob)+f" (allowed {spec['low']}..{spec['high']})")
            print('RESULT: '+calculation['summary'])
            print('BOUNDARY: '+calculation['note'])
            print('Reproduces the selected question/rule/result panel; other page dials are independent.')
            print(json.dumps(calculation,ensure_ascii=True,indent=2))
        elif args.lesson_only or args.value is not None:
            parser.error('This captured run has no complete lesson inputs: '+str((spec or {}).get('unavailable','missing calculation')))
    if args.lesson_only:
        result=dict(mode='offline-calculation',calculation=calculation)
    elif not calls:
        if args.live_url:
            parser.error('This page has no HTTP requests: it is analytical or recorded diagnostic evidence')
        print('No HTTP request, GBNF or JSON output constraint was used by this page.')
        print('The included result is a calculation/diagnostic snapshot, not a new model answer.')
        result = dict(mode='offline-snapshot', result=CAPTURED['result'])
        print(json.dumps(result, ensure_ascii=True, indent=2))
    else:
        indexes = range(len(calls)) if args.all else [args.request-1]
        if any(i < 0 or i >= len(calls) for i in indexes):
            parser.error('Request index must be 1..'+str(len(calls)))
        results = []
        for i in indexes:
            fixture = calls[i]
            request = copy.deepcopy(fixture['request'])  # Edit here to try your own live request.
            if args.show:
                print(json.dumps(request, ensure_ascii=True, indent=2))
            response = live_post(args.live_url, request) if args.live_url else mock_post(request, fixture)
            print('Request '+str(i+1)+' / '+str(len(calls))+': '+summarize(response))
            if args.tokens:
                print_raw_tokens(response)
            results.append(dict(request=request, response=response,
                                provenance='live-request' if args.live_url else 'mocked-native-recording'))
        result = dict(mode='live' if args.live_url else 'offline-mock', calls=results)
        print('GBNF and JSON settings are in each request. Use --show to inspect them.')
        print('The saved page result is in CAPTURED["result"]; live responses do not recompute that snapshot.')
    if calculation is not None:result['calculation']=calculation
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
