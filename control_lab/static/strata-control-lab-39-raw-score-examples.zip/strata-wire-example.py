# -*- coding: utf-8 -*-
"""Downloaded Strata example: Python 3 standard library; offline by default.

Windows: py strata-example.py
Ubuntu:  python3 strata-example.py
Show a request: python strata-example.py --request 1 --show
Replay all recorded calls: python strata-example.py --all
Recalculate the panel: python strata-example.py --lesson-only
Change its knob: python strata-example.py --lesson-only --value NUMBER
Try ONE request live: python strata-example.py --request 1 --live-url http://127.0.0.1:8080
An optional STRATA_API_KEY environment variable supplies authentication.

CAPTURED is inserted above this runner by the page. It contains this exact run,
with requests, GBNF/JSON settings, responses, streaming chunks and the page result.
Mock mode returns those responses; it performs no inference and opens no socket.
Live mode runs only a selected request. It does not execute tools or adapt a saved
multi-step trace to new answers. No captured API key or authorization header exists.
"""
CAPTURED = {
    "experiment": "wire",
    "score_view": {
        "raw": "Each generated token carries target logprob before grammar, penalties and sampling. Raw probability is exp(logprob), with the denominator over the full target vocabulary. Every score belongs to its selected request and exact preceding token path.",
        "derived": "The token view converts logprob to raw probability without changing the denominator. Grammar may force a low-probability token; hidden reasoning and tool syntax are not scored answer content.",
        "scope": "The raw receipt stays attached to the captured request. Page dials recalculate derived views; they do not rerun the model or replace token scores. Neither model probability nor a derived weight is calibrated truth. Missing top-N alternatives stay unknown.",
        "raw_kind": "native"
    },
    "type": "result",
    "result": {
        "request": {
            "model": "x",
            "messages": [
                {
                    "role": "user",
                    "content": "Explain a hash table in one short sentence."
                }
            ],
            "max_tokens": 40,
            "temperature": 0,
            "logprobs": True,
            "top_logprobs": 5,
            "reasoning_effort": "none",
            "stream": True
        },
        "response": {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "A hash table is a data structure that uses a hash function to map keys to specific array indices, enabling efficient average-case constant-time lookups."
                    },
                    "logprobs": {
                        "content": [
                            {
                                "token": "A",
                                "logprob": -0.009605920814287731,
                                "bytes": [
                                    65
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "A",
                                        "logprob": -0.009605920814287731,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": " A",
                                        "logprob": -5.849193132423174,
                                        "bytes": [
                                            32,
                                            65
                                        ]
                                    },
                                    {
                                        "token": "Hash",
                                        "logprob": -6.063899553321612,
                                        "bytes": [
                                            72,
                                            97,
                                            115,
                                            104
                                        ]
                                    },
                                    {
                                        "token": "Think",
                                        "logprob": -7.075668848060381,
                                        "bytes": [
                                            84,
                                            104,
                                            105,
                                            110,
                                            107
                                        ]
                                    },
                                    {
                                        "token": "It",
                                        "logprob": -7.717365777992022,
                                        "bytes": [
                                            73,
                                            116
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " hash",
                                "logprob": -0.0036843889287193356,
                                "bytes": [
                                    32,
                                    104,
                                    97,
                                    115,
                                    104
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " hash",
                                        "logprob": -0.0036843889287193356,
                                        "bytes": [
                                            32,
                                            104,
                                            97,
                                            115,
                                            104
                                        ]
                                    },
                                    {
                                        "token": " **",
                                        "logprob": -6.02704750233204,
                                        "bytes": [
                                            32,
                                            42,
                                            42
                                        ]
                                    },
                                    {
                                        "token": " data",
                                        "logprob": -8.319580423169443,
                                        "bytes": [
                                            32,
                                            100,
                                            97,
                                            116,
                                            97
                                        ]
                                    },
                                    {
                                        "token": " Hash",
                                        "logprob": -9.29534469776661,
                                        "bytes": [
                                            32,
                                            72,
                                            97,
                                            115,
                                            104
                                        ]
                                    },
                                    {
                                        "token": " table",
                                        "logprob": -9.458113061719247,
                                        "bytes": [
                                            32,
                                            116,
                                            97,
                                            98,
                                            108,
                                            101
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " table",
                                "logprob": -0.0006116733458044623,
                                "bytes": [
                                    32,
                                    116,
                                    97,
                                    98,
                                    108,
                                    101
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " table",
                                        "logprob": -0.0006116733458044623,
                                        "bytes": [
                                            32,
                                            116,
                                            97,
                                            98,
                                            108,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " map",
                                        "logprob": -8.259772668829203,
                                        "bytes": [
                                            32,
                                            109,
                                            97,
                                            112
                                        ]
                                    },
                                    {
                                        "token": " is",
                                        "logprob": -8.32273806189561,
                                        "bytes": [
                                            32,
                                            105,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " key",
                                        "logprob": -11.331397424688578,
                                        "bytes": [
                                            32,
                                            107,
                                            101,
                                            121
                                        ]
                                    },
                                    {
                                        "token": " data",
                                        "logprob": -11.340312372198344,
                                        "bytes": [
                                            32,
                                            100,
                                            97,
                                            116,
                                            97
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " is",
                                "logprob": -0.049000717719115336,
                                "bytes": [
                                    32,
                                    105,
                                    115
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " is",
                                        "logprob": -0.049000717719115336,
                                        "bytes": [
                                            32,
                                            105,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " uses",
                                        "logprob": -4.102190949042358,
                                        "bytes": [
                                            32,
                                            117,
                                            115,
                                            101,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " stores",
                                        "logprob": -4.321391083319702,
                                        "bytes": [
                                            32,
                                            115,
                                            116,
                                            111,
                                            114,
                                            101,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " maps",
                                        "logprob": -4.562510468085327,
                                        "bytes": [
                                            32,
                                            109,
                                            97,
                                            112,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " provides",
                                        "logprob": -6.022900559027709,
                                        "bytes": [
                                            32,
                                            112,
                                            114,
                                            111,
                                            118,
                                            105,
                                            100,
                                            101,
                                            115
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " a",
                                "logprob": -0.006397230417056335,
                                "bytes": [
                                    32,
                                    97
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " a",
                                        "logprob": -0.006397230417056335,
                                        "bytes": [
                                            32,
                                            97
                                        ]
                                    },
                                    {
                                        "token": " an",
                                        "logprob": -5.158563596994205,
                                        "bytes": [
                                            32,
                                            97,
                                            110
                                        ]
                                    },
                                    {
                                        "token": " data",
                                        "logprob": -7.966663343698307,
                                        "bytes": [
                                            32,
                                            100,
                                            97,
                                            116,
                                            97
                                        ]
                                    },
                                    {
                                        "token": " **",
                                        "logprob": -9.222950918466372,
                                        "bytes": [
                                            32,
                                            42,
                                            42
                                        ]
                                    },
                                    {
                                        "token": "...",
                                        "logprob": -11.315877897531314,
                                        "bytes": [
                                            46,
                                            46,
                                            46
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " data",
                                "logprob": -0.016307816264760907,
                                "bytes": [
                                    32,
                                    100,
                                    97,
                                    116,
                                    97
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " data",
                                        "logprob": -0.016307816264760907,
                                        "bytes": [
                                            32,
                                            100,
                                            97,
                                            116,
                                            97
                                        ]
                                    },
                                    {
                                        "token": " dynamic",
                                        "logprob": -5.044296250102652,
                                        "bytes": [
                                            32,
                                            100,
                                            121,
                                            110,
                                            97,
                                            109,
                                            105,
                                            99
                                        ]
                                    },
                                    {
                                        "token": " key",
                                        "logprob": -5.404319748637808,
                                        "bytes": [
                                            32,
                                            107,
                                            101,
                                            121
                                        ]
                                    },
                                    {
                                        "token": " fast",
                                        "logprob": -7.041679367778433,
                                        "bytes": [
                                            32,
                                            102,
                                            97,
                                            115,
                                            116
                                        ]
                                    },
                                    {
                                        "token": " dictionary",
                                        "logprob": -7.1522483680225735,
                                        "bytes": [
                                            32,
                                            100,
                                            105,
                                            99,
                                            116,
                                            105,
                                            111,
                                            110,
                                            97,
                                            114,
                                            121
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " structure",
                                "logprob": -0.00008833903476141789,
                                "bytes": [
                                    32,
                                    115,
                                    116,
                                    114,
                                    117,
                                    99,
                                    116,
                                    117,
                                    114,
                                    101
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " structure",
                                        "logprob": -0.00008833903476141789,
                                        "bytes": [
                                            32,
                                            115,
                                            116,
                                            114,
                                            117,
                                            99,
                                            116,
                                            117,
                                            114,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " store",
                                        "logprob": -10.95295870799228,
                                        "bytes": [
                                            32,
                                            115,
                                            116,
                                            111,
                                            114,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " storage",
                                        "logprob": -11.26069033641025,
                                        "bytes": [
                                            32,
                                            115,
                                            116,
                                            111,
                                            114,
                                            97,
                                            103,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "structure",
                                        "logprob": -11.949978475753511,
                                        "bytes": [
                                            115,
                                            116,
                                            114,
                                            117,
                                            99,
                                            116,
                                            117,
                                            114,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " struct",
                                        "logprob": -12.20780432719394,
                                        "bytes": [
                                            32,
                                            115,
                                            116,
                                            114,
                                            117,
                                            99,
                                            116
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " that",
                                "logprob": -0.0027607059327317994,
                                "bytes": [
                                    32,
                                    116,
                                    104,
                                    97,
                                    116
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " that",
                                        "logprob": -0.0027607059327317994,
                                        "bytes": [
                                            32,
                                            116,
                                            104,
                                            97,
                                            116
                                        ]
                                    },
                                    {
                                        "token": " used",
                                        "logprob": -6.865443048462029,
                                        "bytes": [
                                            32,
                                            117,
                                            115,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": " for",
                                        "logprob": -8.004568872436638,
                                        "bytes": [
                                            32,
                                            102,
                                            111,
                                            114
                                        ]
                                    },
                                    {
                                        "token": " optimized",
                                        "logprob": -8.235091028198356,
                                        "bytes": [
                                            32,
                                            111,
                                            112,
                                            116,
                                            105,
                                            109,
                                            105,
                                            122,
                                            101,
                                            100
                                        ]
                                    },
                                    {
                                        "token": " designed",
                                        "logprob": -8.500841913208122,
                                        "bytes": [
                                            32,
                                            100,
                                            101,
                                            115,
                                            105,
                                            103,
                                            110,
                                            101,
                                            100
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " uses",
                                "logprob": -0.9972555610278937,
                                "bytes": [
                                    32,
                                    117,
                                    115,
                                    101,
                                    115
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " uses",
                                        "logprob": -0.9972555610278937,
                                        "bytes": [
                                            32,
                                            117,
                                            115,
                                            101,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " maps",
                                        "logprob": -1.5666525336841437,
                                        "bytes": [
                                            32,
                                            109,
                                            97,
                                            112,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " stores",
                                        "logprob": -1.6583940955737921,
                                        "bytes": [
                                            32,
                                            115,
                                            116,
                                            111,
                                            114,
                                            101,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " provides",
                                        "logprob": -2.498686072502503,
                                        "bytes": [
                                            32,
                                            112,
                                            114,
                                            111,
                                            118,
                                            105,
                                            100,
                                            101,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " enables",
                                        "logprob": -3.515775916252503,
                                        "bytes": [
                                            32,
                                            101,
                                            110,
                                            97,
                                            98,
                                            108,
                                            101,
                                            115
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " a",
                                "logprob": -0.0800093897881112,
                                "bytes": [
                                    32,
                                    97
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " a",
                                        "logprob": -0.0800093897881112,
                                        "bytes": [
                                            32,
                                            97
                                        ]
                                    },
                                    {
                                        "token": " an",
                                        "logprob": -2.750736165911158,
                                        "bytes": [
                                            32,
                                            97,
                                            110
                                        ]
                                    },
                                    {
                                        "token": " hash",
                                        "logprob": -5.946681905657252,
                                        "bytes": [
                                            32,
                                            104,
                                            97,
                                            115,
                                            104
                                        ]
                                    },
                                    {
                                        "token": " mathematical",
                                        "logprob": -6.255741048723658,
                                        "bytes": [
                                            32,
                                            109,
                                            97,
                                            116,
                                            104,
                                            101,
                                            109,
                                            97,
                                            116,
                                            105,
                                            99,
                                            97,
                                            108
                                        ]
                                    },
                                    {
                                        "token": " hashing",
                                        "logprob": -6.319971013933619,
                                        "bytes": [
                                            32,
                                            104,
                                            97,
                                            115,
                                            104,
                                            105,
                                            110,
                                            103
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " hash",
                                "logprob": -0.7337365816534168,
                                "bytes": [
                                    32,
                                    104,
                                    97,
                                    115,
                                    104
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " hash",
                                        "logprob": -0.7337365816534168,
                                        "bytes": [
                                            32,
                                            104,
                                            97,
                                            115,
                                            104
                                        ]
                                    },
                                    {
                                        "token": " mathematical",
                                        "logprob": -1.7523999880254872,
                                        "bytes": [
                                            32,
                                            109,
                                            97,
                                            116,
                                            104,
                                            101,
                                            109,
                                            97,
                                            116,
                                            105,
                                            99,
                                            97,
                                            108
                                        ]
                                    },
                                    {
                                        "token": " function",
                                        "logprob": -1.7670350740850576,
                                        "bytes": [
                                            32,
                                            102,
                                            117,
                                            110,
                                            99,
                                            116,
                                            105,
                                            111,
                                            110
                                        ]
                                    },
                                    {
                                        "token": " hashing",
                                        "logprob": -2.5374932955206044,
                                        "bytes": [
                                            32,
                                            104,
                                            97,
                                            115,
                                            104,
                                            105,
                                            110,
                                            103
                                        ]
                                    },
                                    {
                                        "token": " mapping",
                                        "logprob": -3.794222421497167,
                                        "bytes": [
                                            32,
                                            109,
                                            97,
                                            112,
                                            112,
                                            105,
                                            110,
                                            103
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " function",
                                "logprob": -0.0009408707368112374,
                                "bytes": [
                                    32,
                                    102,
                                    117,
                                    110,
                                    99,
                                    116,
                                    105,
                                    111,
                                    110
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " function",
                                        "logprob": -0.0009408707368112374,
                                        "bytes": [
                                            32,
                                            102,
                                            117,
                                            110,
                                            99,
                                            116,
                                            105,
                                            111,
                                            110
                                        ]
                                    },
                                    {
                                        "token": " to",
                                        "logprob": -8.328304838632318,
                                        "bytes": [
                                            32,
                                            116,
                                            111
                                        ]
                                    },
                                    {
                                        "token": " algorithm",
                                        "logprob": -9.15212495276806,
                                        "bytes": [
                                            32,
                                            97,
                                            108,
                                            103,
                                            111,
                                            114,
                                            105,
                                            116,
                                            104,
                                            109
                                        ]
                                    },
                                    {
                                        "token": " map",
                                        "logprob": -9.563561033700678,
                                        "bytes": [
                                            32,
                                            109,
                                            97,
                                            112
                                        ]
                                    },
                                    {
                                        "token": "ing",
                                        "logprob": -9.677500318978998,
                                        "bytes": [
                                            105,
                                            110,
                                            103
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " to",
                                "logprob": -0.0012115155566533888,
                                "bytes": [
                                    32,
                                    116,
                                    111
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " to",
                                        "logprob": -0.0012115155566533888,
                                        "bytes": [
                                            32,
                                            116,
                                            111
                                        ]
                                    },
                                    {
                                        "token": " and",
                                        "logprob": -8.55713116277345,
                                        "bytes": [
                                            32,
                                            97,
                                            110,
                                            100
                                        ]
                                    },
                                    {
                                        "token": " on",
                                        "logprob": -8.779829374443372,
                                        "bytes": [
                                            32,
                                            111,
                                            110
                                        ]
                                    },
                                    {
                                        "token": " map",
                                        "logprob": -8.792598119865735,
                                        "bytes": [
                                            32,
                                            109,
                                            97,
                                            112
                                        ]
                                    },
                                    {
                                        "token": " as",
                                        "logprob": -8.858074537407239,
                                        "bytes": [
                                            32,
                                            97,
                                            115
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " map",
                                "logprob": -0.10402005311829027,
                                "bytes": [
                                    32,
                                    109,
                                    97,
                                    112
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " map",
                                        "logprob": -0.10402005311829027,
                                        "bytes": [
                                            32,
                                            109,
                                            97,
                                            112
                                        ]
                                    },
                                    {
                                        "token": " efficiently",
                                        "logprob": -4.013012820452275,
                                        "bytes": [
                                            32,
                                            101,
                                            102,
                                            102,
                                            105,
                                            99,
                                            105,
                                            101,
                                            110,
                                            116,
                                            108,
                                            121
                                        ]
                                    },
                                    {
                                        "token": " store",
                                        "logprob": -4.301762515276494,
                                        "bytes": [
                                            32,
                                            115,
                                            116,
                                            111,
                                            114,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " rapidly",
                                        "logprob": -4.596150332659306,
                                        "bytes": [
                                            32,
                                            114,
                                            97,
                                            112,
                                            105,
                                            100,
                                            108,
                                            121
                                        ]
                                    },
                                    {
                                        "token": " assign",
                                        "logprob": -4.646489077776494,
                                        "bytes": [
                                            32,
                                            97,
                                            115,
                                            115,
                                            105,
                                            103,
                                            110
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " keys",
                                "logprob": -0.3346376696825336,
                                "bytes": [
                                    32,
                                    107,
                                    101,
                                    121,
                                    115
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " keys",
                                        "logprob": -0.3346376696825336,
                                        "bytes": [
                                            32,
                                            107,
                                            101,
                                            121,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " unique",
                                        "logprob": -1.635283497929604,
                                        "bytes": [
                                            32,
                                            117,
                                            110,
                                            105,
                                            113,
                                            117,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " a",
                                        "logprob": -3.558808354496987,
                                        "bytes": [
                                            32,
                                            97
                                        ]
                                    },
                                    {
                                        "token": " values",
                                        "logprob": -4.219592122197182,
                                        "bytes": [
                                            32,
                                            118,
                                            97,
                                            108,
                                            117,
                                            101,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " each",
                                        "logprob": -5.007794407963783,
                                        "bytes": [
                                            32,
                                            101,
                                            97,
                                            99,
                                            104
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " to",
                                "logprob": -0.009816865798112815,
                                "bytes": [
                                    32,
                                    116,
                                    111
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " to",
                                        "logprob": -0.009816865798112815,
                                        "bytes": [
                                            32,
                                            116,
                                            111
                                        ]
                                    },
                                    {
                                        "token": " directly",
                                        "logprob": -4.950738649245379,
                                        "bytes": [
                                            32,
                                            100,
                                            105,
                                            114,
                                            101,
                                            99,
                                            116,
                                            108,
                                            121
                                        ]
                                    },
                                    {
                                        "token": " into",
                                        "logprob": -6.8498189257346365,
                                        "bytes": [
                                            32,
                                            105,
                                            110,
                                            116,
                                            111
                                        ]
                                    },
                                    {
                                        "token": " unique",
                                        "logprob": -8.693950395461199,
                                        "bytes": [
                                            32,
                                            117,
                                            110,
                                            105,
                                            113,
                                            117,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " specific",
                                        "logprob": -8.699996690627215,
                                        "bytes": [
                                            32,
                                            115,
                                            112,
                                            101,
                                            99,
                                            105,
                                            102,
                                            105,
                                            99
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " specific",
                                "logprob": -0.41573522147341563,
                                "bytes": [
                                    32,
                                    115,
                                    112,
                                    101,
                                    99,
                                    105,
                                    102,
                                    105,
                                    99
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " specific",
                                        "logprob": -0.41573522147341563,
                                        "bytes": [
                                            32,
                                            115,
                                            112,
                                            101,
                                            99,
                                            105,
                                            102,
                                            105,
                                            99
                                        ]
                                    },
                                    {
                                        "token": " array",
                                        "logprob": -1.6735248332898218,
                                        "bytes": [
                                            32,
                                            97,
                                            114,
                                            114,
                                            97,
                                            121
                                        ]
                                    },
                                    {
                                        "token": " indices",
                                        "logprob": -2.94656751212283,
                                        "bytes": [
                                            32,
                                            105,
                                            110,
                                            100,
                                            105,
                                            99,
                                            101,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " unique",
                                        "logprob": -2.9516658550183377,
                                        "bytes": [
                                            32,
                                            117,
                                            110,
                                            105,
                                            113,
                                            117,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " memory",
                                        "logprob": -4.897409415809353,
                                        "bytes": [
                                            32,
                                            109,
                                            101,
                                            109,
                                            111,
                                            114,
                                            121
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " array",
                                "logprob": -0.6904054686437778,
                                "bytes": [
                                    32,
                                    97,
                                    114,
                                    114,
                                    97,
                                    121
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " array",
                                        "logprob": -0.6904054686437778,
                                        "bytes": [
                                            32,
                                            97,
                                            114,
                                            114,
                                            97,
                                            121
                                        ]
                                    },
                                    {
                                        "token": " indices",
                                        "logprob": -1.629335980118387,
                                        "bytes": [
                                            32,
                                            105,
                                            110,
                                            100,
                                            105,
                                            99,
                                            101,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " memory",
                                        "logprob": -2.3140970274816683,
                                        "bytes": [
                                            32,
                                            109,
                                            101,
                                            109,
                                            111,
                                            114,
                                            121
                                        ]
                                    },
                                    {
                                        "token": " storage",
                                        "logprob": -2.50798664540159,
                                        "bytes": [
                                            32,
                                            115,
                                            116,
                                            111,
                                            114,
                                            97,
                                            103,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " positions",
                                        "logprob": -3.63652668446409,
                                        "bytes": [
                                            32,
                                            112,
                                            111,
                                            115,
                                            105,
                                            116,
                                            105,
                                            111,
                                            110,
                                            115
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " indices",
                                "logprob": -0.15044958009309664,
                                "bytes": [
                                    32,
                                    105,
                                    110,
                                    100,
                                    105,
                                    99,
                                    101,
                                    115
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " indices",
                                        "logprob": -0.15044958009309664,
                                        "bytes": [
                                            32,
                                            105,
                                            110,
                                            100,
                                            105,
                                            99,
                                            101,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " indexes",
                                        "logprob": -2.8397043408352842,
                                        "bytes": [
                                            32,
                                            105,
                                            110,
                                            100,
                                            101,
                                            120,
                                            101,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " positions",
                                        "logprob": -3.0645960034329405,
                                        "bytes": [
                                            32,
                                            112,
                                            111,
                                            115,
                                            105,
                                            116,
                                            105,
                                            111,
                                            110,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " locations",
                                        "logprob": -4.184308833022784,
                                        "bytes": [
                                            32,
                                            108,
                                            111,
                                            99,
                                            97,
                                            116,
                                            105,
                                            111,
                                            110,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " slots",
                                        "logprob": -4.7673090161282525,
                                        "bytes": [
                                            32,
                                            115,
                                            108,
                                            111,
                                            116,
                                            115
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": ",",
                                "logprob": -0.22428342194299355,
                                "bytes": [
                                    44
                                ],
                                "top_logprobs": [
                                    {
                                        "token": ",",
                                        "logprob": -0.22428342194299355,
                                        "bytes": [
                                            44
                                        ]
                                    },
                                    {
                                        "token": " for",
                                        "logprob": -1.6202776083443609,
                                        "bytes": [
                                            32,
                                            102,
                                            111,
                                            114
                                        ]
                                    },
                                    {
                                        "token": " (",
                                        "logprob": -6.733642781684204,
                                        "bytes": [
                                            32,
                                            40
                                        ]
                                    },
                                    {
                                        "token": ".",
                                        "logprob": -7.981128896186157,
                                        "bytes": [
                                            46
                                        ]
                                    },
                                    {
                                        "token": " or",
                                        "logprob": -8.06021424622278,
                                        "bytes": [
                                            32,
                                            111,
                                            114
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " enabling",
                                "logprob": -0.23290423966548837,
                                "bytes": [
                                    32,
                                    101,
                                    110,
                                    97,
                                    98,
                                    108,
                                    105,
                                    110,
                                    103
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " enabling",
                                        "logprob": -0.23290423966548837,
                                        "bytes": [
                                            32,
                                            101,
                                            110,
                                            97,
                                            98,
                                            108,
                                            105,
                                            110,
                                            103
                                        ]
                                    },
                                    {
                                        "token": " allowing",
                                        "logprob": -1.6671140632738868,
                                        "bytes": [
                                            32,
                                            97,
                                            108,
                                            108,
                                            111,
                                            119,
                                            105,
                                            110,
                                            103
                                        ]
                                    },
                                    {
                                        "token": " providing",
                                        "logprob": -4.571973606120567,
                                        "bytes": [
                                            32,
                                            112,
                                            114,
                                            111,
                                            118,
                                            105,
                                            100,
                                            105,
                                            110,
                                            103
                                        ]
                                    },
                                    {
                                        "token": " thereby",
                                        "logprob": -5.895282550822715,
                                        "bytes": [
                                            32,
                                            116,
                                            104,
                                            101,
                                            114,
                                            101,
                                            98,
                                            121
                                        ]
                                    },
                                    {
                                        "token": " ensuring",
                                        "logprob": -6.115592762004356,
                                        "bytes": [
                                            32,
                                            101,
                                            110,
                                            115,
                                            117,
                                            114,
                                            105,
                                            110,
                                            103
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " efficient",
                                "logprob": -1.1511581785523002,
                                "bytes": [
                                    32,
                                    101,
                                    102,
                                    102,
                                    105,
                                    99,
                                    105,
                                    101,
                                    110,
                                    116
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " efficient",
                                        "logprob": -1.1511581785523002,
                                        "bytes": [
                                            32,
                                            101,
                                            102,
                                            102,
                                            105,
                                            99,
                                            105,
                                            101,
                                            110,
                                            116
                                        ]
                                    },
                                    {
                                        "token": " fast",
                                        "logprob": -1.4398849851929252,
                                        "bytes": [
                                            32,
                                            102,
                                            97,
                                            115,
                                            116
                                        ]
                                    },
                                    {
                                        "token": " extremely",
                                        "logprob": -2.2769974119507377,
                                        "bytes": [
                                            32,
                                            101,
                                            120,
                                            116,
                                            114,
                                            101,
                                            109,
                                            101,
                                            108,
                                            121
                                        ]
                                    },
                                    {
                                        "token": " near",
                                        "logprob": -2.3892200834595267,
                                        "bytes": [
                                            32,
                                            110,
                                            101,
                                            97,
                                            114
                                        ]
                                    },
                                    {
                                        "token": " average",
                                        "logprob": -2.829462850793511,
                                        "bytes": [
                                            32,
                                            97,
                                            118,
                                            101,
                                            114,
                                            97,
                                            103,
                                            101
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " average",
                                "logprob": -1.8453192349314596,
                                "bytes": [
                                    32,
                                    97,
                                    118,
                                    101,
                                    114,
                                    97,
                                    103,
                                    101
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " average",
                                        "logprob": -1.8453192349314596,
                                        "bytes": [
                                            32,
                                            97,
                                            118,
                                            101,
                                            114,
                                            97,
                                            103,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " storage",
                                        "logprob": -1.9130072232127096,
                                        "bytes": [
                                            32,
                                            115,
                                            116,
                                            111,
                                            114,
                                            97,
                                            103,
                                            101
                                        ]
                                    },
                                    {
                                        "token": ",",
                                        "logprob": -2.2133841153025533,
                                        "bytes": [
                                            44
                                        ]
                                    },
                                    {
                                        "token": " constant",
                                        "logprob": -2.2615179654002096,
                                        "bytes": [
                                            32,
                                            99,
                                            111,
                                            110,
                                            115,
                                            116,
                                            97,
                                            110,
                                            116
                                        ]
                                    },
                                    {
                                        "token": " insertion",
                                        "logprob": -2.5175909634470846,
                                        "bytes": [
                                            32,
                                            105,
                                            110,
                                            115,
                                            101,
                                            114,
                                            116,
                                            105,
                                            111,
                                            110
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": "-case",
                                "logprob": -0.4134986671095364,
                                "bytes": [
                                    45,
                                    99,
                                    97,
                                    115,
                                    101
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "-case",
                                        "logprob": -0.4134986671095364,
                                        "bytes": [
                                            45,
                                            99,
                                            97,
                                            115,
                                            101
                                        ]
                                    },
                                    {
                                        "token": "-time",
                                        "logprob": -1.4157226356153958,
                                        "bytes": [
                                            45,
                                            116,
                                            105,
                                            109,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " constant",
                                        "logprob": -3.4097507270460596,
                                        "bytes": [
                                            32,
                                            99,
                                            111,
                                            110,
                                            115,
                                            116,
                                            97,
                                            110,
                                            116
                                        ]
                                    },
                                    {
                                        "token": " $",
                                        "logprob": -3.5946357520704737,
                                        "bytes": [
                                            32,
                                            36
                                        ]
                                    },
                                    {
                                        "token": " O",
                                        "logprob": -3.978237894404458,
                                        "bytes": [
                                            32,
                                            79
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " constant",
                                "logprob": -1.086719784230094,
                                "bytes": [
                                    32,
                                    99,
                                    111,
                                    110,
                                    115,
                                    116,
                                    97,
                                    110,
                                    116
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " constant",
                                        "logprob": -1.086719784230094,
                                        "bytes": [
                                            32,
                                            99,
                                            111,
                                            110,
                                            115,
                                            116,
                                            97,
                                            110,
                                            116
                                        ]
                                    },
                                    {
                                        "token": " $",
                                        "logprob": -1.2561476559341955,
                                        "bytes": [
                                            32,
                                            36
                                        ]
                                    },
                                    {
                                        "token": " lookup",
                                        "logprob": -2.528549465626578,
                                        "bytes": [
                                            32,
                                            108,
                                            111,
                                            111,
                                            107,
                                            117,
                                            112
                                        ]
                                    },
                                    {
                                        "token": " look",
                                        "logprob": -2.585006985157828,
                                        "bytes": [
                                            32,
                                            108,
                                            111,
                                            111,
                                            107
                                        ]
                                    },
                                    {
                                        "token": " O",
                                        "logprob": -2.847601208180289,
                                        "bytes": [
                                            32,
                                            79
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": "-time",
                                "logprob": -0.3409626178190075,
                                "bytes": [
                                    45,
                                    116,
                                    105,
                                    109,
                                    101
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "-time",
                                        "logprob": -0.3409626178190075,
                                        "bytes": [
                                            45,
                                            116,
                                            105,
                                            109,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " time",
                                        "logprob": -1.2588283709928356,
                                        "bytes": [
                                            32,
                                            116,
                                            105,
                                            109,
                                            101
                                        ]
                                    },
                                    {
                                        "token": " $",
                                        "logprob": -6.152165620748695,
                                        "bytes": [
                                            32,
                                            36
                                        ]
                                    },
                                    {
                                        "token": " O",
                                        "logprob": -7.610231607381996,
                                        "bytes": [
                                            32,
                                            79
                                        ]
                                    },
                                    {
                                        "token": " lookup",
                                        "logprob": -7.908202379171547,
                                        "bytes": [
                                            32,
                                            108,
                                            111,
                                            111,
                                            107,
                                            117,
                                            112
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": " look",
                                "logprob": -0.8999246499906713,
                                "bytes": [
                                    32,
                                    108,
                                    111,
                                    111,
                                    107
                                ],
                                "top_logprobs": [
                                    {
                                        "token": " look",
                                        "logprob": -0.8999246499906713,
                                        "bytes": [
                                            32,
                                            108,
                                            111,
                                            111,
                                            107
                                        ]
                                    },
                                    {
                                        "token": " lookup",
                                        "logprob": -1.986131086147898,
                                        "bytes": [
                                            32,
                                            108,
                                            111,
                                            111,
                                            107,
                                            117,
                                            112
                                        ]
                                    },
                                    {
                                        "token": " access",
                                        "logprob": -2.0309251687894996,
                                        "bytes": [
                                            32,
                                            97,
                                            99,
                                            99,
                                            101,
                                            115,
                                            115
                                        ]
                                    },
                                    {
                                        "token": " ($",
                                        "logprob": -2.659623517788523,
                                        "bytes": [
                                            32,
                                            40,
                                            36
                                        ]
                                    },
                                    {
                                        "token": " searches",
                                        "logprob": -3.3545469186674293,
                                        "bytes": [
                                            32,
                                            115,
                                            101,
                                            97,
                                            114,
                                            99,
                                            104,
                                            101,
                                            115
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": "ups",
                                "logprob": -0.00034106497777397363,
                                "bytes": [
                                    117,
                                    112,
                                    115
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "ups",
                                        "logprob": -0.00034106497777397363,
                                        "bytes": [
                                            117,
                                            112,
                                            115
                                        ]
                                    },
                                    {
                                        "token": "-ups",
                                        "logprob": -8.479114182043203,
                                        "bytes": [
                                            45,
                                            117,
                                            112,
                                            115
                                        ]
                                    },
                                    {
                                        "token": ",",
                                        "logprob": -9.967187531042226,
                                        "bytes": [
                                            44
                                        ]
                                    },
                                    {
                                        "token": "up",
                                        "logprob": -11.105747826147207,
                                        "bytes": [
                                            117,
                                            112
                                        ]
                                    },
                                    {
                                        "token": " and",
                                        "logprob": -11.247834808874257,
                                        "bytes": [
                                            32,
                                            97,
                                            110,
                                            100
                                        ]
                                    }
                                ]
                            },
                            {
                                "token": ".",
                                "logprob": -0.7382951322007896,
                                "bytes": [
                                    46
                                ],
                                "top_logprobs": [
                                    {
                                        "token": ".",
                                        "logprob": -0.7382951322007896,
                                        "bytes": [
                                            46
                                        ]
                                    },
                                    {
                                        "token": ",",
                                        "logprob": -1.0753789487291099,
                                        "bytes": [
                                            44
                                        ]
                                    },
                                    {
                                        "token": " and",
                                        "logprob": -2.355888897459579,
                                        "bytes": [
                                            32,
                                            97,
                                            110,
                                            100
                                        ]
                                    },
                                    {
                                        "token": " for",
                                        "logprob": -3.0731969418931726,
                                        "bytes": [
                                            32,
                                            102,
                                            111,
                                            114
                                        ]
                                    },
                                    {
                                        "token": " by",
                                        "logprob": -3.77264457372911,
                                        "bytes": [
                                            32,
                                            98,
                                            121
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    "finish_reason": "stop"
                }
            ],
            "usage": {
                "prompt_tokens": 22,
                "completion_tokens": 30,
                "total_tokens": 52,
                "prompt_tokens_details": {
                    "cached_tokens": 0
                }
            },
            "timings": {
                "cache_n": 0,
                "prompt_n": 22,
                "prompt_ms": 647.1,
                "prompt_per_token_ms": 29.414,
                "prompt_per_second": 34,
                "predicted_n": 30,
                "predicted_ms": 744.4,
                "predicted_per_token_ms": 24.813,
                "predicted_per_second": 40.3,
                "draft_n": 0,
                "draft_n_accepted": 0
            }
        },
        "entries": [
            {
                "token": "A",
                "logprob": -0.009605920814287731,
                "bytes": [
                    65
                ],
                "top_logprobs": [
                    {
                        "token": "A",
                        "logprob": -0.009605920814287731,
                        "bytes": [
                            65
                        ]
                    },
                    {
                        "token": " A",
                        "logprob": -5.849193132423174,
                        "bytes": [
                            32,
                            65
                        ]
                    },
                    {
                        "token": "Hash",
                        "logprob": -6.063899553321612,
                        "bytes": [
                            72,
                            97,
                            115,
                            104
                        ]
                    },
                    {
                        "token": "Think",
                        "logprob": -7.075668848060381,
                        "bytes": [
                            84,
                            104,
                            105,
                            110,
                            107
                        ]
                    },
                    {
                        "token": "It",
                        "logprob": -7.717365777992022,
                        "bytes": [
                            73,
                            116
                        ]
                    }
                ]
            },
            {
                "token": " hash",
                "logprob": -0.0036843889287193356,
                "bytes": [
                    32,
                    104,
                    97,
                    115,
                    104
                ],
                "top_logprobs": [
                    {
                        "token": " hash",
                        "logprob": -0.0036843889287193356,
                        "bytes": [
                            32,
                            104,
                            97,
                            115,
                            104
                        ]
                    },
                    {
                        "token": " **",
                        "logprob": -6.02704750233204,
                        "bytes": [
                            32,
                            42,
                            42
                        ]
                    },
                    {
                        "token": " data",
                        "logprob": -8.319580423169443,
                        "bytes": [
                            32,
                            100,
                            97,
                            116,
                            97
                        ]
                    },
                    {
                        "token": " Hash",
                        "logprob": -9.29534469776661,
                        "bytes": [
                            32,
                            72,
                            97,
                            115,
                            104
                        ]
                    },
                    {
                        "token": " table",
                        "logprob": -9.458113061719247,
                        "bytes": [
                            32,
                            116,
                            97,
                            98,
                            108,
                            101
                        ]
                    }
                ]
            },
            {
                "token": " table",
                "logprob": -0.0006116733458044623,
                "bytes": [
                    32,
                    116,
                    97,
                    98,
                    108,
                    101
                ],
                "top_logprobs": [
                    {
                        "token": " table",
                        "logprob": -0.0006116733458044623,
                        "bytes": [
                            32,
                            116,
                            97,
                            98,
                            108,
                            101
                        ]
                    },
                    {
                        "token": " map",
                        "logprob": -8.259772668829203,
                        "bytes": [
                            32,
                            109,
                            97,
                            112
                        ]
                    },
                    {
                        "token": " is",
                        "logprob": -8.32273806189561,
                        "bytes": [
                            32,
                            105,
                            115
                        ]
                    },
                    {
                        "token": " key",
                        "logprob": -11.331397424688578,
                        "bytes": [
                            32,
                            107,
                            101,
                            121
                        ]
                    },
                    {
                        "token": " data",
                        "logprob": -11.340312372198344,
                        "bytes": [
                            32,
                            100,
                            97,
                            116,
                            97
                        ]
                    }
                ]
            },
            {
                "token": " is",
                "logprob": -0.049000717719115336,
                "bytes": [
                    32,
                    105,
                    115
                ],
                "top_logprobs": [
                    {
                        "token": " is",
                        "logprob": -0.049000717719115336,
                        "bytes": [
                            32,
                            105,
                            115
                        ]
                    },
                    {
                        "token": " uses",
                        "logprob": -4.102190949042358,
                        "bytes": [
                            32,
                            117,
                            115,
                            101,
                            115
                        ]
                    },
                    {
                        "token": " stores",
                        "logprob": -4.321391083319702,
                        "bytes": [
                            32,
                            115,
                            116,
                            111,
                            114,
                            101,
                            115
                        ]
                    },
                    {
                        "token": " maps",
                        "logprob": -4.562510468085327,
                        "bytes": [
                            32,
                            109,
                            97,
                            112,
                            115
                        ]
                    },
                    {
                        "token": " provides",
                        "logprob": -6.022900559027709,
                        "bytes": [
                            32,
                            112,
                            114,
                            111,
                            118,
                            105,
                            100,
                            101,
                            115
                        ]
                    }
                ]
            },
            {
                "token": " a",
                "logprob": -0.006397230417056335,
                "bytes": [
                    32,
                    97
                ],
                "top_logprobs": [
                    {
                        "token": " a",
                        "logprob": -0.006397230417056335,
                        "bytes": [
                            32,
                            97
                        ]
                    },
                    {
                        "token": " an",
                        "logprob": -5.158563596994205,
                        "bytes": [
                            32,
                            97,
                            110
                        ]
                    },
                    {
                        "token": " data",
                        "logprob": -7.966663343698307,
                        "bytes": [
                            32,
                            100,
                            97,
                            116,
                            97
                        ]
                    },
                    {
                        "token": " **",
                        "logprob": -9.222950918466372,
                        "bytes": [
                            32,
                            42,
                            42
                        ]
                    },
                    {
                        "token": "...",
                        "logprob": -11.315877897531314,
                        "bytes": [
                            46,
                            46,
                            46
                        ]
                    }
                ]
            },
            {
                "token": " data",
                "logprob": -0.016307816264760907,
                "bytes": [
                    32,
                    100,
                    97,
                    116,
                    97
                ],
                "top_logprobs": [
                    {
                        "token": " data",
                        "logprob": -0.016307816264760907,
                        "bytes": [
                            32,
                            100,
                            97,
                            116,
                            97
                        ]
                    },
                    {
                        "token": " dynamic",
                        "logprob": -5.044296250102652,
                        "bytes": [
                            32,
                            100,
                            121,
                            110,
                            97,
                            109,
                            105,
                            99
                        ]
                    },
                    {
                        "token": " key",
                        "logprob": -5.404319748637808,
                        "bytes": [
                            32,
                            107,
                            101,
                            121
                        ]
                    },
                    {
                        "token": " fast",
                        "logprob": -7.041679367778433,
                        "bytes": [
                            32,
                            102,
                            97,
                            115,
                            116
                        ]
                    },
                    {
                        "token": " dictionary",
                        "logprob": -7.1522483680225735,
                        "bytes": [
                            32,
                            100,
                            105,
                            99,
                            116,
                            105,
                            111,
                            110,
                            97,
                            114,
                            121
                        ]
                    }
                ]
            },
            {
                "token": " structure",
                "logprob": -0.00008833903476141789,
                "bytes": [
                    32,
                    115,
                    116,
                    114,
                    117,
                    99,
                    116,
                    117,
                    114,
                    101
                ],
                "top_logprobs": [
                    {
                        "token": " structure",
                        "logprob": -0.00008833903476141789,
                        "bytes": [
                            32,
                            115,
                            116,
                            114,
                            117,
                            99,
                            116,
                            117,
                            114,
                            101
                        ]
                    },
                    {
                        "token": " store",
                        "logprob": -10.95295870799228,
                        "bytes": [
                            32,
                            115,
                            116,
                            111,
                            114,
                            101
                        ]
                    },
                    {
                        "token": " storage",
                        "logprob": -11.26069033641025,
                        "bytes": [
                            32,
                            115,
                            116,
                            111,
                            114,
                            97,
                            103,
                            101
                        ]
                    },
                    {
                        "token": "structure",
                        "logprob": -11.949978475753511,
                        "bytes": [
                            115,
                            116,
                            114,
                            117,
                            99,
                            116,
                            117,
                            114,
                            101
                        ]
                    },
                    {
                        "token": " struct",
                        "logprob": -12.20780432719394,
                        "bytes": [
                            32,
                            115,
                            116,
                            114,
                            117,
                            99,
                            116
                        ]
                    }
                ]
            },
            {
                "token": " that",
                "logprob": -0.0027607059327317994,
                "bytes": [
                    32,
                    116,
                    104,
                    97,
                    116
                ],
                "top_logprobs": [
                    {
                        "token": " that",
                        "logprob": -0.0027607059327317994,
                        "bytes": [
                            32,
                            116,
                            104,
                            97,
                            116
                        ]
                    },
                    {
                        "token": " used",
                        "logprob": -6.865443048462029,
                        "bytes": [
                            32,
                            117,
                            115,
                            101,
                            100
                        ]
                    },
                    {
                        "token": " for",
                        "logprob": -8.004568872436638,
                        "bytes": [
                            32,
                            102,
                            111,
                            114
                        ]
                    },
                    {
                        "token": " optimized",
                        "logprob": -8.235091028198356,
                        "bytes": [
                            32,
                            111,
                            112,
                            116,
                            105,
                            109,
                            105,
                            122,
                            101,
                            100
                        ]
                    },
                    {
                        "token": " designed",
                        "logprob": -8.500841913208122,
                        "bytes": [
                            32,
                            100,
                            101,
                            115,
                            105,
                            103,
                            110,
                            101,
                            100
                        ]
                    }
                ]
            },
            {
                "token": " uses",
                "logprob": -0.9972555610278937,
                "bytes": [
                    32,
                    117,
                    115,
                    101,
                    115
                ],
                "top_logprobs": [
                    {
                        "token": " uses",
                        "logprob": -0.9972555610278937,
                        "bytes": [
                            32,
                            117,
                            115,
                            101,
                            115
                        ]
                    },
                    {
                        "token": " maps",
                        "logprob": -1.5666525336841437,
                        "bytes": [
                            32,
                            109,
                            97,
                            112,
                            115
                        ]
                    },
                    {
                        "token": " stores",
                        "logprob": -1.6583940955737921,
                        "bytes": [
                            32,
                            115,
                            116,
                            111,
                            114,
                            101,
                            115
                        ]
                    },
                    {
                        "token": " provides",
                        "logprob": -2.498686072502503,
                        "bytes": [
                            32,
                            112,
                            114,
                            111,
                            118,
                            105,
                            100,
                            101,
                            115
                        ]
                    },
                    {
                        "token": " enables",
                        "logprob": -3.515775916252503,
                        "bytes": [
                            32,
                            101,
                            110,
                            97,
                            98,
                            108,
                            101,
                            115
                        ]
                    }
                ]
            },
            {
                "token": " a",
                "logprob": -0.0800093897881112,
                "bytes": [
                    32,
                    97
                ],
                "top_logprobs": [
                    {
                        "token": " a",
                        "logprob": -0.0800093897881112,
                        "bytes": [
                            32,
                            97
                        ]
                    },
                    {
                        "token": " an",
                        "logprob": -2.750736165911158,
                        "bytes": [
                            32,
                            97,
                            110
                        ]
                    },
                    {
                        "token": " hash",
                        "logprob": -5.946681905657252,
                        "bytes": [
                            32,
                            104,
                            97,
                            115,
                            104
                        ]
                    },
                    {
                        "token": " mathematical",
                        "logprob": -6.255741048723658,
                        "bytes": [
                            32,
                            109,
                            97,
                            116,
                            104,
                            101,
                            109,
                            97,
                            116,
                            105,
                            99,
                            97,
                            108
                        ]
                    },
                    {
                        "token": " hashing",
                        "logprob": -6.319971013933619,
                        "bytes": [
                            32,
                            104,
                            97,
                            115,
                            104,
                            105,
                            110,
                            103
                        ]
                    }
                ]
            },
            {
                "token": " hash",
                "logprob": -0.7337365816534168,
                "bytes": [
                    32,
                    104,
                    97,
                    115,
                    104
                ],
                "top_logprobs": [
                    {
                        "token": " hash",
                        "logprob": -0.7337365816534168,
                        "bytes": [
                            32,
                            104,
                            97,
                            115,
                            104
                        ]
                    },
                    {
                        "token": " mathematical",
                        "logprob": -1.7523999880254872,
                        "bytes": [
                            32,
                            109,
                            97,
                            116,
                            104,
                            101,
                            109,
                            97,
                            116,
                            105,
                            99,
                            97,
                            108
                        ]
                    },
                    {
                        "token": " function",
                        "logprob": -1.7670350740850576,
                        "bytes": [
                            32,
                            102,
                            117,
                            110,
                            99,
                            116,
                            105,
                            111,
                            110
                        ]
                    },
                    {
                        "token": " hashing",
                        "logprob": -2.5374932955206044,
                        "bytes": [
                            32,
                            104,
                            97,
                            115,
                            104,
                            105,
                            110,
                            103
                        ]
                    },
                    {
                        "token": " mapping",
                        "logprob": -3.794222421497167,
                        "bytes": [
                            32,
                            109,
                            97,
                            112,
                            112,
                            105,
                            110,
                            103
                        ]
                    }
                ]
            },
            {
                "token": " function",
                "logprob": -0.0009408707368112374,
                "bytes": [
                    32,
                    102,
                    117,
                    110,
                    99,
                    116,
                    105,
                    111,
                    110
                ],
                "top_logprobs": [
                    {
                        "token": " function",
                        "logprob": -0.0009408707368112374,
                        "bytes": [
                            32,
                            102,
                            117,
                            110,
                            99,
                            116,
                            105,
                            111,
                            110
                        ]
                    },
                    {
                        "token": " to",
                        "logprob": -8.328304838632318,
                        "bytes": [
                            32,
                            116,
                            111
                        ]
                    },
                    {
                        "token": " algorithm",
                        "logprob": -9.15212495276806,
                        "bytes": [
                            32,
                            97,
                            108,
                            103,
                            111,
                            114,
                            105,
                            116,
                            104,
                            109
                        ]
                    },
                    {
                        "token": " map",
                        "logprob": -9.563561033700678,
                        "bytes": [
                            32,
                            109,
                            97,
                            112
                        ]
                    },
                    {
                        "token": "ing",
                        "logprob": -9.677500318978998,
                        "bytes": [
                            105,
                            110,
                            103
                        ]
                    }
                ]
            },
            {
                "token": " to",
                "logprob": -0.0012115155566533888,
                "bytes": [
                    32,
                    116,
                    111
                ],
                "top_logprobs": [
                    {
                        "token": " to",
                        "logprob": -0.0012115155566533888,
                        "bytes": [
                            32,
                            116,
                            111
                        ]
                    },
                    {
                        "token": " and",
                        "logprob": -8.55713116277345,
                        "bytes": [
                            32,
                            97,
                            110,
                            100
                        ]
                    },
                    {
                        "token": " on",
                        "logprob": -8.779829374443372,
                        "bytes": [
                            32,
                            111,
                            110
                        ]
                    },
                    {
                        "token": " map",
                        "logprob": -8.792598119865735,
                        "bytes": [
                            32,
                            109,
                            97,
                            112
                        ]
                    },
                    {
                        "token": " as",
                        "logprob": -8.858074537407239,
                        "bytes": [
                            32,
                            97,
                            115
                        ]
                    }
                ]
            },
            {
                "token": " map",
                "logprob": -0.10402005311829027,
                "bytes": [
                    32,
                    109,
                    97,
                    112
                ],
                "top_logprobs": [
                    {
                        "token": " map",
                        "logprob": -0.10402005311829027,
                        "bytes": [
                            32,
                            109,
                            97,
                            112
                        ]
                    },
                    {
                        "token": " efficiently",
                        "logprob": -4.013012820452275,
                        "bytes": [
                            32,
                            101,
                            102,
                            102,
                            105,
                            99,
                            105,
                            101,
                            110,
                            116,
                            108,
                            121
                        ]
                    },
                    {
                        "token": " store",
                        "logprob": -4.301762515276494,
                        "bytes": [
                            32,
                            115,
                            116,
                            111,
                            114,
                            101
                        ]
                    },
                    {
                        "token": " rapidly",
                        "logprob": -4.596150332659306,
                        "bytes": [
                            32,
                            114,
                            97,
                            112,
                            105,
                            100,
                            108,
                            121
                        ]
                    },
                    {
                        "token": " assign",
                        "logprob": -4.646489077776494,
                        "bytes": [
                            32,
                            97,
                            115,
                            115,
                            105,
                            103,
                            110
                        ]
                    }
                ]
            },
            {
                "token": " keys",
                "logprob": -0.3346376696825336,
                "bytes": [
                    32,
                    107,
                    101,
                    121,
                    115
                ],
                "top_logprobs": [
                    {
                        "token": " keys",
                        "logprob": -0.3346376696825336,
                        "bytes": [
                            32,
                            107,
                            101,
                            121,
                            115
                        ]
                    },
                    {
                        "token": " unique",
                        "logprob": -1.635283497929604,
                        "bytes": [
                            32,
                            117,
                            110,
                            105,
                            113,
                            117,
                            101
                        ]
                    },
                    {
                        "token": " a",
                        "logprob": -3.558808354496987,
                        "bytes": [
                            32,
                            97
                        ]
                    },
                    {
                        "token": " values",
                        "logprob": -4.219592122197182,
                        "bytes": [
                            32,
                            118,
                            97,
                            108,
                            117,
                            101,
                            115
                        ]
                    },
                    {
                        "token": " each",
                        "logprob": -5.007794407963783,
                        "bytes": [
                            32,
                            101,
                            97,
                            99,
                            104
                        ]
                    }
                ]
            },
            {
                "token": " to",
                "logprob": -0.009816865798112815,
                "bytes": [
                    32,
                    116,
                    111
                ],
                "top_logprobs": [
                    {
                        "token": " to",
                        "logprob": -0.009816865798112815,
                        "bytes": [
                            32,
                            116,
                            111
                        ]
                    },
                    {
                        "token": " directly",
                        "logprob": -4.950738649245379,
                        "bytes": [
                            32,
                            100,
                            105,
                            114,
                            101,
                            99,
                            116,
                            108,
                            121
                        ]
                    },
                    {
                        "token": " into",
                        "logprob": -6.8498189257346365,
                        "bytes": [
                            32,
                            105,
                            110,
                            116,
                            111
                        ]
                    },
                    {
                        "token": " unique",
                        "logprob": -8.693950395461199,
                        "bytes": [
                            32,
                            117,
                            110,
                            105,
                            113,
                            117,
                            101
                        ]
                    },
                    {
                        "token": " specific",
                        "logprob": -8.699996690627215,
                        "bytes": [
                            32,
                            115,
                            112,
                            101,
                            99,
                            105,
                            102,
                            105,
                            99
                        ]
                    }
                ]
            },
            {
                "token": " specific",
                "logprob": -0.41573522147341563,
                "bytes": [
                    32,
                    115,
                    112,
                    101,
                    99,
                    105,
                    102,
                    105,
                    99
                ],
                "top_logprobs": [
                    {
                        "token": " specific",
                        "logprob": -0.41573522147341563,
                        "bytes": [
                            32,
                            115,
                            112,
                            101,
                            99,
                            105,
                            102,
                            105,
                            99
                        ]
                    },
                    {
                        "token": " array",
                        "logprob": -1.6735248332898218,
                        "bytes": [
                            32,
                            97,
                            114,
                            114,
                            97,
                            121
                        ]
                    },
                    {
                        "token": " indices",
                        "logprob": -2.94656751212283,
                        "bytes": [
                            32,
                            105,
                            110,
                            100,
                            105,
                            99,
                            101,
                            115
                        ]
                    },
                    {
                        "token": " unique",
                        "logprob": -2.9516658550183377,
                        "bytes": [
                            32,
                            117,
                            110,
                            105,
                            113,
                            117,
                            101
                        ]
                    },
                    {
                        "token": " memory",
                        "logprob": -4.897409415809353,
                        "bytes": [
                            32,
                            109,
                            101,
                            109,
                            111,
                            114,
                            121
                        ]
                    }
                ]
            },
            {
                "token": " array",
                "logprob": -0.6904054686437778,
                "bytes": [
                    32,
                    97,
                    114,
                    114,
                    97,
                    121
                ],
                "top_logprobs": [
                    {
                        "token": " array",
                        "logprob": -0.6904054686437778,
                        "bytes": [
                            32,
                            97,
                            114,
                            114,
                            97,
                            121
                        ]
                    },
                    {
                        "token": " indices",
                        "logprob": -1.629335980118387,
                        "bytes": [
                            32,
                            105,
                            110,
                            100,
                            105,
                            99,
                            101,
                            115
                        ]
                    },
                    {
                        "token": " memory",
                        "logprob": -2.3140970274816683,
                        "bytes": [
                            32,
                            109,
                            101,
                            109,
                            111,
                            114,
                            121
                        ]
                    },
                    {
                        "token": " storage",
                        "logprob": -2.50798664540159,
                        "bytes": [
                            32,
                            115,
                            116,
                            111,
                            114,
                            97,
                            103,
                            101
                        ]
                    },
                    {
                        "token": " positions",
                        "logprob": -3.63652668446409,
                        "bytes": [
                            32,
                            112,
                            111,
                            115,
                            105,
                            116,
                            105,
                            111,
                            110,
                            115
                        ]
                    }
                ]
            },
            {
                "token": " indices",
                "logprob": -0.15044958009309664,
                "bytes": [
                    32,
                    105,
                    110,
                    100,
                    105,
                    99,
                    101,
                    115
                ],
                "top_logprobs": [
                    {
                        "token": " indices",
                        "logprob": -0.15044958009309664,
                        "bytes": [
                            32,
                            105,
                            110,
                            100,
                            105,
                            99,
                            101,
                            115
                        ]
                    },
                    {
                        "token": " indexes",
                        "logprob": -2.8397043408352842,
                        "bytes": [
                            32,
                            105,
                            110,
                            100,
                            101,
                            120,
                            101,
                            115
                        ]
                    },
                    {
                        "token": " positions",
                        "logprob": -3.0645960034329405,
                        "bytes": [
                            32,
                            112,
                            111,
                            115,
                            105,
                            116,
                            105,
                            111,
                            110,
                            115
                        ]
                    },
                    {
                        "token": " locations",
                        "logprob": -4.184308833022784,
                        "bytes": [
                            32,
                            108,
                            111,
                            99,
                            97,
                            116,
                            105,
                            111,
                            110,
                            115
                        ]
                    },
                    {
                        "token": " slots",
                        "logprob": -4.7673090161282525,
                        "bytes": [
                            32,
                            115,
                            108,
                            111,
                            116,
                            115
                        ]
                    }
                ]
            },
            {
                "token": ",",
                "logprob": -0.22428342194299355,
                "bytes": [
                    44
                ],
                "top_logprobs": [
                    {
                        "token": ",",
                        "logprob": -0.22428342194299355,
                        "bytes": [
                            44
                        ]
                    },
                    {
                        "token": " for",
                        "logprob": -1.6202776083443609,
                        "bytes": [
                            32,
                            102,
                            111,
                            114
                        ]
                    },
                    {
                        "token": " (",
                        "logprob": -6.733642781684204,
                        "bytes": [
                            32,
                            40
                        ]
                    },
                    {
                        "token": ".",
                        "logprob": -7.981128896186157,
                        "bytes": [
                            46
                        ]
                    },
                    {
                        "token": " or",
                        "logprob": -8.06021424622278,
                        "bytes": [
                            32,
                            111,
                            114
                        ]
                    }
                ]
            },
            {
                "token": " enabling",
                "logprob": -0.23290423966548837,
                "bytes": [
                    32,
                    101,
                    110,
                    97,
                    98,
                    108,
                    105,
                    110,
                    103
                ],
                "top_logprobs": [
                    {
                        "token": " enabling",
                        "logprob": -0.23290423966548837,
                        "bytes": [
                            32,
                            101,
                            110,
                            97,
                            98,
                            108,
                            105,
                            110,
                            103
                        ]
                    },
                    {
                        "token": " allowing",
                        "logprob": -1.6671140632738868,
                        "bytes": [
                            32,
                            97,
                            108,
                            108,
                            111,
                            119,
                            105,
                            110,
                            103
                        ]
                    },
                    {
                        "token": " providing",
                        "logprob": -4.571973606120567,
                        "bytes": [
                            32,
                            112,
                            114,
                            111,
                            118,
                            105,
                            100,
                            105,
                            110,
                            103
                        ]
                    },
                    {
                        "token": " thereby",
                        "logprob": -5.895282550822715,
                        "bytes": [
                            32,
                            116,
                            104,
                            101,
                            114,
                            101,
                            98,
                            121
                        ]
                    },
                    {
                        "token": " ensuring",
                        "logprob": -6.115592762004356,
                        "bytes": [
                            32,
                            101,
                            110,
                            115,
                            117,
                            114,
                            105,
                            110,
                            103
                        ]
                    }
                ]
            },
            {
                "token": " efficient",
                "logprob": -1.1511581785523002,
                "bytes": [
                    32,
                    101,
                    102,
                    102,
                    105,
                    99,
                    105,
                    101,
                    110,
                    116
                ],
                "top_logprobs": [
                    {
                        "token": " efficient",
                        "logprob": -1.1511581785523002,
                        "bytes": [
                            32,
                            101,
                            102,
                            102,
                            105,
                            99,
                            105,
                            101,
                            110,
                            116
                        ]
                    },
                    {
                        "token": " fast",
                        "logprob": -1.4398849851929252,
                        "bytes": [
                            32,
                            102,
                            97,
                            115,
                            116
                        ]
                    },
                    {
                        "token": " extremely",
                        "logprob": -2.2769974119507377,
                        "bytes": [
                            32,
                            101,
                            120,
                            116,
                            114,
                            101,
                            109,
                            101,
                            108,
                            121
                        ]
                    },
                    {
                        "token": " near",
                        "logprob": -2.3892200834595267,
                        "bytes": [
                            32,
                            110,
                            101,
                            97,
                            114
                        ]
                    },
                    {
                        "token": " average",
                        "logprob": -2.829462850793511,
                        "bytes": [
                            32,
                            97,
                            118,
                            101,
                            114,
                            97,
                            103,
                            101
                        ]
                    }
                ]
            },
            {
                "token": " average",
                "logprob": -1.8453192349314596,
                "bytes": [
                    32,
                    97,
                    118,
                    101,
                    114,
                    97,
                    103,
                    101
                ],
                "top_logprobs": [
                    {
                        "token": " average",
                        "logprob": -1.8453192349314596,
                        "bytes": [
                            32,
                            97,
                            118,
                            101,
                            114,
                            97,
                            103,
                            101
                        ]
                    },
                    {
                        "token": " storage",
                        "logprob": -1.9130072232127096,
                        "bytes": [
                            32,
                            115,
                            116,
                            111,
                            114,
                            97,
                            103,
                            101
                        ]
                    },
                    {
                        "token": ",",
                        "logprob": -2.2133841153025533,
                        "bytes": [
                            44
                        ]
                    },
                    {
                        "token": " constant",
                        "logprob": -2.2615179654002096,
                        "bytes": [
                            32,
                            99,
                            111,
                            110,
                            115,
                            116,
                            97,
                            110,
                            116
                        ]
                    },
                    {
                        "token": " insertion",
                        "logprob": -2.5175909634470846,
                        "bytes": [
                            32,
                            105,
                            110,
                            115,
                            101,
                            114,
                            116,
                            105,
                            111,
                            110
                        ]
                    }
                ]
            },
            {
                "token": "-case",
                "logprob": -0.4134986671095364,
                "bytes": [
                    45,
                    99,
                    97,
                    115,
                    101
                ],
                "top_logprobs": [
                    {
                        "token": "-case",
                        "logprob": -0.4134986671095364,
                        "bytes": [
                            45,
                            99,
                            97,
                            115,
                            101
                        ]
                    },
                    {
                        "token": "-time",
                        "logprob": -1.4157226356153958,
                        "bytes": [
                            45,
                            116,
                            105,
                            109,
                            101
                        ]
                    },
                    {
                        "token": " constant",
                        "logprob": -3.4097507270460596,
                        "bytes": [
                            32,
                            99,
                            111,
                            110,
                            115,
                            116,
                            97,
                            110,
                            116
                        ]
                    },
                    {
                        "token": " $",
                        "logprob": -3.5946357520704737,
                        "bytes": [
                            32,
                            36
                        ]
                    },
                    {
                        "token": " O",
                        "logprob": -3.978237894404458,
                        "bytes": [
                            32,
                            79
                        ]
                    }
                ]
            },
            {
                "token": " constant",
                "logprob": -1.086719784230094,
                "bytes": [
                    32,
                    99,
                    111,
                    110,
                    115,
                    116,
                    97,
                    110,
                    116
                ],
                "top_logprobs": [
                    {
                        "token": " constant",
                        "logprob": -1.086719784230094,
                        "bytes": [
                            32,
                            99,
                            111,
                            110,
                            115,
                            116,
                            97,
                            110,
                            116
                        ]
                    },
                    {
                        "token": " $",
                        "logprob": -1.2561476559341955,
                        "bytes": [
                            32,
                            36
                        ]
                    },
                    {
                        "token": " lookup",
                        "logprob": -2.528549465626578,
                        "bytes": [
                            32,
                            108,
                            111,
                            111,
                            107,
                            117,
                            112
                        ]
                    },
                    {
                        "token": " look",
                        "logprob": -2.585006985157828,
                        "bytes": [
                            32,
                            108,
                            111,
                            111,
                            107
                        ]
                    },
                    {
                        "token": " O",
                        "logprob": -2.847601208180289,
                        "bytes": [
                            32,
                            79
                        ]
                    }
                ]
            },
            {
                "token": "-time",
                "logprob": -0.3409626178190075,
                "bytes": [
                    45,
                    116,
                    105,
                    109,
                    101
                ],
                "top_logprobs": [
                    {
                        "token": "-time",
                        "logprob": -0.3409626178190075,
                        "bytes": [
                            45,
                            116,
                            105,
                            109,
                            101
                        ]
                    },
                    {
                        "token": " time",
                        "logprob": -1.2588283709928356,
                        "bytes": [
                            32,
                            116,
                            105,
                            109,
                            101
                        ]
                    },
                    {
                        "token": " $",
                        "logprob": -6.152165620748695,
                        "bytes": [
                            32,
                            36
                        ]
                    },
                    {
                        "token": " O",
                        "logprob": -7.610231607381996,
                        "bytes": [
                            32,
                            79
                        ]
                    },
                    {
                        "token": " lookup",
                        "logprob": -7.908202379171547,
                        "bytes": [
                            32,
                            108,
                            111,
                            111,
                            107,
                            117,
                            112
                        ]
                    }
                ]
            },
            {
                "token": " look",
                "logprob": -0.8999246499906713,
                "bytes": [
                    32,
                    108,
                    111,
                    111,
                    107
                ],
                "top_logprobs": [
                    {
                        "token": " look",
                        "logprob": -0.8999246499906713,
                        "bytes": [
                            32,
                            108,
                            111,
                            111,
                            107
                        ]
                    },
                    {
                        "token": " lookup",
                        "logprob": -1.986131086147898,
                        "bytes": [
                            32,
                            108,
                            111,
                            111,
                            107,
                            117,
                            112
                        ]
                    },
                    {
                        "token": " access",
                        "logprob": -2.0309251687894996,
                        "bytes": [
                            32,
                            97,
                            99,
                            99,
                            101,
                            115,
                            115
                        ]
                    },
                    {
                        "token": " ($",
                        "logprob": -2.659623517788523,
                        "bytes": [
                            32,
                            40,
                            36
                        ]
                    },
                    {
                        "token": " searches",
                        "logprob": -3.3545469186674293,
                        "bytes": [
                            32,
                            115,
                            101,
                            97,
                            114,
                            99,
                            104,
                            101,
                            115
                        ]
                    }
                ]
            },
            {
                "token": "ups",
                "logprob": -0.00034106497777397363,
                "bytes": [
                    117,
                    112,
                    115
                ],
                "top_logprobs": [
                    {
                        "token": "ups",
                        "logprob": -0.00034106497777397363,
                        "bytes": [
                            117,
                            112,
                            115
                        ]
                    },
                    {
                        "token": "-ups",
                        "logprob": -8.479114182043203,
                        "bytes": [
                            45,
                            117,
                            112,
                            115
                        ]
                    },
                    {
                        "token": ",",
                        "logprob": -9.967187531042226,
                        "bytes": [
                            44
                        ]
                    },
                    {
                        "token": "up",
                        "logprob": -11.105747826147207,
                        "bytes": [
                            117,
                            112
                        ]
                    },
                    {
                        "token": " and",
                        "logprob": -11.247834808874257,
                        "bytes": [
                            32,
                            97,
                            110,
                            100
                        ]
                    }
                ]
            },
            {
                "token": ".",
                "logprob": -0.7382951322007896,
                "bytes": [
                    46
                ],
                "top_logprobs": [
                    {
                        "token": ".",
                        "logprob": -0.7382951322007896,
                        "bytes": [
                            46
                        ]
                    },
                    {
                        "token": ",",
                        "logprob": -1.0753789487291099,
                        "bytes": [
                            44
                        ]
                    },
                    {
                        "token": " and",
                        "logprob": -2.355888897459579,
                        "bytes": [
                            32,
                            97,
                            110,
                            100
                        ]
                    },
                    {
                        "token": " for",
                        "logprob": -3.0731969418931726,
                        "bytes": [
                            32,
                            102,
                            111,
                            114
                        ]
                    },
                    {
                        "token": " by",
                        "logprob": -3.77264457372911,
                        "bytes": [
                            32,
                            98,
                            121
                        ]
                    }
                ]
            }
        ],
        "semantics": "Only generated answer content has these scores; reasoning and tool syntax are separate channels."
    },
    "lesson": {
        "question": "What did the model assign to this actual token?",
        "rule": "Exponentiate its raw logprob. Sum only the reported alternatives; their top-N list may omit probability mass.",
        "knob": "Visible token index (zero-based)",
        "default": 0,
        "compare": 5,
        "low": 0,
        "high": 10000,
        "integer": True,
        "states": [
            {
                "value": 0,
                "summary": "Token 'A': raw probability 0.99044.",
                "rows": [
                    {
                        "label": "A",
                        "value": 0.9904400686681458
                    },
                    {
                        "label": " A",
                        "value": 0.0028822237930536034
                    },
                    {
                        "label": "Hash",
                        "value": 0.002325315492797895
                    },
                    {
                        "label": "Think",
                        "value": 0.0008454269025534164
                    },
                    {
                        "label": "It",
                        "value": 0.0004450313726295131
                    }
                ],
                "unit": "raw probability",
                "metrics": {
                    "token": "A",
                    "raw_probability": 0.9904400686681458,
                    "reported_top_mass": 0.9969380662291802
                },
                "note": "This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary."
            },
            {
                "value": 5,
                "summary": "Token ' data': raw probability 0.983824.",
                "rows": [
                    {
                        "label": " data",
                        "value": 0.9838244362782446
                    },
                    {
                        "label": " dynamic",
                        "value": 0.006445995136406133
                    },
                    {
                        "label": " key",
                        "value": 0.004497112527841109
                    },
                    {
                        "label": " fast",
                        "value": 0.0008746564583078669
                    },
                    {
                        "label": " dictionary",
                        "value": 0.0007831014003287757
                    }
                ],
                "unit": "raw probability",
                "metrics": {
                    "token": " data",
                    "raw_probability": 0.9838244362782446,
                    "reported_top_mass": 0.9964253018011284
                },
                "note": "This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary."
            }
        ],
        "input_excerpt": "",
        "scope": "This panel and its Python calculation reproduce saved measurements. Other page controls are independent views."
    },
    "receipt": {
        "mode": "recorded",
        "requests": 1,
        "summed_request_ms": 1420.115499990061,
        "prompt_tokens": 22,
        "completion_tokens": 30,
        "calls": [
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Explain a hash table in one short sentence."
                        }
                    ],
                    "max_tokens": 40,
                    "temperature": 0,
                    "logprobs": True,
                    "top_logprobs": 5,
                    "reasoning_effort": "none",
                    "stream": True
                },
                "response": {
                    "choices": [
                        {
                            "message": {
                                "role": "assistant",
                                "content": "A hash table is a data structure that uses a hash function to map keys to specific array indices, enabling efficient average-case constant-time lookups."
                            },
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.009605920814287731,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.009605920814287731,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -5.849193132423174,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Hash",
                                                "logprob": -6.063899553321612,
                                                "bytes": [
                                                    72,
                                                    97,
                                                    115,
                                                    104
                                                ]
                                            },
                                            {
                                                "token": "Think",
                                                "logprob": -7.075668848060381,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107
                                                ]
                                            },
                                            {
                                                "token": "It",
                                                "logprob": -7.717365777992022,
                                                "bytes": [
                                                    73,
                                                    116
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " hash",
                                        "logprob": -0.0036843889287193356,
                                        "bytes": [
                                            32,
                                            104,
                                            97,
                                            115,
                                            104
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " hash",
                                                "logprob": -0.0036843889287193356,
                                                "bytes": [
                                                    32,
                                                    104,
                                                    97,
                                                    115,
                                                    104
                                                ]
                                            },
                                            {
                                                "token": " **",
                                                "logprob": -6.02704750233204,
                                                "bytes": [
                                                    32,
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": " data",
                                                "logprob": -8.319580423169443,
                                                "bytes": [
                                                    32,
                                                    100,
                                                    97,
                                                    116,
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " Hash",
                                                "logprob": -9.29534469776661,
                                                "bytes": [
                                                    32,
                                                    72,
                                                    97,
                                                    115,
                                                    104
                                                ]
                                            },
                                            {
                                                "token": " table",
                                                "logprob": -9.458113061719247,
                                                "bytes": [
                                                    32,
                                                    116,
                                                    97,
                                                    98,
                                                    108,
                                                    101
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " table",
                                        "logprob": -0.0006116733458044623,
                                        "bytes": [
                                            32,
                                            116,
                                            97,
                                            98,
                                            108,
                                            101
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " table",
                                                "logprob": -0.0006116733458044623,
                                                "bytes": [
                                                    32,
                                                    116,
                                                    97,
                                                    98,
                                                    108,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " map",
                                                "logprob": -8.259772668829203,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    97,
                                                    112
                                                ]
                                            },
                                            {
                                                "token": " is",
                                                "logprob": -8.32273806189561,
                                                "bytes": [
                                                    32,
                                                    105,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " key",
                                                "logprob": -11.331397424688578,
                                                "bytes": [
                                                    32,
                                                    107,
                                                    101,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": " data",
                                                "logprob": -11.340312372198344,
                                                "bytes": [
                                                    32,
                                                    100,
                                                    97,
                                                    116,
                                                    97
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " is",
                                        "logprob": -0.049000717719115336,
                                        "bytes": [
                                            32,
                                            105,
                                            115
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " is",
                                                "logprob": -0.049000717719115336,
                                                "bytes": [
                                                    32,
                                                    105,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " uses",
                                                "logprob": -4.102190949042358,
                                                "bytes": [
                                                    32,
                                                    117,
                                                    115,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " stores",
                                                "logprob": -4.321391083319702,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    116,
                                                    111,
                                                    114,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " maps",
                                                "logprob": -4.562510468085327,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    97,
                                                    112,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " provides",
                                                "logprob": -6.022900559027709,
                                                "bytes": [
                                                    32,
                                                    112,
                                                    114,
                                                    111,
                                                    118,
                                                    105,
                                                    100,
                                                    101,
                                                    115
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " a",
                                        "logprob": -0.006397230417056335,
                                        "bytes": [
                                            32,
                                            97
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " a",
                                                "logprob": -0.006397230417056335,
                                                "bytes": [
                                                    32,
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " an",
                                                "logprob": -5.158563596994205,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": " data",
                                                "logprob": -7.966663343698307,
                                                "bytes": [
                                                    32,
                                                    100,
                                                    97,
                                                    116,
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " **",
                                                "logprob": -9.222950918466372,
                                                "bytes": [
                                                    32,
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "...",
                                                "logprob": -11.315877897531314,
                                                "bytes": [
                                                    46,
                                                    46,
                                                    46
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " data",
                                        "logprob": -0.016307816264760907,
                                        "bytes": [
                                            32,
                                            100,
                                            97,
                                            116,
                                            97
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " data",
                                                "logprob": -0.016307816264760907,
                                                "bytes": [
                                                    32,
                                                    100,
                                                    97,
                                                    116,
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " dynamic",
                                                "logprob": -5.044296250102652,
                                                "bytes": [
                                                    32,
                                                    100,
                                                    121,
                                                    110,
                                                    97,
                                                    109,
                                                    105,
                                                    99
                                                ]
                                            },
                                            {
                                                "token": " key",
                                                "logprob": -5.404319748637808,
                                                "bytes": [
                                                    32,
                                                    107,
                                                    101,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": " fast",
                                                "logprob": -7.041679367778433,
                                                "bytes": [
                                                    32,
                                                    102,
                                                    97,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " dictionary",
                                                "logprob": -7.1522483680225735,
                                                "bytes": [
                                                    32,
                                                    100,
                                                    105,
                                                    99,
                                                    116,
                                                    105,
                                                    111,
                                                    110,
                                                    97,
                                                    114,
                                                    121
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " structure",
                                        "logprob": -0.00008833903476141789,
                                        "bytes": [
                                            32,
                                            115,
                                            116,
                                            114,
                                            117,
                                            99,
                                            116,
                                            117,
                                            114,
                                            101
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " structure",
                                                "logprob": -0.00008833903476141789,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    116,
                                                    114,
                                                    117,
                                                    99,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " store",
                                                "logprob": -10.95295870799228,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    116,
                                                    111,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " storage",
                                                "logprob": -11.26069033641025,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    116,
                                                    111,
                                                    114,
                                                    97,
                                                    103,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "structure",
                                                "logprob": -11.949978475753511,
                                                "bytes": [
                                                    115,
                                                    116,
                                                    114,
                                                    117,
                                                    99,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " struct",
                                                "logprob": -12.20780432719394,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    116,
                                                    114,
                                                    117,
                                                    99,
                                                    116
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " that",
                                        "logprob": -0.0027607059327317994,
                                        "bytes": [
                                            32,
                                            116,
                                            104,
                                            97,
                                            116
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " that",
                                                "logprob": -0.0027607059327317994,
                                                "bytes": [
                                                    32,
                                                    116,
                                                    104,
                                                    97,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " used",
                                                "logprob": -6.865443048462029,
                                                "bytes": [
                                                    32,
                                                    117,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": " for",
                                                "logprob": -8.004568872436638,
                                                "bytes": [
                                                    32,
                                                    102,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": " optimized",
                                                "logprob": -8.235091028198356,
                                                "bytes": [
                                                    32,
                                                    111,
                                                    112,
                                                    116,
                                                    105,
                                                    109,
                                                    105,
                                                    122,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": " designed",
                                                "logprob": -8.500841913208122,
                                                "bytes": [
                                                    32,
                                                    100,
                                                    101,
                                                    115,
                                                    105,
                                                    103,
                                                    110,
                                                    101,
                                                    100
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " uses",
                                        "logprob": -0.9972555610278937,
                                        "bytes": [
                                            32,
                                            117,
                                            115,
                                            101,
                                            115
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " uses",
                                                "logprob": -0.9972555610278937,
                                                "bytes": [
                                                    32,
                                                    117,
                                                    115,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " maps",
                                                "logprob": -1.5666525336841437,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    97,
                                                    112,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " stores",
                                                "logprob": -1.6583940955737921,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    116,
                                                    111,
                                                    114,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " provides",
                                                "logprob": -2.498686072502503,
                                                "bytes": [
                                                    32,
                                                    112,
                                                    114,
                                                    111,
                                                    118,
                                                    105,
                                                    100,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " enables",
                                                "logprob": -3.515775916252503,
                                                "bytes": [
                                                    32,
                                                    101,
                                                    110,
                                                    97,
                                                    98,
                                                    108,
                                                    101,
                                                    115
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " a",
                                        "logprob": -0.0800093897881112,
                                        "bytes": [
                                            32,
                                            97
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " a",
                                                "logprob": -0.0800093897881112,
                                                "bytes": [
                                                    32,
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " an",
                                                "logprob": -2.750736165911158,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": " hash",
                                                "logprob": -5.946681905657252,
                                                "bytes": [
                                                    32,
                                                    104,
                                                    97,
                                                    115,
                                                    104
                                                ]
                                            },
                                            {
                                                "token": " mathematical",
                                                "logprob": -6.255741048723658,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    97,
                                                    116,
                                                    104,
                                                    101,
                                                    109,
                                                    97,
                                                    116,
                                                    105,
                                                    99,
                                                    97,
                                                    108
                                                ]
                                            },
                                            {
                                                "token": " hashing",
                                                "logprob": -6.319971013933619,
                                                "bytes": [
                                                    32,
                                                    104,
                                                    97,
                                                    115,
                                                    104,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " hash",
                                        "logprob": -0.7337365816534168,
                                        "bytes": [
                                            32,
                                            104,
                                            97,
                                            115,
                                            104
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " hash",
                                                "logprob": -0.7337365816534168,
                                                "bytes": [
                                                    32,
                                                    104,
                                                    97,
                                                    115,
                                                    104
                                                ]
                                            },
                                            {
                                                "token": " mathematical",
                                                "logprob": -1.7523999880254872,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    97,
                                                    116,
                                                    104,
                                                    101,
                                                    109,
                                                    97,
                                                    116,
                                                    105,
                                                    99,
                                                    97,
                                                    108
                                                ]
                                            },
                                            {
                                                "token": " function",
                                                "logprob": -1.7670350740850576,
                                                "bytes": [
                                                    32,
                                                    102,
                                                    117,
                                                    110,
                                                    99,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": " hashing",
                                                "logprob": -2.5374932955206044,
                                                "bytes": [
                                                    32,
                                                    104,
                                                    97,
                                                    115,
                                                    104,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": " mapping",
                                                "logprob": -3.794222421497167,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    97,
                                                    112,
                                                    112,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " function",
                                        "logprob": -0.0009408707368112374,
                                        "bytes": [
                                            32,
                                            102,
                                            117,
                                            110,
                                            99,
                                            116,
                                            105,
                                            111,
                                            110
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " function",
                                                "logprob": -0.0009408707368112374,
                                                "bytes": [
                                                    32,
                                                    102,
                                                    117,
                                                    110,
                                                    99,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": " to",
                                                "logprob": -8.328304838632318,
                                                "bytes": [
                                                    32,
                                                    116,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": " algorithm",
                                                "logprob": -9.15212495276806,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    108,
                                                    103,
                                                    111,
                                                    114,
                                                    105,
                                                    116,
                                                    104,
                                                    109
                                                ]
                                            },
                                            {
                                                "token": " map",
                                                "logprob": -9.563561033700678,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    97,
                                                    112
                                                ]
                                            },
                                            {
                                                "token": "ing",
                                                "logprob": -9.677500318978998,
                                                "bytes": [
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " to",
                                        "logprob": -0.0012115155566533888,
                                        "bytes": [
                                            32,
                                            116,
                                            111
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " to",
                                                "logprob": -0.0012115155566533888,
                                                "bytes": [
                                                    32,
                                                    116,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": " and",
                                                "logprob": -8.55713116277345,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    110,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": " on",
                                                "logprob": -8.779829374443372,
                                                "bytes": [
                                                    32,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": " map",
                                                "logprob": -8.792598119865735,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    97,
                                                    112
                                                ]
                                            },
                                            {
                                                "token": " as",
                                                "logprob": -8.858074537407239,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    115
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " map",
                                        "logprob": -0.10402005311829027,
                                        "bytes": [
                                            32,
                                            109,
                                            97,
                                            112
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " map",
                                                "logprob": -0.10402005311829027,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    97,
                                                    112
                                                ]
                                            },
                                            {
                                                "token": " efficiently",
                                                "logprob": -4.013012820452275,
                                                "bytes": [
                                                    32,
                                                    101,
                                                    102,
                                                    102,
                                                    105,
                                                    99,
                                                    105,
                                                    101,
                                                    110,
                                                    116,
                                                    108,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": " store",
                                                "logprob": -4.301762515276494,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    116,
                                                    111,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " rapidly",
                                                "logprob": -4.596150332659306,
                                                "bytes": [
                                                    32,
                                                    114,
                                                    97,
                                                    112,
                                                    105,
                                                    100,
                                                    108,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": " assign",
                                                "logprob": -4.646489077776494,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    115,
                                                    115,
                                                    105,
                                                    103,
                                                    110
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " keys",
                                        "logprob": -0.3346376696825336,
                                        "bytes": [
                                            32,
                                            107,
                                            101,
                                            121,
                                            115
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " keys",
                                                "logprob": -0.3346376696825336,
                                                "bytes": [
                                                    32,
                                                    107,
                                                    101,
                                                    121,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " unique",
                                                "logprob": -1.635283497929604,
                                                "bytes": [
                                                    32,
                                                    117,
                                                    110,
                                                    105,
                                                    113,
                                                    117,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " a",
                                                "logprob": -3.558808354496987,
                                                "bytes": [
                                                    32,
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " values",
                                                "logprob": -4.219592122197182,
                                                "bytes": [
                                                    32,
                                                    118,
                                                    97,
                                                    108,
                                                    117,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " each",
                                                "logprob": -5.007794407963783,
                                                "bytes": [
                                                    32,
                                                    101,
                                                    97,
                                                    99,
                                                    104
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " to",
                                        "logprob": -0.009816865798112815,
                                        "bytes": [
                                            32,
                                            116,
                                            111
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " to",
                                                "logprob": -0.009816865798112815,
                                                "bytes": [
                                                    32,
                                                    116,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": " directly",
                                                "logprob": -4.950738649245379,
                                                "bytes": [
                                                    32,
                                                    100,
                                                    105,
                                                    114,
                                                    101,
                                                    99,
                                                    116,
                                                    108,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": " into",
                                                "logprob": -6.8498189257346365,
                                                "bytes": [
                                                    32,
                                                    105,
                                                    110,
                                                    116,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": " unique",
                                                "logprob": -8.693950395461199,
                                                "bytes": [
                                                    32,
                                                    117,
                                                    110,
                                                    105,
                                                    113,
                                                    117,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " specific",
                                                "logprob": -8.699996690627215,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    112,
                                                    101,
                                                    99,
                                                    105,
                                                    102,
                                                    105,
                                                    99
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " specific",
                                        "logprob": -0.41573522147341563,
                                        "bytes": [
                                            32,
                                            115,
                                            112,
                                            101,
                                            99,
                                            105,
                                            102,
                                            105,
                                            99
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " specific",
                                                "logprob": -0.41573522147341563,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    112,
                                                    101,
                                                    99,
                                                    105,
                                                    102,
                                                    105,
                                                    99
                                                ]
                                            },
                                            {
                                                "token": " array",
                                                "logprob": -1.6735248332898218,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    114,
                                                    114,
                                                    97,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": " indices",
                                                "logprob": -2.94656751212283,
                                                "bytes": [
                                                    32,
                                                    105,
                                                    110,
                                                    100,
                                                    105,
                                                    99,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " unique",
                                                "logprob": -2.9516658550183377,
                                                "bytes": [
                                                    32,
                                                    117,
                                                    110,
                                                    105,
                                                    113,
                                                    117,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " memory",
                                                "logprob": -4.897409415809353,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    101,
                                                    109,
                                                    111,
                                                    114,
                                                    121
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " array",
                                        "logprob": -0.6904054686437778,
                                        "bytes": [
                                            32,
                                            97,
                                            114,
                                            114,
                                            97,
                                            121
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " array",
                                                "logprob": -0.6904054686437778,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    114,
                                                    114,
                                                    97,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": " indices",
                                                "logprob": -1.629335980118387,
                                                "bytes": [
                                                    32,
                                                    105,
                                                    110,
                                                    100,
                                                    105,
                                                    99,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " memory",
                                                "logprob": -2.3140970274816683,
                                                "bytes": [
                                                    32,
                                                    109,
                                                    101,
                                                    109,
                                                    111,
                                                    114,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": " storage",
                                                "logprob": -2.50798664540159,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    116,
                                                    111,
                                                    114,
                                                    97,
                                                    103,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " positions",
                                                "logprob": -3.63652668446409,
                                                "bytes": [
                                                    32,
                                                    112,
                                                    111,
                                                    115,
                                                    105,
                                                    116,
                                                    105,
                                                    111,
                                                    110,
                                                    115
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " indices",
                                        "logprob": -0.15044958009309664,
                                        "bytes": [
                                            32,
                                            105,
                                            110,
                                            100,
                                            105,
                                            99,
                                            101,
                                            115
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " indices",
                                                "logprob": -0.15044958009309664,
                                                "bytes": [
                                                    32,
                                                    105,
                                                    110,
                                                    100,
                                                    105,
                                                    99,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " indexes",
                                                "logprob": -2.8397043408352842,
                                                "bytes": [
                                                    32,
                                                    105,
                                                    110,
                                                    100,
                                                    101,
                                                    120,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " positions",
                                                "logprob": -3.0645960034329405,
                                                "bytes": [
                                                    32,
                                                    112,
                                                    111,
                                                    115,
                                                    105,
                                                    116,
                                                    105,
                                                    111,
                                                    110,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " locations",
                                                "logprob": -4.184308833022784,
                                                "bytes": [
                                                    32,
                                                    108,
                                                    111,
                                                    99,
                                                    97,
                                                    116,
                                                    105,
                                                    111,
                                                    110,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " slots",
                                                "logprob": -4.7673090161282525,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    108,
                                                    111,
                                                    116,
                                                    115
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": ",",
                                        "logprob": -0.22428342194299355,
                                        "bytes": [
                                            44
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": ",",
                                                "logprob": -0.22428342194299355,
                                                "bytes": [
                                                    44
                                                ]
                                            },
                                            {
                                                "token": " for",
                                                "logprob": -1.6202776083443609,
                                                "bytes": [
                                                    32,
                                                    102,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": " (",
                                                "logprob": -6.733642781684204,
                                                "bytes": [
                                                    32,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -7.981128896186157,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " or",
                                                "logprob": -8.06021424622278,
                                                "bytes": [
                                                    32,
                                                    111,
                                                    114
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " enabling",
                                        "logprob": -0.23290423966548837,
                                        "bytes": [
                                            32,
                                            101,
                                            110,
                                            97,
                                            98,
                                            108,
                                            105,
                                            110,
                                            103
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " enabling",
                                                "logprob": -0.23290423966548837,
                                                "bytes": [
                                                    32,
                                                    101,
                                                    110,
                                                    97,
                                                    98,
                                                    108,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": " allowing",
                                                "logprob": -1.6671140632738868,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    108,
                                                    108,
                                                    111,
                                                    119,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": " providing",
                                                "logprob": -4.571973606120567,
                                                "bytes": [
                                                    32,
                                                    112,
                                                    114,
                                                    111,
                                                    118,
                                                    105,
                                                    100,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": " thereby",
                                                "logprob": -5.895282550822715,
                                                "bytes": [
                                                    32,
                                                    116,
                                                    104,
                                                    101,
                                                    114,
                                                    101,
                                                    98,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": " ensuring",
                                                "logprob": -6.115592762004356,
                                                "bytes": [
                                                    32,
                                                    101,
                                                    110,
                                                    115,
                                                    117,
                                                    114,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " efficient",
                                        "logprob": -1.1511581785523002,
                                        "bytes": [
                                            32,
                                            101,
                                            102,
                                            102,
                                            105,
                                            99,
                                            105,
                                            101,
                                            110,
                                            116
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " efficient",
                                                "logprob": -1.1511581785523002,
                                                "bytes": [
                                                    32,
                                                    101,
                                                    102,
                                                    102,
                                                    105,
                                                    99,
                                                    105,
                                                    101,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " fast",
                                                "logprob": -1.4398849851929252,
                                                "bytes": [
                                                    32,
                                                    102,
                                                    97,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " extremely",
                                                "logprob": -2.2769974119507377,
                                                "bytes": [
                                                    32,
                                                    101,
                                                    120,
                                                    116,
                                                    114,
                                                    101,
                                                    109,
                                                    101,
                                                    108,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": " near",
                                                "logprob": -2.3892200834595267,
                                                "bytes": [
                                                    32,
                                                    110,
                                                    101,
                                                    97,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": " average",
                                                "logprob": -2.829462850793511,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    118,
                                                    101,
                                                    114,
                                                    97,
                                                    103,
                                                    101
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " average",
                                        "logprob": -1.8453192349314596,
                                        "bytes": [
                                            32,
                                            97,
                                            118,
                                            101,
                                            114,
                                            97,
                                            103,
                                            101
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " average",
                                                "logprob": -1.8453192349314596,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    118,
                                                    101,
                                                    114,
                                                    97,
                                                    103,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " storage",
                                                "logprob": -1.9130072232127096,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    116,
                                                    111,
                                                    114,
                                                    97,
                                                    103,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": ",",
                                                "logprob": -2.2133841153025533,
                                                "bytes": [
                                                    44
                                                ]
                                            },
                                            {
                                                "token": " constant",
                                                "logprob": -2.2615179654002096,
                                                "bytes": [
                                                    32,
                                                    99,
                                                    111,
                                                    110,
                                                    115,
                                                    116,
                                                    97,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " insertion",
                                                "logprob": -2.5175909634470846,
                                                "bytes": [
                                                    32,
                                                    105,
                                                    110,
                                                    115,
                                                    101,
                                                    114,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": "-case",
                                        "logprob": -0.4134986671095364,
                                        "bytes": [
                                            45,
                                            99,
                                            97,
                                            115,
                                            101
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "-case",
                                                "logprob": -0.4134986671095364,
                                                "bytes": [
                                                    45,
                                                    99,
                                                    97,
                                                    115,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "-time",
                                                "logprob": -1.4157226356153958,
                                                "bytes": [
                                                    45,
                                                    116,
                                                    105,
                                                    109,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " constant",
                                                "logprob": -3.4097507270460596,
                                                "bytes": [
                                                    32,
                                                    99,
                                                    111,
                                                    110,
                                                    115,
                                                    116,
                                                    97,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " $",
                                                "logprob": -3.5946357520704737,
                                                "bytes": [
                                                    32,
                                                    36
                                                ]
                                            },
                                            {
                                                "token": " O",
                                                "logprob": -3.978237894404458,
                                                "bytes": [
                                                    32,
                                                    79
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " constant",
                                        "logprob": -1.086719784230094,
                                        "bytes": [
                                            32,
                                            99,
                                            111,
                                            110,
                                            115,
                                            116,
                                            97,
                                            110,
                                            116
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " constant",
                                                "logprob": -1.086719784230094,
                                                "bytes": [
                                                    32,
                                                    99,
                                                    111,
                                                    110,
                                                    115,
                                                    116,
                                                    97,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " $",
                                                "logprob": -1.2561476559341955,
                                                "bytes": [
                                                    32,
                                                    36
                                                ]
                                            },
                                            {
                                                "token": " lookup",
                                                "logprob": -2.528549465626578,
                                                "bytes": [
                                                    32,
                                                    108,
                                                    111,
                                                    111,
                                                    107,
                                                    117,
                                                    112
                                                ]
                                            },
                                            {
                                                "token": " look",
                                                "logprob": -2.585006985157828,
                                                "bytes": [
                                                    32,
                                                    108,
                                                    111,
                                                    111,
                                                    107
                                                ]
                                            },
                                            {
                                                "token": " O",
                                                "logprob": -2.847601208180289,
                                                "bytes": [
                                                    32,
                                                    79
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": "-time",
                                        "logprob": -0.3409626178190075,
                                        "bytes": [
                                            45,
                                            116,
                                            105,
                                            109,
                                            101
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "-time",
                                                "logprob": -0.3409626178190075,
                                                "bytes": [
                                                    45,
                                                    116,
                                                    105,
                                                    109,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " time",
                                                "logprob": -1.2588283709928356,
                                                "bytes": [
                                                    32,
                                                    116,
                                                    105,
                                                    109,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " $",
                                                "logprob": -6.152165620748695,
                                                "bytes": [
                                                    32,
                                                    36
                                                ]
                                            },
                                            {
                                                "token": " O",
                                                "logprob": -7.610231607381996,
                                                "bytes": [
                                                    32,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": " lookup",
                                                "logprob": -7.908202379171547,
                                                "bytes": [
                                                    32,
                                                    108,
                                                    111,
                                                    111,
                                                    107,
                                                    117,
                                                    112
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": " look",
                                        "logprob": -0.8999246499906713,
                                        "bytes": [
                                            32,
                                            108,
                                            111,
                                            111,
                                            107
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " look",
                                                "logprob": -0.8999246499906713,
                                                "bytes": [
                                                    32,
                                                    108,
                                                    111,
                                                    111,
                                                    107
                                                ]
                                            },
                                            {
                                                "token": " lookup",
                                                "logprob": -1.986131086147898,
                                                "bytes": [
                                                    32,
                                                    108,
                                                    111,
                                                    111,
                                                    107,
                                                    117,
                                                    112
                                                ]
                                            },
                                            {
                                                "token": " access",
                                                "logprob": -2.0309251687894996,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    99,
                                                    99,
                                                    101,
                                                    115,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " ($",
                                                "logprob": -2.659623517788523,
                                                "bytes": [
                                                    32,
                                                    40,
                                                    36
                                                ]
                                            },
                                            {
                                                "token": " searches",
                                                "logprob": -3.3545469186674293,
                                                "bytes": [
                                                    32,
                                                    115,
                                                    101,
                                                    97,
                                                    114,
                                                    99,
                                                    104,
                                                    101,
                                                    115
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": "ups",
                                        "logprob": -0.00034106497777397363,
                                        "bytes": [
                                            117,
                                            112,
                                            115
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "ups",
                                                "logprob": -0.00034106497777397363,
                                                "bytes": [
                                                    117,
                                                    112,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "-ups",
                                                "logprob": -8.479114182043203,
                                                "bytes": [
                                                    45,
                                                    117,
                                                    112,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": ",",
                                                "logprob": -9.967187531042226,
                                                "bytes": [
                                                    44
                                                ]
                                            },
                                            {
                                                "token": "up",
                                                "logprob": -11.105747826147207,
                                                "bytes": [
                                                    117,
                                                    112
                                                ]
                                            },
                                            {
                                                "token": " and",
                                                "logprob": -11.247834808874257,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    110,
                                                    100
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "token": ".",
                                        "logprob": -0.7382951322007896,
                                        "bytes": [
                                            46
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": ".",
                                                "logprob": -0.7382951322007896,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": ",",
                                                "logprob": -1.0753789487291099,
                                                "bytes": [
                                                    44
                                                ]
                                            },
                                            {
                                                "token": " and",
                                                "logprob": -2.355888897459579,
                                                "bytes": [
                                                    32,
                                                    97,
                                                    110,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": " for",
                                                "logprob": -3.0731969418931726,
                                                "bytes": [
                                                    32,
                                                    102,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": " by",
                                                "logprob": -3.77264457372911,
                                                "bytes": [
                                                    32,
                                                    98,
                                                    121
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            },
                            "finish_reason": "stop"
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 22,
                        "completion_tokens": 30,
                        "total_tokens": 52,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 22,
                        "prompt_ms": 647.1,
                        "prompt_per_token_ms": 29.414,
                        "prompt_per_second": 34,
                        "predicted_n": 30,
                        "predicted_ms": 744.4,
                        "predicted_per_token_ms": 24.813,
                        "predicted_per_second": 40.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "role": "assistant",
                                    "content": ""
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": "A"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": "A",
                                            "logprob": -0.009605920814287731,
                                            "bytes": [
                                                65
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "A",
                                                    "logprob": -0.009605920814287731,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -5.849193132423174,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Hash",
                                                    "logprob": -6.063899553321612,
                                                    "bytes": [
                                                        72,
                                                        97,
                                                        115,
                                                        104
                                                    ]
                                                },
                                                {
                                                    "token": "Think",
                                                    "logprob": -7.075668848060381,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        105,
                                                        110,
                                                        107
                                                    ]
                                                },
                                                {
                                                    "token": "It",
                                                    "logprob": -7.717365777992022,
                                                    "bytes": [
                                                        73,
                                                        116
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " hash"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " hash",
                                            "logprob": -0.0036843889287193356,
                                            "bytes": [
                                                32,
                                                104,
                                                97,
                                                115,
                                                104
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " hash",
                                                    "logprob": -0.0036843889287193356,
                                                    "bytes": [
                                                        32,
                                                        104,
                                                        97,
                                                        115,
                                                        104
                                                    ]
                                                },
                                                {
                                                    "token": " **",
                                                    "logprob": -6.02704750233204,
                                                    "bytes": [
                                                        32,
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": " data",
                                                    "logprob": -8.319580423169443,
                                                    "bytes": [
                                                        32,
                                                        100,
                                                        97,
                                                        116,
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": " Hash",
                                                    "logprob": -9.29534469776661,
                                                    "bytes": [
                                                        32,
                                                        72,
                                                        97,
                                                        115,
                                                        104
                                                    ]
                                                },
                                                {
                                                    "token": " table",
                                                    "logprob": -9.458113061719247,
                                                    "bytes": [
                                                        32,
                                                        116,
                                                        97,
                                                        98,
                                                        108,
                                                        101
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " table"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " table",
                                            "logprob": -0.0006116733458044623,
                                            "bytes": [
                                                32,
                                                116,
                                                97,
                                                98,
                                                108,
                                                101
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " table",
                                                    "logprob": -0.0006116733458044623,
                                                    "bytes": [
                                                        32,
                                                        116,
                                                        97,
                                                        98,
                                                        108,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " map",
                                                    "logprob": -8.259772668829203,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        97,
                                                        112
                                                    ]
                                                },
                                                {
                                                    "token": " is",
                                                    "logprob": -8.32273806189561,
                                                    "bytes": [
                                                        32,
                                                        105,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " key",
                                                    "logprob": -11.331397424688578,
                                                    "bytes": [
                                                        32,
                                                        107,
                                                        101,
                                                        121
                                                    ]
                                                },
                                                {
                                                    "token": " data",
                                                    "logprob": -11.340312372198344,
                                                    "bytes": [
                                                        32,
                                                        100,
                                                        97,
                                                        116,
                                                        97
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " is"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " is",
                                            "logprob": -0.049000717719115336,
                                            "bytes": [
                                                32,
                                                105,
                                                115
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " is",
                                                    "logprob": -0.049000717719115336,
                                                    "bytes": [
                                                        32,
                                                        105,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " uses",
                                                    "logprob": -4.102190949042358,
                                                    "bytes": [
                                                        32,
                                                        117,
                                                        115,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " stores",
                                                    "logprob": -4.321391083319702,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        116,
                                                        111,
                                                        114,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " maps",
                                                    "logprob": -4.562510468085327,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        97,
                                                        112,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " provides",
                                                    "logprob": -6.022900559027709,
                                                    "bytes": [
                                                        32,
                                                        112,
                                                        114,
                                                        111,
                                                        118,
                                                        105,
                                                        100,
                                                        101,
                                                        115
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " a"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " a",
                                            "logprob": -0.006397230417056335,
                                            "bytes": [
                                                32,
                                                97
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " a",
                                                    "logprob": -0.006397230417056335,
                                                    "bytes": [
                                                        32,
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": " an",
                                                    "logprob": -5.158563596994205,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": " data",
                                                    "logprob": -7.966663343698307,
                                                    "bytes": [
                                                        32,
                                                        100,
                                                        97,
                                                        116,
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": " **",
                                                    "logprob": -9.222950918466372,
                                                    "bytes": [
                                                        32,
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "...",
                                                    "logprob": -11.315877897531314,
                                                    "bytes": [
                                                        46,
                                                        46,
                                                        46
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " data"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " data",
                                            "logprob": -0.016307816264760907,
                                            "bytes": [
                                                32,
                                                100,
                                                97,
                                                116,
                                                97
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " data",
                                                    "logprob": -0.016307816264760907,
                                                    "bytes": [
                                                        32,
                                                        100,
                                                        97,
                                                        116,
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": " dynamic",
                                                    "logprob": -5.044296250102652,
                                                    "bytes": [
                                                        32,
                                                        100,
                                                        121,
                                                        110,
                                                        97,
                                                        109,
                                                        105,
                                                        99
                                                    ]
                                                },
                                                {
                                                    "token": " key",
                                                    "logprob": -5.404319748637808,
                                                    "bytes": [
                                                        32,
                                                        107,
                                                        101,
                                                        121
                                                    ]
                                                },
                                                {
                                                    "token": " fast",
                                                    "logprob": -7.041679367778433,
                                                    "bytes": [
                                                        32,
                                                        102,
                                                        97,
                                                        115,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": " dictionary",
                                                    "logprob": -7.1522483680225735,
                                                    "bytes": [
                                                        32,
                                                        100,
                                                        105,
                                                        99,
                                                        116,
                                                        105,
                                                        111,
                                                        110,
                                                        97,
                                                        114,
                                                        121
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " structure"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " structure",
                                            "logprob": -0.00008833903476141789,
                                            "bytes": [
                                                32,
                                                115,
                                                116,
                                                114,
                                                117,
                                                99,
                                                116,
                                                117,
                                                114,
                                                101
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " structure",
                                                    "logprob": -0.00008833903476141789,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        116,
                                                        114,
                                                        117,
                                                        99,
                                                        116,
                                                        117,
                                                        114,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " store",
                                                    "logprob": -10.95295870799228,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        116,
                                                        111,
                                                        114,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " storage",
                                                    "logprob": -11.26069033641025,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        116,
                                                        111,
                                                        114,
                                                        97,
                                                        103,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "structure",
                                                    "logprob": -11.949978475753511,
                                                    "bytes": [
                                                        115,
                                                        116,
                                                        114,
                                                        117,
                                                        99,
                                                        116,
                                                        117,
                                                        114,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " struct",
                                                    "logprob": -12.20780432719394,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        116,
                                                        114,
                                                        117,
                                                        99,
                                                        116
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " that"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " that",
                                            "logprob": -0.0027607059327317994,
                                            "bytes": [
                                                32,
                                                116,
                                                104,
                                                97,
                                                116
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " that",
                                                    "logprob": -0.0027607059327317994,
                                                    "bytes": [
                                                        32,
                                                        116,
                                                        104,
                                                        97,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": " used",
                                                    "logprob": -6.865443048462029,
                                                    "bytes": [
                                                        32,
                                                        117,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": " for",
                                                    "logprob": -8.004568872436638,
                                                    "bytes": [
                                                        32,
                                                        102,
                                                        111,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": " optimized",
                                                    "logprob": -8.235091028198356,
                                                    "bytes": [
                                                        32,
                                                        111,
                                                        112,
                                                        116,
                                                        105,
                                                        109,
                                                        105,
                                                        122,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": " designed",
                                                    "logprob": -8.500841913208122,
                                                    "bytes": [
                                                        32,
                                                        100,
                                                        101,
                                                        115,
                                                        105,
                                                        103,
                                                        110,
                                                        101,
                                                        100
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " uses"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " uses",
                                            "logprob": -0.9972555610278937,
                                            "bytes": [
                                                32,
                                                117,
                                                115,
                                                101,
                                                115
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " uses",
                                                    "logprob": -0.9972555610278937,
                                                    "bytes": [
                                                        32,
                                                        117,
                                                        115,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " maps",
                                                    "logprob": -1.5666525336841437,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        97,
                                                        112,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " stores",
                                                    "logprob": -1.6583940955737921,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        116,
                                                        111,
                                                        114,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " provides",
                                                    "logprob": -2.498686072502503,
                                                    "bytes": [
                                                        32,
                                                        112,
                                                        114,
                                                        111,
                                                        118,
                                                        105,
                                                        100,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " enables",
                                                    "logprob": -3.515775916252503,
                                                    "bytes": [
                                                        32,
                                                        101,
                                                        110,
                                                        97,
                                                        98,
                                                        108,
                                                        101,
                                                        115
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " a"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " a",
                                            "logprob": -0.0800093897881112,
                                            "bytes": [
                                                32,
                                                97
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " a",
                                                    "logprob": -0.0800093897881112,
                                                    "bytes": [
                                                        32,
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": " an",
                                                    "logprob": -2.750736165911158,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": " hash",
                                                    "logprob": -5.946681905657252,
                                                    "bytes": [
                                                        32,
                                                        104,
                                                        97,
                                                        115,
                                                        104
                                                    ]
                                                },
                                                {
                                                    "token": " mathematical",
                                                    "logprob": -6.255741048723658,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        97,
                                                        116,
                                                        104,
                                                        101,
                                                        109,
                                                        97,
                                                        116,
                                                        105,
                                                        99,
                                                        97,
                                                        108
                                                    ]
                                                },
                                                {
                                                    "token": " hashing",
                                                    "logprob": -6.319971013933619,
                                                    "bytes": [
                                                        32,
                                                        104,
                                                        97,
                                                        115,
                                                        104,
                                                        105,
                                                        110,
                                                        103
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " hash"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " hash",
                                            "logprob": -0.7337365816534168,
                                            "bytes": [
                                                32,
                                                104,
                                                97,
                                                115,
                                                104
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " hash",
                                                    "logprob": -0.7337365816534168,
                                                    "bytes": [
                                                        32,
                                                        104,
                                                        97,
                                                        115,
                                                        104
                                                    ]
                                                },
                                                {
                                                    "token": " mathematical",
                                                    "logprob": -1.7523999880254872,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        97,
                                                        116,
                                                        104,
                                                        101,
                                                        109,
                                                        97,
                                                        116,
                                                        105,
                                                        99,
                                                        97,
                                                        108
                                                    ]
                                                },
                                                {
                                                    "token": " function",
                                                    "logprob": -1.7670350740850576,
                                                    "bytes": [
                                                        32,
                                                        102,
                                                        117,
                                                        110,
                                                        99,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": " hashing",
                                                    "logprob": -2.5374932955206044,
                                                    "bytes": [
                                                        32,
                                                        104,
                                                        97,
                                                        115,
                                                        104,
                                                        105,
                                                        110,
                                                        103
                                                    ]
                                                },
                                                {
                                                    "token": " mapping",
                                                    "logprob": -3.794222421497167,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        97,
                                                        112,
                                                        112,
                                                        105,
                                                        110,
                                                        103
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " function"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " function",
                                            "logprob": -0.0009408707368112374,
                                            "bytes": [
                                                32,
                                                102,
                                                117,
                                                110,
                                                99,
                                                116,
                                                105,
                                                111,
                                                110
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " function",
                                                    "logprob": -0.0009408707368112374,
                                                    "bytes": [
                                                        32,
                                                        102,
                                                        117,
                                                        110,
                                                        99,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": " to",
                                                    "logprob": -8.328304838632318,
                                                    "bytes": [
                                                        32,
                                                        116,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": " algorithm",
                                                    "logprob": -9.15212495276806,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        108,
                                                        103,
                                                        111,
                                                        114,
                                                        105,
                                                        116,
                                                        104,
                                                        109
                                                    ]
                                                },
                                                {
                                                    "token": " map",
                                                    "logprob": -9.563561033700678,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        97,
                                                        112
                                                    ]
                                                },
                                                {
                                                    "token": "ing",
                                                    "logprob": -9.677500318978998,
                                                    "bytes": [
                                                        105,
                                                        110,
                                                        103
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " to"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " to",
                                            "logprob": -0.0012115155566533888,
                                            "bytes": [
                                                32,
                                                116,
                                                111
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " to",
                                                    "logprob": -0.0012115155566533888,
                                                    "bytes": [
                                                        32,
                                                        116,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": " and",
                                                    "logprob": -8.55713116277345,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        110,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": " on",
                                                    "logprob": -8.779829374443372,
                                                    "bytes": [
                                                        32,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": " map",
                                                    "logprob": -8.792598119865735,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        97,
                                                        112
                                                    ]
                                                },
                                                {
                                                    "token": " as",
                                                    "logprob": -8.858074537407239,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        115
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " map"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " map",
                                            "logprob": -0.10402005311829027,
                                            "bytes": [
                                                32,
                                                109,
                                                97,
                                                112
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " map",
                                                    "logprob": -0.10402005311829027,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        97,
                                                        112
                                                    ]
                                                },
                                                {
                                                    "token": " efficiently",
                                                    "logprob": -4.013012820452275,
                                                    "bytes": [
                                                        32,
                                                        101,
                                                        102,
                                                        102,
                                                        105,
                                                        99,
                                                        105,
                                                        101,
                                                        110,
                                                        116,
                                                        108,
                                                        121
                                                    ]
                                                },
                                                {
                                                    "token": " store",
                                                    "logprob": -4.301762515276494,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        116,
                                                        111,
                                                        114,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " rapidly",
                                                    "logprob": -4.596150332659306,
                                                    "bytes": [
                                                        32,
                                                        114,
                                                        97,
                                                        112,
                                                        105,
                                                        100,
                                                        108,
                                                        121
                                                    ]
                                                },
                                                {
                                                    "token": " assign",
                                                    "logprob": -4.646489077776494,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        115,
                                                        115,
                                                        105,
                                                        103,
                                                        110
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " keys"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " keys",
                                            "logprob": -0.3346376696825336,
                                            "bytes": [
                                                32,
                                                107,
                                                101,
                                                121,
                                                115
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " keys",
                                                    "logprob": -0.3346376696825336,
                                                    "bytes": [
                                                        32,
                                                        107,
                                                        101,
                                                        121,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " unique",
                                                    "logprob": -1.635283497929604,
                                                    "bytes": [
                                                        32,
                                                        117,
                                                        110,
                                                        105,
                                                        113,
                                                        117,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " a",
                                                    "logprob": -3.558808354496987,
                                                    "bytes": [
                                                        32,
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": " values",
                                                    "logprob": -4.219592122197182,
                                                    "bytes": [
                                                        32,
                                                        118,
                                                        97,
                                                        108,
                                                        117,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " each",
                                                    "logprob": -5.007794407963783,
                                                    "bytes": [
                                                        32,
                                                        101,
                                                        97,
                                                        99,
                                                        104
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " to"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " to",
                                            "logprob": -0.009816865798112815,
                                            "bytes": [
                                                32,
                                                116,
                                                111
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " to",
                                                    "logprob": -0.009816865798112815,
                                                    "bytes": [
                                                        32,
                                                        116,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": " directly",
                                                    "logprob": -4.950738649245379,
                                                    "bytes": [
                                                        32,
                                                        100,
                                                        105,
                                                        114,
                                                        101,
                                                        99,
                                                        116,
                                                        108,
                                                        121
                                                    ]
                                                },
                                                {
                                                    "token": " into",
                                                    "logprob": -6.8498189257346365,
                                                    "bytes": [
                                                        32,
                                                        105,
                                                        110,
                                                        116,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": " unique",
                                                    "logprob": -8.693950395461199,
                                                    "bytes": [
                                                        32,
                                                        117,
                                                        110,
                                                        105,
                                                        113,
                                                        117,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " specific",
                                                    "logprob": -8.699996690627215,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        112,
                                                        101,
                                                        99,
                                                        105,
                                                        102,
                                                        105,
                                                        99
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " specific"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " specific",
                                            "logprob": -0.41573522147341563,
                                            "bytes": [
                                                32,
                                                115,
                                                112,
                                                101,
                                                99,
                                                105,
                                                102,
                                                105,
                                                99
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " specific",
                                                    "logprob": -0.41573522147341563,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        112,
                                                        101,
                                                        99,
                                                        105,
                                                        102,
                                                        105,
                                                        99
                                                    ]
                                                },
                                                {
                                                    "token": " array",
                                                    "logprob": -1.6735248332898218,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        114,
                                                        114,
                                                        97,
                                                        121
                                                    ]
                                                },
                                                {
                                                    "token": " indices",
                                                    "logprob": -2.94656751212283,
                                                    "bytes": [
                                                        32,
                                                        105,
                                                        110,
                                                        100,
                                                        105,
                                                        99,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " unique",
                                                    "logprob": -2.9516658550183377,
                                                    "bytes": [
                                                        32,
                                                        117,
                                                        110,
                                                        105,
                                                        113,
                                                        117,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " memory",
                                                    "logprob": -4.897409415809353,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        101,
                                                        109,
                                                        111,
                                                        114,
                                                        121
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " array"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " array",
                                            "logprob": -0.6904054686437778,
                                            "bytes": [
                                                32,
                                                97,
                                                114,
                                                114,
                                                97,
                                                121
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " array",
                                                    "logprob": -0.6904054686437778,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        114,
                                                        114,
                                                        97,
                                                        121
                                                    ]
                                                },
                                                {
                                                    "token": " indices",
                                                    "logprob": -1.629335980118387,
                                                    "bytes": [
                                                        32,
                                                        105,
                                                        110,
                                                        100,
                                                        105,
                                                        99,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " memory",
                                                    "logprob": -2.3140970274816683,
                                                    "bytes": [
                                                        32,
                                                        109,
                                                        101,
                                                        109,
                                                        111,
                                                        114,
                                                        121
                                                    ]
                                                },
                                                {
                                                    "token": " storage",
                                                    "logprob": -2.50798664540159,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        116,
                                                        111,
                                                        114,
                                                        97,
                                                        103,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " positions",
                                                    "logprob": -3.63652668446409,
                                                    "bytes": [
                                                        32,
                                                        112,
                                                        111,
                                                        115,
                                                        105,
                                                        116,
                                                        105,
                                                        111,
                                                        110,
                                                        115
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " indices"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " indices",
                                            "logprob": -0.15044958009309664,
                                            "bytes": [
                                                32,
                                                105,
                                                110,
                                                100,
                                                105,
                                                99,
                                                101,
                                                115
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " indices",
                                                    "logprob": -0.15044958009309664,
                                                    "bytes": [
                                                        32,
                                                        105,
                                                        110,
                                                        100,
                                                        105,
                                                        99,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " indexes",
                                                    "logprob": -2.8397043408352842,
                                                    "bytes": [
                                                        32,
                                                        105,
                                                        110,
                                                        100,
                                                        101,
                                                        120,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " positions",
                                                    "logprob": -3.0645960034329405,
                                                    "bytes": [
                                                        32,
                                                        112,
                                                        111,
                                                        115,
                                                        105,
                                                        116,
                                                        105,
                                                        111,
                                                        110,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " locations",
                                                    "logprob": -4.184308833022784,
                                                    "bytes": [
                                                        32,
                                                        108,
                                                        111,
                                                        99,
                                                        97,
                                                        116,
                                                        105,
                                                        111,
                                                        110,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " slots",
                                                    "logprob": -4.7673090161282525,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        108,
                                                        111,
                                                        116,
                                                        115
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": ","
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": ",",
                                            "logprob": -0.22428342194299355,
                                            "bytes": [
                                                44
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": ",",
                                                    "logprob": -0.22428342194299355,
                                                    "bytes": [
                                                        44
                                                    ]
                                                },
                                                {
                                                    "token": " for",
                                                    "logprob": -1.6202776083443609,
                                                    "bytes": [
                                                        32,
                                                        102,
                                                        111,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": " (",
                                                    "logprob": -6.733642781684204,
                                                    "bytes": [
                                                        32,
                                                        40
                                                    ]
                                                },
                                                {
                                                    "token": ".",
                                                    "logprob": -7.981128896186157,
                                                    "bytes": [
                                                        46
                                                    ]
                                                },
                                                {
                                                    "token": " or",
                                                    "logprob": -8.06021424622278,
                                                    "bytes": [
                                                        32,
                                                        111,
                                                        114
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " enabling"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " enabling",
                                            "logprob": -0.23290423966548837,
                                            "bytes": [
                                                32,
                                                101,
                                                110,
                                                97,
                                                98,
                                                108,
                                                105,
                                                110,
                                                103
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " enabling",
                                                    "logprob": -0.23290423966548837,
                                                    "bytes": [
                                                        32,
                                                        101,
                                                        110,
                                                        97,
                                                        98,
                                                        108,
                                                        105,
                                                        110,
                                                        103
                                                    ]
                                                },
                                                {
                                                    "token": " allowing",
                                                    "logprob": -1.6671140632738868,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        108,
                                                        108,
                                                        111,
                                                        119,
                                                        105,
                                                        110,
                                                        103
                                                    ]
                                                },
                                                {
                                                    "token": " providing",
                                                    "logprob": -4.571973606120567,
                                                    "bytes": [
                                                        32,
                                                        112,
                                                        114,
                                                        111,
                                                        118,
                                                        105,
                                                        100,
                                                        105,
                                                        110,
                                                        103
                                                    ]
                                                },
                                                {
                                                    "token": " thereby",
                                                    "logprob": -5.895282550822715,
                                                    "bytes": [
                                                        32,
                                                        116,
                                                        104,
                                                        101,
                                                        114,
                                                        101,
                                                        98,
                                                        121
                                                    ]
                                                },
                                                {
                                                    "token": " ensuring",
                                                    "logprob": -6.115592762004356,
                                                    "bytes": [
                                                        32,
                                                        101,
                                                        110,
                                                        115,
                                                        117,
                                                        114,
                                                        105,
                                                        110,
                                                        103
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " efficient"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " efficient",
                                            "logprob": -1.1511581785523002,
                                            "bytes": [
                                                32,
                                                101,
                                                102,
                                                102,
                                                105,
                                                99,
                                                105,
                                                101,
                                                110,
                                                116
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " efficient",
                                                    "logprob": -1.1511581785523002,
                                                    "bytes": [
                                                        32,
                                                        101,
                                                        102,
                                                        102,
                                                        105,
                                                        99,
                                                        105,
                                                        101,
                                                        110,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": " fast",
                                                    "logprob": -1.4398849851929252,
                                                    "bytes": [
                                                        32,
                                                        102,
                                                        97,
                                                        115,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": " extremely",
                                                    "logprob": -2.2769974119507377,
                                                    "bytes": [
                                                        32,
                                                        101,
                                                        120,
                                                        116,
                                                        114,
                                                        101,
                                                        109,
                                                        101,
                                                        108,
                                                        121
                                                    ]
                                                },
                                                {
                                                    "token": " near",
                                                    "logprob": -2.3892200834595267,
                                                    "bytes": [
                                                        32,
                                                        110,
                                                        101,
                                                        97,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": " average",
                                                    "logprob": -2.829462850793511,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        118,
                                                        101,
                                                        114,
                                                        97,
                                                        103,
                                                        101
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " average"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " average",
                                            "logprob": -1.8453192349314596,
                                            "bytes": [
                                                32,
                                                97,
                                                118,
                                                101,
                                                114,
                                                97,
                                                103,
                                                101
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " average",
                                                    "logprob": -1.8453192349314596,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        118,
                                                        101,
                                                        114,
                                                        97,
                                                        103,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " storage",
                                                    "logprob": -1.9130072232127096,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        116,
                                                        111,
                                                        114,
                                                        97,
                                                        103,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": ",",
                                                    "logprob": -2.2133841153025533,
                                                    "bytes": [
                                                        44
                                                    ]
                                                },
                                                {
                                                    "token": " constant",
                                                    "logprob": -2.2615179654002096,
                                                    "bytes": [
                                                        32,
                                                        99,
                                                        111,
                                                        110,
                                                        115,
                                                        116,
                                                        97,
                                                        110,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": " insertion",
                                                    "logprob": -2.5175909634470846,
                                                    "bytes": [
                                                        32,
                                                        105,
                                                        110,
                                                        115,
                                                        101,
                                                        114,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": "-case"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": "-case",
                                            "logprob": -0.4134986671095364,
                                            "bytes": [
                                                45,
                                                99,
                                                97,
                                                115,
                                                101
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "-case",
                                                    "logprob": -0.4134986671095364,
                                                    "bytes": [
                                                        45,
                                                        99,
                                                        97,
                                                        115,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "-time",
                                                    "logprob": -1.4157226356153958,
                                                    "bytes": [
                                                        45,
                                                        116,
                                                        105,
                                                        109,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " constant",
                                                    "logprob": -3.4097507270460596,
                                                    "bytes": [
                                                        32,
                                                        99,
                                                        111,
                                                        110,
                                                        115,
                                                        116,
                                                        97,
                                                        110,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": " $",
                                                    "logprob": -3.5946357520704737,
                                                    "bytes": [
                                                        32,
                                                        36
                                                    ]
                                                },
                                                {
                                                    "token": " O",
                                                    "logprob": -3.978237894404458,
                                                    "bytes": [
                                                        32,
                                                        79
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " constant"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " constant",
                                            "logprob": -1.086719784230094,
                                            "bytes": [
                                                32,
                                                99,
                                                111,
                                                110,
                                                115,
                                                116,
                                                97,
                                                110,
                                                116
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " constant",
                                                    "logprob": -1.086719784230094,
                                                    "bytes": [
                                                        32,
                                                        99,
                                                        111,
                                                        110,
                                                        115,
                                                        116,
                                                        97,
                                                        110,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": " $",
                                                    "logprob": -1.2561476559341955,
                                                    "bytes": [
                                                        32,
                                                        36
                                                    ]
                                                },
                                                {
                                                    "token": " lookup",
                                                    "logprob": -2.528549465626578,
                                                    "bytes": [
                                                        32,
                                                        108,
                                                        111,
                                                        111,
                                                        107,
                                                        117,
                                                        112
                                                    ]
                                                },
                                                {
                                                    "token": " look",
                                                    "logprob": -2.585006985157828,
                                                    "bytes": [
                                                        32,
                                                        108,
                                                        111,
                                                        111,
                                                        107
                                                    ]
                                                },
                                                {
                                                    "token": " O",
                                                    "logprob": -2.847601208180289,
                                                    "bytes": [
                                                        32,
                                                        79
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": "-time"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": "-time",
                                            "logprob": -0.3409626178190075,
                                            "bytes": [
                                                45,
                                                116,
                                                105,
                                                109,
                                                101
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "-time",
                                                    "logprob": -0.3409626178190075,
                                                    "bytes": [
                                                        45,
                                                        116,
                                                        105,
                                                        109,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " time",
                                                    "logprob": -1.2588283709928356,
                                                    "bytes": [
                                                        32,
                                                        116,
                                                        105,
                                                        109,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": " $",
                                                    "logprob": -6.152165620748695,
                                                    "bytes": [
                                                        32,
                                                        36
                                                    ]
                                                },
                                                {
                                                    "token": " O",
                                                    "logprob": -7.610231607381996,
                                                    "bytes": [
                                                        32,
                                                        79
                                                    ]
                                                },
                                                {
                                                    "token": " lookup",
                                                    "logprob": -7.908202379171547,
                                                    "bytes": [
                                                        32,
                                                        108,
                                                        111,
                                                        111,
                                                        107,
                                                        117,
                                                        112
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": " look"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": " look",
                                            "logprob": -0.8999246499906713,
                                            "bytes": [
                                                32,
                                                108,
                                                111,
                                                111,
                                                107
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": " look",
                                                    "logprob": -0.8999246499906713,
                                                    "bytes": [
                                                        32,
                                                        108,
                                                        111,
                                                        111,
                                                        107
                                                    ]
                                                },
                                                {
                                                    "token": " lookup",
                                                    "logprob": -1.986131086147898,
                                                    "bytes": [
                                                        32,
                                                        108,
                                                        111,
                                                        111,
                                                        107,
                                                        117,
                                                        112
                                                    ]
                                                },
                                                {
                                                    "token": " access",
                                                    "logprob": -2.0309251687894996,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        99,
                                                        99,
                                                        101,
                                                        115,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " ($",
                                                    "logprob": -2.659623517788523,
                                                    "bytes": [
                                                        32,
                                                        40,
                                                        36
                                                    ]
                                                },
                                                {
                                                    "token": " searches",
                                                    "logprob": -3.3545469186674293,
                                                    "bytes": [
                                                        32,
                                                        115,
                                                        101,
                                                        97,
                                                        114,
                                                        99,
                                                        104,
                                                        101,
                                                        115
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": "ups"
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": "ups",
                                            "logprob": -0.00034106497777397363,
                                            "bytes": [
                                                117,
                                                112,
                                                115
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "ups",
                                                    "logprob": -0.00034106497777397363,
                                                    "bytes": [
                                                        117,
                                                        112,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "-ups",
                                                    "logprob": -8.479114182043203,
                                                    "bytes": [
                                                        45,
                                                        117,
                                                        112,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": ",",
                                                    "logprob": -9.967187531042226,
                                                    "bytes": [
                                                        44
                                                    ]
                                                },
                                                {
                                                    "token": "up",
                                                    "logprob": -11.105747826147207,
                                                    "bytes": [
                                                        117,
                                                        112
                                                    ]
                                                },
                                                {
                                                    "token": " and",
                                                    "logprob": -11.247834808874257,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        110,
                                                        100
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {
                                    "content": "."
                                },
                                "finish_reason": None,
                                "logprobs": {
                                    "content": [
                                        {
                                            "token": ".",
                                            "logprob": -0.7382951322007896,
                                            "bytes": [
                                                46
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": ".",
                                                    "logprob": -0.7382951322007896,
                                                    "bytes": [
                                                        46
                                                    ]
                                                },
                                                {
                                                    "token": ",",
                                                    "logprob": -1.0753789487291099,
                                                    "bytes": [
                                                        44
                                                    ]
                                                },
                                                {
                                                    "token": " and",
                                                    "logprob": -2.355888897459579,
                                                    "bytes": [
                                                        32,
                                                        97,
                                                        110,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": " for",
                                                    "logprob": -3.0731969418931726,
                                                    "bytes": [
                                                        32,
                                                        102,
                                                        111,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": " by",
                                                    "logprob": -3.77264457372911,
                                                    "bytes": [
                                                        32,
                                                        98,
                                                        121
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "refusal": None
                                }
                            }
                        ]
                    },
                    {
                        "id": "chatcmpl-3b47853e6cc4463f81c40e88",
                        "object": "chat.completion.chunk",
                        "created": 1791077997,
                        "model": "qwen3.8-flash-next",
                        "choices": [
                            {
                                "index": 0,
                                "delta": {},
                                "finish_reason": "stop",
                                "logprobs": None
                            }
                        ],
                        "usage": {
                            "prompt_tokens": 22,
                            "completion_tokens": 30,
                            "total_tokens": 52,
                            "prompt_tokens_details": {
                                "cached_tokens": 0
                            }
                        },
                        "timings": {
                            "cache_n": 0,
                            "prompt_n": 22,
                            "prompt_ms": 647.1,
                            "prompt_per_token_ms": 29.414,
                            "prompt_per_second": 34,
                            "predicted_n": 30,
                            "predicted_ms": 744.4,
                            "predicted_per_token_ms": 24.813,
                            "predicted_per_second": 40.3,
                            "draft_n": 0,
                            "draft_n_accepted": 0
                        }
                    }
                ],
                "wall_ms": 1420.115499990061,
                "captured_at": "2026-10-04T01:39:59Z"
            }
        ]
    },
    "wall_ms": 10.996999975759536,
    "lesson_view": {
        "index": 0,
        "value": 0,
        "scope": "Reproduce the selected question/rule/result panel. Other page dials are independent."
    }
}
import argparse
import copy
import hashlib
import json
import math
import os
import sys
from pathlib import Path
import urllib.error
import urllib.request

"""Small, portable calculations behind the question/rule/result panels.

Standard library only. This exact source is included in every Python download.
Inputs are the captured experiment, never an invented new model response. A knob
changes a disclosed calculation on those inputs; it does not rescore a new prompt.
"""
import itertools
import math
import statistics


def _spec(question, rule, knob, default, compare, low, high, integer=False):
    return dict(question=question, rule=rule, knob=knob, default=default,
                compare=compare, low=low, high=high, integer=integer)


LESSON_SPECS = {
    'choice': _spec('Which ticket queue gets this message?', 'Compare the three saved label scores. Heat flattens their relative weights; it adds no evidence.', 'Reweighting temperature', 1, 2, .1, 3),
    'boolean': _spec('Does this message ask to cancel?', 'Normalize the saved Yes and No scores. A number near one is a strong preference, not proof.', 'Reweighting temperature', 1, 2, .1, 3),
    'score': _spec('How serious is the outage?', 'Multiply each rubric value by its answer weight, then add. The rating comes from the whole distribution.', 'Reweighting temperature', 1, 2, .1, 3),
    'candidates': _spec('Read the failure first, or start changing things?', 'Add token logprobs along each saved path, then sum path mass inside each finite group. A length penalty changes the objective.', 'Length penalty exponent', 0, 1, 0, 1),
    'controller': _spec('May the simulated repair take its next step?', 'Keep only state-legal actions. Hold the recorded action if its relative legal weight falls below the threshold.', 'Required legal-action weight', 0, .999, 0, 1),
    'rerank': _spec('Which sources help explain cancellation?', 'Compute each source’s expected relevance separately, then keep those above the cutoff.', 'Minimum relevance', 0, .9, 0, 1),
    'graph': _spec('Which text links can coexist?', 'Search every small edge subset. Reject cycles and competing attachments, then maximize useful edge weight.', 'Edge cost / threshold', .5, .9, .01, .99),
    'scene': _spec('Which valid drawing best fits the instruction?', 'Average the three saved text probes. Optionally charge for disagreement between them; code still checks geometry.', 'Disagreement penalty', 0, 1, 0, 2),
    'wire': _spec('What did the model assign to this actual token?', 'Exponentiate its raw logprob. Sum only the reported alternatives; their top-N list may omit probability mass.', 'Visible token index (zero-based)', 0, 5, 0, 10000, True),
    'speculation': _spec('Why can a draft be rejected?', 'Compare the proposal head and target verification on the same proposed token. They are different distributions.', 'Proposal position (zero-based)', 0, 2, 0, 10000, True),
    'performance': _spec('What did each API path cost on this setup?', 'Recalculate a latency percentile from the original wall-time samples. Different output tasks remain separate.', 'Latency percentile', 50, 90, 0, 100),
    'samplers': _spec('How much did this recipe change the selected token’s weight?', 'Compare its raw target probability with its post-sampler probability. Read support and entropy from the complete native row.', 'Recorded recipe index (zero-based)', 0, 1, 0, 10000, True),
    'sampler-sandbox': _spec('Can we add heat without admitting implausible tokens?', 'Remove logits below max + log(0.05), then divide the survivors by temperature and normalize.', 'Temperature after Min-P', 1.5, .7, .1, 3),
    'tictactoe': _spec('Did a legal move give away a winnable outcome?', 'Solve the saved position by exhaustive minimax. Compare the best legal outcome with the recorded model move.', 'Recorded turn index (zero-based)', 0, 1, 0, 10000, True),
    'chess': _spec('Did the shortlist favor a mating move?', 'Add the saved label weights attached to code-checked mating moves. The separately generated UCI move uses a different prompt.', 'Shortlist temperature', 1, 3, .1, 3),
    'poker': _spec('Should this hand check or bet?', 'Average exact chip payoffs over the two possible opponent cards using the stated calling policy.', 'Opponent call-rate multiplier', 1, 0, 0, 2),
    'thermal': _spec('What happens if we replay the fan commands differently?', 'Step the disclosed thermal equation through the same loads. A fan offset is an open-loop counterfactual, not a new model policy.', 'Fan offset', 0, 20, -60, 60),
    'scheduler': _spec('How much lateness did this legal schedule cause?', 'Add job durations in the recorded order and check dependencies. Charge for finishing after the adjusted deadline.', 'Deadline shift', 0, -3, -10, 10),
    'context': _spec('Did replacing old text change the current-state answer?', 'Recalculate each saved Yes/No distribution and compare the selected wording with the original append-only prompt.', 'Context variant index (zero-based)', 0, 2, 0, 10000, True),
    'observer': _spec('Which action follows from these three semantic measurements?', 'Apply the same explicit threshold rule to every saved report: inspect, verify, finish, or ask.', 'Decision threshold', .5, .999, 0, 1),
    'calibration': _spec('Does demanding stronger answers leave enough coverage?', 'Recalculate Brier error on all six examples and accuracy only on retained examples. Empty coverage has no accuracy.', 'Required answer weight', .5, 1, .5, 1),
    'information': _spec('Which observation is worth buying?', 'Use the stated sensor likelihoods to compute both Bayesian posteriors and expected entropy reduction.', 'Test index (zero-based)', 0, 1, 0, 10000, True),
    'search': _spec('Which valid scene survives a cost penalty?', 'Subtract the chosen cost charge from each saved semantic weight. Reject invalid geometry before ranking.', 'Cost weight', .1, 1, 0, 1),
    'frontier': _spec('Would faster score transfer matter here?', 'Add assumed forward time, a transfer lower bound, and the measured selector. This is a serial cost sketch.', 'Assumed transfer GB/s', 12, 2, .1, 128),
    'research-map': _spec('What would make this research idea testable?', 'Count the disclosed implementation categories, then reveal one branch’s next gate. A proposal is not a native result.', 'Branch index (zero-based)', 0, 12, 0, 10000, True),
    'pressure': _spec('How much original mass did this boundary throw away?', 'At temperature 1 with pure masking, log Z = raw selected logprob − log(selected masked probability). Pressure is −log Z.', 'Native grammar index (zero-based)', 0, 1, 0, 10000, True),
    'circuit': _spec('Can we compute AND without assuming independence?', 'Start with four joint worlds. Optionally condition on noisy evidence of style, then add worlds for each logical operation.', 'Reliability of observing style', .5, 1, .5, 1),
    'control': _spec('Can preference change while forbidden actions stay forbidden?', 'Normalize log(base) + strength × [log(desired) − log(undesired)] inside the legal set.', 'Control strength', 0, 2, 0, 3),
    'future': _spec('Can a less likely first move have a better future?', 'Weight the root policy by exact future success raised to strength. At strength zero use the base policy.', 'Future-value strength', 0, 1, 0, 2),
    'sensitivity': _spec('Which prompt intervention moves this measurement?', 'Rebuild the central finite-difference matrix. Predict a change in hours, with load fixed at +5 points; preserve the measured holdout error.', 'Change in hours remaining', -1, -2, -2, 2),
    'counterexamples': _spec('Can equivalent algebra confuse the observer?', 'Find the equivalent pair with the largest measured log-odds distance. Evaluate its exact coefficients at the chosen integer.', 'Integer x', 2, -2, -10, 10, True),
}


def normalize_logs(logs):
    finite = [x for x in logs if math.isfinite(x)]
    if not finite:
        raise ValueError('No candidate has positive mass')
    maximum = max(finite)
    weights = [math.exp(x-maximum) if math.isfinite(x) else 0. for x in logs]
    total = math.fsum(weights)
    return [w/total for w in weights]


def weights(rows, temperature=1):
    if any(r.get('logprob') is None for r in rows):
        raise ValueError('A complete label measurement is required; missing top-N entries stay unknown')
    return normalize_logs([r['logprob']/temperature for r in rows])


def entropy(p):
    return -math.fsum(x*math.log2(x) for x in p if x)


def _pick(items, value):
    if not 0 <= value < len(items):
        raise ValueError('Index must be 0..'+str(len(items)-1))
    return items[int(value)]


def _rows(names, values):
    return [dict(label=str(n), value=float(v)) for n,v in zip(names,values)]


def _graph(edges, threshold):
    if len(edges)>12:
        raise ValueError('This exact demonstration supports at most 12 edges')
    best, score = [], 0.
    for bits in itertools.product((False,True), repeat=len(edges)):
        selected=[e for e,yes in zip(edges,bits) if yes]
        out, incoming, captions = {}, set(), set()
        good=True
        for e in selected:
            a,b=e['source'],e['target']
            if a==b:good=False;break
            if e['relation']=='caption':
                if a in captions:good=False;break
                captions.add(a)
            else:
                if a in out or b in incoming:good=False;break
                out[a]=b;incoming.add(b)
        for start in out:
            node,visited=start,set()
            while node in out:
                if node in visited:good=False;break
                visited.add(node);node=out[node]
        utility=math.fsum(e['weight']-threshold for e in selected)
        if good and utility>score:best,score=selected,utility
    return best,score


def _ttt(board, turn):
    lines=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
    for a,b,c in lines:
        if board[a]!='.' and board[a]==board[b]==board[c]:return 1 if board[a]=='X' else -1
    if '.' not in board:return 0
    values=[_ttt(board[:i]+turn+board[i+1:],'O' if turn=='X' else 'X') for i,s in enumerate(board) if s=='.']
    return (max if turn=='X' else min)(values)


def calculate_lesson(name, data, value=None):
    spec=LESSON_SPECS[name]
    v=spec['default'] if value is None else value
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not spec['low']<=v<=spec['high'] or (spec['integer'] and int(v)!=v):
        raise ValueError(f"{spec['knob']} must be {'an integer' if spec['integer'] else 'finite'} in [{spec['low']}, {spec['high']}]")
    rows=[];metrics={};note='Calculation on saved inputs; changing this setting makes no new model request.'
    summary='';unit='weight'
    if name in ('choice','boolean','score'):
        p=weights(data['rows'],v);at=max(range(len(p)),key=p.__getitem__)
        rows=_rows([r['label']+' · '+r.get('description','') for r in data['rows']],p)
        metrics=dict(winner=data['rows'][at]['label'],top_weight=p[at],entropy_bits=entropy(p))
        if name in ('boolean','score'):
            metrics['expected_value']=math.fsum(q*r['value'] for q,r in zip(p,data['rows']))
        summary=f"Answer {metrics['winner']} leads with {p[at]:.2%} of the listed-label weight."
        if name=='score':summary=f"Expected rubric value: {metrics['expected_value']:.4f} on the stated 0–1 scale."
    elif name=='candidates':
        paths=data['paths'];logs=[math.fsum(t['logprob'] for t in r['tokens'])/len(r['tokens'])**v for r in paths]
        p=normalize_logs(logs);names=list(dict.fromkeys(r['group'] for r in paths))
        values=[math.fsum(q for q,r in zip(p,paths) if r['group']==g) for g in names];rows=_rows(names,values)
        metrics=dict(winner=names[values.index(max(values))],group_weights=values)
        summary=metrics['winner']+' carries the most relative group weight.'
        note='Only these emitted token paths, with their saved terminators and no EOS. A nonzero length penalty produces preference scores, not path probability.'
    elif name=='controller':
        labels=data['measure']['rows'];p=weights(labels);legal=[i for i,r in enumerate(labels) if r['allowed']]
        mass=math.fsum(p[i] for i in legal);pick=next(i for i,r in enumerate(labels) if r['action']==data['action'])
        q=p[pick]/mass;held=q<v
        rows=_rows([labels[i]['action'] for i in legal],[p[i]/mass for i in legal])
        metrics=dict(held=held,selected_weight=q,next_state=data['state'] if held else data['next_state'])
        summary=('Hold the action.' if held else 'Apply '+data['action']+'.')+' State: '+metrics['next_state']+'.'
    elif name=='rerank':
        values=[math.fsum(q*r['value'] for q,r in zip(weights(s['measure']['rows']),s['measure']['rows'])) for s in data['sources']]
        rows=_rows([s['id'] for s in data['sources']],values);kept=[r['label'] for r in rows if r['value']>=v]
        metrics=dict(retained=kept,scores=values);summary='Retain '+(', '.join(kept) or 'no sources')+' at this cutoff.'
    elif name=='graph':
        selected,utility=_graph(data['edges'],v);rows=_rows([e['source']+' → '+e['target'] for e in selected],[e['weight']-v for e in selected]);unit='utility'
        metrics=dict(selected=[(e['source'],e['target'],e['relation']) for e in selected],utility=utility)
        summary=f'{len(selected)} compatible links, total utility {utility:.4f}.'
        note='Global code constraints select links; utility is not the probability that the document graph is correct.'
    elif name=='scene':
        valid=[c for c in data['candidates'] if c['valid']];values=[]
        for c in valid:
            p=[weights(x['measure']['rows'])[0] for x in c['vector']]
            values.append(statistics.mean(p)-v*statistics.pvariance(p))
        rows=_rows([c['name'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['name'],utilities=values)
        summary='Retain '+metrics['retained']+' among geometry-valid candidates.'
        note='These are saved text judgments. This calculation cannot see the drawing or measure visual appeal.'
    elif name=='wire':
        entry=_pick(data['entries'],v);p=math.exp(entry['logprob']);top=entry.get('top_logprobs',[])
        rows=_rows([x['token'] for x in top],[math.exp(x['logprob']) for x in top]);unit='raw probability'
        metrics=dict(token=entry['token'],raw_probability=p,reported_top_mass=math.fsum(r['value'] for r in rows))
        summary=f"Token {entry['token']!r}: raw probability {p:.6g}."
        note='This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary.'
    elif name=='speculation':
        window=data['oracle']['example_rejection'];r=_pick(window['proposal'],v)
        rows=_rows(['Draft head','Target verification'],[r['draft_probability'],math.exp(r['target_logprob'])]);unit='probability / distinct heads'
        metrics=dict(token_id=r['token_id'],target_sequence_logprob=math.fsum(x['target_logprob'] for x in window['proposal']),draft_target_logprob_gap=r['draft_logprob']-r['target_logprob'])
        summary=f"Proposal token {r['token_id']}: the two heads differ by {metrics['draft_target_logprob_gap']:.4f} log units."
        note='Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability.'
    elif name=='performance':
        values=[]
        for r in data['rows']:
            xs=sorted(x['wall_ms'] for x in r['runs']);a=(len(xs)-1)*v/100;lo=math.floor(a);hi=math.ceil(a)
            values.append(xs[lo]+(xs[hi]-xs[lo])*(a-lo))
        rows=_rows([r['name'] for r in data['rows']],values);unit='ms';metrics=dict(percentile=v,times_ms=values)
        summary=f'Percentile {v:g}, recalculated from {data["repeats"]} samples per path.'
        note='Small same-setup samples include network and API cost. JSON answers a different task; this is no universal speed ranking.'
    elif name=='samplers':
        run=_pick(data['runs'],v);token=run['tokens'][0];sample=token['strata_sampling']
        raw=math.exp(token['logprob']);post=sample['probability']
        rows=_rows(['Raw target','After recipe'],[raw,post]);unit='selected token probability'
        metrics=dict(recipe=run['name'],support=sample['support'],raw=raw,selected=post,log_weight_change=math.log(post)-token['logprob'],entropy_bits=sample['entropy']/math.log(2))
        summary=f"{run['name']}: {sample['support']} native tokens remain eligible."
        note='Recipes are separate generations. Entropy and support are full-row native measurements; a top-N slice cannot recover them.'
    elif name=='sampler-sandbox':
        cut=max(data['logits'])+math.log(.05);logs=[x/v if x>=cut else -math.inf for x in data['logits']];p=normalize_logs(logs)
        rows=_rows(data['tokens'],p);metrics=dict(support=sum(x>0 for x in p),entropy_bits=entropy(p),probabilities=p)
        summary=f"{metrics['support']} credible tokens survive; entropy {metrics['entropy_bits']:.3f} bits."
        note='All eight logits are synthetic and visible. This is exact finite-row arithmetic, not a new native receipt.'
    elif name=='tictactoe':
        f=_pick(data['frames'],v);b=f['before'];legal=[i for i,c in enumerate(b) if c=='.'];oracle={i:_ttt(b[:i]+'X'+b[i+1:],'O') for i in legal}
        regret=max(oracle.values())-oracle[f['square']];rows=_rows([str(i+1) for i in legal],list(oracle.values()));unit='X outcome: lose −1 / draw 0 / win 1'
        metrics=dict(regret=regret,square=f['square']+1,oracle=oracle);summary=f"Recorded move: square {f['square']+1}; exact outcome regret {regret}."
    elif name=='chess':
        p=weights(data['measure']['rows'],v);mass=math.fsum(q for q,m in zip(p,data['shortlist']) if m['mate'])
        rows=_rows([m['san'] for m in data['shortlist']],p);metrics=dict(mating_shortlist_weight=mass,generated_uci=data['chosen']['text'],generated_mate=data['mate'])
        summary=f'{mass:.2%} of shortlist weight favors mate; the separate UCI generation '+('mated.' if data['mate'] else 'did not mate.')
        note='The saved legal/mate flags came from python-chess. This portable calculation aggregates them; it is not a replacement chess engine.'
    elif name=='poker':
        ranks=['J','Q','K'];rates={c:min(1,max(0,r*v)) for c,r in data['call_rates'].items()};values={}
        for own in ranks:
            opponents=[c for c in ranks if c!=own];sign=lambda c:1 if ranks.index(own)>ranks.index(c) else -1
            values[own]=dict(check=statistics.mean(sign(c) for c in opponents),bet=statistics.mean((1-rates[c])+rates[c]*2*sign(c) for c in opponents))
        rows=_rows([c+' bet − check' for c in ranks],[values[c]['bet']-values[c]['check'] for c in ranks]);unit='expected chips'
        metrics=dict(values=values,call_rates=rates);summary='Bet when the bar is positive; check when it is negative.'
        note='Uniform remaining-card prior and explicitly assumed opponent policy. Answer weights are not hidden-card beliefs or equilibrium probabilities.'
    elif name=='thermal':
        t=data['frames'][0]['temperature'];temperatures=[]
        for f in data['frames']:
            fan=min(60,max(0,f['fan']+v));t=round(t+.22*f['load']-.32*fan-.04*(t-25),3);temperatures.append(t)
        rows=_rows(range(1,len(temperatures)+1),temperatures);unit='°C';metrics=dict(temperatures=temperatures,mean_error=statistics.mean(abs(t-data['target']) for t in temperatures),violations=sum(t>data['limit'] for t in temperatures))
        summary=f"Mean distance from target: {metrics['mean_error']:.2f}°C; {metrics['violations']} limit violations."
        note='Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control.'
    elif name=='scheduler':
        done=set();clock=0;late=[]
        for f in data['frames']:
            j=f['job']
            if not set(j['after'])<=done:raise ValueError('Saved schedule violates dependencies')
            clock+=j['duration'];late.append(max(0,clock-j['deadline']-v));done.add(j['id'])
        rows=_rows([f['job']['id'] for f in data['frames']],late);unit='late time units';metrics=dict(total_lateness=sum(late),finish_time=clock)
        summary=f'Total lateness {sum(late):g}; the same dependency-valid order ends at time {clock}.'
    elif name=='context':
        selected=_pick(data['runs'],v);all_weights=[weights(r['measure']['rows'])[1] for r in data['runs']];p=all_weights[int(v)]
        rows=_rows([r['name'] for r in data['runs']],all_weights);metrics=dict(variant=selected['name'],no_weight=p,delta_from_append=p-all_weights[0])
        summary=f"{selected['name']}: keep-still answer weight {p:.3%}."
        note='Saved prompt interventions, not KV tensor mutation. This calculation compares their recorded measurements.'
    elif name=='observer':
        actions=[];triples=[]
        for f in data['frames']:
            p=[weights(x['measure']['rows'])[0] for x in f['vector']];triples.append(p)
            actions.append('inspect failure' if p[0]>v else 'verify' if p[1]>v else 'finish' if p[2]>v else 'ask')
        rows=_rows(['Fault','Missing check','Verified'],triples[0]);metrics=dict(actions=actions,vectors=triples)
        summary=' → '.join(actions)+'.';note='Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability.'
    elif name=='calibration':
        p=[weights(r['measure']['rows'])[0] for r in data['rows']];truth=[r['truth'] for r in data['rows']];kept=[i for i,q in enumerate(p) if max(q,1-q)>=v]
        brier=statistics.mean((q-y)**2 for q,y in zip(p,truth));accuracy=statistics.mean(int(p[i]>=.5)==truth[i] for i in kept) if kept else None
        rows=_rows([str(i+1) for i in range(len(p))],p);metrics=dict(brier=brier,retained=len(kept),coverage=len(kept)/len(p),accuracy=accuracy)
        summary=f'{len(kept)}/{len(p)} retained; '+(f'{accuracy:.1%} correct in those cases.' if accuracy is not None else 'accuracy is undefined with zero coverage.')
        note='Six disclosed teaching examples, not a held-out calibration benchmark. Brier error still counts every example.'
    elif name=='information':
        t=_pick(data['tests'],v);prior=data['prior'];py=math.fsum(p*l for p,l in zip(prior,t['likelihood']));yes=[p*l/py for p,l in zip(prior,t['likelihood'])];no=[p*(1-l)/(1-py) for p,l in zip(prior,t['likelihood'])]
        gain=entropy(prior)-py*entropy(yes)-(1-py)*entropy(no);rows=_rows(data['faults'],yes)
        metrics=dict(test=t['name'],gain_bits=gain,gain_per_cost=gain/t['cost'],yes=yes,no=no)
        summary=t['name']+f': {gain:.3f} expected bits; {gain/t["cost"]:.3f} bits per cost unit.'
        note='Prior and likelihoods are stated synthetic sensor assumptions. Bars condition on a positive result; no test was actually purchased.'
    elif name=='search':
        valid=[c for c in data['candidates'] if c['valid']];values=[weights(c['measure']['rows'])[0]-v*c['cost']/3 for c in valid]
        rows=_rows([c['id'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['id'],utilities=values)
        summary='Retain '+metrics['retained']+' after charging for cost; invalid geometry is excluded.'
    elif name=='frontier':
        selector=sorted(r['selection_ms'] for r in data['measurements'])[len(data['measurements'])//2];transfer=data['vocabulary']*data['bytes_per_logit']/(v*1e6);total=60+transfer+selector
        rows=_rows(['Assumed forward','Transfer lower bound','Measured host selector'],[60,transfer,selector]);unit='ms'
        metrics=dict(transfer_ms=transfer,serial_ms=total,tokens_per_second=1000/total)
        summary=f'Serial estimate: {total:.3f} ms/token; {1000/total:.2f} tokens/s.'
        note='Forward time is assumed 60 ms. Selector uses the upper-middle measured sample to match the chart. Queue, prefill and network are excluded.'
    elif name=='research-map':
        branch=_pick(data['branches'],v);categories={}
        for b in data['branches']:categories[b['status']]=categories.get(b['status'],0)+1
        rows=_rows(list(categories),list(categories.values()));unit='branches';metrics=dict(branch=branch['name'],gate=branch['gate'],categories=categories)
        summary=branch['name']+': '+branch['gate'];note='This page recomputes an agenda inventory, not an experiment result. Each implemented branch links to its own evidence.'
    elif name=='pressure':
        case=_pick(data['cases'],v);r=case['rows'][0];token=r['token'];q=token['strata_sampling']['probability'];logz=token['logprob']-math.log(q)
        if logz>1e-6:raise ValueError('Pure-mask mass exceeds one')
        z=math.exp(min(0,logz));rows=_rows(['Survived','Removed'],[z,1-z]);unit='original probability mass'
        metrics=dict(grammar=case['name'],mass=z,pressure_nats=-logz,pressure_bits=-logz/math.log(2))
        summary=f"{case['name']}: {z:.4%} survives; pressure {-logz:.4f} nats."
        note='First actual prefix of this native grammar. Exact only for pure masking at temperature 1, not arbitrary sampler recipes or entire grammar languages.'
    elif name=='circuit':
        p=weights(data['cases'][0]['measurement']['rows']);weighted=[p[0]*(1-v),p[1]*(1-v),p[2]*v,p[3]*v];z=math.fsum(weighted);p=[x/z for x in weighted]
        f=p[1]+p[3];s=p[2]+p[3];rows=_rows(['Neither','Facts only','Style only','Both'],p)
        metrics=dict(F=f,S=s,AND=p[3],OR=1-p[0],F_given_S=p[3]/s if s else None,marginal_product=f*s)
        summary=f'Facts AND style: {p[3]:.2%}; multiplying the marginals would give {f*s:.2%}.'
        note='At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world.'
    elif name=='control':
        logs=[math.log(b)+v*(math.log(d)-math.log(u)) if i in data['allowed'] else -math.inf for i,(b,d,u) in enumerate(zip(data['base'],data['desired'],data['undesired']))];p=normalize_logs(logs)
        rows=_rows(list('ABCD'),p);pick=max(range(len(p)),key=p.__getitem__);metrics=dict(probabilities=p,selected=pick,forbidden_mass=math.fsum(p[i] for i in range(len(p)) if i not in data['allowed']))
        summary=f"Action {'ABCD'[pick]} leads; forbidden-action mass stays zero."
        note='Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook.'
    elif name=='future':
        root=weights(data['policy'][0]['rows']);child=weights(data['policy'][2]['rows']);h=[0,child[1]];p=normalize_logs([math.log(r)+(v*math.log(x) if x else -math.inf) if v else math.log(r) for r,x in zip(root,h)])
        rows=_rows(['A: dead end','B: viable route'],p);success=p[1]*child[1];metrics=dict(root_weights=p,exact_h=h,success_root_only=success,base_success=root[1]*child[1])
        summary=f'{p[1]:.2%} chooses B; leaving the next policy unchanged succeeds {success:.2%} of the time.'
        note='Only BB succeeds in this exact two-step toy. Conditioning both steps is different from steering only the root. No native future-value decoder is claimed.'
    elif name=='sensitivity':
        o=data['observations'];zs=[[math.log(p/(1-p)) for p in row['probabilities']] for row in o]
        matrix=[[(zs[2][i]-zs[1][i])/(2*data['epsilon'][0]),(zs[4][i]-zs[3][i])/(2*data['epsilon'][1])] for i in range(3)]
        delta=[r[0]*v+r[1]*5 for r in matrix];rows=_rows(['Urgency','Load','Damage'],delta);unit='predicted log-odds change'
        observed=[zs[6][i]-zs[0][i] for i in range(3)];held=[r[0]*-1+r[1]*5 for r in matrix]
        metrics=dict(matrix=matrix,predicted_delta=delta,holdout_residual=[a-b for a,b in zip(observed,held)])
        summary=f'Predicted urgency shift {delta[0]:+.3f}; the measured −1h/+5 holdout had error {metrics["holdout_residual"][0]:+.3f}.'
        note='The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses.'
    elif name=='counterexamples':
        nodes=data['nodes'];pairs=[]
        for i,a in enumerate(nodes):
            za=[math.log(p/(1-p)) for p in a['p_yes']]
            for j,b in enumerate(nodes[i+1:],i+1):
                if a['coefficients']!=b['coefficients']:continue
                zb=[math.log(p/(1-p)) for p in b['p_yes']];distance=math.sqrt(math.fsum((x-y)**2 for x,y in zip(za,zb)));pairs.append((distance,i,j))
        distance,i,j=max(pairs);a,b=nodes[i],nodes[j];evaluate=lambda c:sum(x*v**k for k,x in enumerate(c))
        rows=_rows([a['expression'],b['expression']],[a['p_yes'][1],b['p_yes'][1]])
        metrics=dict(left=a['expression'],right=b['expression'],margin_distance=distance,left_value=evaluate(a['coefficients']),right_value=evaluate(b['coefficients']))
        summary=f'Equal exact values at x={v:g}: {metrics["left_value"]:g}; observer distance {distance:.3f}.'
        note='Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe.'
    else:
        raise ValueError('No portable calculation for '+name)
    return dict(value=v,summary=summary,rows=rows,unit=unit,metrics=metrics,note=note)


def make_lesson(name, data):
    spec=LESSON_SPECS[name]
    try:
        first=calculate_lesson(name,data)
        compare=spec['compare']
        # An edited run can have fewer tokens/turns than the recorded default.
        lengths={'wire':len(data.get('entries',[])), 'samplers':len(data.get('runs',[])),
                 'tictactoe':len(data.get('frames',[])), 'context':len(data.get('runs',[])),
                 'information':len(data.get('tests',[])), 'research-map':len(data.get('branches',[])),
                 'pressure':len(data.get('cases',[]))}
        if name in lengths:compare=min(compare,lengths[name]-1)
        second=calculate_lesson(name,data,compare)
        context=data.get('prompt','').partition('STATE:\n')[2].partition('\nQUESTION:')[0]
        return dict(**spec,states=[first,second],input_excerpt=context[:320]+('…' if len(context)>320 else ''),scope='This panel and its Python calculation reproduce saved measurements. Other page controls are independent views.')
    except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:
        # A genuinely incomplete score or a tool-only wire response stays usable.
        # Do not turn an unavailable lesson into fabricated measurement data.
        return dict(**spec,states=[],unavailable=str(error),scope='This run has no complete inputs for this calculation. Inspect its exact request and result below.')



def mock_post(request, fixture):
    if request != fixture['request']:
        raise ValueError('No mock matches the edited request. Supply a new fixture or explicitly choose --live-url.')
    return copy.deepcopy(fixture['response'])


def live_post(base_url, request):
    if not base_url.startswith(('http://', 'https://')):
        raise ValueError('--live-url must be an http(s) Strata address')
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('STRATA_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['STRATA_API_KEY']
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    body = json.dumps(request, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base_url.rstrip('/')+'/v1/chat/completions', data=body, headers=headers)
    with opener.open(req, timeout=600) as response:
        wire = response.read().decode('utf-8')
    if request.get('stream'):
        events = [line[5:].strip() for line in wire.splitlines() if line.startswith('data:')]
        if not events or events[-1] != '[DONE]':
            raise ValueError('Stream closed without [DONE]')
        chunks = [json.loads(line) for line in events[:-1]]
        if any('error' in chunk for chunk in chunks):
            raise ValueError('Stream reported an error: '+repr(chunks))
        return {'sse_events': chunks, 'wire': wire}
    reply = json.loads(wire)
    if 'error' in reply:
        raise ValueError('Strata reported an error: '+repr(reply['error']))
    return reply


def summarize(response):
    if 'sse_events' in response:
        return str(len(response['sse_events']))+' SSE events; inspect the saved wire response'
    choice = (response.get('choices') or [{}])[0]
    message = choice.get('message', {})
    text = message.get('content') or json.dumps(message.get('tool_calls') or message, ensure_ascii=False)
    entries = (choice.get('logprobs') or {}).get('content') or []
    if entries:
        text += '\n  First visible token raw logprob: '+repr(entries[0]['logprob'])
        text += '\n  First visible token raw probability: '+format(math.exp(entries[0]['logprob']), '.7g')
    return text


def raw_tokens(response):
    if 'sse_events' in response:
        return [token for chunk in response['sse_events'] for choice in chunk.get('choices', [])
                for token in (choice.get('logprobs') or {}).get('content') or []]
    choices = response.get('choices') or []
    return ((choices[0].get('logprobs') or {}).get('content') or []) if choices else []


def print_raw_tokens(response):
    entries = raw_tokens(response)
    if not entries:
        print('No scored answer tokens returned; no raw probabilities are invented.')
    for i, token in enumerate(entries):
        lp = token['logprob']
        p = math.exp(lp)
        shown = format(p, '.9g') if p else 'underflows; use the finite logprob'
        print('  Token '+str(i)+': '+repr(token['token'])+' bytes='+repr(token['bytes'])+
              ' raw ln p='+repr(lp)+' raw p='+shown)
        sampling = token.get('strata_sampling')
        if sampling:
            print('    Final native selection weight q='+repr(sampling['probability'])+' (separate from raw p)')


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=int, default=1, help='1-based request index (default 1)')
    parser.add_argument('--all', action='store_true', help='Replay every mock in this captured run')
    parser.add_argument('--show', action='store_true', help='Print exact selected HTTP request JSON')
    parser.add_argument('--tokens', action='store_true', help='Print every original token raw logprob/probability and available native sampling weight')
    parser.add_argument('--lesson-only', action='store_true', help='Recalculate the captured question/rule/result panel without printing mocked calls')
    parser.add_argument('--value', type=float, help='Change the panel parameter within its documented bounds; offline calculation only')
    parser.add_argument('--live-url', help='Explicitly send ONE request to your compatible Strata server')
    parser.add_argument('--output', type=Path, help='Write responses and their provenance as JSON')
    args = parser.parse_args()
    if args.all and args.live_url:
        parser.error('--all is offline only; saved dependent requests are not a live adaptive controller')
    if args.live_url and (args.lesson_only or args.value is not None):
        parser.error('Lesson calculations use captured evidence. Do not mix --live-url with --lesson-only or --value.')
    calls = CAPTURED['receipt']['calls']
    print('Strata Control Lab / '+CAPTURED['experiment'])
    print('LIVE selected request' if args.live_url else 'OFFLINE MOCK / recorded responses, no inference or network')
    view = CAPTURED.get('score_view')
    if view:
        print('\nRAW LAYER: '+view['raw'])
        print('DERIVED VIEW: '+view['derived'])
        print('SCOPE: '+view['scope'])
    calculation=None
    if not args.live_url:
        spec=CAPTURED.get('lesson')
        if spec and spec.get('states'):
            knob=args.value if args.value is not None else (CAPTURED.get('lesson_view') or {}).get('value',spec['default'])
            try:calculation=calculate_lesson(CAPTURED['experiment'],CAPTURED['result'],knob)
            except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:parser.error(str(error))
            print('\nQUESTION: '+spec['question']+'\nRULE: '+spec['rule'])
            print(spec['knob']+' = '+str(knob)+f" (allowed {spec['low']}..{spec['high']})")
            print('RESULT: '+calculation['summary'])
            print('BOUNDARY: '+calculation['note'])
            print('Reproduces the selected question/rule/result panel; other page dials are independent.')
            print(json.dumps(calculation,ensure_ascii=True,indent=2))
        elif args.lesson_only or args.value is not None:
            parser.error('This captured run has no complete lesson inputs: '+str((spec or {}).get('unavailable','missing calculation')))
    if args.lesson_only:
        result=dict(mode='offline-calculation',calculation=calculation)
    elif not calls:
        if args.live_url:
            parser.error('This page has no HTTP requests: it is analytical or recorded diagnostic evidence')
        print('No HTTP request, GBNF or JSON output constraint was used by this page.')
        print('The included result is a calculation/diagnostic snapshot, not a new model answer.')
        result = dict(mode='offline-snapshot', result=CAPTURED['result'])
        print(json.dumps(result, ensure_ascii=True, indent=2))
    else:
        indexes = range(len(calls)) if args.all else [args.request-1]
        if any(i < 0 or i >= len(calls) for i in indexes):
            parser.error('Request index must be 1..'+str(len(calls)))
        results = []
        for i in indexes:
            fixture = calls[i]
            request = copy.deepcopy(fixture['request'])  # Edit here to try your own live request.
            if args.show:
                print(json.dumps(request, ensure_ascii=True, indent=2))
            response = live_post(args.live_url, request) if args.live_url else mock_post(request, fixture)
            print('Request '+str(i+1)+' / '+str(len(calls))+': '+summarize(response))
            if args.tokens:
                print_raw_tokens(response)
            results.append(dict(request=request, response=response,
                                provenance='live-request' if args.live_url else 'mocked-native-recording'))
        result = dict(mode='live' if args.live_url else 'offline-mock', calls=results)
        print('GBNF and JSON settings are in each request. Use --show to inspect them.')
        print('The saved page result is in CAPTURED["result"]; live responses do not recompute that snapshot.')
    if calculation is not None:result['calculation']=calculation
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
