# -*- coding: utf-8 -*-
"""Downloaded Strata example: Python 3 standard library; offline by default.

Windows: py strata-example.py
Ubuntu:  python3 strata-example.py
Show a request: python strata-example.py --request 1 --show
Replay all recorded calls: python strata-example.py --all
Recalculate the panel: python strata-example.py --lesson-only
Change its knob: python strata-example.py --lesson-only --value NUMBER
Try ONE request live: python strata-example.py --request 1 --live-url http://127.0.0.1:8080
An optional STRATA_API_KEY environment variable supplies authentication.

CAPTURED is inserted above this runner by the page. It contains this exact run,
with requests, GBNF/JSON settings, responses, streaming chunks and the page result.
Mock mode returns those responses; it performs no inference and opens no socket.
Live mode runs only a selected request. It does not execute tools or adapt a saved
multi-step trace to new answers. No captured API key or authorization header exists.
"""
CAPTURED = {
    "experiment": "counterexamples",
    "score_view": {
        "raw": "Each generated token carries target logprob before grammar, penalties and sampling. Raw probability is exp(logprob), with the denominator over the full target vocabulary. Every score belongs to its selected request and exact preceding token path. These instruments also inspect a pure temperature-1 grammar mask. Complete answer rows recover raw label p from native legal-set weight q times surviving mass Z; the selected token logprob below is the direct target score, not that recovered row.",
        "derived": "Semantic weights score disclosed candidates. Counterexample tests, consistency gaps and selection rules are derived comparisons on those measurements, not an independent correctness guarantee.",
        "scope": "The raw receipt stays attached to the captured request. Page dials recalculate derived views; they do not rerun the model or replace token scores. Neither model probability nor a derived weight is calibrated truth. Missing top-N alternatives stay unknown.",
        "raw_kind": "native"
    },
    "type": "result",
    "result": {
        "nodes": [
            {
                "id": 0,
                "expression": "x",
                "coefficients": [
                    0,
                    1,
                    0
                ],
                "truth": [
                    True,
                    False
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.983489532594177,
                                "logprob": -0.018047350828326234,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.016510467405823064,
                                "logprob": -4.105159777586139,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0013990666030856205,
                            "mass": 0.9986019116343346,
                            "pressure_nats": 0.0013990666030856205,
                            "pressure_bits": 0.0020184264501449927,
                            "selected_raw_logprob": -0.018047350828326234,
                            "selected_probability": 0.983489532594177,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: x\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.02726513043949044,
                                "logprob": -3.607963876407296,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9727348695605095,
                                "logprob": -0.03346093146100649,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0058172099285610235,
                            "mass": 0.9941996772757767,
                            "pressure_nats": 0.0058172099285610235,
                            "pressure_bits": 0.00839245991574503,
                            "selected_raw_logprob": -0.03346093146100649,
                            "selected_probability": 0.9727348695605095,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: x\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.983489532594177,
                    0.02726513043949044
                ],
                "z": [
                    4.0871124267578125,
                    -3.5745029449462895
                ]
            },
            {
                "id": 1,
                "expression": "((x+1)-1)",
                "coefficients": [
                    0,
                    1,
                    0
                ],
                "truth": [
                    True,
                    False
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.9433751925565599,
                                "logprob": -0.0621758325070182,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.05662480744344002,
                                "logprob": -2.8751927239865105,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0038846282444388452,
                            "mass": 0.9961229071632829,
                            "pressure_nats": 0.0038846282444388452,
                            "pressure_bits": 0.0056043339039491226,
                            "selected_raw_logprob": -0.0621758325070182,
                            "selected_probability": 0.9433751925565599,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: ((x+1)-1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.8661194637809663,
                                "logprob": -0.14820622944643053,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.13388053621903384,
                                "logprob": -2.015281195877095,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.004473798451408856,
                            "mass": 0.9955361940778086,
                            "pressure_nats": 0.004473798451408856,
                            "pressure_bits": 0.006454326839784281,
                            "selected_raw_logprob": -0.14820622944643053,
                            "selected_probability": 0.8661194637809663,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: ((x+1)-1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.9433751925565599,
                    0.8661194637809663
                ],
                "z": [
                    2.813016891479492,
                    1.8670749664306643
                ]
            },
            {
                "id": 2,
                "expression": "(x+0)",
                "coefficients": [
                    0,
                    1,
                    0
                ],
                "truth": [
                    True,
                    False
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.96086888770343,
                                "logprob": -0.04302815667137756,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.03913111229657002,
                                "logprob": -3.243948261651846,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0031108441606588558,
                            "mass": 0.9968939895014814,
                            "pressure_nats": 0.0031108441606588558,
                            "pressure_bits": 0.004487999443560921,
                            "selected_raw_logprob": -0.04302815667137756,
                            "selected_probability": 0.96086888770343,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (x+0)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.9196148999882252,
                                "logprob": -0.08816542010900705,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.08038510001177482,
                                "logprob": -2.525291579776976,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.004365136568654865,
                            "mass": 0.9956443767925691,
                            "pressure_nats": 0.004365136568654865,
                            "pressure_bits": 0.00629756088040144,
                            "selected_raw_logprob": -0.08816542010900705,
                            "selected_probability": 0.9196148999882252,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (x+0)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.96086888770343,
                    0.9196148999882252
                ],
                "z": [
                    3.2009201049804683,
                    2.4371261596679688
                ]
            },
            {
                "id": 3,
                "expression": "(1*x)",
                "coefficients": [
                    0,
                    1,
                    0
                ],
                "truth": [
                    True,
                    False
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.9284833076511865,
                                "logprob": -0.07678249167813837,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.0715166923488134,
                                "logprob": -2.640404012674232,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0025796155686101246,
                            "mass": 0.9974237087805021,
                            "pressure_nats": 0.0025796155686101246,
                            "pressure_bits": 0.0037215985882337907,
                            "selected_raw_logprob": -0.07678249167813837,
                            "selected_probability": 0.9284833076511865,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (1*x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.02012816725855873,
                                "logprob": -3.9094498101714965,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9798718327414412,
                                "logprob": -0.02414822020567617,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0038147214184285766,
                            "mass": 0.996192545388104,
                            "pressure_nats": 0.0038147214184285766,
                            "pressure_bits": 0.00550347967273982,
                            "selected_raw_logprob": -0.02414822020567617,
                            "selected_probability": 0.9798718327414412,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (1*x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.9284833076511865,
                    0.02012816725855873
                ],
                "z": [
                    2.5636215209960938,
                    -3.8853015899658203
                ]
            },
            {
                "id": 4,
                "expression": "((x-x)+x)",
                "coefficients": [
                    0,
                    1,
                    0
                ],
                "truth": [
                    True,
                    False
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.9177336719092041,
                                "logprob": -0.09032661876970118,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.0822663280907959,
                                "logprob": -2.502271961787279,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.004478570569794921,
                            "mass": 0.9955314432725686,
                            "pressure_nats": 0.004478570569794921,
                            "pressure_bits": 0.006461211551314391,
                            "selected_raw_logprob": -0.09032661876970118,
                            "selected_probability": 0.9177336719092041,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: ((x-x)+x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.8760421856632626,
                                "logprob": -0.1446531844169736,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.12395781433673735,
                                "logprob": -2.100126130583966,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.012312152361552892,
                            "mass": 0.9877633320767762,
                            "pressure_nats": 0.012312152361552892,
                            "pressure_bits": 0.017762681154681697,
                            "selected_raw_logprob": -0.1446531844169736,
                            "selected_probability": 0.8760421856632626,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: ((x-x)+x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.9177336719092041,
                    0.8760421856632626
                ],
                "z": [
                    2.4119453430175777,
                    1.9554729461669922
                ]
            },
            {
                "id": 5,
                "expression": "((2*x)-x)",
                "coefficients": [
                    0,
                    1,
                    0
                ],
                "truth": [
                    True,
                    False
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.9180902356391756,
                                "logprob": -0.09020275006068788,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.08190976436082444,
                                "logprob": -2.506880225036274,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.00474315277155693,
                            "mass": 0.9952680782137742,
                            "pressure_nats": 0.00474315277155693,
                            "pressure_bits": 0.006842922981703925,
                            "selected_raw_logprob": -0.09020275006068788,
                            "selected_probability": 0.9180902356391756,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: ((2*x)-x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.7002734594327369,
                                "logprob": -0.3661456978798634,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.29972654056726306,
                                "logprob": -1.2147460854531056,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.009861333987294385,
                            "mass": 0.9901871295309033,
                            "pressure_nats": 0.009861333987294385,
                            "pressure_bits": 0.014226897640019397,
                            "selected_raw_logprob": -0.3661456978798634,
                            "selected_probability": 0.7002734594327369,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: ((2*x)-x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.9180902356391756,
                    0.7002734594327369
                ],
                "z": [
                    2.416677474975586,
                    0.8486003875732422
                ]
            },
            {
                "id": 6,
                "expression": "(x+1)",
                "coefficients": [
                    1,
                    1,
                    0
                ],
                "truth": [
                    False,
                    False
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.013260254268451097,
                                "logprob": -4.326084727006924,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9867397457315489,
                                "logprob": -0.01644956465340751,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.003100608198283221,
                            "mass": 0.9969041937230754,
                            "pressure_nats": 0.003100608198283221,
                            "pressure_bits": 0.004473232071402867,
                            "selected_raw_logprob": -0.01644956465340751,
                            "selected_probability": 0.9867397457315489,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (x+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.03441885830307765,
                                "logprob": -3.372931095858875,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9655811416969223,
                                "logprob": -0.0388055770600466,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0037804375306257493,
                            "mass": 0.9962266993270217,
                            "pressure_nats": 0.0037804375306257493,
                            "pressure_bits": 0.005454018477824288,
                            "selected_raw_logprob": -0.0388055770600466,
                            "selected_probability": 0.9655811416969223,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (x+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.013260254268451097,
                    0.03441885830307765
                ],
                "z": [
                    -4.3096351623535165,
                    -3.3341255187988286
                ]
            },
            {
                "id": 7,
                "expression": "(x-1)",
                "coefficients": [
                    -1,
                    1,
                    0
                ],
                "truth": [
                    False,
                    False
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.013242746183094161,
                                "logprob": -4.3286264242756705,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9867572538169058,
                                "logprob": -0.01765230318192017,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.00432108993629801,
                            "mass": 0.9956882325402338,
                            "pressure_nats": 0.00432108993629801,
                            "pressure_bits": 0.006234015022332346,
                            "selected_raw_logprob": -0.01765230318192017,
                            "selected_probability": 0.9867572538169058,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (x-1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.01791452575163086,
                                "logprob": -4.026722665165341,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9820854742483692,
                                "logprob": -0.022656197880184453,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.004579264450785828,
                            "mass": 0.9954312043947025,
                            "pressure_nats": 0.004579264450785828,
                            "pressure_bits": 0.006606482114067837,
                            "selected_raw_logprob": -0.022656197880184453,
                            "selected_probability": 0.9820854742483692,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (x-1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.013242746183094161,
                    0.01791452575163086
                ],
                "z": [
                    -4.31097412109375,
                    -4.004066467285156
                ]
            },
            {
                "id": 8,
                "expression": "(x*x)",
                "coefficients": [
                    0,
                    0,
                    1
                ],
                "truth": [
                    False,
                    True
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.013960094313654652,
                                "logprob": -4.27478699080792,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9860399056863453,
                                "logprob": -0.017293018029599337,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.003234565129640923,
                            "mass": 0.9967706604404807,
                            "pressure_nats": 0.003234565129640923,
                            "pressure_bits": 0.004666491071965327,
                            "selected_raw_logprob": -0.017293018029599337,
                            "selected_probability": 0.9860399056863453,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (x*x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.9725352068735665,
                                "logprob": -0.03402818196452531,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.027464793126433525,
                                "logprob": -3.601029524737963,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0061791802603824615,
                            "mass": 0.9938398716121127,
                            "pressure_nats": 0.0061791802603824615,
                            "pressure_bits": 0.008914672718412751,
                            "selected_raw_logprob": -0.03402818196452531,
                            "selected_probability": 0.9725352068735665,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (x*x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.013960094313654652,
                    0.9725352068735665
                ],
                "z": [
                    -4.25749397277832,
                    3.5670013427734375
                ]
            },
            {
                "id": 9,
                "expression": "(((x+1)*(x-1))+1)",
                "coefficients": [
                    0,
                    0,
                    1
                ],
                "truth": [
                    False,
                    True
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.034368056350039755,
                                "logprob": -3.3876540226099476,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9656319436499603,
                                "logprob": -0.05199881020760402,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.01702628212063366,
                            "mass": 0.98311784587354,
                            "pressure_nats": 0.01702628212063366,
                            "pressure_bits": 0.024563732780214606,
                            "selected_raw_logprob": -0.05199881020760402,
                            "selected_probability": 0.9656319436499603,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (((x+1)*(x-1))+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.8270612695461484,
                                "logprob": -0.20595305839291594,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.17293873045385152,
                                "logprob": -1.7708944646429159,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.016076558203076047,
                            "mass": 0.9840519799200531,
                            "pressure_nats": 0.016076558203076047,
                            "pressure_bits": 0.023193570794140597,
                            "selected_raw_logprob": -0.20595305839291594,
                            "selected_probability": 0.8270612695461484,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: (((x+1)*(x-1))+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.034368056350039755,
                    0.8270612695461484
                ],
                "z": [
                    -3.3356552124023438,
                    1.56494140625
                ]
            },
            {
                "id": 10,
                "expression": "((x*x)+0)",
                "coefficients": [
                    0,
                    0,
                    1
                ],
                "truth": [
                    False,
                    True
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.016730303221174473,
                                "logprob": -4.094812408070743,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9832696967788256,
                                "logprob": -0.021150603871523684,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.004278768320850047,
                            "mass": 0.9957303725664282,
                            "pressure_nats": 0.004278768320850047,
                            "pressure_bits": 0.006172957837603159,
                            "selected_raw_logprob": -0.021150603871523684,
                            "selected_probability": 0.9832696967788256,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: ((x*x)+0)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.9690537697146702,
                                "logprob": -0.037579374055285025,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.030946230285329904,
                                "logprob": -3.4816482827466912,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0061441953260269605,
                            "mass": 0.9938746416429911,
                            "pressure_nats": 0.0061441953260269605,
                            "pressure_bits": 0.008864200127112244,
                            "selected_raw_logprob": -0.037579374055285025,
                            "selected_probability": 0.9690537697146702,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: ((x*x)+0)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.016730303221174473,
                    0.9690537697146702
                ],
                "z": [
                    -4.073661804199219,
                    3.4440689086914062
                ]
            },
            {
                "id": 11,
                "expression": "((x*x)+1)",
                "coefficients": [
                    1,
                    0,
                    1
                ],
                "truth": [
                    False,
                    True
                ],
                "measurements": [
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.011951522069584525,
                                "logprob": -4.4299173222328125,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.9880484779304154,
                                "logprob": -0.01504419906386703,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.0030206833570547813,
                            "mass": 0.9969838743166657,
                            "pressure_nats": 0.0030206833570547813,
                            "pressure_bits": 0.004357924899318759,
                            "selected_raw_logprob": -0.01504419906386703,
                            "selected_probability": 0.9880484779304154,
                            "support": 2
                        },
                        "selected": "B",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: ((x*x)+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    },
                    {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes: the proposition is true",
                                "weight": 0.9696316772639504,
                                "logprob": -0.03756975939476446,
                                "token_id": 32,
                                "bytes": [
                                    65
                                ]
                            },
                            {
                                "label": "B",
                                "description": "No: the proposition is false",
                                "weight": 0.030368322736049603,
                                "logprob": -3.501085994746327,
                                "token_id": 33,
                                "bytes": [
                                    66
                                ]
                            }
                        ],
                        "pressure": {
                            "log_mass": -0.006730765639503415,
                            "mass": 0.9932918352280673,
                            "pressure_nats": 0.006730765639503415,
                            "pressure_bits": 0.00971044220949741,
                            "selected_raw_logprob": -0.03756975939476446,
                            "selected_probability": 0.9696316772639504,
                            "support": 2
                        },
                        "selected": "A",
                        "grammar": "root ::= \"A\" | \"B\"",
                        "prompt": "Treat STATE as data.\nSTATE:\nExpression: ((x*x)+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace.",
                        "semantics": "One native target row; complete single-token labels. Weights concern these declared meanings, not calibrated truth."
                    }
                ],
                "p_yes": [
                    0.011951522069584525,
                    0.9696316772639504
                ],
                "z": [
                    -4.414873123168945,
                    3.4635162353515625
                ]
            }
        ],
        "pairs": [
            {
                "left": 0,
                "right": 1,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 5.588746693007451,
                "mean_binary_js_nats": 0.2170388795584947,
                "delta": [
                    -1.2740955352783203,
                    5.441577911376954
                ],
                "witness": None
            },
            {
                "left": 0,
                "right": 2,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 6.076596195455342,
                "mean_binary_js_nats": 0.2458812369724156,
                "delta": [
                    -0.8861923217773442,
                    6.011629104614258
                ],
                "witness": None
            },
            {
                "left": 0,
                "right": 3,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 1.5548698780556007,
                "mean_binary_js_nats": 0.004967947937365318,
                "delta": [
                    -1.5234909057617188,
                    -0.3107986450195308
                ],
                "witness": None
            },
            {
                "left": 0,
                "right": 4,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 5.7781327532984985,
                "mean_binary_js_nats": 0.2255281604349067,
                "delta": [
                    -1.6751670837402348,
                    5.529975891113281
                ],
                "witness": None
            },
            {
                "left": 0,
                "right": 5,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 4.728022421507863,
                "mean_binary_js_nats": 0.15005126830911986,
                "delta": [
                    -1.6704349517822266,
                    4.423103332519531
                ],
                "witness": None
            },
            {
                "left": 0,
                "right": 6,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 8.400187580182253,
                "mean_binary_js_nats": 0.30802213015288,
                "delta": [
                    -8.396747589111328,
                    0.24037742614746094
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 0,
                "right": 7,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 8.409065494151509,
                "mean_binary_js_nats": 0.30818298237753855,
                "delta": [
                    -8.398086547851562,
                    -0.42956352233886674
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": -1
                }
            },
            {
                "left": 0,
                "right": 8,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 10.983330071280687,
                "mean_binary_js_nats": 0.5910103301714597,
                "delta": [
                    -8.344606399536133,
                    7.141504287719727
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 0,
                "right": 9,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 9.028364617360483,
                "mean_binary_js_nats": 0.4829034725023721,
                "delta": [
                    -7.422767639160156,
                    5.139444351196289
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 0,
                "right": 10,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 10.763762674517103,
                "mean_binary_js_nats": 0.5850755327549497,
                "delta": [
                    -8.160774230957031,
                    7.018571853637695
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 0,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 11.037095282428426,
                "mean_binary_js_nats": 0.5906296837971667,
                "delta": [
                    -8.501985549926758,
                    7.038019180297852
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 1,
                "right": 2,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 0.689512339233794,
                "mean_binary_js_nats": 0.002309493514018795,
                "delta": [
                    0.3879032135009761,
                    0.5700511932373045
                ],
                "witness": None
            },
            {
                "left": 1,
                "right": 3,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 5.757780309928335,
                "mean_binary_js_nats": 0.22050457576319057,
                "delta": [
                    -0.24939537048339844,
                    -5.752376556396484
                ],
                "witness": None
            },
            {
                "left": 1,
                "right": 4,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 0.41069768663470957,
                "mean_binary_js_nats": 0.0006941082700267077,
                "delta": [
                    -0.4010715484619145,
                    0.0883979797363279
                ],
                "witness": None
            },
            {
                "left": 1,
                "right": 5,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 1.0928748331137743,
                "mean_binary_js_nats": 0.010956800565505378,
                "delta": [
                    -0.39633941650390625,
                    -1.018474578857422
                ],
                "witness": None
            },
            {
                "left": 1,
                "right": 6,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 8.819561143703416,
                "mean_binary_js_nats": 0.4823114316107997,
                "delta": [
                    -7.122652053833009,
                    -5.201200485229493
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 1,
                "right": 7,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 9.231551856644634,
                "mean_binary_js_nats": 0.4964310750049621,
                "delta": [
                    -7.123991012573242,
                    -5.87114143371582
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": -1
                }
            },
            {
                "left": 1,
                "right": 8,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.271992406938668,
                "mean_binary_js_nats": 0.28367682614435286,
                "delta": [
                    -7.0705108642578125,
                    1.6999263763427732
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 1,
                "right": 9,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.156090750569076,
                "mean_binary_js_nats": 0.25538801345897205,
                "delta": [
                    -6.148672103881836,
                    -0.3021335601806643
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 1,
                "right": 10,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.064931234728482,
                "mean_binary_js_nats": 0.27990864885173555,
                "delta": [
                    -6.886678695678711,
                    1.576993942260742
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 1,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.402095567403082,
                "mean_binary_js_nats": 0.28501744494259407,
                "delta": [
                    -7.2278900146484375,
                    1.5964412689208982
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 2,
                "right": 3,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 6.354466313899843,
                "mean_binary_js_nats": 0.25237550148777516,
                "delta": [
                    -0.6372985839843746,
                    -6.322427749633789
                ],
                "witness": None
            },
            {
                "left": 2,
                "right": 4,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 0.9243760020090402,
                "mean_binary_js_nats": 0.0033847159472408317,
                "delta": [
                    -0.7889747619628906,
                    -0.48165321350097656
                ],
                "witness": None
            },
            {
                "left": 2,
                "right": 5,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 1.7715672810610728,
                "mean_binary_js_nats": 0.02261969026582497,
                "delta": [
                    -0.7842426300048824,
                    -1.5885257720947266
                ],
                "witness": None
            },
            {
                "left": 2,
                "right": 6,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 9.471841761763342,
                "mean_binary_js_nats": 0.5261615420369147,
                "delta": [
                    -7.510555267333984,
                    -5.771251678466797
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 2,
                "right": 7,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 9.895328055261356,
                "mean_binary_js_nats": 0.5407258250180959,
                "delta": [
                    -7.511894226074219,
                    -6.441192626953125
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": -1
                }
            },
            {
                "left": 2,
                "right": 8,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.543511018399065,
                "mean_binary_js_nats": 0.29032423327252754,
                "delta": [
                    -7.458414077758789,
                    1.1298751831054688
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 2,
                "right": 9,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.594507041766881,
                "mean_binary_js_nats": 0.2728112326256236,
                "delta": [
                    -6.5365753173828125,
                    -0.8721847534179688
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 2,
                "right": 10,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.343941424955354,
                "mean_binary_js_nats": 0.28690279474740515,
                "delta": [
                    -7.2745819091796875,
                    1.0069427490234375
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 2,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.684645930775747,
                "mean_binary_js_nats": 0.2919924751558056,
                "delta": [
                    -7.615793228149414,
                    1.0263900756835938
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 3,
                "right": 4,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 5.842743605952912,
                "mean_binary_js_nats": 0.2256567340911755,
                "delta": [
                    -0.15167617797851607,
                    5.8407745361328125
                ],
                "witness": None
            },
            {
                "left": 3,
                "right": 5,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 4.73618205790372,
                "mean_binary_js_nats": 0.14956972610113328,
                "delta": [
                    -0.1469440460205078,
                    4.7339019775390625
                ],
                "witness": None
            },
            {
                "left": 3,
                "right": 6,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.89532105827112,
                "mean_binary_js_nats": 0.26420117889786476,
                "delta": [
                    -6.87325668334961,
                    0.5511760711669917
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 3,
                "right": 7,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.875621451063558,
                "mean_binary_js_nats": 0.2637493289867961,
                "delta": [
                    -6.874595642089844,
                    -0.11876487731933594
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": -1
                }
            },
            {
                "left": 3,
                "right": 8,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 10.10269447131425,
                "mean_binary_js_nats": 0.5534571923691862,
                "delta": [
                    -6.821115493774414,
                    7.452302932739258
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 3,
                "right": 9,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 8.031601004470762,
                "mean_binary_js_nats": 0.4453888688858358,
                "delta": [
                    -5.8992767333984375,
                    5.45024299621582
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 3,
                "right": 10,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 9.8880332647854,
                "mean_binary_js_nats": 0.5475862424660314,
                "delta": [
                    -6.6372833251953125,
                    7.329370498657227
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 3,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 10.134323407526654,
                "mean_binary_js_nats": 0.553010875109285,
                "delta": [
                    -6.978494644165039,
                    7.348817825317383
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 4,
                "right": 5,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 1.1068826740177762,
                "mean_binary_js_nats": 0.011851309892598588,
                "delta": [
                    0.004732131958008257,
                    -1.10687255859375
                ],
                "witness": None
            },
            {
                "left": 4,
                "right": 6,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 8.553332473998278,
                "mean_binary_js_nats": 0.47012756459892585,
                "delta": [
                    -6.721580505371094,
                    -5.28959846496582
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 4,
                "right": 7,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 8.984083489227853,
                "mean_binary_js_nats": 0.48432974321077465,
                "delta": [
                    -6.722919464111328,
                    -5.959539413452148
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": -1
                }
            },
            {
                "left": 4,
                "right": 8,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.861373372740548,
                "mean_binary_js_nats": 0.264911029589123,
                "delta": [
                    -6.669439315795898,
                    1.6115283966064453
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 4,
                "right": 9,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 5.760852977496764,
                "mean_binary_js_nats": 0.23872002606739934,
                "delta": [
                    -5.747600555419922,
                    -0.3905315399169922
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 4,
                "right": 10,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.654248117381376,
                "mean_binary_js_nats": 0.26123780101283656,
                "delta": [
                    -6.485607147216797,
                    1.488595962524414
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 4,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.991397924043512,
                "mean_binary_js_nats": 0.26627537368319665,
                "delta": [
                    -6.826818466186523,
                    1.5080432891845703
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 5,
                "right": 6,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.9207624445459315,
                "mean_binary_js_nats": 0.3955787317122037,
                "delta": [
                    -6.7263126373291025,
                    -4.18272590637207
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 5,
                "right": 7,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 8.295159528444017,
                "mean_binary_js_nats": 0.40827400242362394,
                "delta": [
                    -6.727651596069336,
                    -4.852666854858398
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": -1
                }
            },
            {
                "left": 5,
                "right": 8,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.206543434077589,
                "mean_binary_js_nats": 0.2948729314904799,
                "delta": [
                    -6.674171447753906,
                    2.7184009552001953
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 5,
                "right": 9,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 5.7967642526943814,
                "mean_binary_js_nats": 0.24337376665265728,
                "delta": [
                    -5.75233268737793,
                    0.7163410186767578
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 5,
                "right": 10,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.990061573613971,
                "mean_binary_js_nats": 0.29044689035404186,
                "delta": [
                    -6.490339279174805,
                    2.595468521118164
                ],
                "witness": {
                    "x": -1,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 5,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.314907276648906,
                "mean_binary_js_nats": 0.2956094839335106,
                "delta": [
                    -6.831550598144531,
                    2.6149158477783203
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 6,
                "right": 7,
                "equivalent": False,
                "same_probe_truth": True,
                "margin_distance": 0.669942286521211,
                "mean_binary_js_nats": 0.0006793415428827742,
                "delta": [
                    -0.0013389587402334868,
                    -0.6699409484863277
                ],
                "witness": {
                    "x": 0,
                    "left": 1,
                    "right": -1
                }
            },
            {
                "left": 6,
                "right": 8,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.901323834103468,
                "mean_binary_js_nats": 0.27766430858708313,
                "delta": [
                    0.0521411895751962,
                    6.901126861572266
                ],
                "witness": {
                    "x": 0,
                    "left": 1,
                    "right": 0
                }
            },
            {
                "left": 6,
                "right": 9,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 4.994946814432989,
                "mean_binary_js_nats": 0.19042632307696863,
                "delta": [
                    0.9739799499511728,
                    4.899066925048828
                ],
                "witness": {
                    "x": 0,
                    "left": 1,
                    "right": 0
                }
            },
            {
                "left": 6,
                "right": 10,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.782300724873402,
                "mean_binary_js_nats": 0.2746721243315439,
                "delta": [
                    0.23597335815429776,
                    6.778194427490234
                ],
                "witness": {
                    "x": 0,
                    "left": 1,
                    "right": 0
                }
            },
            {
                "left": 6,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 6.79845632817961,
                "mean_binary_js_nats": 0.2751275662770123,
                "delta": [
                    -0.1052379608154288,
                    6.797641754150391
                ],
                "witness": {
                    "x": -1,
                    "left": 0,
                    "right": 2
                }
            },
            {
                "left": 7,
                "right": 8,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.57125669296513,
                "mean_binary_js_nats": 0.2926472252666921,
                "delta": [
                    0.05348014831542969,
                    7.571067810058594
                ],
                "witness": {
                    "x": 0,
                    "left": -1,
                    "right": 0
                }
            },
            {
                "left": 7,
                "right": 9,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 5.6537682716173965,
                "mean_binary_js_nats": 0.2042024197491477,
                "delta": [
                    0.9753189086914062,
                    5.569007873535156
                ],
                "witness": {
                    "x": 0,
                    "left": -1,
                    "right": 0
                }
            },
            {
                "left": 7,
                "right": 10,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.451915036728705,
                "mean_binary_js_nats": 0.28962674115814774,
                "delta": [
                    0.23731231689453125,
                    7.4481353759765625
                ],
                "witness": {
                    "x": 0,
                    "left": -1,
                    "right": 0
                }
            },
            {
                "left": 7,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": False,
                "margin_distance": 7.468305458626564,
                "mean_binary_js_nats": 0.29008618172474354,
                "delta": [
                    -0.10389900207519531,
                    7.467582702636719
                ],
                "witness": {
                    "x": 0,
                    "left": -1,
                    "right": 1
                }
            },
            {
                "left": 8,
                "right": 9,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 2.2040940745720787,
                "mean_binary_js_nats": 0.017318624283300135,
                "delta": [
                    0.9218387603759766,
                    -2.0020599365234375
                ],
                "witness": None
            },
            {
                "left": 8,
                "right": 10,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 0.221148478524787,
                "mean_binary_js_nats": 0.00005851906851328661,
                "delta": [
                    0.18383216857910156,
                    -0.12293243408203125
                ],
                "witness": None
            },
            {
                "left": 8,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": True,
                "margin_distance": 0.1883543586854097,
                "mean_binary_js_nats": 0.00003850896141993889,
                "delta": [
                    -0.157379150390625,
                    -0.103485107421875
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 9,
                "right": 10,
                "equivalent": True,
                "same_probe_truth": True,
                "margin_distance": 2.018854600997139,
                "mean_binary_js_nats": 0.01582903920855033,
                "delta": [
                    -0.738006591796875,
                    1.8791275024414062
                ],
                "witness": None
            },
            {
                "left": 9,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": True,
                "margin_distance": 2.183872175887924,
                "mean_binary_js_nats": 0.016663446585532954,
                "delta": [
                    -1.0792179107666016,
                    1.8985748291015625
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            },
            {
                "left": 10,
                "right": 11,
                "equivalent": False,
                "same_probe_truth": True,
                "margin_distance": 0.34176506946627433,
                "mean_binary_js_nats": 0.00010214236379084811,
                "delta": [
                    -0.34121131896972656,
                    0.01944732666015625
                ],
                "witness": {
                    "x": 0,
                    "left": 0,
                    "right": 1
                }
            }
        ],
        "edges": [
            {
                "left": 0,
                "right": 1,
                "operation": "add and subtract one",
                "equivalent": True
            },
            {
                "left": 0,
                "right": 2,
                "operation": "add zero",
                "equivalent": True
            },
            {
                "left": 0,
                "right": 3,
                "operation": "multiply by one",
                "equivalent": True
            },
            {
                "left": 0,
                "right": 4,
                "operation": "insert cancelling x",
                "equivalent": True
            },
            {
                "left": 0,
                "right": 5,
                "operation": "double then subtract x",
                "equivalent": True
            },
            {
                "left": 0,
                "right": 6,
                "operation": "add one",
                "equivalent": False
            },
            {
                "left": 0,
                "right": 7,
                "operation": "subtract one",
                "equivalent": False
            },
            {
                "left": 8,
                "right": 9,
                "operation": "factor then restore one",
                "equivalent": True
            },
            {
                "left": 8,
                "right": 10,
                "operation": "add zero",
                "equivalent": True
            },
            {
                "left": 8,
                "right": 11,
                "operation": "add one",
                "equivalent": False
            },
            {
                "left": 0,
                "right": 8,
                "operation": "square",
                "equivalent": False
            }
        ],
        "probes": [
            "Is this expression equal to x for every integer x?",
            "Is this expression nonnegative for every integer x?"
        ],
        "rankings": {
            "equivalent": [
                {
                    "left": 2,
                    "right": 3,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 6.354466313899843,
                    "mean_binary_js_nats": 0.25237550148777516,
                    "delta": [
                        -0.6372985839843746,
                        -6.322427749633789
                    ],
                    "witness": None
                },
                {
                    "left": 0,
                    "right": 2,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 6.076596195455342,
                    "mean_binary_js_nats": 0.2458812369724156,
                    "delta": [
                        -0.8861923217773442,
                        6.011629104614258
                    ],
                    "witness": None
                },
                {
                    "left": 3,
                    "right": 4,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 5.842743605952912,
                    "mean_binary_js_nats": 0.2256567340911755,
                    "delta": [
                        -0.15167617797851607,
                        5.8407745361328125
                    ],
                    "witness": None
                },
                {
                    "left": 0,
                    "right": 4,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 5.7781327532984985,
                    "mean_binary_js_nats": 0.2255281604349067,
                    "delta": [
                        -1.6751670837402348,
                        5.529975891113281
                    ],
                    "witness": None
                },
                {
                    "left": 1,
                    "right": 3,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 5.757780309928335,
                    "mean_binary_js_nats": 0.22050457576319057,
                    "delta": [
                        -0.24939537048339844,
                        -5.752376556396484
                    ],
                    "witness": None
                },
                {
                    "left": 0,
                    "right": 1,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 5.588746693007451,
                    "mean_binary_js_nats": 0.2170388795584947,
                    "delta": [
                        -1.2740955352783203,
                        5.441577911376954
                    ],
                    "witness": None
                },
                {
                    "left": 3,
                    "right": 5,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 4.73618205790372,
                    "mean_binary_js_nats": 0.14956972610113328,
                    "delta": [
                        -0.1469440460205078,
                        4.7339019775390625
                    ],
                    "witness": None
                },
                {
                    "left": 0,
                    "right": 5,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 4.728022421507863,
                    "mean_binary_js_nats": 0.15005126830911986,
                    "delta": [
                        -1.6704349517822266,
                        4.423103332519531
                    ],
                    "witness": None
                },
                {
                    "left": 8,
                    "right": 9,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 2.2040940745720787,
                    "mean_binary_js_nats": 0.017318624283300135,
                    "delta": [
                        0.9218387603759766,
                        -2.0020599365234375
                    ],
                    "witness": None
                },
                {
                    "left": 9,
                    "right": 10,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 2.018854600997139,
                    "mean_binary_js_nats": 0.01582903920855033,
                    "delta": [
                        -0.738006591796875,
                        1.8791275024414062
                    ],
                    "witness": None
                },
                {
                    "left": 2,
                    "right": 5,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 1.7715672810610728,
                    "mean_binary_js_nats": 0.02261969026582497,
                    "delta": [
                        -0.7842426300048824,
                        -1.5885257720947266
                    ],
                    "witness": None
                },
                {
                    "left": 0,
                    "right": 3,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 1.5548698780556007,
                    "mean_binary_js_nats": 0.004967947937365318,
                    "delta": [
                        -1.5234909057617188,
                        -0.3107986450195308
                    ],
                    "witness": None
                },
                {
                    "left": 4,
                    "right": 5,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 1.1068826740177762,
                    "mean_binary_js_nats": 0.011851309892598588,
                    "delta": [
                        0.004732131958008257,
                        -1.10687255859375
                    ],
                    "witness": None
                },
                {
                    "left": 1,
                    "right": 5,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 1.0928748331137743,
                    "mean_binary_js_nats": 0.010956800565505378,
                    "delta": [
                        -0.39633941650390625,
                        -1.018474578857422
                    ],
                    "witness": None
                },
                {
                    "left": 2,
                    "right": 4,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 0.9243760020090402,
                    "mean_binary_js_nats": 0.0033847159472408317,
                    "delta": [
                        -0.7889747619628906,
                        -0.48165321350097656
                    ],
                    "witness": None
                },
                {
                    "left": 1,
                    "right": 2,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 0.689512339233794,
                    "mean_binary_js_nats": 0.002309493514018795,
                    "delta": [
                        0.3879032135009761,
                        0.5700511932373045
                    ],
                    "witness": None
                },
                {
                    "left": 1,
                    "right": 4,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 0.41069768663470957,
                    "mean_binary_js_nats": 0.0006941082700267077,
                    "delta": [
                        -0.4010715484619145,
                        0.0883979797363279
                    ],
                    "witness": None
                },
                {
                    "left": 8,
                    "right": 10,
                    "equivalent": True,
                    "same_probe_truth": True,
                    "margin_distance": 0.221148478524787,
                    "mean_binary_js_nats": 0.00005851906851328661,
                    "delta": [
                        0.18383216857910156,
                        -0.12293243408203125
                    ],
                    "witness": None
                }
            ],
            "distinct": [
                {
                    "left": 6,
                    "right": 9,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 4.994946814432989,
                    "mean_binary_js_nats": 0.19042632307696863,
                    "delta": [
                        0.9739799499511728,
                        4.899066925048828
                    ],
                    "witness": {
                        "x": 0,
                        "left": 1,
                        "right": 0
                    }
                },
                {
                    "left": 7,
                    "right": 9,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 5.6537682716173965,
                    "mean_binary_js_nats": 0.2042024197491477,
                    "delta": [
                        0.9753189086914062,
                        5.569007873535156
                    ],
                    "witness": {
                        "x": 0,
                        "left": -1,
                        "right": 0
                    }
                },
                {
                    "left": 4,
                    "right": 9,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 5.760852977496764,
                    "mean_binary_js_nats": 0.23872002606739934,
                    "delta": [
                        -5.747600555419922,
                        -0.3905315399169922
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 5,
                    "right": 9,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 5.7967642526943814,
                    "mean_binary_js_nats": 0.24337376665265728,
                    "delta": [
                        -5.75233268737793,
                        0.7163410186767578
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 1,
                    "right": 9,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.156090750569076,
                    "mean_binary_js_nats": 0.25538801345897205,
                    "delta": [
                        -6.148672103881836,
                        -0.3021335601806643
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 2,
                    "right": 9,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.594507041766881,
                    "mean_binary_js_nats": 0.2728112326256236,
                    "delta": [
                        -6.5365753173828125,
                        -0.8721847534179688
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 4,
                    "right": 10,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.654248117381376,
                    "mean_binary_js_nats": 0.26123780101283656,
                    "delta": [
                        -6.485607147216797,
                        1.488595962524414
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 6,
                    "right": 10,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.782300724873402,
                    "mean_binary_js_nats": 0.2746721243315439,
                    "delta": [
                        0.23597335815429776,
                        6.778194427490234
                    ],
                    "witness": {
                        "x": 0,
                        "left": 1,
                        "right": 0
                    }
                },
                {
                    "left": 6,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.79845632817961,
                    "mean_binary_js_nats": 0.2751275662770123,
                    "delta": [
                        -0.1052379608154288,
                        6.797641754150391
                    ],
                    "witness": {
                        "x": -1,
                        "left": 0,
                        "right": 2
                    }
                },
                {
                    "left": 4,
                    "right": 8,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.861373372740548,
                    "mean_binary_js_nats": 0.264911029589123,
                    "delta": [
                        -6.669439315795898,
                        1.6115283966064453
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 3,
                    "right": 7,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.875621451063558,
                    "mean_binary_js_nats": 0.2637493289867961,
                    "delta": [
                        -6.874595642089844,
                        -0.11876487731933594
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": -1
                    }
                },
                {
                    "left": 3,
                    "right": 6,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.89532105827112,
                    "mean_binary_js_nats": 0.26420117889786476,
                    "delta": [
                        -6.87325668334961,
                        0.5511760711669917
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 6,
                    "right": 8,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.901323834103468,
                    "mean_binary_js_nats": 0.27766430858708313,
                    "delta": [
                        0.0521411895751962,
                        6.901126861572266
                    ],
                    "witness": {
                        "x": 0,
                        "left": 1,
                        "right": 0
                    }
                },
                {
                    "left": 5,
                    "right": 10,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.990061573613971,
                    "mean_binary_js_nats": 0.29044689035404186,
                    "delta": [
                        -6.490339279174805,
                        2.595468521118164
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 4,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 6.991397924043512,
                    "mean_binary_js_nats": 0.26627537368319665,
                    "delta": [
                        -6.826818466186523,
                        1.5080432891845703
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 1,
                    "right": 10,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.064931234728482,
                    "mean_binary_js_nats": 0.27990864885173555,
                    "delta": [
                        -6.886678695678711,
                        1.576993942260742
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 5,
                    "right": 8,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.206543434077589,
                    "mean_binary_js_nats": 0.2948729314904799,
                    "delta": [
                        -6.674171447753906,
                        2.7184009552001953
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 1,
                    "right": 8,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.271992406938668,
                    "mean_binary_js_nats": 0.28367682614435286,
                    "delta": [
                        -7.0705108642578125,
                        1.6999263763427732
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 5,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.314907276648906,
                    "mean_binary_js_nats": 0.2956094839335106,
                    "delta": [
                        -6.831550598144531,
                        2.6149158477783203
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 2,
                    "right": 10,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.343941424955354,
                    "mean_binary_js_nats": 0.28690279474740515,
                    "delta": [
                        -7.2745819091796875,
                        1.0069427490234375
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 1,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.402095567403082,
                    "mean_binary_js_nats": 0.28501744494259407,
                    "delta": [
                        -7.2278900146484375,
                        1.5964412689208982
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 7,
                    "right": 10,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.451915036728705,
                    "mean_binary_js_nats": 0.28962674115814774,
                    "delta": [
                        0.23731231689453125,
                        7.4481353759765625
                    ],
                    "witness": {
                        "x": 0,
                        "left": -1,
                        "right": 0
                    }
                },
                {
                    "left": 7,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.468305458626564,
                    "mean_binary_js_nats": 0.29008618172474354,
                    "delta": [
                        -0.10389900207519531,
                        7.467582702636719
                    ],
                    "witness": {
                        "x": 0,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 2,
                    "right": 8,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.543511018399065,
                    "mean_binary_js_nats": 0.29032423327252754,
                    "delta": [
                        -7.458414077758789,
                        1.1298751831054688
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 7,
                    "right": 8,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.57125669296513,
                    "mean_binary_js_nats": 0.2926472252666921,
                    "delta": [
                        0.05348014831542969,
                        7.571067810058594
                    ],
                    "witness": {
                        "x": 0,
                        "left": -1,
                        "right": 0
                    }
                },
                {
                    "left": 2,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.684645930775747,
                    "mean_binary_js_nats": 0.2919924751558056,
                    "delta": [
                        -7.615793228149414,
                        1.0263900756835938
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 5,
                    "right": 6,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 7.9207624445459315,
                    "mean_binary_js_nats": 0.3955787317122037,
                    "delta": [
                        -6.7263126373291025,
                        -4.18272590637207
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 3,
                    "right": 9,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 8.031601004470762,
                    "mean_binary_js_nats": 0.4453888688858358,
                    "delta": [
                        -5.8992767333984375,
                        5.45024299621582
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 5,
                    "right": 7,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 8.295159528444017,
                    "mean_binary_js_nats": 0.40827400242362394,
                    "delta": [
                        -6.727651596069336,
                        -4.852666854858398
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": -1
                    }
                },
                {
                    "left": 0,
                    "right": 6,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 8.400187580182253,
                    "mean_binary_js_nats": 0.30802213015288,
                    "delta": [
                        -8.396747589111328,
                        0.24037742614746094
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 0,
                    "right": 7,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 8.409065494151509,
                    "mean_binary_js_nats": 0.30818298237753855,
                    "delta": [
                        -8.398086547851562,
                        -0.42956352233886674
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": -1
                    }
                },
                {
                    "left": 4,
                    "right": 6,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 8.553332473998278,
                    "mean_binary_js_nats": 0.47012756459892585,
                    "delta": [
                        -6.721580505371094,
                        -5.28959846496582
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 1,
                    "right": 6,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 8.819561143703416,
                    "mean_binary_js_nats": 0.4823114316107997,
                    "delta": [
                        -7.122652053833009,
                        -5.201200485229493
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 4,
                    "right": 7,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 8.984083489227853,
                    "mean_binary_js_nats": 0.48432974321077465,
                    "delta": [
                        -6.722919464111328,
                        -5.959539413452148
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": -1
                    }
                },
                {
                    "left": 0,
                    "right": 9,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 9.028364617360483,
                    "mean_binary_js_nats": 0.4829034725023721,
                    "delta": [
                        -7.422767639160156,
                        5.139444351196289
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 1,
                    "right": 7,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 9.231551856644634,
                    "mean_binary_js_nats": 0.4964310750049621,
                    "delta": [
                        -7.123991012573242,
                        -5.87114143371582
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": -1
                    }
                },
                {
                    "left": 2,
                    "right": 6,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 9.471841761763342,
                    "mean_binary_js_nats": 0.5261615420369147,
                    "delta": [
                        -7.510555267333984,
                        -5.771251678466797
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 3,
                    "right": 10,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 9.8880332647854,
                    "mean_binary_js_nats": 0.5475862424660314,
                    "delta": [
                        -6.6372833251953125,
                        7.329370498657227
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 2,
                    "right": 7,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 9.895328055261356,
                    "mean_binary_js_nats": 0.5407258250180959,
                    "delta": [
                        -7.511894226074219,
                        -6.441192626953125
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": -1
                    }
                },
                {
                    "left": 3,
                    "right": 8,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 10.10269447131425,
                    "mean_binary_js_nats": 0.5534571923691862,
                    "delta": [
                        -6.821115493774414,
                        7.452302932739258
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 3,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 10.134323407526654,
                    "mean_binary_js_nats": 0.553010875109285,
                    "delta": [
                        -6.978494644165039,
                        7.348817825317383
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 0,
                    "right": 10,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 10.763762674517103,
                    "mean_binary_js_nats": 0.5850755327549497,
                    "delta": [
                        -8.160774230957031,
                        7.018571853637695
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 0,
                    "right": 8,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 10.983330071280687,
                    "mean_binary_js_nats": 0.5910103301714597,
                    "delta": [
                        -8.344606399536133,
                        7.141504287719727
                    ],
                    "witness": {
                        "x": -1,
                        "left": -1,
                        "right": 1
                    }
                },
                {
                    "left": 0,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": False,
                    "margin_distance": 11.037095282428426,
                    "mean_binary_js_nats": 0.5906296837971667,
                    "delta": [
                        -8.501985549926758,
                        7.038019180297852
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                }
            ],
            "collision": [
                {
                    "left": 8,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": True,
                    "margin_distance": 0.1883543586854097,
                    "mean_binary_js_nats": 0.00003850896141993889,
                    "delta": [
                        -0.157379150390625,
                        -0.103485107421875
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 10,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": True,
                    "margin_distance": 0.34176506946627433,
                    "mean_binary_js_nats": 0.00010214236379084811,
                    "delta": [
                        -0.34121131896972656,
                        0.01944732666015625
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                },
                {
                    "left": 6,
                    "right": 7,
                    "equivalent": False,
                    "same_probe_truth": True,
                    "margin_distance": 0.669942286521211,
                    "mean_binary_js_nats": 0.0006793415428827742,
                    "delta": [
                        -0.0013389587402334868,
                        -0.6699409484863277
                    ],
                    "witness": {
                        "x": 0,
                        "left": 1,
                        "right": -1
                    }
                },
                {
                    "left": 9,
                    "right": 11,
                    "equivalent": False,
                    "same_probe_truth": True,
                    "margin_distance": 2.183872175887924,
                    "mean_binary_js_nats": 0.016663446585532954,
                    "delta": [
                        -1.0792179107666016,
                        1.8985748291015625
                    ],
                    "witness": {
                        "x": 0,
                        "left": 0,
                        "right": 1
                    }
                }
            ]
        },
        "generated": {
            "expression": "(1*x)",
            "coefficients": [
                0,
                1,
                0
            ],
            "grammar": "root ::= \"x\" | \"((x+1)-1)\" | \"(x+0)\" | \"(1*x)\" | \"((x-x)+x)\" | \"((2*x)-x)\" | \"(x+1)\" | \"(x-1)\" | \"(x*x)\" | \"(((x+1)*(x-1))+1)\" | \"((x*x)+0)\" | \"((x*x)+1)\"",
            "native": {
                "text": "(1*x)",
                "tokens": [
                    {
                        "token": "(",
                        "logprob": -4.211707392782849,
                        "bytes": [
                            40
                        ],
                        "top_logprobs": [
                            {
                                "token": "2",
                                "logprob": -2.3854945097872426,
                                "bytes": [
                                    50
                                ]
                            },
                            {
                                "token": "`",
                                "logprob": -2.4553206358858755,
                                "bytes": [
                                    96
                                ]
                            },
                            {
                                "token": "```",
                                "logprob": -2.514120379538219,
                                "bytes": [
                                    96,
                                    96,
                                    96
                                ]
                            },
                            {
                                "token": "The",
                                "logprob": -2.6422388945528676,
                                "bytes": [
                                    84,
                                    104,
                                    101
                                ]
                            },
                            {
                                "token": "**",
                                "logprob": -3.104099551291149,
                                "bytes": [
                                    42,
                                    42
                                ]
                            },
                            {
                                "token": "1",
                                "logprob": -3.1672203932711294,
                                "bytes": [
                                    49
                                ]
                            },
                            {
                                "token": "x",
                                "logprob": -3.532707491964977,
                                "bytes": [
                                    120
                                ]
                            },
                            {
                                "token": "sqrt",
                                "logprob": -3.632331172079723,
                                "bytes": [
                                    115,
                                    113,
                                    114,
                                    116
                                ]
                            },
                            {
                                "token": "\"",
                                "logprob": -3.880342761130016,
                                "bytes": [
                                    34
                                ]
                            },
                            {
                                "token": "0",
                                "logprob": -3.8844254408785512,
                                "bytes": [
                                    48
                                ]
                            },
                            {
                                "token": "Let",
                                "logprob": -4.090537348837536,
                                "bytes": [
                                    76,
                                    101,
                                    116
                                ]
                            },
                            {
                                "token": "(",
                                "logprob": -4.211707392782849,
                                "bytes": [
                                    40
                                ]
                            },
                            {
                                "token": "$$",
                                "logprob": -4.314987460226696,
                                "bytes": [
                                    36,
                                    36
                                ]
                            },
                            {
                                "token": "e",
                                "logprob": -4.4052451048800165,
                                "bytes": [
                                    101
                                ]
                            },
                            {
                                "token": "$\\",
                                "logprob": -4.531498232931774,
                                "bytes": [
                                    36,
                                    92
                                ]
                            },
                            {
                                "token": "$",
                                "logprob": -4.599783221335095,
                                "bytes": [
                                    36
                                ]
                            },
                            {
                                "token": "Choose",
                                "logprob": -4.731452265829724,
                                "bytes": [
                                    67,
                                    104,
                                    111,
                                    111,
                                    115,
                                    101
                                ]
                            },
                            {
                                "token": "5",
                                "logprob": -4.755179682821911,
                                "bytes": [
                                    53
                                ]
                            },
                            {
                                "token": "let",
                                "logprob": -4.7581408415743525,
                                "bytes": [
                                    108,
                                    101,
                                    116
                                ]
                            },
                            {
                                "token": "((",
                                "logprob": -4.84272030934779,
                                "bytes": [
                                    40,
                                    40
                                ]
                            }
                        ],
                        "strata_sampling": {
                            "index": 0,
                            "id": 7,
                            "probability": 0.2817279822732899,
                            "support": 5,
                            "entropy": 1.0312132455335141,
                            "selection_ms": 0.113892,
                            "stages": [
                                {
                                    "operator": "grammar",
                                    "support": 5,
                                    "entropy": 1.0312132455335141
                                },
                                {
                                    "operator": "temperature",
                                    "support": 5,
                                    "entropy": 1.0312132455335141
                                }
                            ],
                            "top": [
                                {
                                    "id": 87,
                                    "probability": 0.5555407170206278,
                                    "bytes": [
                                        120
                                    ],
                                    "token": "x"
                                },
                                {
                                    "id": 7,
                                    "probability": 0.2817279822732899,
                                    "bytes": [
                                        40
                                    ],
                                    "token": "("
                                },
                                {
                                    "id": 1148,
                                    "probability": 0.14989410632804026,
                                    "bytes": [
                                        40,
                                        40
                                    ],
                                    "token": "(("
                                },
                                {
                                    "id": 2007,
                                    "probability": 0.009478785972524308,
                                    "bytes": [
                                        40,
                                        120
                                    ],
                                    "token": "(x"
                                },
                                {
                                    "id": 6427,
                                    "probability": 0.0033584084055178222,
                                    "bytes": [
                                        40,
                                        40,
                                        40
                                    ],
                                    "token": "((("
                                }
                            ]
                        }
                    },
                    {
                        "token": "1",
                        "logprob": -0.5092159910800459,
                        "bytes": [
                            49
                        ],
                        "top_logprobs": [
                            {
                                "token": "1",
                                "logprob": -0.5092159910800459,
                                "bytes": [
                                    49
                                ]
                            },
                            {
                                "token": "2",
                                "logprob": -2.4234539671542645,
                                "bytes": [
                                    50
                                ]
                            },
                            {
                                "token": "3",
                                "logprob": -2.577737490713835,
                                "bytes": [
                                    51
                                ]
                            },
                            {
                                "token": "0",
                                "logprob": -2.69229380327487,
                                "bytes": [
                                    48
                                ]
                            },
                            {
                                "token": "5",
                                "logprob": -3.30237738329196,
                                "bytes": [
                                    53
                                ]
                            },
                            {
                                "token": "4",
                                "logprob": -3.7880188627841473,
                                "bytes": [
                                    52
                                ]
                            },
                            {
                                "token": "7",
                                "logprob": -3.924931208670378,
                                "bytes": [
                                    55
                                ]
                            },
                            {
                                "token": "9",
                                "logprob": -4.471318881094694,
                                "bytes": [
                                    57
                                ]
                            },
                            {
                                "token": "6",
                                "logprob": -4.8705059691073895,
                                "bytes": [
                                    54
                                ]
                            },
                            {
                                "token": "8",
                                "logprob": -5.23265139299655,
                                "bytes": [
                                    56
                                ]
                            },
                            {
                                "token": " ",
                                "logprob": -5.543575923025847,
                                "bytes": [
                                    32
                                ]
                            },
                            {
                                "token": "√",
                                "logprob": -5.707276980459929,
                                "bytes": [
                                    226,
                                    136,
                                    154
                                ]
                            },
                            {
                                "token": "�",
                                "logprob": -5.869870822012663,
                                "bytes": [
                                    226,
                                    136
                                ]
                            },
                            {
                                "token": "!!",
                                "logprob": -5.972071330130339,
                                "bytes": [
                                    33,
                                    33
                                ]
                            },
                            {
                                "token": "\n",
                                "logprob": -6.083629290640593,
                                "bytes": [
                                    10
                                ]
                            },
                            {
                                "token": "\n\n",
                                "logprob": -6.112152735769987,
                                "bytes": [
                                    10,
                                    10
                                ]
                            },
                            {
                                "token": "λ",
                                "logprob": -6.539027850210905,
                                "bytes": [
                                    206,
                                    187
                                ]
                            },
                            {
                                "token": " (",
                                "logprob": -6.541910807669401,
                                "bytes": [
                                    32,
                                    40
                                ]
                            },
                            {
                                "token": "<|endoftext|>",
                                "logprob": -6.571901957571745,
                                "bytes": None
                            },
                            {
                                "token": " a",
                                "logprob": -6.683499972403288,
                                "bytes": [
                                    32,
                                    97
                                ]
                            }
                        ],
                        "strata_sampling": {
                            "index": 1,
                            "id": 16,
                            "probability": 0.999995830029442,
                            "support": 5,
                            "entropy": 0.00005820036510486225,
                            "selection_ms": 0.113892,
                            "stages": [
                                {
                                    "operator": "grammar",
                                    "support": 5,
                                    "entropy": 0.00005820036510486225
                                },
                                {
                                    "operator": "temperature",
                                    "support": 5,
                                    "entropy": 0.00005820036510486225
                                }
                            ],
                            "top": [
                                {
                                    "id": 16,
                                    "probability": 0.999995830029442,
                                    "bytes": [
                                        49
                                    ],
                                    "token": "1"
                                },
                                {
                                    "id": 1148,
                                    "probability": 0.0000035384608054184848,
                                    "bytes": [
                                        40,
                                        40
                                    ],
                                    "token": "(("
                                },
                                {
                                    "id": 87,
                                    "probability": 3.4818349703614387e-7,
                                    "bytes": [
                                        120
                                    ],
                                    "token": "x"
                                },
                                {
                                    "id": 7,
                                    "probability": 2.0504913855245548e-7,
                                    "bytes": [
                                        40
                                    ],
                                    "token": "("
                                },
                                {
                                    "id": 2007,
                                    "probability": 7.82771170837418e-8,
                                    "bytes": [
                                        40,
                                        120
                                    ],
                                    "token": "(x"
                                }
                            ]
                        }
                    },
                    {
                        "token": "*",
                        "logprob": -9.83770152718637,
                        "bytes": [
                            42
                        ],
                        "top_logprobs": [
                            {
                                "token": " +",
                                "logprob": -1.4730107465467224,
                                "bytes": [
                                    32,
                                    43
                                ]
                            },
                            {
                                "token": " /",
                                "logprob": -1.7045399823865661,
                                "bytes": [
                                    32,
                                    47
                                ]
                            },
                            {
                                "token": " <<",
                                "logprob": -1.9922978559217224,
                                "bytes": [
                                    32,
                                    60,
                                    60
                                ]
                            },
                            {
                                "token": "0",
                                "logprob": -2.3663956800184023,
                                "bytes": [
                                    48
                                ]
                            },
                            {
                                "token": "/",
                                "logprob": -2.626195637293793,
                                "bytes": [
                                    47
                                ]
                            },
                            {
                                "token": ".",
                                "logprob": -2.786612240382172,
                                "bytes": [
                                    46
                                ]
                            },
                            {
                                "token": " ==",
                                "logprob": -3.2446410337171327,
                                "bytes": [
                                    32,
                                    61,
                                    61
                                ]
                            },
                            {
                                "token": ",",
                                "logprob": -3.7985789457044374,
                                "bytes": [
                                    44
                                ]
                            },
                            {
                                "token": " -",
                                "logprob": -3.8133637586316835,
                                "bytes": [
                                    32,
                                    45
                                ]
                            },
                            {
                                "token": "+",
                                "logprob": -4.099909512110687,
                                "bytes": [
                                    43
                                ]
                            },
                            {
                                "token": "2",
                                "logprob": -4.2613312879285585,
                                "bytes": [
                                    50
                                ]
                            },
                            {
                                "token": " >",
                                "logprob": -4.42824336678598,
                                "bytes": [
                                    32,
                                    62
                                ]
                            },
                            {
                                "token": " <",
                                "logprob": -4.62382671029184,
                                "bytes": [
                                    32,
                                    60
                                ]
                            },
                            {
                                "token": "3",
                                "logprob": -4.751979557581879,
                                "bytes": [
                                    51
                                ]
                            },
                            {
                                "token": "7",
                                "logprob": -4.972516743250824,
                                "bytes": [
                                    55
                                ]
                            },
                            {
                                "token": "1",
                                "logprob": -5.061221806117035,
                                "bytes": [
                                    49
                                ]
                            },
                            {
                                "token": " !=",
                                "logprob": -5.078162876673676,
                                "bytes": [
                                    32,
                                    33,
                                    61
                                ]
                            },
                            {
                                "token": ")",
                                "logprob": -5.133243290492035,
                                "bytes": [
                                    41
                                ]
                            },
                            {
                                "token": "5",
                                "logprob": -5.254750935145355,
                                "bytes": [
                                    53
                                ]
                            },
                            {
                                "token": "9",
                                "logprob": -5.469378201075531,
                                "bytes": [
                                    57
                                ]
                            }
                        ],
                        "strata_sampling": {
                            "index": 2,
                            "id": 9,
                            "probability": 0.8784136912070387,
                            "support": 2,
                            "entropy": 0.37007373114313097,
                            "selection_ms": 0.1126,
                            "stages": [
                                {
                                    "operator": "grammar",
                                    "support": 2,
                                    "entropy": 0.37007373114313097
                                },
                                {
                                    "operator": "temperature",
                                    "support": 2,
                                    "entropy": 0.37007373114313097
                                }
                            ],
                            "top": [
                                {
                                    "id": 9,
                                    "probability": 0.8784136912070387,
                                    "bytes": [
                                        42
                                    ],
                                    "token": "*"
                                },
                                {
                                    "id": 17930,
                                    "probability": 0.1215863087929612,
                                    "bytes": [
                                        42,
                                        120
                                    ],
                                    "token": "*x"
                                }
                            ]
                        }
                    },
                    {
                        "token": "x",
                        "logprob": -11.079480511021227,
                        "bytes": [
                            120
                        ],
                        "top_logprobs": [
                            {
                                "token": "2",
                                "logprob": -1.132863384556383,
                                "bytes": [
                                    50
                                ]
                            },
                            {
                                "token": "1",
                                "logprob": -1.3641675532575548,
                                "bytes": [
                                    49
                                ]
                            },
                            {
                                "token": "0",
                                "logprob": -1.8678124964948595,
                                "bytes": [
                                    48
                                ]
                            },
                            {
                                "token": "3",
                                "logprob": -2.378253322910875,
                                "bytes": [
                                    51
                                ]
                            },
                            {
                                "token": "5",
                                "logprob": -3.9246438563581405,
                                "bytes": [
                                    53
                                ]
                            },
                            {
                                "token": "4",
                                "logprob": -4.0068238795515,
                                "bytes": [
                                    52
                                ]
                            },
                            {
                                "token": "8",
                                "logprob": -4.203275066685289,
                                "bytes": [
                                    56
                                ]
                            },
                            {
                                "token": "7",
                                "logprob": -4.290414196323961,
                                "bytes": [
                                    55
                                ]
                            },
                            {
                                "token": "6",
                                "logprob": -4.298295360874742,
                                "bytes": [
                                    54
                                ]
                            },
                            {
                                "token": "9",
                                "logprob": -4.529340130161851,
                                "bytes": [
                                    57
                                ]
                            },
                            {
                                "token": "sqrt",
                                "logprob": -5.028619152378648,
                                "bytes": [
                                    115,
                                    113,
                                    114,
                                    116
                                ]
                            },
                            {
                                "token": " ",
                                "logprob": -5.121857982945055,
                                "bytes": [
                                    32
                                ]
                            },
                            {
                                "token": "+",
                                "logprob": -5.177617412876695,
                                "bytes": [
                                    43
                                ]
                            },
                            {
                                "token": "exp",
                                "logprob": -5.6410697520490585,
                                "bytes": [
                                    101,
                                    120,
                                    112
                                ]
                            },
                            {
                                "token": " -",
                                "logprob": -6.894120556187242,
                                "bytes": [
                                    32,
                                    45
                                ]
                            },
                            {
                                "token": "rand",
                                "logprob": -6.896769863438219,
                                "bytes": [
                                    114,
                                    97,
                                    110,
                                    100
                                ]
                            },
                            {
                                "token": "<",
                                "logprob": -6.946973186802476,
                                "bytes": [
                                    60
                                ]
                            },
                            {
                                "token": " (",
                                "logprob": -7.050428730320543,
                                "bytes": [
                                    32,
                                    40
                                ]
                            },
                            {
                                "token": "int",
                                "logprob": -7.05092845566234,
                                "bytes": [
                                    105,
                                    110,
                                    116
                                ]
                            },
                            {
                                "token": "E",
                                "logprob": -7.060738903355211,
                                "bytes": [
                                    69
                                ]
                            }
                        ],
                        "strata_sampling": {
                            "index": 3,
                            "id": 87,
                            "probability": 1,
                            "support": 1,
                            "entropy": 0,
                            "selection_ms": 0.11305,
                            "stages": [
                                {
                                    "operator": "grammar",
                                    "support": 1,
                                    "entropy": 0
                                },
                                {
                                    "operator": "temperature",
                                    "support": 1,
                                    "entropy": 0
                                }
                            ],
                            "top": [
                                {
                                    "id": 87,
                                    "probability": 1,
                                    "bytes": [
                                        120
                                    ],
                                    "token": "x"
                                }
                            ]
                        }
                    },
                    {
                        "token": ")",
                        "logprob": -1.6531204548654481,
                        "bytes": [
                            41
                        ],
                        "top_logprobs": [
                            {
                                "token": ")",
                                "logprob": -1.6531204548654481,
                                "bytes": [
                                    41
                                ]
                            },
                            {
                                "token": " +",
                                "logprob": -2.0223945942697448,
                                "bytes": [
                                    32,
                                    43
                                ]
                            },
                            {
                                "token": ")/",
                                "logprob": -2.876347002106659,
                                "bytes": [
                                    41,
                                    47
                                ]
                            },
                            {
                                "token": ")*",
                                "logprob": -3.0428594914255065,
                                "bytes": [
                                    41,
                                    42
                                ]
                            },
                            {
                                "token": "+",
                                "logprob": -3.07432883651828,
                                "bytes": [
                                    43
                                ]
                            },
                            {
                                "token": " -",
                                "logprob": -3.2185510960397643,
                                "bytes": [
                                    32,
                                    45
                                ]
                            },
                            {
                                "token": "**",
                                "logprob": -3.29407924087619,
                                "bytes": [
                                    42,
                                    42
                                ]
                            },
                            {
                                "token": "*",
                                "logprob": -3.3949388829049987,
                                "bytes": [
                                    42
                                ]
                            },
                            {
                                "token": "-",
                                "logprob": -3.7125753727731627,
                                "bytes": [
                                    45
                                ]
                            },
                            {
                                "token": ")**",
                                "logprob": -3.794187006073944,
                                "bytes": [
                                    41,
                                    42,
                                    42
                                ]
                            },
                            {
                                "token": ")/(",
                                "logprob": -3.9231762257394713,
                                "bytes": [
                                    41,
                                    47,
                                    40
                                ]
                            },
                            {
                                "token": ")*(",
                                "logprob": -3.98322719009494,
                                "bytes": [
                                    41,
                                    42,
                                    40
                                ]
                            },
                            {
                                "token": " ==",
                                "logprob": -4.053686555939667,
                                "bytes": [
                                    32,
                                    61,
                                    61
                                ]
                            },
                            {
                                "token": "^",
                                "logprob": -4.078093942719452,
                                "bytes": [
                                    94
                                ]
                            },
                            {
                                "token": "/",
                                "logprob": -4.136602815705292,
                                "bytes": [
                                    47
                                ]
                            },
                            {
                                "token": ")^",
                                "logprob": -4.389486726838104,
                                "bytes": [
                                    41,
                                    94
                                ]
                            },
                            {
                                "token": ").",
                                "logprob": -4.420134958344452,
                                "bytes": [
                                    41,
                                    46
                                ]
                            },
                            {
                                "token": ")+",
                                "logprob": -4.612466272431366,
                                "bytes": [
                                    41,
                                    43
                                ]
                            },
                            {
                                "token": " !=",
                                "logprob": -4.635986742096893,
                                "bytes": [
                                    32,
                                    33,
                                    61
                                ]
                            },
                            {
                                "token": "+y",
                                "logprob": -4.758687433320038,
                                "bytes": [
                                    43,
                                    121
                                ]
                            }
                        ],
                        "strata_sampling": {
                            "index": 4,
                            "id": 8,
                            "probability": 1,
                            "support": 1,
                            "entropy": 0,
                            "selection_ms": 0.11273,
                            "stages": [
                                {
                                    "operator": "grammar",
                                    "support": 1,
                                    "entropy": 0
                                },
                                {
                                    "operator": "temperature",
                                    "support": 1,
                                    "entropy": 0
                                }
                            ],
                            "top": [
                                {
                                    "id": 8,
                                    "probability": 1,
                                    "bytes": [
                                        41
                                    ],
                                    "token": ")"
                                }
                            ]
                        }
                    }
                ],
                "token_count": 5,
                "logprob": -27.29122587693594,
                "path_probability": 1.4046599415302757e-12,
                "mean_logprob": -5.458245175387188,
                "finish_reason": "stop"
            }
        },
        "training_pairs": [
            {
                "left": 2,
                "right": 3,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -0.6372985839843746,
                    -6.322427749633789
                ]
            },
            {
                "left": 0,
                "right": 2,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -0.8861923217773442,
                    6.011629104614258
                ]
            },
            {
                "left": 3,
                "right": 4,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -0.15167617797851607,
                    5.8407745361328125
                ]
            },
            {
                "left": 0,
                "right": 4,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -1.6751670837402348,
                    5.529975891113281
                ]
            },
            {
                "left": 1,
                "right": 3,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -0.24939537048339844,
                    -5.752376556396484
                ]
            },
            {
                "left": 0,
                "right": 1,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -1.2740955352783203,
                    5.441577911376954
                ]
            },
            {
                "left": 3,
                "right": 5,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -0.1469440460205078,
                    4.7339019775390625
                ]
            },
            {
                "left": 0,
                "right": 5,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -1.6704349517822266,
                    4.423103332519531
                ]
            },
            {
                "left": 8,
                "right": 9,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    0.9218387603759766,
                    -2.0020599365234375
                ]
            },
            {
                "left": 9,
                "right": 10,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -0.738006591796875,
                    1.8791275024414062
                ]
            },
            {
                "left": 2,
                "right": 5,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -0.7842426300048824,
                    -1.5885257720947266
                ]
            },
            {
                "left": 0,
                "right": 3,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -1.5234909057617188,
                    -0.3107986450195308
                ]
            },
            {
                "left": 4,
                "right": 5,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    0.004732131958008257,
                    -1.10687255859375
                ]
            },
            {
                "left": 1,
                "right": 5,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -0.39633941650390625,
                    -1.018474578857422
                ]
            },
            {
                "left": 2,
                "right": 4,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -0.7889747619628906,
                    -0.48165321350097656
                ]
            },
            {
                "left": 1,
                "right": 2,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    0.3879032135009761,
                    0.5700511932373045
                ]
            },
            {
                "left": 1,
                "right": 4,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    -0.4010715484619145,
                    0.0883979797363279
                ]
            },
            {
                "left": 8,
                "right": 10,
                "relation": "exactly equivalent",
                "measurement_delta": [
                    0.18383216857910156,
                    -0.12293243408203125
                ]
            }
        ],
        "semantics": "Canonical coefficients prove equivalence for all integers. Mean binary JS averages two separate marginal comparisons; it is not a joint divergence. A feature collision can be expected information loss: two correct yes/no properties need not identify the whole expression. No probability is assumed calibrated."
    },
    "lesson": {
        "question": "Can equivalent algebra confuse the observer?",
        "rule": "Find the equivalent pair with the largest measured log-odds distance. Evaluate its exact coefficients at the chosen integer.",
        "knob": "Integer x",
        "default": 2,
        "compare": -2,
        "low": -10,
        "high": 10,
        "integer": True,
        "states": [
            {
                "value": 2,
                "summary": "Equal exact values at x=2: 2; observer distance 6.354.",
                "rows": [
                    {
                        "label": "(x+0)",
                        "value": 0.9196148999882252
                    },
                    {
                        "label": "(1*x)",
                        "value": 0.02012816725855873
                    }
                ],
                "unit": "weight",
                "metrics": {
                    "left": "(x+0)",
                    "right": "(1*x)",
                    "margin_distance": 6.354466313899845,
                    "left_value": 2,
                    "right_value": 2
                },
                "note": "Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe."
            },
            {
                "value": -2,
                "summary": "Equal exact values at x=-2: -2; observer distance 6.354.",
                "rows": [
                    {
                        "label": "(x+0)",
                        "value": 0.9196148999882252
                    },
                    {
                        "label": "(1*x)",
                        "value": 0.02012816725855873
                    }
                ],
                "unit": "weight",
                "metrics": {
                    "left": "(x+0)",
                    "right": "(1*x)",
                    "margin_distance": 6.354466313899845,
                    "left_value": -2,
                    "right_value": -2
                },
                "note": "Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe."
            }
        ],
        "input_excerpt": "",
        "scope": "This panel and its Python calculation reproduce saved measurements. Other page controls are independent views."
    },
    "receipt": {
        "mode": "recorded",
        "requests": 25,
        "summed_request_ms": 21335.689599916805,
        "prompt_tokens": 2162,
        "completion_tokens": 30,
        "calls": [
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: x\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-734c61bb04b247c0a1d5b8eb",
                    "object": "chat.completion",
                    "created": 1791088243,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.018047350828326234,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.018047350828326234,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -4.105159777586139,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.924238223020709,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.630993861143267,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -9.711639422361529,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.142841357175982,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.314527529661333,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -10.386110323850787,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.475757616941607,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.49252797979561,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.557192820493853,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.583782214109576,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.622857111875689,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.714155215208208,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -10.888864535276568,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.970151919309771,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -11.058734911863482,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.102325457517779,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "AB",
                                                "logprob": -11.127266901914751,
                                                "bytes": [
                                                    65,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -11.221115130369341,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.983489532594177,
                                            "support": 2,
                                            "entropy": 0.08412842073115988,
                                            "selection_ms": 0.126215,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.08412842073115988
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.08412842073115988
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.983489532594177,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.016510467405823064,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 85,
                        "completion_tokens": 1,
                        "total_tokens": 86,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 85,
                        "prompt_ms": 761,
                        "prompt_per_token_ms": 8.953,
                        "prompt_per_second": 111.7,
                        "predicted_n": 1,
                        "predicted_ms": 28.6,
                        "predicted_per_token_ms": 28.6,
                        "predicted_per_second": 35,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 885.5131000163965,
                "captured_at": "2026-10-04T04:30:45Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: x\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-6b99a7dbb8c5454c8c46fafd",
                    "object": "chat.completion",
                    "created": 1791088244,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.03346093146100649,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.03346093146100649,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.6079638764072954,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -5.88285191504255,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.836561517398507,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -8.195185975711494,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.195221261661201,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.746563272159248,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -9.072447137515693,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "Is",
                                                "logprob": -9.333390550296455,
                                                "bytes": [
                                                    73,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -9.40612442938581,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.528824166934639,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -9.858654336612373,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -9.993089990298897,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.12611134497419,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.126604394595772,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.168275193851143,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.377605752627998,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.437023477237373,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -10.520004586856514,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.539873437564522,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9727348695605095,
                                            "support": 2,
                                            "entropy": 0.12510301058274875,
                                            "selection_ms": 0.11249,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.12510301058274875
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.12510301058274875
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9727348695605095,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.02726513043949044,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 84,
                        "completion_tokens": 1,
                        "total_tokens": 85,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 84,
                        "prompt_ms": 741.2,
                        "prompt_per_token_ms": 8.824,
                        "prompt_per_second": 113.3,
                        "predicted_n": 1,
                        "predicted_ms": 28.6,
                        "predicted_per_token_ms": 28.6,
                        "predicted_per_second": 35,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 798.9548000041395,
                "captured_at": "2026-10-04T04:30:45Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: ((x+1)-1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-9e26ea7a0ff748f1a6f035ec",
                    "object": "chat.completion",
                    "created": 1791088245,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.0621758325070182,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.0621758325070182,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.8751927239865105,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -6.601966939684752,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.8830672128170765,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.447365842577819,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -8.889744840380553,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.96567066740692,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -9.274547658678893,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -9.856853566882018,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "AB",
                                                "logprob": -9.90270622801483,
                                                "bytes": [
                                                    65,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -10.022691808459166,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -10.111288152453307,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -10.16048153471649,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -10.417390905138854,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.432008825060729,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.553077779528502,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -10.631639562365416,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.644560895678405,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -10.652702413317565,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -10.707304082629088,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9433751925565599,
                                            "support": 2,
                                            "entropy": 0.2175777440777498,
                                            "selection_ms": 0.111838,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.2175777440777498
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.2175777440777498
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9433751925565599,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.05662480744344002,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 91,
                        "completion_tokens": 1,
                        "total_tokens": 92,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 91,
                        "prompt_ms": 793.6,
                        "prompt_per_token_ms": 8.721,
                        "prompt_per_second": 114.7,
                        "predicted_n": 1,
                        "predicted_ms": 26.3,
                        "predicted_per_token_ms": 26.3,
                        "predicted_per_second": 38,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 838.575600006152,
                "captured_at": "2026-10-04T04:30:46Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: ((x+1)-1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-4eada3d116434d32afdfd9ef",
                    "object": "chat.completion",
                    "created": 1791088246,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.14820622944643053,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.14820622944643053,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.0152811958770944,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -6.86094045185854,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.892335410354634,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -7.899308676956196,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -8.008893485305805,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.031044478652973,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.533163542984028,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -9.631651396987934,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -9.793080802200336,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -9.880795951126117,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -9.91901921772768,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.141273017166156,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.269811148880024,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "(A",
                                                "logprob": -10.27800130390932,
                                                "bytes": [
                                                    40,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -10.288815970657367,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.309854979751606,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -10.335656638381977,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.432811255691547,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.434348578689594,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.8661194637809663,
                                            "support": 2,
                                            "entropy": 0.3936974286618936,
                                            "selection_ms": 0.121937,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.3936974286618936
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.3936974286618936
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.8661194637809663,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.13388053621903384,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 90,
                        "completion_tokens": 1,
                        "total_tokens": 91,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 90,
                        "prompt_ms": 797.4,
                        "prompt_per_token_ms": 8.86,
                        "prompt_per_second": 112.9,
                        "predicted_n": 1,
                        "predicted_ms": 26.1,
                        "predicted_per_token_ms": 26.1,
                        "predicted_per_second": 38.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 843.2894999859855,
                "captured_at": "2026-10-04T04:30:47Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (x+0)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-c653f95ef0064cdebba3b452",
                    "object": "chat.completion",
                    "created": 1791088247,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.04302815667137756,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.04302815667137756,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -3.2439482616518465,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.100818912896964,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -8.969141285333487,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.170709888849112,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -9.198091785821768,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -9.22644070855126,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.370311062249991,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.600070278558585,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -9.67780904046044,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -9.826305668268057,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -9.833423893365714,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.128055851373526,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.187560360345694,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.202174465570303,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -10.303653995904776,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.315550129327628,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -10.33538846245751,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -10.379114429864737,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.507947246942374,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.96086888770343,
                                            "support": 2,
                                            "entropy": 0.16517287659105812,
                                            "selection_ms": 0.112399,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.16517287659105812
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.16517287659105812
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.96086888770343,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.03913111229657002,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 89,
                        "completion_tokens": 1,
                        "total_tokens": 90,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 89,
                        "prompt_ms": 782.5,
                        "prompt_per_token_ms": 8.792,
                        "prompt_per_second": 113.7,
                        "predicted_n": 1,
                        "predicted_ms": 25.5,
                        "predicted_per_token_ms": 25.5,
                        "predicted_per_second": 39.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 830.8305999962613,
                "captured_at": "2026-10-04T04:30:48Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (x+0)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-90f88dda2a464a31b9867ca7",
                    "object": "chat.completion",
                    "created": 1791088247,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.08816542010900705,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.08816542010900705,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.525291579776976,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -6.545254844242308,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.306406158024046,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -8.38986124377844,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -8.443888801151488,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -9.12809767108557,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.190685409122679,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -9.29009546619055,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.461530822330687,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "(A",
                                                "logprob": -9.555955070072386,
                                                "bytes": [
                                                    40,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.701322692447874,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -9.749259131962035,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -9.805015700870726,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -10.07774366717932,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.102150100284788,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.186939376407835,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "(B",
                                                "logprob": -10.208933013492796,
                                                "bytes": [
                                                    40,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.249279159122679,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.419811385685179,
                                                "bytes": [
                                                    98
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9196148999882252,
                                            "support": 2,
                                            "entropy": 0.2797089136265746,
                                            "selection_ms": 0.112068,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.2797089136265746
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.2797089136265746
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9196148999882252,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.08038510001177482,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 88,
                        "completion_tokens": 1,
                        "total_tokens": 89,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 88,
                        "prompt_ms": 768.7,
                        "prompt_per_token_ms": 8.735,
                        "prompt_per_second": 114.5,
                        "predicted_n": 1,
                        "predicted_ms": 25.4,
                        "predicted_per_token_ms": 25.4,
                        "predicted_per_second": 39.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 818.5781000065617,
                "captured_at": "2026-10-04T04:30:49Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (1*x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-2224d575efc94e2fa2bcdd65",
                    "object": "chat.completion",
                    "created": 1791088248,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.07678249167813837,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.07678249167813837,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.640404012674232,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.9567702083529435,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -8.815465238565345,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.180809286111732,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -9.597885396951575,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.662569311136146,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -9.701890256875892,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -9.703990247720618,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -9.718776967996497,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.740079191202064,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.766577032083411,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -9.963262823099036,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.056078222268958,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -10.136995580667396,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -10.208973196023841,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.4609530239047,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -10.515486028665443,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -10.619268682474036,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -10.676681783670325,
                                                "bytes": [
                                                    91
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9284833076511865,
                                            "support": 2,
                                            "entropy": 0.25754460772540294,
                                            "selection_ms": 0.112509,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.25754460772540294
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.25754460772540294
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9284833076511865,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.0715166923488134,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 88,
                        "completion_tokens": 1,
                        "total_tokens": 89,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 88,
                        "prompt_ms": 787.4,
                        "prompt_per_token_ms": 8.948,
                        "prompt_per_second": 111.8,
                        "predicted_n": 1,
                        "predicted_ms": 24.9,
                        "predicted_per_token_ms": 24.9,
                        "predicted_per_second": 40.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 836.0245000221767,
                "captured_at": "2026-10-04T04:30:50Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (1*x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-86cb677752884b88bcc7ca77",
                    "object": "chat.completion",
                    "created": 1791088249,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.02414822020567617,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.02414822020567617,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.9094498101714965,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.688056224966418,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.655197376394641,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.758874172354114,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.929097408438098,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -9.150711292410266,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.531077617788684,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -9.608186954641711,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.631818050527942,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -9.79284500517882,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.064898723745715,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -10.091253513479602,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.11555408873595,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "expression",
                                                "logprob": -10.187611812734973,
                                                "bytes": [
                                                    101,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -10.41560291686095,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -10.516230816030872,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "(B",
                                                "logprob": -10.526753658438098,
                                                "bytes": [
                                                    40,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.551797145986926,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.70376324095763,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9798718327414412,
                                            "support": 2,
                                            "entropy": 0.09853749904002379,
                                            "selection_ms": 0.11303,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.09853749904002379
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.09853749904002379
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9798718327414412,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.02012816725855873,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 87,
                        "completion_tokens": 1,
                        "total_tokens": 88,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 87,
                        "prompt_ms": 789.1,
                        "prompt_per_token_ms": 9.07,
                        "prompt_per_second": 110.3,
                        "predicted_n": 1,
                        "predicted_ms": 26.3,
                        "predicted_per_token_ms": 26.3,
                        "predicted_per_second": 38,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 832.3847999563441,
                "captured_at": "2026-10-04T04:30:50Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: ((x-x)+x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-7858e309e95e4e16916f334f",
                    "object": "chat.completion",
                    "created": 1791088250,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.09032661876970118,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.09032661876970118,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.5022719617872795,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.240387272456225,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.640419315913256,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -7.688146900752123,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -8.297622990229662,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -8.77163345775896,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.179968189814623,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.285809826472338,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -9.639795612910326,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "(A",
                                                "logprob": -9.720674824336108,
                                                "bytes": [
                                                    40,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -9.726685833552416,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -10.00355370006853,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.02083427868181,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.050044369319018,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -10.074030232050951,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -10.177462887385424,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.179078411677416,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -10.211644482234057,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.242380451777514,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9177336719092041,
                                            "support": 2,
                                            "entropy": 0.28426993512565757,
                                            "selection_ms": 0.112519,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.28426993512565757
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.28426993512565757
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9177336719092041,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.0822663280907959,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 90,
                        "completion_tokens": 1,
                        "total_tokens": 91,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 90,
                        "prompt_ms": 793.3,
                        "prompt_per_token_ms": 8.814,
                        "prompt_per_second": 113.5,
                        "predicted_n": 1,
                        "predicted_ms": 24.6,
                        "predicted_per_token_ms": 24.6,
                        "predicted_per_second": 40.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 845.2554999967106,
                "captured_at": "2026-10-04T04:30:51Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: ((x-x)+x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-7ab7c17266014d50a4a119e4",
                    "object": "chat.completion",
                    "created": 1791088251,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.1446531844169736,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.1446531844169736,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.100126130583966,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -5.672670228484357,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.69140992880174,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.557696206572736,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.065547807219708,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -8.157197816374982,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -8.297281129363263,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -8.37219320059129,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -8.556077821257794,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -8.892827851775372,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.020906312468732,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -9.164081437590802,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -9.215512139800275,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -9.266343934539044,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -9.351199014189923,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "(A",
                                                "logprob": -9.379314286711896,
                                                "bytes": [
                                                    40,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -9.480695588591779,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -9.491246087554181,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "Analy",
                                                "logprob": -9.576755387786115,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    97,
                                                    108,
                                                    121
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.8760421856632626,
                                            "support": 2,
                                            "entropy": 0.3747371844569015,
                                            "selection_ms": 0.112389,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.3747371844569015
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.3747371844569015
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.8760421856632626,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.12395781433673735,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 89,
                        "completion_tokens": 1,
                        "total_tokens": 90,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 89,
                        "prompt_ms": 798.3,
                        "prompt_per_token_ms": 8.97,
                        "prompt_per_second": 111.5,
                        "predicted_n": 1,
                        "predicted_ms": 24.7,
                        "predicted_per_token_ms": 24.7,
                        "predicted_per_second": 40.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 853.9623000542633,
                "captured_at": "2026-10-04T04:30:52Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: ((2*x)-x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-d4b6dc4382c9435b870233cb",
                    "object": "chat.completion",
                    "created": 1791088252,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.09020275006068788,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.09020275006068788,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.506880225036274,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -6.909559668395649,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.591919363830219,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.619450033996235,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -8.429026068542132,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -8.615694464538226,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.966851652953753,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -9.15034812817348,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.287664831969867,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -9.597537459228167,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "(A",
                                                "logprob": -9.96945041546596,
                                                "bytes": [
                                                    40,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -10.011158408019671,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.06234592327846,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.072390974853167,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -10.162693442199359,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.191647948119769,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -10.31743854412807,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.421491087768207,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " ((",
                                                "logprob": -10.422894896361957,
                                                "bytes": [
                                                    32,
                                                    40,
                                                    40
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9180902356391756,
                                            "support": 2,
                                            "entropy": 0.2834090798004934,
                                            "selection_ms": 0.112259,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.2834090798004934
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.2834090798004934
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9180902356391756,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.08190976436082444,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 90,
                        "completion_tokens": 1,
                        "total_tokens": 91,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 90,
                        "prompt_ms": 798.7,
                        "prompt_per_token_ms": 8.874,
                        "prompt_per_second": 112.7,
                        "predicted_n": 1,
                        "predicted_ms": 23.9,
                        "predicted_per_token_ms": 23.9,
                        "predicted_per_second": 41.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 846.5857999981381,
                "captured_at": "2026-10-04T04:30:53Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: ((2*x)-x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-94815d74861843a8972b7b92",
                    "object": "chat.completion",
                    "created": 1791088253,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.3661456978798634,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.3661456978798634,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.2147460854531056,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -5.960523215580059,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.663887587833477,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.4825912392617,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -7.668073264408184,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -7.793851462650371,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.977126685428692,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -8.632075873661114,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.899444190311504,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -8.949047652530743,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.05110701684959,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -9.267602530765606,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -9.353079406070782,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -9.48797282342918,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "(A",
                                                "logprob": -9.500354377079082,
                                                "bytes": [
                                                    40,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -9.562635985660625,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.596379843998028,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "expression",
                                                "logprob": -9.60085066919334,
                                                "bytes": [
                                                    101,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": " ((",
                                                "logprob": -9.733245459842754,
                                                "bytes": [
                                                    32,
                                                    40,
                                                    40
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.7002734594327369,
                                            "support": 2,
                                            "entropy": 0.6106324223839356,
                                            "selection_ms": 0.111778,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.6106324223839356
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.6106324223839356
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.7002734594327369,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.29972654056726306,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 89,
                        "completion_tokens": 1,
                        "total_tokens": 90,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 89,
                        "prompt_ms": 789.5,
                        "prompt_per_token_ms": 8.871,
                        "prompt_per_second": 112.7,
                        "predicted_n": 1,
                        "predicted_ms": 24.5,
                        "predicted_per_token_ms": 24.5,
                        "predicted_per_second": 40.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 839.8305999580771,
                "captured_at": "2026-10-04T04:30:54Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (x+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-b62fda0daa2e484b908b290f",
                    "object": "chat.completion",
                    "created": 1791088253,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.01644956465340751,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.01644956465340751,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.326084727006923,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.3442979991016495,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.4736925303516495,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.92466031904794,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.213511103349697,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -9.419166201311123,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -9.884260767656338,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -9.925633066850674,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.019777888017666,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.076656931596768,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -10.095295542436611,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.337669962602627,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -10.349484080034268,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -10.35699331160165,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.3937975108204,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.530844324785244,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.550329798418057,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.664143198686611,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.790299051958096,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9867397457315489,
                                            "support": 2,
                                            "entropy": 0.07049581451218943,
                                            "selection_ms": 0.121987,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.07049581451218943
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.07049581451218943
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9867397457315489,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.013260254268451097,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 89,
                        "completion_tokens": 1,
                        "total_tokens": 90,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 89,
                        "prompt_ms": 784.2,
                        "prompt_per_token_ms": 8.811,
                        "prompt_per_second": 113.5,
                        "predicted_n": 1,
                        "predicted_ms": 25.8,
                        "predicted_per_token_ms": 25.8,
                        "predicted_per_second": 38.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 848.068899998907,
                "captured_at": "2026-10-04T04:30:55Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (x+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-64290ee14030430b873c3eab",
                    "object": "chat.completion",
                    "created": 1791088254,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.0388055770600466,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.0388055770600466,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.3729310958588745,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.207352253695789,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -8.083447071811023,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.864048573275866,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -8.869586560031237,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -9.425524327060046,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.871719929477038,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.087795826693835,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.530878636142077,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.579250904818835,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -10.589547726413073,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -10.746437641879382,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -10.77822169949657,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.899500462313952,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -11.007248493930163,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.121737095614733,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -11.12706145932323,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.200275990268054,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -11.208792301913562,
                                                "bytes": [
                                                    35
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9655811416969223,
                                            "support": 2,
                                            "entropy": 0.14978193332563297,
                                            "selection_ms": 0.116166,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.14978193332563297
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.14978193332563297
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9655811416969223,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.03441885830307765,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 88,
                        "completion_tokens": 1,
                        "total_tokens": 89,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 88,
                        "prompt_ms": 781.8,
                        "prompt_per_token_ms": 8.884,
                        "prompt_per_second": 112.6,
                        "predicted_n": 1,
                        "predicted_ms": 27.4,
                        "predicted_per_token_ms": 27.4,
                        "predicted_per_second": 36.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 839.2390999943018,
                "captured_at": "2026-10-04T04:30:56Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (x-1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-4aace3c2aa7043b99ed5b68e",
                    "object": "chat.completion",
                    "created": 1791088255,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.01765230318192017,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.01765230318192017,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.3286264242756705,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.7645395102131705,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.913436681233678,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -9.264928609334264,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.307618886433874,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.656453877888952,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.694820195637975,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -9.712284833394323,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -9.793596059285436,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -9.855623036824499,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -9.932464391194616,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "(B",
                                                "logprob": -9.971912175618444,
                                                "bytes": [
                                                    40,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -9.981810361348424,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -9.987684995137487,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.211704045735631,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "test",
                                                "logprob": -10.24165132661942,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -10.272645741902624,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -10.280242711507116,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Test",
                                                "logprob": -10.30352762361649,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    115,
                                                    116
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9867572538169058,
                                            "support": 2,
                                            "entropy": 0.07042034933315412,
                                            "selection_ms": 0.114413,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.07042034933315412
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.07042034933315412
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9867572538169058,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.013242746183094161,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 89,
                        "completion_tokens": 1,
                        "total_tokens": 90,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 89,
                        "prompt_ms": 787.7,
                        "prompt_per_token_ms": 8.851,
                        "prompt_per_second": 113,
                        "predicted_n": 1,
                        "predicted_ms": 25.7,
                        "predicted_per_token_ms": 25.7,
                        "predicted_per_second": 38.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 840.8423999790102,
                "captured_at": "2026-10-04T04:30:56Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (x-1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-cb616b959b9a4485ba745360",
                    "object": "chat.completion",
                    "created": 1791088256,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.022656197880184453,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.022656197880184453,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.026722665165341,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.224674935673153,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.36880373511163,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -8.848772759769833,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -9.153202767704403,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.158867593143857,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.201215501163876,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -9.84580683264581,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -9.99428915533868,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -10.078963990543759,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.09561037573663,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -10.167887444828427,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -10.248219247196591,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.443180795048153,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -10.457741494511044,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.610135789249814,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -10.650923486088193,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -10.687239404056943,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.699673409794247,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9820854742483692,
                                            "support": 2,
                                            "entropy": 0.08980788526882016,
                                            "selection_ms": 0.112209,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.08980788526882016
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.08980788526882016
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9820854742483692,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.01791452575163086,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 88,
                        "completion_tokens": 1,
                        "total_tokens": 89,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 88,
                        "prompt_ms": 780.2,
                        "prompt_per_token_ms": 8.866,
                        "prompt_per_second": 112.8,
                        "predicted_n": 1,
                        "predicted_ms": 25.6,
                        "predicted_per_token_ms": 25.6,
                        "predicted_per_second": 39.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 837.2999000130221,
                "captured_at": "2026-10-04T04:30:57Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (x*x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-1a18bd4c599b4c668dfa3d26",
                    "object": "chat.completion",
                    "created": 1791088257,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.017293018029599337,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.017293018029599337,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.27478699080792,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.329251331017881,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.5048418461546,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.800356906579404,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -8.880915683434873,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.974440616296201,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -9.811828654931455,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.815020602868467,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -9.848101657555967,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.025998157189756,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.039809268639951,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -10.297828715966611,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -10.355155032800107,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.372181934045225,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -10.388119739221006,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.600964587853818,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -10.688086551354795,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -10.822878879235654,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "test",
                                                "logprob": -10.863646548913389,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    115,
                                                    116
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9860399056863453,
                                            "support": 2,
                                            "entropy": 0.07349347029976,
                                            "selection_ms": 0.11262,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.07349347029976
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.07349347029976
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9860399056863453,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.013960094313654652,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 88,
                        "completion_tokens": 1,
                        "total_tokens": 89,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 88,
                        "prompt_ms": 775.5,
                        "prompt_per_token_ms": 8.812,
                        "prompt_per_second": 113.5,
                        "predicted_n": 1,
                        "predicted_ms": 24.9,
                        "predicted_per_token_ms": 24.9,
                        "predicted_per_second": 40.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 826.968899986241,
                "captured_at": "2026-10-04T04:30:58Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (x*x)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-304312d05865442cb843b256",
                    "object": "chat.completion",
                    "created": 1791088258,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.03402818196452531,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.03402818196452531,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -3.601029524737963,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -5.739304671222338,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.6416474675480215,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.23465455525554,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.609306464130052,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -8.886935362750657,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -9.21409619801677,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -9.362424025470384,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.426518568927415,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -9.83264268391765,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -9.972117552692064,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -10.261291632587083,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -10.451522002154954,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "AB",
                                                "logprob": -10.499638686114915,
                                                "bytes": [
                                                    65,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.524479994708665,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -10.628805289203294,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.672373900348314,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Think",
                                                "logprob": -10.712226042682298,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -10.738217482501634,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9725352068735665,
                                            "support": 2,
                                            "entropy": 0.1258159556651259,
                                            "selection_ms": 0.11269,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.1258159556651259
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.1258159556651259
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9725352068735665,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.027464793126433525,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 87,
                        "completion_tokens": 1,
                        "total_tokens": 88,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 87,
                        "prompt_ms": 772.6,
                        "prompt_per_token_ms": 8.88,
                        "prompt_per_second": 112.6,
                        "predicted_n": 1,
                        "predicted_ms": 25.4,
                        "predicted_per_token_ms": 25.4,
                        "predicted_per_second": 39.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 825.1243999693543,
                "captured_at": "2026-10-04T04:30:59Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (((x+1)*(x-1))+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-01ab41797a2247e082a2bbf9",
                    "object": "chat.completion",
                    "created": 1791088258,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.05199881020760402,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.05199881020760402,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.3876540226099476,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -4.913374618923425,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -6.518642143642663,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -6.933979706203698,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -7.562920288479089,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -8.01461191598153,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.196428017055748,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -8.409377769863365,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.491691307461021,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.628468231594322,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.76412077370858,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -8.798131660854576,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -8.81634016457772,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "(((",
                                                "logprob": -8.834761337673424,
                                                "bytes": [
                                                    40,
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -8.889170364773033,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -8.907103256618736,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -9.084554390346764,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -9.113941864406822,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -9.119381622707603,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9656319436499603,
                                            "support": 2,
                                            "entropy": 0.14961251439111795,
                                            "selection_ms": 0.122448,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.14961251439111795
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.14961251439111795
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9656319436499603,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.034368056350039755,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 95,
                        "completion_tokens": 1,
                        "total_tokens": 96,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 95,
                        "prompt_ms": 816.1,
                        "prompt_per_token_ms": 8.591,
                        "prompt_per_second": 116.4,
                        "predicted_n": 1,
                        "predicted_ms": 24.5,
                        "predicted_per_token_ms": 24.5,
                        "predicted_per_second": 40.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 869.170900026802,
                "captured_at": "2026-10-04T04:31:00Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: (((x+1)*(x-1))+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-9c93c278d0724245a3de51bc",
                    "object": "chat.completion",
                    "created": 1791088259,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.20595305839291594,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.20595305839291594,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.7708944646429159,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.252282556683932,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -5.91508239188901,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -6.96395820060483,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "(((",
                                                "logprob": -7.106778558881198,
                                                "bytes": [
                                                    40,
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -7.8152298299383265,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -8.019240793378268,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.268256601483737,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.540599283368502,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -8.604448732526217,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Analy",
                                                "logprob": -8.90199988761655,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    97,
                                                    108,
                                                    121
                                                ]
                                            },
                                            {
                                                "token": "((((",
                                                "logprob": -8.90586608329526,
                                                "bytes": [
                                                    40,
                                                    40,
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -8.924998697431002,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -8.930737909467135,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.225524362714205,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -9.226540979535494,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "analyze",
                                                "logprob": -9.263528284222994,
                                                "bytes": [
                                                    97,
                                                    110,
                                                    97,
                                                    108,
                                                    121,
                                                    122,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -9.277677950055514,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "An",
                                                "logprob": -9.299880441815768,
                                                "bytes": [
                                                    65,
                                                    110
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.8270612695461484,
                                            "support": 2,
                                            "entropy": 0.46051548022138,
                                            "selection_ms": 0.116637,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.46051548022138
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.46051548022138
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.8270612695461484,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.17293873045385152,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 94,
                        "completion_tokens": 1,
                        "total_tokens": 95,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 94,
                        "prompt_ms": 811.1,
                        "prompt_per_token_ms": 8.629,
                        "prompt_per_second": 115.9,
                        "predicted_n": 1,
                        "predicted_ms": 24.4,
                        "predicted_per_token_ms": 24.4,
                        "predicted_per_second": 41,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 929.9123999662697,
                "captured_at": "2026-10-04T04:31:01Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: ((x*x)+0)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-ace71682cf6d4d17837ded84",
                    "object": "chat.completion",
                    "created": 1791088260,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.021150603871523684,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.021150603871523684,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.094812408070743,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.7265587001850005,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.436809554677188,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -8.105530753712832,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.665328040700137,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -8.865449920277774,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.450227752309024,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -9.622186675648868,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.7709341198017,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -9.817342773060977,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -9.858959212880313,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -9.900205627064883,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -9.987209334950625,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.0541372448017,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.133739486317813,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.302189841847598,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "expression",
                                                "logprob": -10.31031228600043,
                                                "bytes": [
                                                    101,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "test",
                                                "logprob": -10.32753755150336,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -10.406236663441836,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9832696967788256,
                                            "support": 2,
                                            "entropy": 0.08502543275544325,
                                            "selection_ms": 0.13946,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.08502543275544325
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.08502543275544325
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9832696967788256,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.016730303221174473,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 90,
                        "completion_tokens": 1,
                        "total_tokens": 91,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 90,
                        "prompt_ms": 787.7,
                        "prompt_per_token_ms": 8.752,
                        "prompt_per_second": 114.3,
                        "predicted_n": 1,
                        "predicted_ms": 25.5,
                        "predicted_per_token_ms": 25.5,
                        "predicted_per_second": 39.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 838.5416999808513,
                "captured_at": "2026-10-04T04:31:02Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: ((x*x)+0)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-18b7557ce6e3405a88a8066e",
                    "object": "chat.completion",
                    "created": 1791088261,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.037579374055285025,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.037579374055285025,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -3.4816482827466912,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -6.031693296174426,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.240889386872668,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.33487780545177,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.507735089997668,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -8.894783811311145,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -8.903201894502063,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -8.997185544709582,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -9.384257154206653,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -9.714997129182239,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -9.74912341092052,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.749291257600207,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -9.762745694856067,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -9.78018744442882,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -10.221703366975207,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -10.330725507478137,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "As",
                                                "logprob": -10.521510915498157,
                                                "bytes": [
                                                    65,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Think",
                                                "logprob": -10.54677851651134,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107
                                                ]
                                            },
                                            {
                                                "token": "AB",
                                                "logprob": -10.569912748078723,
                                                "bytes": [
                                                    65,
                                                    66
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9690537697146702,
                                            "support": 2,
                                            "entropy": 0.13801612829616716,
                                            "selection_ms": 0.116607,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.13801612829616716
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.13801612829616716
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9690537697146702,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.030946230285329904,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 89,
                        "completion_tokens": 1,
                        "total_tokens": 90,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 89,
                        "prompt_ms": 799.3,
                        "prompt_per_token_ms": 8.981,
                        "prompt_per_second": 111.3,
                        "predicted_n": 1,
                        "predicted_ms": 25.5,
                        "predicted_per_token_ms": 25.5,
                        "predicted_per_second": 39.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 868.1027999846265,
                "captured_at": "2026-10-04T04:31:02Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: ((x*x)+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression equal to x for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-e345a38df14946c08d38cbbe",
                    "object": "chat.completion",
                    "created": 1791088262,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.01504419906386703,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.01504419906386703,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.4299173222328125,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.975890146329492,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.025046335294336,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.953362451627344,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -9.435276971891016,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.54801844222793,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -9.803775774076074,
                                                "bytes": [
                                                    88
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -10.005144105985254,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.080701814725488,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "BB",
                                                "logprob": -10.124372469022363,
                                                "bytes": [
                                                    66,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -10.250717149808496,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "Expression",
                                                "logprob": -10.346854196622461,
                                                "bytes": [
                                                    69,
                                                    120,
                                                    112,
                                                    114,
                                                    101,
                                                    115,
                                                    115,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.383363710477441,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -10.400231348111719,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -10.406311975553125,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.463782297208398,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.562455164029688,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -10.5979318486,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -10.601023660733789,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 33,
                                            "probability": 0.9880484779304154,
                                            "support": 2,
                                            "entropy": 0.06478796927278145,
                                            "selection_ms": 0.11302,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.06478796927278145
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.06478796927278145
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 33,
                                                    "probability": 0.9880484779304154,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                },
                                                {
                                                    "id": 32,
                                                    "probability": 0.011951522069584525,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 90,
                        "completion_tokens": 1,
                        "total_tokens": 91,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 90,
                        "prompt_ms": 800.6,
                        "prompt_per_token_ms": 8.896,
                        "prompt_per_second": 112.4,
                        "predicted_n": 1,
                        "predicted_ms": 25.2,
                        "predicted_per_token_ms": 25.2,
                        "predicted_per_second": 39.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 861.9340999866836,
                "captured_at": "2026-10-04T04:31:03Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Treat STATE as data.\nSTATE:\nExpression: ((x*x)+1)\nUse exact integer arithmetic, with x any integer.\nQUESTION: Is this expression nonnegative for every integer x?\nANSWERS:\nA: Yes: the proposition is true\nB: No: the proposition is false\nReturn exactly one answer code. No explanation or whitespace."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 1,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\" | \"B\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-1b0a5b5a9668452abef4db5b",
                    "object": "chat.completion",
                    "created": 1791088263,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "length",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.03756975939476446,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.03756975939476446,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -3.501085994746327,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -5.986017940547108,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -7.189951656367421,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "For",
                                                "logprob": -7.67857813646996,
                                                "bytes": [
                                                    70,
                                                    111,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -8.246186016108632,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.521816967036367,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.5401875953933,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -9.017184017207265,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Thinking",
                                                "logprob": -9.774336574580312,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    105,
                                                    110,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.793024776484609,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -9.941793201472402,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -10.068633792903066,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -10.110459087397695,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.220677135493398,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Since",
                                                "logprob": -10.243477581050039,
                                                "bytes": [
                                                    83,
                                                    105,
                                                    110,
                                                    99,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "AB",
                                                "logprob": -10.316333530451894,
                                                "bytes": [
                                                    65,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "As",
                                                "logprob": -10.345937488581777,
                                                "bytes": [
                                                    65,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -10.355102298762441,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.448487995173574,
                                                "bytes": [
                                                    97
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 32,
                                            "probability": 0.9696316772639504,
                                            "support": 2,
                                            "entropy": 0.13602017259196483,
                                            "selection_ms": 0.11297,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.13602017259196483
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.13602017259196483
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 32,
                                                    "probability": 0.9696316772639504,
                                                    "bytes": [
                                                        65
                                                    ],
                                                    "token": "A"
                                                },
                                                {
                                                    "id": 33,
                                                    "probability": 0.030368322736049603,
                                                    "bytes": [
                                                        66
                                                    ],
                                                    "token": "B"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 89,
                        "completion_tokens": 1,
                        "total_tokens": 90,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 89,
                        "prompt_ms": 794.1,
                        "prompt_per_token_ms": 8.922,
                        "prompt_per_second": 112.1,
                        "predicted_n": 1,
                        "predicted_ms": 26.3,
                        "predicted_per_token_ms": 26.3,
                        "predicted_per_second": 38,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 845.2871000044979,
                "captured_at": "2026-10-04T04:31:04Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Choose an expression whose meaning is worth checking. Return only the expression."
                        }
                    ],
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 64,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"x\" | \"((x+1)-1)\" | \"(x+0)\" | \"(1*x)\" | \"((x-x)+x)\" | \"((2*x)-x)\" | \"(x+1)\" | \"(x-1)\" | \"(x*x)\" | \"(((x+1)*(x-1))+1)\" | \"((x*x)+0)\" | \"((x*x)+1)\"",
                    "strata_sampler": {
                        "chain": [
                            "temperature"
                        ],
                        "temperature": 1,
                        "inspect": True
                    }
                },
                "response": {
                    "id": "chatcmpl-73e407a815fb4cf3ab2afeda",
                    "object": "chat.completion",
                    "created": 1791088264,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "(1*x)"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "(",
                                        "logprob": -4.211707392782849,
                                        "bytes": [
                                            40
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "2",
                                                "logprob": -2.3854945097872426,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": "`",
                                                "logprob": -2.4553206358858755,
                                                "bytes": [
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -2.514120379538219,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -2.6422388945528676,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -3.104099551291149,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -3.1672203932711294,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "x",
                                                "logprob": -3.532707491964977,
                                                "bytes": [
                                                    120
                                                ]
                                            },
                                            {
                                                "token": "sqrt",
                                                "logprob": -3.632331172079723,
                                                "bytes": [
                                                    115,
                                                    113,
                                                    114,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -3.880342761130016,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -3.8844254408785512,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -4.090537348837536,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "(",
                                                "logprob": -4.211707392782849,
                                                "bytes": [
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "$$",
                                                "logprob": -4.314987460226696,
                                                "bytes": [
                                                    36,
                                                    36
                                                ]
                                            },
                                            {
                                                "token": "e",
                                                "logprob": -4.4052451048800165,
                                                "bytes": [
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "$\\",
                                                "logprob": -4.531498232931774,
                                                "bytes": [
                                                    36,
                                                    92
                                                ]
                                            },
                                            {
                                                "token": "$",
                                                "logprob": -4.599783221335095,
                                                "bytes": [
                                                    36
                                                ]
                                            },
                                            {
                                                "token": "Choose",
                                                "logprob": -4.731452265829724,
                                                "bytes": [
                                                    67,
                                                    104,
                                                    111,
                                                    111,
                                                    115,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -4.755179682821911,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -4.7581408415743525,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "((",
                                                "logprob": -4.84272030934779,
                                                "bytes": [
                                                    40,
                                                    40
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 0,
                                            "id": 7,
                                            "probability": 0.2817279822732899,
                                            "support": 5,
                                            "entropy": 1.0312132455335141,
                                            "selection_ms": 0.113892,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 5,
                                                    "entropy": 1.0312132455335141
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 5,
                                                    "entropy": 1.0312132455335141
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 87,
                                                    "probability": 0.5555407170206278,
                                                    "bytes": [
                                                        120
                                                    ],
                                                    "token": "x"
                                                },
                                                {
                                                    "id": 7,
                                                    "probability": 0.2817279822732899,
                                                    "bytes": [
                                                        40
                                                    ],
                                                    "token": "("
                                                },
                                                {
                                                    "id": 1148,
                                                    "probability": 0.14989410632804026,
                                                    "bytes": [
                                                        40,
                                                        40
                                                    ],
                                                    "token": "(("
                                                },
                                                {
                                                    "id": 2007,
                                                    "probability": 0.009478785972524308,
                                                    "bytes": [
                                                        40,
                                                        120
                                                    ],
                                                    "token": "(x"
                                                },
                                                {
                                                    "id": 6427,
                                                    "probability": 0.0033584084055178222,
                                                    "bytes": [
                                                        40,
                                                        40,
                                                        40
                                                    ],
                                                    "token": "((("
                                                }
                                            ]
                                        }
                                    },
                                    {
                                        "token": "1",
                                        "logprob": -0.5092159910800459,
                                        "bytes": [
                                            49
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "1",
                                                "logprob": -0.5092159910800459,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "2",
                                                "logprob": -2.4234539671542645,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -2.577737490713835,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -2.69229380327487,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -3.30237738329196,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "4",
                                                "logprob": -3.7880188627841473,
                                                "bytes": [
                                                    52
                                                ]
                                            },
                                            {
                                                "token": "7",
                                                "logprob": -3.924931208670378,
                                                "bytes": [
                                                    55
                                                ]
                                            },
                                            {
                                                "token": "9",
                                                "logprob": -4.471318881094694,
                                                "bytes": [
                                                    57
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -4.8705059691073895,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "8",
                                                "logprob": -5.23265139299655,
                                                "bytes": [
                                                    56
                                                ]
                                            },
                                            {
                                                "token": " ",
                                                "logprob": -5.543575923025847,
                                                "bytes": [
                                                    32
                                                ]
                                            },
                                            {
                                                "token": "√",
                                                "logprob": -5.707276980459929,
                                                "bytes": [
                                                    226,
                                                    136,
                                                    154
                                                ]
                                            },
                                            {
                                                "token": "�",
                                                "logprob": -5.869870822012663,
                                                "bytes": [
                                                    226,
                                                    136
                                                ]
                                            },
                                            {
                                                "token": "!!",
                                                "logprob": -5.972071330130339,
                                                "bytes": [
                                                    33,
                                                    33
                                                ]
                                            },
                                            {
                                                "token": "\n",
                                                "logprob": -6.083629290640593,
                                                "bytes": [
                                                    10
                                                ]
                                            },
                                            {
                                                "token": "\n\n",
                                                "logprob": -6.112152735769987,
                                                "bytes": [
                                                    10,
                                                    10
                                                ]
                                            },
                                            {
                                                "token": "λ",
                                                "logprob": -6.539027850210905,
                                                "bytes": [
                                                    206,
                                                    187
                                                ]
                                            },
                                            {
                                                "token": " (",
                                                "logprob": -6.541910807669401,
                                                "bytes": [
                                                    32,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "<|endoftext|>",
                                                "logprob": -6.571901957571745,
                                                "bytes": None
                                            },
                                            {
                                                "token": " a",
                                                "logprob": -6.683499972403288,
                                                "bytes": [
                                                    32,
                                                    97
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 1,
                                            "id": 16,
                                            "probability": 0.999995830029442,
                                            "support": 5,
                                            "entropy": 0.00005820036510486225,
                                            "selection_ms": 0.113892,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 5,
                                                    "entropy": 0.00005820036510486225
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 5,
                                                    "entropy": 0.00005820036510486225
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 16,
                                                    "probability": 0.999995830029442,
                                                    "bytes": [
                                                        49
                                                    ],
                                                    "token": "1"
                                                },
                                                {
                                                    "id": 1148,
                                                    "probability": 0.0000035384608054184848,
                                                    "bytes": [
                                                        40,
                                                        40
                                                    ],
                                                    "token": "(("
                                                },
                                                {
                                                    "id": 87,
                                                    "probability": 3.4818349703614387e-7,
                                                    "bytes": [
                                                        120
                                                    ],
                                                    "token": "x"
                                                },
                                                {
                                                    "id": 7,
                                                    "probability": 2.0504913855245548e-7,
                                                    "bytes": [
                                                        40
                                                    ],
                                                    "token": "("
                                                },
                                                {
                                                    "id": 2007,
                                                    "probability": 7.82771170837418e-8,
                                                    "bytes": [
                                                        40,
                                                        120
                                                    ],
                                                    "token": "(x"
                                                }
                                            ]
                                        }
                                    },
                                    {
                                        "token": "*",
                                        "logprob": -9.83770152718637,
                                        "bytes": [
                                            42
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": " +",
                                                "logprob": -1.4730107465467224,
                                                "bytes": [
                                                    32,
                                                    43
                                                ]
                                            },
                                            {
                                                "token": " /",
                                                "logprob": -1.7045399823865661,
                                                "bytes": [
                                                    32,
                                                    47
                                                ]
                                            },
                                            {
                                                "token": " <<",
                                                "logprob": -1.9922978559217224,
                                                "bytes": [
                                                    32,
                                                    60,
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -2.3663956800184023,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "/",
                                                "logprob": -2.626195637293793,
                                                "bytes": [
                                                    47
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -2.786612240382172,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " ==",
                                                "logprob": -3.2446410337171327,
                                                "bytes": [
                                                    32,
                                                    61,
                                                    61
                                                ]
                                            },
                                            {
                                                "token": ",",
                                                "logprob": -3.7985789457044374,
                                                "bytes": [
                                                    44
                                                ]
                                            },
                                            {
                                                "token": " -",
                                                "logprob": -3.8133637586316835,
                                                "bytes": [
                                                    32,
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "+",
                                                "logprob": -4.099909512110687,
                                                "bytes": [
                                                    43
                                                ]
                                            },
                                            {
                                                "token": "2",
                                                "logprob": -4.2613312879285585,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": " >",
                                                "logprob": -4.42824336678598,
                                                "bytes": [
                                                    32,
                                                    62
                                                ]
                                            },
                                            {
                                                "token": " <",
                                                "logprob": -4.62382671029184,
                                                "bytes": [
                                                    32,
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -4.751979557581879,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "7",
                                                "logprob": -4.972516743250824,
                                                "bytes": [
                                                    55
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -5.061221806117035,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": " !=",
                                                "logprob": -5.078162876673676,
                                                "bytes": [
                                                    32,
                                                    33,
                                                    61
                                                ]
                                            },
                                            {
                                                "token": ")",
                                                "logprob": -5.133243290492035,
                                                "bytes": [
                                                    41
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -5.254750935145355,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "9",
                                                "logprob": -5.469378201075531,
                                                "bytes": [
                                                    57
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 2,
                                            "id": 9,
                                            "probability": 0.8784136912070387,
                                            "support": 2,
                                            "entropy": 0.37007373114313097,
                                            "selection_ms": 0.1126,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 2,
                                                    "entropy": 0.37007373114313097
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 2,
                                                    "entropy": 0.37007373114313097
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 9,
                                                    "probability": 0.8784136912070387,
                                                    "bytes": [
                                                        42
                                                    ],
                                                    "token": "*"
                                                },
                                                {
                                                    "id": 17930,
                                                    "probability": 0.1215863087929612,
                                                    "bytes": [
                                                        42,
                                                        120
                                                    ],
                                                    "token": "*x"
                                                }
                                            ]
                                        }
                                    },
                                    {
                                        "token": "x",
                                        "logprob": -11.079480511021227,
                                        "bytes": [
                                            120
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "2",
                                                "logprob": -1.132863384556383,
                                                "bytes": [
                                                    50
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -1.3641675532575548,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -1.8678124964948595,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -2.378253322910875,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -3.9246438563581405,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "4",
                                                "logprob": -4.0068238795515,
                                                "bytes": [
                                                    52
                                                ]
                                            },
                                            {
                                                "token": "8",
                                                "logprob": -4.203275066685289,
                                                "bytes": [
                                                    56
                                                ]
                                            },
                                            {
                                                "token": "7",
                                                "logprob": -4.290414196323961,
                                                "bytes": [
                                                    55
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -4.298295360874742,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "9",
                                                "logprob": -4.529340130161851,
                                                "bytes": [
                                                    57
                                                ]
                                            },
                                            {
                                                "token": "sqrt",
                                                "logprob": -5.028619152378648,
                                                "bytes": [
                                                    115,
                                                    113,
                                                    114,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": " ",
                                                "logprob": -5.121857982945055,
                                                "bytes": [
                                                    32
                                                ]
                                            },
                                            {
                                                "token": "+",
                                                "logprob": -5.177617412876695,
                                                "bytes": [
                                                    43
                                                ]
                                            },
                                            {
                                                "token": "exp",
                                                "logprob": -5.6410697520490585,
                                                "bytes": [
                                                    101,
                                                    120,
                                                    112
                                                ]
                                            },
                                            {
                                                "token": " -",
                                                "logprob": -6.894120556187242,
                                                "bytes": [
                                                    32,
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "rand",
                                                "logprob": -6.896769863438219,
                                                "bytes": [
                                                    114,
                                                    97,
                                                    110,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -6.946973186802476,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": " (",
                                                "logprob": -7.050428730320543,
                                                "bytes": [
                                                    32,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": "int",
                                                "logprob": -7.05092845566234,
                                                "bytes": [
                                                    105,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -7.060738903355211,
                                                "bytes": [
                                                    69
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 3,
                                            "id": 87,
                                            "probability": 1,
                                            "support": 1,
                                            "entropy": 0,
                                            "selection_ms": 0.11305,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 1,
                                                    "entropy": 0
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 1,
                                                    "entropy": 0
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 87,
                                                    "probability": 1,
                                                    "bytes": [
                                                        120
                                                    ],
                                                    "token": "x"
                                                }
                                            ]
                                        }
                                    },
                                    {
                                        "token": ")",
                                        "logprob": -1.6531204548654481,
                                        "bytes": [
                                            41
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": ")",
                                                "logprob": -1.6531204548654481,
                                                "bytes": [
                                                    41
                                                ]
                                            },
                                            {
                                                "token": " +",
                                                "logprob": -2.0223945942697448,
                                                "bytes": [
                                                    32,
                                                    43
                                                ]
                                            },
                                            {
                                                "token": ")/",
                                                "logprob": -2.876347002106659,
                                                "bytes": [
                                                    41,
                                                    47
                                                ]
                                            },
                                            {
                                                "token": ")*",
                                                "logprob": -3.0428594914255065,
                                                "bytes": [
                                                    41,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "+",
                                                "logprob": -3.07432883651828,
                                                "bytes": [
                                                    43
                                                ]
                                            },
                                            {
                                                "token": " -",
                                                "logprob": -3.2185510960397643,
                                                "bytes": [
                                                    32,
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -3.29407924087619,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "*",
                                                "logprob": -3.3949388829049987,
                                                "bytes": [
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -3.7125753727731627,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": ")**",
                                                "logprob": -3.794187006073944,
                                                "bytes": [
                                                    41,
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": ")/(",
                                                "logprob": -3.9231762257394713,
                                                "bytes": [
                                                    41,
                                                    47,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": ")*(",
                                                "logprob": -3.98322719009494,
                                                "bytes": [
                                                    41,
                                                    42,
                                                    40
                                                ]
                                            },
                                            {
                                                "token": " ==",
                                                "logprob": -4.053686555939667,
                                                "bytes": [
                                                    32,
                                                    61,
                                                    61
                                                ]
                                            },
                                            {
                                                "token": "^",
                                                "logprob": -4.078093942719452,
                                                "bytes": [
                                                    94
                                                ]
                                            },
                                            {
                                                "token": "/",
                                                "logprob": -4.136602815705292,
                                                "bytes": [
                                                    47
                                                ]
                                            },
                                            {
                                                "token": ")^",
                                                "logprob": -4.389486726838104,
                                                "bytes": [
                                                    41,
                                                    94
                                                ]
                                            },
                                            {
                                                "token": ").",
                                                "logprob": -4.420134958344452,
                                                "bytes": [
                                                    41,
                                                    46
                                                ]
                                            },
                                            {
                                                "token": ")+",
                                                "logprob": -4.612466272431366,
                                                "bytes": [
                                                    41,
                                                    43
                                                ]
                                            },
                                            {
                                                "token": " !=",
                                                "logprob": -4.635986742096893,
                                                "bytes": [
                                                    32,
                                                    33,
                                                    61
                                                ]
                                            },
                                            {
                                                "token": "+y",
                                                "logprob": -4.758687433320038,
                                                "bytes": [
                                                    43,
                                                    121
                                                ]
                                            }
                                        ],
                                        "strata_sampling": {
                                            "index": 4,
                                            "id": 8,
                                            "probability": 1,
                                            "support": 1,
                                            "entropy": 0,
                                            "selection_ms": 0.11273,
                                            "stages": [
                                                {
                                                    "operator": "grammar",
                                                    "support": 1,
                                                    "entropy": 0
                                                },
                                                {
                                                    "operator": "temperature",
                                                    "support": 1,
                                                    "entropy": 0
                                                }
                                            ],
                                            "top": [
                                                {
                                                    "id": 8,
                                                    "probability": 1,
                                                    "bytes": [
                                                        41
                                                    ],
                                                    "token": ")"
                                                }
                                            ]
                                        }
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 26,
                        "completion_tokens": 6,
                        "total_tokens": 32,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 26,
                        "prompt_ms": 718.6,
                        "prompt_per_token_ms": 27.638,
                        "prompt_per_second": 36.2,
                        "predicted_n": 6,
                        "predicted_ms": 240.7,
                        "predicted_per_token_ms": 40.117,
                        "predicted_per_second": 24.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1035.411800025031,
                "captured_at": "2026-10-04T04:31:05Z"
            }
        ]
    },
    "wall_ms": 144.8344000382349,
    "lesson_view": {
        "index": 0,
        "value": 2,
        "scope": "Reproduce the selected question/rule/result panel. Other page dials are independent."
    }
}
import argparse
import copy
import hashlib
import json
import math
import os
import sys
from pathlib import Path
import urllib.error
import urllib.request

"""Small, portable calculations behind the question/rule/result panels.

Standard library only. This exact source is included in every Python download.
Inputs are the captured experiment, never an invented new model response. A knob
changes a disclosed calculation on those inputs; it does not rescore a new prompt.
"""
import itertools
import math
import statistics


def _spec(question, rule, knob, default, compare, low, high, integer=False):
    return dict(question=question, rule=rule, knob=knob, default=default,
                compare=compare, low=low, high=high, integer=integer)


LESSON_SPECS = {
    'choice': _spec('Which ticket queue gets this message?', 'Compare the three saved label scores. Heat flattens their relative weights; it adds no evidence.', 'Reweighting temperature', 1, 2, .1, 3),
    'boolean': _spec('Does this message ask to cancel?', 'Normalize the saved Yes and No scores. A number near one is a strong preference, not proof.', 'Reweighting temperature', 1, 2, .1, 3),
    'score': _spec('How serious is the outage?', 'Multiply each rubric value by its answer weight, then add. The rating comes from the whole distribution.', 'Reweighting temperature', 1, 2, .1, 3),
    'candidates': _spec('Read the failure first, or start changing things?', 'Add token logprobs along each saved path, then sum path mass inside each finite group. A length penalty changes the objective.', 'Length penalty exponent', 0, 1, 0, 1),
    'controller': _spec('May the simulated repair take its next step?', 'Keep only state-legal actions. Hold the recorded action if its relative legal weight falls below the threshold.', 'Required legal-action weight', 0, .999, 0, 1),
    'rerank': _spec('Which sources help explain cancellation?', 'Compute each source’s expected relevance separately, then keep those above the cutoff.', 'Minimum relevance', 0, .9, 0, 1),
    'graph': _spec('Which text links can coexist?', 'Search every small edge subset. Reject cycles and competing attachments, then maximize useful edge weight.', 'Edge cost / threshold', .5, .9, .01, .99),
    'scene': _spec('Which valid drawing best fits the instruction?', 'Average the three saved text probes. Optionally charge for disagreement between them; code still checks geometry.', 'Disagreement penalty', 0, 1, 0, 2),
    'wire': _spec('What did the model assign to this actual token?', 'Exponentiate its raw logprob. Sum only the reported alternatives; their top-N list may omit probability mass.', 'Visible token index (zero-based)', 0, 5, 0, 10000, True),
    'speculation': _spec('Why can a draft be rejected?', 'Compare the proposal head and target verification on the same proposed token. They are different distributions.', 'Proposal position (zero-based)', 0, 2, 0, 10000, True),
    'performance': _spec('What did each API path cost on this setup?', 'Recalculate a latency percentile from the original wall-time samples. Different output tasks remain separate.', 'Latency percentile', 50, 90, 0, 100),
    'samplers': _spec('How much did this recipe change the selected token’s weight?', 'Compare its raw target probability with its post-sampler probability. Read support and entropy from the complete native row.', 'Recorded recipe index (zero-based)', 0, 1, 0, 10000, True),
    'sampler-sandbox': _spec('Can we add heat without admitting implausible tokens?', 'Remove logits below max + log(0.05), then divide the survivors by temperature and normalize.', 'Temperature after Min-P', 1.5, .7, .1, 3),
    'tictactoe': _spec('Did a legal move give away a winnable outcome?', 'Solve the saved position by exhaustive minimax. Compare the best legal outcome with the recorded model move.', 'Recorded turn index (zero-based)', 0, 1, 0, 10000, True),
    'chess': _spec('Did the shortlist favor a mating move?', 'Add the saved label weights attached to code-checked mating moves. The separately generated UCI move uses a different prompt.', 'Shortlist temperature', 1, 3, .1, 3),
    'poker': _spec('Should this hand check or bet?', 'Average exact chip payoffs over the two possible opponent cards using the stated calling policy.', 'Opponent call-rate multiplier', 1, 0, 0, 2),
    'thermal': _spec('What happens if we replay the fan commands differently?', 'Step the disclosed thermal equation through the same loads. A fan offset is an open-loop counterfactual, not a new model policy.', 'Fan offset', 0, 20, -60, 60),
    'scheduler': _spec('How much lateness did this legal schedule cause?', 'Add job durations in the recorded order and check dependencies. Charge for finishing after the adjusted deadline.', 'Deadline shift', 0, -3, -10, 10),
    'context': _spec('Did replacing old text change the current-state answer?', 'Recalculate each saved Yes/No distribution and compare the selected wording with the original append-only prompt.', 'Context variant index (zero-based)', 0, 2, 0, 10000, True),
    'observer': _spec('Which action follows from these three semantic measurements?', 'Apply the same explicit threshold rule to every saved report: inspect, verify, finish, or ask.', 'Decision threshold', .5, .999, 0, 1),
    'calibration': _spec('Does demanding stronger answers leave enough coverage?', 'Recalculate Brier error on all six examples and accuracy only on retained examples. Empty coverage has no accuracy.', 'Required answer weight', .5, 1, .5, 1),
    'information': _spec('Which observation is worth buying?', 'Use the stated sensor likelihoods to compute both Bayesian posteriors and expected entropy reduction.', 'Test index (zero-based)', 0, 1, 0, 10000, True),
    'search': _spec('Which valid scene survives a cost penalty?', 'Subtract the chosen cost charge from each saved semantic weight. Reject invalid geometry before ranking.', 'Cost weight', .1, 1, 0, 1),
    'frontier': _spec('Would faster score transfer matter here?', 'Add assumed forward time, a transfer lower bound, and the measured selector. This is a serial cost sketch.', 'Assumed transfer GB/s', 12, 2, .1, 128),
    'research-map': _spec('What would make this research idea testable?', 'Count the disclosed implementation categories, then reveal one branch’s next gate. A proposal is not a native result.', 'Branch index (zero-based)', 0, 12, 0, 10000, True),
    'pressure': _spec('How much original mass did this boundary throw away?', 'At temperature 1 with pure masking, log Z = raw selected logprob − log(selected masked probability). Pressure is −log Z.', 'Native grammar index (zero-based)', 0, 1, 0, 10000, True),
    'circuit': _spec('Can we compute AND without assuming independence?', 'Start with four joint worlds. Optionally condition on noisy evidence of style, then add worlds for each logical operation.', 'Reliability of observing style', .5, 1, .5, 1),
    'control': _spec('Can preference change while forbidden actions stay forbidden?', 'Normalize log(base) + strength × [log(desired) − log(undesired)] inside the legal set.', 'Control strength', 0, 2, 0, 3),
    'future': _spec('Can a less likely first move have a better future?', 'Weight the root policy by exact future success raised to strength. At strength zero use the base policy.', 'Future-value strength', 0, 1, 0, 2),
    'sensitivity': _spec('Which prompt intervention moves this measurement?', 'Rebuild the central finite-difference matrix. Predict a change in hours, with load fixed at +5 points; preserve the measured holdout error.', 'Change in hours remaining', -1, -2, -2, 2),
    'counterexamples': _spec('Can equivalent algebra confuse the observer?', 'Find the equivalent pair with the largest measured log-odds distance. Evaluate its exact coefficients at the chosen integer.', 'Integer x', 2, -2, -10, 10, True),
}


def normalize_logs(logs):
    finite = [x for x in logs if math.isfinite(x)]
    if not finite:
        raise ValueError('No candidate has positive mass')
    maximum = max(finite)
    weights = [math.exp(x-maximum) if math.isfinite(x) else 0. for x in logs]
    total = math.fsum(weights)
    return [w/total for w in weights]


def weights(rows, temperature=1):
    if any(r.get('logprob') is None for r in rows):
        raise ValueError('A complete label measurement is required; missing top-N entries stay unknown')
    return normalize_logs([r['logprob']/temperature for r in rows])


def entropy(p):
    return -math.fsum(x*math.log2(x) for x in p if x)


def _pick(items, value):
    if not 0 <= value < len(items):
        raise ValueError('Index must be 0..'+str(len(items)-1))
    return items[int(value)]


def _rows(names, values):
    return [dict(label=str(n), value=float(v)) for n,v in zip(names,values)]


def _graph(edges, threshold):
    if len(edges)>12:
        raise ValueError('This exact demonstration supports at most 12 edges')
    best, score = [], 0.
    for bits in itertools.product((False,True), repeat=len(edges)):
        selected=[e for e,yes in zip(edges,bits) if yes]
        out, incoming, captions = {}, set(), set()
        good=True
        for e in selected:
            a,b=e['source'],e['target']
            if a==b:good=False;break
            if e['relation']=='caption':
                if a in captions:good=False;break
                captions.add(a)
            else:
                if a in out or b in incoming:good=False;break
                out[a]=b;incoming.add(b)
        for start in out:
            node,visited=start,set()
            while node in out:
                if node in visited:good=False;break
                visited.add(node);node=out[node]
        utility=math.fsum(e['weight']-threshold for e in selected)
        if good and utility>score:best,score=selected,utility
    return best,score


def _ttt(board, turn):
    lines=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
    for a,b,c in lines:
        if board[a]!='.' and board[a]==board[b]==board[c]:return 1 if board[a]=='X' else -1
    if '.' not in board:return 0
    values=[_ttt(board[:i]+turn+board[i+1:],'O' if turn=='X' else 'X') for i,s in enumerate(board) if s=='.']
    return (max if turn=='X' else min)(values)


def calculate_lesson(name, data, value=None):
    spec=LESSON_SPECS[name]
    v=spec['default'] if value is None else value
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not spec['low']<=v<=spec['high'] or (spec['integer'] and int(v)!=v):
        raise ValueError(f"{spec['knob']} must be {'an integer' if spec['integer'] else 'finite'} in [{spec['low']}, {spec['high']}]")
    rows=[];metrics={};note='Calculation on saved inputs; changing this setting makes no new model request.'
    summary='';unit='weight'
    if name in ('choice','boolean','score'):
        p=weights(data['rows'],v);at=max(range(len(p)),key=p.__getitem__)
        rows=_rows([r['label']+' · '+r.get('description','') for r in data['rows']],p)
        metrics=dict(winner=data['rows'][at]['label'],top_weight=p[at],entropy_bits=entropy(p))
        if name in ('boolean','score'):
            metrics['expected_value']=math.fsum(q*r['value'] for q,r in zip(p,data['rows']))
        summary=f"Answer {metrics['winner']} leads with {p[at]:.2%} of the listed-label weight."
        if name=='score':summary=f"Expected rubric value: {metrics['expected_value']:.4f} on the stated 0–1 scale."
    elif name=='candidates':
        paths=data['paths'];logs=[math.fsum(t['logprob'] for t in r['tokens'])/len(r['tokens'])**v for r in paths]
        p=normalize_logs(logs);names=list(dict.fromkeys(r['group'] for r in paths))
        values=[math.fsum(q for q,r in zip(p,paths) if r['group']==g) for g in names];rows=_rows(names,values)
        metrics=dict(winner=names[values.index(max(values))],group_weights=values)
        summary=metrics['winner']+' carries the most relative group weight.'
        note='Only these emitted token paths, with their saved terminators and no EOS. A nonzero length penalty produces preference scores, not path probability.'
    elif name=='controller':
        labels=data['measure']['rows'];p=weights(labels);legal=[i for i,r in enumerate(labels) if r['allowed']]
        mass=math.fsum(p[i] for i in legal);pick=next(i for i,r in enumerate(labels) if r['action']==data['action'])
        q=p[pick]/mass;held=q<v
        rows=_rows([labels[i]['action'] for i in legal],[p[i]/mass for i in legal])
        metrics=dict(held=held,selected_weight=q,next_state=data['state'] if held else data['next_state'])
        summary=('Hold the action.' if held else 'Apply '+data['action']+'.')+' State: '+metrics['next_state']+'.'
    elif name=='rerank':
        values=[math.fsum(q*r['value'] for q,r in zip(weights(s['measure']['rows']),s['measure']['rows'])) for s in data['sources']]
        rows=_rows([s['id'] for s in data['sources']],values);kept=[r['label'] for r in rows if r['value']>=v]
        metrics=dict(retained=kept,scores=values);summary='Retain '+(', '.join(kept) or 'no sources')+' at this cutoff.'
    elif name=='graph':
        selected,utility=_graph(data['edges'],v);rows=_rows([e['source']+' → '+e['target'] for e in selected],[e['weight']-v for e in selected]);unit='utility'
        metrics=dict(selected=[(e['source'],e['target'],e['relation']) for e in selected],utility=utility)
        summary=f'{len(selected)} compatible links, total utility {utility:.4f}.'
        note='Global code constraints select links; utility is not the probability that the document graph is correct.'
    elif name=='scene':
        valid=[c for c in data['candidates'] if c['valid']];values=[]
        for c in valid:
            p=[weights(x['measure']['rows'])[0] for x in c['vector']]
            values.append(statistics.mean(p)-v*statistics.pvariance(p))
        rows=_rows([c['name'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['name'],utilities=values)
        summary='Retain '+metrics['retained']+' among geometry-valid candidates.'
        note='These are saved text judgments. This calculation cannot see the drawing or measure visual appeal.'
    elif name=='wire':
        entry=_pick(data['entries'],v);p=math.exp(entry['logprob']);top=entry.get('top_logprobs',[])
        rows=_rows([x['token'] for x in top],[math.exp(x['logprob']) for x in top]);unit='raw probability'
        metrics=dict(token=entry['token'],raw_probability=p,reported_top_mass=math.fsum(r['value'] for r in rows))
        summary=f"Token {entry['token']!r}: raw probability {p:.6g}."
        note='This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary.'
    elif name=='speculation':
        window=data['oracle']['example_rejection'];r=_pick(window['proposal'],v)
        rows=_rows(['Draft head','Target verification'],[r['draft_probability'],math.exp(r['target_logprob'])]);unit='probability / distinct heads'
        metrics=dict(token_id=r['token_id'],target_sequence_logprob=math.fsum(x['target_logprob'] for x in window['proposal']),draft_target_logprob_gap=r['draft_logprob']-r['target_logprob'])
        summary=f"Proposal token {r['token_id']}: the two heads differ by {metrics['draft_target_logprob_gap']:.4f} log units."
        note='Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability.'
    elif name=='performance':
        values=[]
        for r in data['rows']:
            xs=sorted(x['wall_ms'] for x in r['runs']);a=(len(xs)-1)*v/100;lo=math.floor(a);hi=math.ceil(a)
            values.append(xs[lo]+(xs[hi]-xs[lo])*(a-lo))
        rows=_rows([r['name'] for r in data['rows']],values);unit='ms';metrics=dict(percentile=v,times_ms=values)
        summary=f'Percentile {v:g}, recalculated from {data["repeats"]} samples per path.'
        note='Small same-setup samples include network and API cost. JSON answers a different task; this is no universal speed ranking.'
    elif name=='samplers':
        run=_pick(data['runs'],v);token=run['tokens'][0];sample=token['strata_sampling']
        raw=math.exp(token['logprob']);post=sample['probability']
        rows=_rows(['Raw target','After recipe'],[raw,post]);unit='selected token probability'
        metrics=dict(recipe=run['name'],support=sample['support'],raw=raw,selected=post,log_weight_change=math.log(post)-token['logprob'],entropy_bits=sample['entropy']/math.log(2))
        summary=f"{run['name']}: {sample['support']} native tokens remain eligible."
        note='Recipes are separate generations. Entropy and support are full-row native measurements; a top-N slice cannot recover them.'
    elif name=='sampler-sandbox':
        cut=max(data['logits'])+math.log(.05);logs=[x/v if x>=cut else -math.inf for x in data['logits']];p=normalize_logs(logs)
        rows=_rows(data['tokens'],p);metrics=dict(support=sum(x>0 for x in p),entropy_bits=entropy(p),probabilities=p)
        summary=f"{metrics['support']} credible tokens survive; entropy {metrics['entropy_bits']:.3f} bits."
        note='All eight logits are synthetic and visible. This is exact finite-row arithmetic, not a new native receipt.'
    elif name=='tictactoe':
        f=_pick(data['frames'],v);b=f['before'];legal=[i for i,c in enumerate(b) if c=='.'];oracle={i:_ttt(b[:i]+'X'+b[i+1:],'O') for i in legal}
        regret=max(oracle.values())-oracle[f['square']];rows=_rows([str(i+1) for i in legal],list(oracle.values()));unit='X outcome: lose −1 / draw 0 / win 1'
        metrics=dict(regret=regret,square=f['square']+1,oracle=oracle);summary=f"Recorded move: square {f['square']+1}; exact outcome regret {regret}."
    elif name=='chess':
        p=weights(data['measure']['rows'],v);mass=math.fsum(q for q,m in zip(p,data['shortlist']) if m['mate'])
        rows=_rows([m['san'] for m in data['shortlist']],p);metrics=dict(mating_shortlist_weight=mass,generated_uci=data['chosen']['text'],generated_mate=data['mate'])
        summary=f'{mass:.2%} of shortlist weight favors mate; the separate UCI generation '+('mated.' if data['mate'] else 'did not mate.')
        note='The saved legal/mate flags came from python-chess. This portable calculation aggregates them; it is not a replacement chess engine.'
    elif name=='poker':
        ranks=['J','Q','K'];rates={c:min(1,max(0,r*v)) for c,r in data['call_rates'].items()};values={}
        for own in ranks:
            opponents=[c for c in ranks if c!=own];sign=lambda c:1 if ranks.index(own)>ranks.index(c) else -1
            values[own]=dict(check=statistics.mean(sign(c) for c in opponents),bet=statistics.mean((1-rates[c])+rates[c]*2*sign(c) for c in opponents))
        rows=_rows([c+' bet − check' for c in ranks],[values[c]['bet']-values[c]['check'] for c in ranks]);unit='expected chips'
        metrics=dict(values=values,call_rates=rates);summary='Bet when the bar is positive; check when it is negative.'
        note='Uniform remaining-card prior and explicitly assumed opponent policy. Answer weights are not hidden-card beliefs or equilibrium probabilities.'
    elif name=='thermal':
        t=data['frames'][0]['temperature'];temperatures=[]
        for f in data['frames']:
            fan=min(60,max(0,f['fan']+v));t=round(t+.22*f['load']-.32*fan-.04*(t-25),3);temperatures.append(t)
        rows=_rows(range(1,len(temperatures)+1),temperatures);unit='°C';metrics=dict(temperatures=temperatures,mean_error=statistics.mean(abs(t-data['target']) for t in temperatures),violations=sum(t>data['limit'] for t in temperatures))
        summary=f"Mean distance from target: {metrics['mean_error']:.2f}°C; {metrics['violations']} limit violations."
        note='Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control.'
    elif name=='scheduler':
        done=set();clock=0;late=[]
        for f in data['frames']:
            j=f['job']
            if not set(j['after'])<=done:raise ValueError('Saved schedule violates dependencies')
            clock+=j['duration'];late.append(max(0,clock-j['deadline']-v));done.add(j['id'])
        rows=_rows([f['job']['id'] for f in data['frames']],late);unit='late time units';metrics=dict(total_lateness=sum(late),finish_time=clock)
        summary=f'Total lateness {sum(late):g}; the same dependency-valid order ends at time {clock}.'
    elif name=='context':
        selected=_pick(data['runs'],v);all_weights=[weights(r['measure']['rows'])[1] for r in data['runs']];p=all_weights[int(v)]
        rows=_rows([r['name'] for r in data['runs']],all_weights);metrics=dict(variant=selected['name'],no_weight=p,delta_from_append=p-all_weights[0])
        summary=f"{selected['name']}: keep-still answer weight {p:.3%}."
        note='Saved prompt interventions, not KV tensor mutation. This calculation compares their recorded measurements.'
    elif name=='observer':
        actions=[];triples=[]
        for f in data['frames']:
            p=[weights(x['measure']['rows'])[0] for x in f['vector']];triples.append(p)
            actions.append('inspect failure' if p[0]>v else 'verify' if p[1]>v else 'finish' if p[2]>v else 'ask')
        rows=_rows(['Fault','Missing check','Verified'],triples[0]);metrics=dict(actions=actions,vectors=triples)
        summary=' → '.join(actions)+'.';note='Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability.'
    elif name=='calibration':
        p=[weights(r['measure']['rows'])[0] for r in data['rows']];truth=[r['truth'] for r in data['rows']];kept=[i for i,q in enumerate(p) if max(q,1-q)>=v]
        brier=statistics.mean((q-y)**2 for q,y in zip(p,truth));accuracy=statistics.mean(int(p[i]>=.5)==truth[i] for i in kept) if kept else None
        rows=_rows([str(i+1) for i in range(len(p))],p);metrics=dict(brier=brier,retained=len(kept),coverage=len(kept)/len(p),accuracy=accuracy)
        summary=f'{len(kept)}/{len(p)} retained; '+(f'{accuracy:.1%} correct in those cases.' if accuracy is not None else 'accuracy is undefined with zero coverage.')
        note='Six disclosed teaching examples, not a held-out calibration benchmark. Brier error still counts every example.'
    elif name=='information':
        t=_pick(data['tests'],v);prior=data['prior'];py=math.fsum(p*l for p,l in zip(prior,t['likelihood']));yes=[p*l/py for p,l in zip(prior,t['likelihood'])];no=[p*(1-l)/(1-py) for p,l in zip(prior,t['likelihood'])]
        gain=entropy(prior)-py*entropy(yes)-(1-py)*entropy(no);rows=_rows(data['faults'],yes)
        metrics=dict(test=t['name'],gain_bits=gain,gain_per_cost=gain/t['cost'],yes=yes,no=no)
        summary=t['name']+f': {gain:.3f} expected bits; {gain/t["cost"]:.3f} bits per cost unit.'
        note='Prior and likelihoods are stated synthetic sensor assumptions. Bars condition on a positive result; no test was actually purchased.'
    elif name=='search':
        valid=[c for c in data['candidates'] if c['valid']];values=[weights(c['measure']['rows'])[0]-v*c['cost']/3 for c in valid]
        rows=_rows([c['id'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['id'],utilities=values)
        summary='Retain '+metrics['retained']+' after charging for cost; invalid geometry is excluded.'
    elif name=='frontier':
        selector=sorted(r['selection_ms'] for r in data['measurements'])[len(data['measurements'])//2];transfer=data['vocabulary']*data['bytes_per_logit']/(v*1e6);total=60+transfer+selector
        rows=_rows(['Assumed forward','Transfer lower bound','Measured host selector'],[60,transfer,selector]);unit='ms'
        metrics=dict(transfer_ms=transfer,serial_ms=total,tokens_per_second=1000/total)
        summary=f'Serial estimate: {total:.3f} ms/token; {1000/total:.2f} tokens/s.'
        note='Forward time is assumed 60 ms. Selector uses the upper-middle measured sample to match the chart. Queue, prefill and network are excluded.'
    elif name=='research-map':
        branch=_pick(data['branches'],v);categories={}
        for b in data['branches']:categories[b['status']]=categories.get(b['status'],0)+1
        rows=_rows(list(categories),list(categories.values()));unit='branches';metrics=dict(branch=branch['name'],gate=branch['gate'],categories=categories)
        summary=branch['name']+': '+branch['gate'];note='This page recomputes an agenda inventory, not an experiment result. Each implemented branch links to its own evidence.'
    elif name=='pressure':
        case=_pick(data['cases'],v);r=case['rows'][0];token=r['token'];q=token['strata_sampling']['probability'];logz=token['logprob']-math.log(q)
        if logz>1e-6:raise ValueError('Pure-mask mass exceeds one')
        z=math.exp(min(0,logz));rows=_rows(['Survived','Removed'],[z,1-z]);unit='original probability mass'
        metrics=dict(grammar=case['name'],mass=z,pressure_nats=-logz,pressure_bits=-logz/math.log(2))
        summary=f"{case['name']}: {z:.4%} survives; pressure {-logz:.4f} nats."
        note='First actual prefix of this native grammar. Exact only for pure masking at temperature 1, not arbitrary sampler recipes or entire grammar languages.'
    elif name=='circuit':
        p=weights(data['cases'][0]['measurement']['rows']);weighted=[p[0]*(1-v),p[1]*(1-v),p[2]*v,p[3]*v];z=math.fsum(weighted);p=[x/z for x in weighted]
        f=p[1]+p[3];s=p[2]+p[3];rows=_rows(['Neither','Facts only','Style only','Both'],p)
        metrics=dict(F=f,S=s,AND=p[3],OR=1-p[0],F_given_S=p[3]/s if s else None,marginal_product=f*s)
        summary=f'Facts AND style: {p[3]:.2%}; multiplying the marginals would give {f*s:.2%}.'
        note='At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world.'
    elif name=='control':
        logs=[math.log(b)+v*(math.log(d)-math.log(u)) if i in data['allowed'] else -math.inf for i,(b,d,u) in enumerate(zip(data['base'],data['desired'],data['undesired']))];p=normalize_logs(logs)
        rows=_rows(list('ABCD'),p);pick=max(range(len(p)),key=p.__getitem__);metrics=dict(probabilities=p,selected=pick,forbidden_mass=math.fsum(p[i] for i in range(len(p)) if i not in data['allowed']))
        summary=f"Action {'ABCD'[pick]} leads; forbidden-action mass stays zero."
        note='Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook.'
    elif name=='future':
        root=weights(data['policy'][0]['rows']);child=weights(data['policy'][2]['rows']);h=[0,child[1]];p=normalize_logs([math.log(r)+(v*math.log(x) if x else -math.inf) if v else math.log(r) for r,x in zip(root,h)])
        rows=_rows(['A: dead end','B: viable route'],p);success=p[1]*child[1];metrics=dict(root_weights=p,exact_h=h,success_root_only=success,base_success=root[1]*child[1])
        summary=f'{p[1]:.2%} chooses B; leaving the next policy unchanged succeeds {success:.2%} of the time.'
        note='Only BB succeeds in this exact two-step toy. Conditioning both steps is different from steering only the root. No native future-value decoder is claimed.'
    elif name=='sensitivity':
        o=data['observations'];zs=[[math.log(p/(1-p)) for p in row['probabilities']] for row in o]
        matrix=[[(zs[2][i]-zs[1][i])/(2*data['epsilon'][0]),(zs[4][i]-zs[3][i])/(2*data['epsilon'][1])] for i in range(3)]
        delta=[r[0]*v+r[1]*5 for r in matrix];rows=_rows(['Urgency','Load','Damage'],delta);unit='predicted log-odds change'
        observed=[zs[6][i]-zs[0][i] for i in range(3)];held=[r[0]*-1+r[1]*5 for r in matrix]
        metrics=dict(matrix=matrix,predicted_delta=delta,holdout_residual=[a-b for a,b in zip(observed,held)])
        summary=f'Predicted urgency shift {delta[0]:+.3f}; the measured −1h/+5 holdout had error {metrics["holdout_residual"][0]:+.3f}.'
        note='The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses.'
    elif name=='counterexamples':
        nodes=data['nodes'];pairs=[]
        for i,a in enumerate(nodes):
            za=[math.log(p/(1-p)) for p in a['p_yes']]
            for j,b in enumerate(nodes[i+1:],i+1):
                if a['coefficients']!=b['coefficients']:continue
                zb=[math.log(p/(1-p)) for p in b['p_yes']];distance=math.sqrt(math.fsum((x-y)**2 for x,y in zip(za,zb)));pairs.append((distance,i,j))
        distance,i,j=max(pairs);a,b=nodes[i],nodes[j];evaluate=lambda c:sum(x*v**k for k,x in enumerate(c))
        rows=_rows([a['expression'],b['expression']],[a['p_yes'][1],b['p_yes'][1]])
        metrics=dict(left=a['expression'],right=b['expression'],margin_distance=distance,left_value=evaluate(a['coefficients']),right_value=evaluate(b['coefficients']))
        summary=f'Equal exact values at x={v:g}: {metrics["left_value"]:g}; observer distance {distance:.3f}.'
        note='Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe.'
    else:
        raise ValueError('No portable calculation for '+name)
    return dict(value=v,summary=summary,rows=rows,unit=unit,metrics=metrics,note=note)


def make_lesson(name, data):
    spec=LESSON_SPECS[name]
    try:
        first=calculate_lesson(name,data)
        compare=spec['compare']
        # An edited run can have fewer tokens/turns than the recorded default.
        lengths={'wire':len(data.get('entries',[])), 'samplers':len(data.get('runs',[])),
                 'tictactoe':len(data.get('frames',[])), 'context':len(data.get('runs',[])),
                 'information':len(data.get('tests',[])), 'research-map':len(data.get('branches',[])),
                 'pressure':len(data.get('cases',[]))}
        if name in lengths:compare=min(compare,lengths[name]-1)
        second=calculate_lesson(name,data,compare)
        context=data.get('prompt','').partition('STATE:\n')[2].partition('\nQUESTION:')[0]
        return dict(**spec,states=[first,second],input_excerpt=context[:320]+('…' if len(context)>320 else ''),scope='This panel and its Python calculation reproduce saved measurements. Other page controls are independent views.')
    except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:
        # A genuinely incomplete score or a tool-only wire response stays usable.
        # Do not turn an unavailable lesson into fabricated measurement data.
        return dict(**spec,states=[],unavailable=str(error),scope='This run has no complete inputs for this calculation. Inspect its exact request and result below.')



def mock_post(request, fixture):
    if request != fixture['request']:
        raise ValueError('No mock matches the edited request. Supply a new fixture or explicitly choose --live-url.')
    return copy.deepcopy(fixture['response'])


def live_post(base_url, request):
    if not base_url.startswith(('http://', 'https://')):
        raise ValueError('--live-url must be an http(s) Strata address')
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('STRATA_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['STRATA_API_KEY']
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    body = json.dumps(request, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base_url.rstrip('/')+'/v1/chat/completions', data=body, headers=headers)
    with opener.open(req, timeout=600) as response:
        wire = response.read().decode('utf-8')
    if request.get('stream'):
        events = [line[5:].strip() for line in wire.splitlines() if line.startswith('data:')]
        if not events or events[-1] != '[DONE]':
            raise ValueError('Stream closed without [DONE]')
        chunks = [json.loads(line) for line in events[:-1]]
        if any('error' in chunk for chunk in chunks):
            raise ValueError('Stream reported an error: '+repr(chunks))
        return {'sse_events': chunks, 'wire': wire}
    reply = json.loads(wire)
    if 'error' in reply:
        raise ValueError('Strata reported an error: '+repr(reply['error']))
    return reply


def summarize(response):
    if 'sse_events' in response:
        return str(len(response['sse_events']))+' SSE events; inspect the saved wire response'
    choice = (response.get('choices') or [{}])[0]
    message = choice.get('message', {})
    text = message.get('content') or json.dumps(message.get('tool_calls') or message, ensure_ascii=False)
    entries = (choice.get('logprobs') or {}).get('content') or []
    if entries:
        text += '\n  First visible token raw logprob: '+repr(entries[0]['logprob'])
        text += '\n  First visible token raw probability: '+format(math.exp(entries[0]['logprob']), '.7g')
    return text


def raw_tokens(response):
    if 'sse_events' in response:
        return [token for chunk in response['sse_events'] for choice in chunk.get('choices', [])
                for token in (choice.get('logprobs') or {}).get('content') or []]
    choices = response.get('choices') or []
    return ((choices[0].get('logprobs') or {}).get('content') or []) if choices else []


def print_raw_tokens(response):
    entries = raw_tokens(response)
    if not entries:
        print('No scored answer tokens returned; no raw probabilities are invented.')
    for i, token in enumerate(entries):
        lp = token['logprob']
        p = math.exp(lp)
        shown = format(p, '.9g') if p else 'underflows; use the finite logprob'
        print('  Token '+str(i)+': '+repr(token['token'])+' bytes='+repr(token['bytes'])+
              ' raw ln p='+repr(lp)+' raw p='+shown)
        sampling = token.get('strata_sampling')
        if sampling:
            print('    Final native selection weight q='+repr(sampling['probability'])+' (separate from raw p)')


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=int, default=1, help='1-based request index (default 1)')
    parser.add_argument('--all', action='store_true', help='Replay every mock in this captured run')
    parser.add_argument('--show', action='store_true', help='Print exact selected HTTP request JSON')
    parser.add_argument('--tokens', action='store_true', help='Print every original token raw logprob/probability and available native sampling weight')
    parser.add_argument('--lesson-only', action='store_true', help='Recalculate the captured question/rule/result panel without printing mocked calls')
    parser.add_argument('--value', type=float, help='Change the panel parameter within its documented bounds; offline calculation only')
    parser.add_argument('--live-url', help='Explicitly send ONE request to your compatible Strata server')
    parser.add_argument('--output', type=Path, help='Write responses and their provenance as JSON')
    args = parser.parse_args()
    if args.all and args.live_url:
        parser.error('--all is offline only; saved dependent requests are not a live adaptive controller')
    if args.live_url and (args.lesson_only or args.value is not None):
        parser.error('Lesson calculations use captured evidence. Do not mix --live-url with --lesson-only or --value.')
    calls = CAPTURED['receipt']['calls']
    print('Strata Control Lab / '+CAPTURED['experiment'])
    print('LIVE selected request' if args.live_url else 'OFFLINE MOCK / recorded responses, no inference or network')
    view = CAPTURED.get('score_view')
    if view:
        print('\nRAW LAYER: '+view['raw'])
        print('DERIVED VIEW: '+view['derived'])
        print('SCOPE: '+view['scope'])
    calculation=None
    if not args.live_url:
        spec=CAPTURED.get('lesson')
        if spec and spec.get('states'):
            knob=args.value if args.value is not None else (CAPTURED.get('lesson_view') or {}).get('value',spec['default'])
            try:calculation=calculate_lesson(CAPTURED['experiment'],CAPTURED['result'],knob)
            except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:parser.error(str(error))
            print('\nQUESTION: '+spec['question']+'\nRULE: '+spec['rule'])
            print(spec['knob']+' = '+str(knob)+f" (allowed {spec['low']}..{spec['high']})")
            print('RESULT: '+calculation['summary'])
            print('BOUNDARY: '+calculation['note'])
            print('Reproduces the selected question/rule/result panel; other page dials are independent.')
            print(json.dumps(calculation,ensure_ascii=True,indent=2))
        elif args.lesson_only or args.value is not None:
            parser.error('This captured run has no complete lesson inputs: '+str((spec or {}).get('unavailable','missing calculation')))
    if args.lesson_only:
        result=dict(mode='offline-calculation',calculation=calculation)
    elif not calls:
        if args.live_url:
            parser.error('This page has no HTTP requests: it is analytical or recorded diagnostic evidence')
        print('No HTTP request, GBNF or JSON output constraint was used by this page.')
        print('The included result is a calculation/diagnostic snapshot, not a new model answer.')
        result = dict(mode='offline-snapshot', result=CAPTURED['result'])
        print(json.dumps(result, ensure_ascii=True, indent=2))
    else:
        indexes = range(len(calls)) if args.all else [args.request-1]
        if any(i < 0 or i >= len(calls) for i in indexes):
            parser.error('Request index must be 1..'+str(len(calls)))
        results = []
        for i in indexes:
            fixture = calls[i]
            request = copy.deepcopy(fixture['request'])  # Edit here to try your own live request.
            if args.show:
                print(json.dumps(request, ensure_ascii=True, indent=2))
            response = live_post(args.live_url, request) if args.live_url else mock_post(request, fixture)
            print('Request '+str(i+1)+' / '+str(len(calls))+': '+summarize(response))
            if args.tokens:
                print_raw_tokens(response)
            results.append(dict(request=request, response=response,
                                provenance='live-request' if args.live_url else 'mocked-native-recording'))
        result = dict(mode='live' if args.live_url else 'offline-mock', calls=results)
        print('GBNF and JSON settings are in each request. Use --show to inspect them.')
        print('The saved page result is in CAPTURED["result"]; live responses do not recompute that snapshot.')
    if calculation is not None:result['calculation']=calculation
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
