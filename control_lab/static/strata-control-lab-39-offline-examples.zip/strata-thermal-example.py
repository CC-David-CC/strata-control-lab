# -*- coding: utf-8 -*-
"""Downloaded Strata example: Python 3 standard library; offline by default.

Windows: py strata-example.py
Ubuntu:  python3 strata-example.py
Show a request: python strata-example.py --request 1 --show
Replay all recorded calls: python strata-example.py --all
Recalculate the panel: python strata-example.py --lesson-only
Change its knob: python strata-example.py --lesson-only --value NUMBER
Try ONE request live: python strata-example.py --request 1 --live-url http://127.0.0.1:8080
An optional STRATA_API_KEY environment variable supplies authentication.

CAPTURED is inserted above this runner by the page. It contains this exact run,
with requests, GBNF/JSON settings, responses, streaming chunks and the page result.
Mock mode returns those responses; it performs no inference and opens no socket.
Live mode runs only a selected request. It does not execute tools or adapt a saved
multi-step trace to new answers. No captured API key or authorization header exists.
"""
CAPTURED = {
    "experiment": "thermal",
    "type": "result",
    "result": {
        "kind": "thermal",
        "frames": [
            {
                "tick": 0,
                "temperature": 70,
                "load": 45,
                "fan": 30,
                "next_temperature": 68.5,
                "allowed": [
                    0,
                    30,
                    60
                ],
                "decision": {
                    "measure": {
                        "rows": [
                            {
                                "label": "A",
                                "description": "fan 0",
                                "text": "A",
                                "tokens": [
                                    {
                                        "token": "A",
                                        "logprob": -2.550341077125383,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7512764408949142,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8179077580335861,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.550341077125383,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -6.248403973853899,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.69522327927382,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.907292790687395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.273274846351457,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.621528096473527,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.717767186439348,
                                                "bytes": None
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.820643849647356,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.88039631394179,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.97051853684218,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -9.077261395728899,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -9.102740712440324,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.12904781845839,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -9.271607823646379,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.370233006751848,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.423066563880754,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.619741864478899,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "c",
                                                "logprob": -9.657709546363664,
                                                "bytes": [
                                                    99
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -2.550341077125383,
                                "path_probability": 0.07805503867221292,
                                "mean_logprob": -2.550341077125383,
                                "finish_reason": "stop",
                                "raw_probability": 0.07805503867221292,
                                "weight": 0.07875015551903526
                            },
                            {
                                "label": "B",
                                "description": "fan 30",
                                "text": "B",
                                "tokens": [
                                    {
                                        "token": "B",
                                        "logprob": -0.7512764408949142,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7512764408949142,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8179077580335861,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.550341077125383,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -6.248403973853899,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.69522327927382,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.907292790687395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.273274846351457,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.621528096473527,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.717767186439348,
                                                "bytes": None
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.820643849647356,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.88039631394179,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.97051853684218,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -9.077261395728899,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -9.102740712440324,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.12904781845839,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -9.271607823646379,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.370233006751848,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.423066563880754,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.619741864478899,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "c",
                                                "logprob": -9.657709546363664,
                                                "bytes": [
                                                    99
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -0.7512764408949142,
                                "path_probability": 0.471763989405761,
                                "mean_logprob": -0.7512764408949142,
                                "finish_reason": "stop",
                                "raw_probability": 0.471763989405761,
                                "weight": 0.47596526971179204
                            },
                            {
                                "label": "C",
                                "description": "fan 60",
                                "text": "C",
                                "tokens": [
                                    {
                                        "token": "C",
                                        "logprob": -0.8179077580335861,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7512764408949142,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8179077580335861,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.550341077125383,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -6.248403973853899,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.69522327927382,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.907292790687395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.273274846351457,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.621528096473527,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.717767186439348,
                                                "bytes": None
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.820643849647356,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.88039631394179,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.97051853684218,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -9.077261395728899,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -9.102740712440324,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.12904781845839,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -9.271607823646379,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.370233006751848,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.423066563880754,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.619741864478899,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "c",
                                                "logprob": -9.657709546363664,
                                                "bytes": [
                                                    99
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -0.8179077580335861,
                                "path_probability": 0.4413541087591423,
                                "mean_logprob": -0.8179077580335861,
                                "finish_reason": "stop",
                                "raw_probability": 0.4413541087591423,
                                "weight": 0.44528457476917266
                            }
                        ],
                        "complete": True,
                        "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 0. Temperature=70.0 C; load=45. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                        "winner": "B",
                        "statistics": {
                            "top_weight": 0.47596526971179204,
                            "margin": 0.03068069494261938,
                            "peakedness": 0.21394790456768806,
                            "entropy_bits": 1.3182725594803295
                        },
                        "strategy": "one literal-constrained call per label",
                        "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                    },
                    "selected": 1,
                    "action": "fan 30",
                    "allowed": [
                        0,
                        1,
                        2
                    ],
                    "grammar": "root ::= \"A\" | \"B\" | \"C\"",
                    "output": {
                        "text": "B",
                        "tokens": [
                            {
                                "token": "B",
                                "logprob": -0.7512764408949142,
                                "bytes": [
                                    66
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "B",
                                        "logprob": -0.7512764408949142,
                                        "bytes": [
                                            66
                                        ]
                                    },
                                    {
                                        "token": "C",
                                        "logprob": -0.8179077580335861,
                                        "bytes": [
                                            67
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -2.550341077125383,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "T",
                                        "logprob": -6.248403973853899,
                                        "bytes": [
                                            84
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -6.69522327927382,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    }
                                ]
                            }
                        ],
                        "token_count": 1,
                        "logprob": -0.7512764408949142,
                        "path_probability": 0.471763989405761,
                        "mean_logprob": -0.7512764408949142,
                        "finish_reason": "stop"
                    }
                },
                "one_step_oracle": 60,
                "error": 8.5
            },
            {
                "tick": 1,
                "temperature": 68.5,
                "load": 70,
                "fan": 60,
                "next_temperature": 62.96,
                "allowed": [
                    0,
                    30,
                    60
                ],
                "decision": {
                    "measure": {
                        "rows": [
                            {
                                "label": "A",
                                "description": "fan 0",
                                "text": "A",
                                "tokens": [
                                    {
                                        "token": "A",
                                        "logprob": -2.551958506702714,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "C",
                                                "logprob": -0.6093601638072063,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0322803908579874,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.551958506702714,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.306089823841386,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.354607051014238,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.632190173267656,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.58139461815291,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -8.004173701404863,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.131057208179765,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -8.258840983509355,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.387920802234941,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.480244105457597,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.526527827381425,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.528688853382402,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -8.560599749683671,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.62105125725203,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.658313220142656,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.683956568836503,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.842512553333574,
                                                "bytes": None
                                            },
                                            {
                                                "token": "What",
                                                "logprob": -8.970396464466386,
                                                "bytes": [
                                                    87,
                                                    104,
                                                    97,
                                                    116
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -2.551958506702714,
                                "path_probability": 0.07792889218803281,
                                "mean_logprob": -2.551958506702714,
                                "finish_reason": "stop",
                                "raw_probability": 0.07792889218803281,
                                "weight": 0.07969645591388325
                            },
                            {
                                "label": "B",
                                "description": "fan 30",
                                "text": "B",
                                "tokens": [
                                    {
                                        "token": "B",
                                        "logprob": -1.0322803908579874,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "C",
                                                "logprob": -0.6093601638072063,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0322803908579874,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.551958506702714,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.306089823841386,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.354607051014238,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.632190173267656,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.58139461815291,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -8.004173701404863,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.131057208179765,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -8.258840983509355,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.387920802234941,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.480244105457597,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.526527827381425,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.528688853382402,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -8.560599749683671,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.62105125725203,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.658313220142656,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.683956568836503,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.842512553333574,
                                                "bytes": None
                                            },
                                            {
                                                "token": "What",
                                                "logprob": -8.970396464466386,
                                                "bytes": [
                                                    87,
                                                    104,
                                                    97,
                                                    116
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -1.0322803908579874,
                                "path_probability": 0.3561937727055064,
                                "mean_logprob": -1.0322803908579874,
                                "finish_reason": "stop",
                                "raw_probability": 0.3561937727055064,
                                "weight": 0.3642728711544992
                            },
                            {
                                "label": "C",
                                "description": "fan 60",
                                "text": "C",
                                "tokens": [
                                    {
                                        "token": "C",
                                        "logprob": -0.6093601638072063,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "C",
                                                "logprob": -0.6093601638072063,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0322803908579874,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.551958506702714,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.306089823841386,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.354607051014238,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.632190173267656,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.58139461815291,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -8.004173701404863,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.131057208179765,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -8.258840983509355,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.387920802234941,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.480244105457597,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.526527827381425,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.528688853382402,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -8.560599749683671,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.62105125725203,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.658313220142656,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.683956568836503,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.842512553333574,
                                                "bytes": None
                                            },
                                            {
                                                "token": "What",
                                                "logprob": -8.970396464466386,
                                                "bytes": [
                                                    87,
                                                    104,
                                                    97,
                                                    116
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -0.6093601638072063,
                                "path_probability": 0.5436986358709467,
                                "mean_logprob": -0.6093601638072063,
                                "finish_reason": "stop",
                                "raw_probability": 0.5436986358709467,
                                "weight": 0.5560306729316176
                            }
                        ],
                        "complete": True,
                        "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 1. Temperature=68.5 C; load=70. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                        "winner": "C",
                        "statistics": {
                            "top_weight": 0.5560306729316176,
                            "margin": 0.19175780177711838,
                            "peakedness": 0.33404600939742635,
                            "entropy_bits": 1.2923783184927657
                        },
                        "strategy": "one literal-constrained call per label",
                        "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                    },
                    "selected": 2,
                    "action": "fan 60",
                    "allowed": [
                        0,
                        1,
                        2
                    ],
                    "grammar": "root ::= \"A\" | \"B\" | \"C\"",
                    "output": {
                        "text": "C",
                        "tokens": [
                            {
                                "token": "C",
                                "logprob": -0.6093601638072063,
                                "bytes": [
                                    67
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "C",
                                        "logprob": -0.6093601638072063,
                                        "bytes": [
                                            67
                                        ]
                                    },
                                    {
                                        "token": "B",
                                        "logprob": -1.0322803908579874,
                                        "bytes": [
                                            66
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -2.551958506702714,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "T",
                                        "logprob": -5.306089823841386,
                                        "bytes": [
                                            84
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -5.354607051014238,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    }
                                ]
                            }
                        ],
                        "token_count": 1,
                        "logprob": -0.6093601638072063,
                        "path_probability": 0.5436986358709467,
                        "mean_logprob": -0.6093601638072063,
                        "finish_reason": "stop"
                    }
                },
                "one_step_oracle": 60,
                "error": 2.960000000000001
            },
            {
                "tick": 2,
                "temperature": 62.96,
                "load": 80,
                "fan": 30,
                "next_temperature": 69.442,
                "allowed": [
                    0,
                    30,
                    60
                ],
                "decision": {
                    "measure": {
                        "rows": [
                            {
                                "label": "A",
                                "description": "fan 0",
                                "text": "A",
                                "tokens": [
                                    {
                                        "token": "A",
                                        "logprob": -2.0142460020507884,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8781318815673899,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.126014724584968,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.0142460020507884,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -2.614828124853523,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.5103302153076243,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.7621555479492255,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.463344589086921,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.752624526831061,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.779226318212897,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.881339088293464,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.194600120397956,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -7.229669586035163,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -7.284547820898444,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.535218253942878,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "Calculate",
                                                "logprob": -7.729134574743659,
                                                "bytes": [
                                                    67,
                                                    97,
                                                    108,
                                                    99,
                                                    117,
                                                    108,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -7.856531158300788,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Current",
                                                "logprob": -7.926839843603522,
                                                "bytes": [
                                                    67,
                                                    117,
                                                    114,
                                                    114,
                                                    101,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.032573715063483,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -8.262392059179694,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Fan",
                                                "logprob": -8.288938537451179,
                                                "bytes": [
                                                    70,
                                                    97,
                                                    110
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -2.0142460020507884,
                                "path_probability": 0.13342096458338704,
                                "mean_logprob": -2.0142460020507884,
                                "finish_reason": "stop",
                                "raw_probability": 0.13342096458338704,
                                "weight": 0.15277746172671178
                            },
                            {
                                "label": "B",
                                "description": "fan 30",
                                "text": "B",
                                "tokens": [
                                    {
                                        "token": "B",
                                        "logprob": -0.8781318815673899,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8781318815673899,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.126014724584968,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.0142460020507884,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -2.614828124853523,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.5103302153076243,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.7621555479492255,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.463344589086921,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.752624526831061,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.779226318212897,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.881339088293464,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.194600120397956,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -7.229669586035163,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -7.284547820898444,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.535218253942878,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "Calculate",
                                                "logprob": -7.729134574743659,
                                                "bytes": [
                                                    67,
                                                    97,
                                                    108,
                                                    99,
                                                    117,
                                                    108,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -7.856531158300788,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Current",
                                                "logprob": -7.926839843603522,
                                                "bytes": [
                                                    67,
                                                    117,
                                                    114,
                                                    114,
                                                    101,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.032573715063483,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -8.262392059179694,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Fan",
                                                "logprob": -8.288938537451179,
                                                "bytes": [
                                                    70,
                                                    97,
                                                    110
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -0.8781318815673899,
                                "path_probability": 0.4155584995038207,
                                "mean_logprob": -0.8781318815673899,
                                "finish_reason": "stop",
                                "raw_probability": 0.4155584995038207,
                                "weight": 0.4758470526082524
                            },
                            {
                                "label": "C",
                                "description": "fan 60",
                                "text": "C",
                                "tokens": [
                                    {
                                        "token": "C",
                                        "logprob": -1.126014724584968,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8781318815673899,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.126014724584968,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.0142460020507884,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -2.614828124853523,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.5103302153076243,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.7621555479492255,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.463344589086921,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.752624526831061,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.779226318212897,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.881339088293464,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.194600120397956,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -7.229669586035163,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -7.284547820898444,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.535218253942878,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "Calculate",
                                                "logprob": -7.729134574743659,
                                                "bytes": [
                                                    67,
                                                    97,
                                                    108,
                                                    99,
                                                    117,
                                                    108,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -7.856531158300788,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Current",
                                                "logprob": -7.926839843603522,
                                                "bytes": [
                                                    67,
                                                    117,
                                                    114,
                                                    114,
                                                    101,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.032573715063483,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -8.262392059179694,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Fan",
                                                "logprob": -8.288938537451179,
                                                "bytes": [
                                                    70,
                                                    97,
                                                    110
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -1.126014724584968,
                                "path_probability": 0.3243232016034317,
                                "mean_logprob": -1.126014724584968,
                                "finish_reason": "stop",
                                "raw_probability": 0.3243232016034317,
                                "weight": 0.371375485665036
                            }
                        ],
                        "complete": True,
                        "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 2. Temperature=62.96 C; load=80. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                        "winner": "B",
                        "statistics": {
                            "top_weight": 0.4758470526082524,
                            "margin": 0.10447156694321641,
                            "peakedness": 0.21377057891237858,
                            "entropy_bits": 1.4546535937617149
                        },
                        "strategy": "one literal-constrained call per label",
                        "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                    },
                    "selected": 1,
                    "action": "fan 30",
                    "allowed": [
                        0,
                        1,
                        2
                    ],
                    "grammar": "root ::= \"A\" | \"B\" | \"C\"",
                    "output": {
                        "text": "B",
                        "tokens": [
                            {
                                "token": "B",
                                "logprob": -0.8781318815673899,
                                "bytes": [
                                    66
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "B",
                                        "logprob": -0.8781318815673899,
                                        "bytes": [
                                            66
                                        ]
                                    },
                                    {
                                        "token": "C",
                                        "logprob": -1.126014724584968,
                                        "bytes": [
                                            67
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -2.0142460020507884,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -2.614828124853523,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "T",
                                        "logprob": -3.5103302153076243,
                                        "bytes": [
                                            84
                                        ]
                                    }
                                ]
                            }
                        ],
                        "token_count": 1,
                        "logprob": -0.8781318815673899,
                        "path_probability": 0.4155584995038207,
                        "mean_logprob": -0.8781318815673899,
                        "finish_reason": "stop"
                    }
                },
                "one_step_oracle": 60,
                "error": 9.441999999999993
            },
            {
                "tick": 3,
                "temperature": 69.442,
                "load": 35,
                "fan": 30,
                "next_temperature": 65.764,
                "allowed": [
                    0,
                    30,
                    60
                ],
                "decision": {
                    "measure": {
                        "rows": [
                            {
                                "label": "A",
                                "description": "fan 0",
                                "text": "A",
                                "tokens": [
                                    {
                                        "token": "A",
                                        "logprob": -2.121065600573081,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -1.1177677947869482,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.1346707183709326,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -1.8598847228875341,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.121065600573081,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.4118017989983738,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.196585162340659,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -5.735079272448081,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.8435778457513035,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.242618067919272,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.346655352770346,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.375350459276694,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -6.695895655809897,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -6.785990222155112,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.022739871202964,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.122409327684897,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -7.164748652636069,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.385038836657065,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -7.427508814989585,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -7.430702670275229,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.439943774401206,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -2.121065600573081,
                                "path_probability": 0.11990379086335932,
                                "mean_logprob": -2.121065600573081,
                                "finish_reason": "stop",
                                "raw_probability": 0.11990379086335932,
                                "weight": 0.15603519038819216
                            },
                            {
                                "label": "B",
                                "description": "fan 30",
                                "text": "B",
                                "tokens": [
                                    {
                                        "token": "B",
                                        "logprob": -1.1177677947869482,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -1.1177677947869482,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.1346707183709326,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -1.8598847228875341,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.121065600573081,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.4118017989983738,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.196585162340659,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -5.735079272448081,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.8435778457513035,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.242618067919272,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.346655352770346,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.375350459276694,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -6.695895655809897,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -6.785990222155112,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.022739871202964,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.122409327684897,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -7.164748652636069,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.385038836657065,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -7.427508814989585,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -7.430702670275229,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.439943774401206,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -1.1177677947869482,
                                "path_probability": 0.3270089315703997,
                                "mean_logprob": -1.1177677947869482,
                                "finish_reason": "stop",
                                "raw_probability": 0.3270089315703997,
                                "weight": 0.4255486880675347
                            },
                            {
                                "label": "C",
                                "description": "fan 60",
                                "text": "C",
                                "tokens": [
                                    {
                                        "token": "C",
                                        "logprob": -1.1346707183709326,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -1.1177677947869482,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.1346707183709326,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -1.8598847228875341,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.121065600573081,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.4118017989983738,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.196585162340659,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -5.735079272448081,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.8435778457513035,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.242618067919272,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.346655352770346,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.375350459276694,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -6.695895655809897,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -6.785990222155112,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.022739871202964,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.122409327684897,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -7.164748652636069,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.385038836657065,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -7.427508814989585,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -7.430702670275229,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.439943774401206,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -1.1346707183709326,
                                "path_probability": 0.3215279771613558,
                                "mean_logprob": -1.1346707183709326,
                                "finish_reason": "stop",
                                "raw_probability": 0.3215279771613558,
                                "weight": 0.41841612154427305
                            }
                        ],
                        "complete": True,
                        "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 3. Temperature=69.442 C; load=35. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                        "winner": "B",
                        "statistics": {
                            "top_weight": 0.4255486880675347,
                            "margin": 0.007132566523261663,
                            "peakedness": 0.13832303210130206,
                            "entropy_bits": 1.4686608564467991
                        },
                        "strategy": "one literal-constrained call per label",
                        "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                    },
                    "selected": 1,
                    "action": "fan 30",
                    "allowed": [
                        0,
                        1,
                        2
                    ],
                    "grammar": "root ::= \"A\" | \"B\" | \"C\"",
                    "output": {
                        "text": "B",
                        "tokens": [
                            {
                                "token": "B",
                                "logprob": -1.1177677947869482,
                                "bytes": [
                                    66
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "B",
                                        "logprob": -1.1177677947869482,
                                        "bytes": [
                                            66
                                        ]
                                    },
                                    {
                                        "token": "C",
                                        "logprob": -1.1346707183709326,
                                        "bytes": [
                                            67
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -1.8598847228875341,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -2.121065600573081,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "T",
                                        "logprob": -3.4118017989983738,
                                        "bytes": [
                                            84
                                        ]
                                    }
                                ]
                            }
                        ],
                        "token_count": 1,
                        "logprob": -1.1177677947869482,
                        "path_probability": 0.3270089315703997,
                        "mean_logprob": -1.1177677947869482,
                        "finish_reason": "stop"
                    }
                },
                "one_step_oracle": 60,
                "error": 5.763999999999996
            },
            {
                "tick": 4,
                "temperature": 65.764,
                "load": 20,
                "fan": 30,
                "next_temperature": 58.933,
                "allowed": [
                    0,
                    30,
                    60
                ],
                "decision": {
                    "measure": {
                        "rows": [
                            {
                                "label": "A",
                                "description": "fan 0",
                                "text": "A",
                                "tokens": [
                                    {
                                        "token": "A",
                                        "logprob": -2.434247620129265,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7861267400023116,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8233620000120773,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.434247620129265,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.051324493908561,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.927264816784538,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.281457550549186,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.837777740978874,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.508731491589225,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.14678920032946,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.351329453015007,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.580331451916374,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.818483002209343,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.848026878857292,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -8.850444443249382,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "4",
                                                "logprob": -8.907484657787956,
                                                "bytes": [
                                                    52
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.921076424145378,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.973747856640495,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.023187286877311,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.11774695637194,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.151761658215202,
                                                "bytes": [
                                                    49
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -2.434247620129265,
                                "path_probability": 0.08766367862934546,
                                "mean_logprob": -2.434247620129265,
                                "finish_reason": "stop",
                                "raw_probability": 0.08766367862934546,
                                "weight": 0.08925026714039484
                            },
                            {
                                "label": "B",
                                "description": "fan 30",
                                "text": "B",
                                "tokens": [
                                    {
                                        "token": "B",
                                        "logprob": -0.7861267400023116,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7861267400023116,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8233620000120773,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.434247620129265,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.051324493908561,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.927264816784538,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.281457550549186,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.837777740978874,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.508731491589225,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.14678920032946,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.351329453015007,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.580331451916374,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.818483002209343,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.848026878857292,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -8.850444443249382,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "4",
                                                "logprob": -8.907484657787956,
                                                "bytes": [
                                                    52
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.921076424145378,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.973747856640495,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.023187286877311,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.11774695637194,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.151761658215202,
                                                "bytes": [
                                                    49
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -0.7861267400023116,
                                "path_probability": 0.45560606289487793,
                                "mean_logprob": -0.7861267400023116,
                                "finish_reason": "stop",
                                "raw_probability": 0.45560606289487793,
                                "weight": 0.4638518878049848
                            },
                            {
                                "label": "C",
                                "description": "fan 60",
                                "text": "C",
                                "tokens": [
                                    {
                                        "token": "C",
                                        "logprob": -0.8233620000120773,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7861267400023116,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8233620000120773,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.434247620129265,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.051324493908561,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.927264816784538,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.281457550549186,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.837777740978874,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.508731491589225,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.14678920032946,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.351329453015007,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.580331451916374,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.818483002209343,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.848026878857292,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -8.850444443249382,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "4",
                                                "logprob": -8.907484657787956,
                                                "bytes": [
                                                    52
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.921076424145378,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.973747856640495,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.023187286877311,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.11774695637194,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.151761658215202,
                                                "bytes": [
                                                    49
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -0.8233620000120773,
                                "path_probability": 0.4389534096003149,
                                "mean_logprob": -0.8233620000120773,
                                "finish_reason": "stop",
                                "raw_probability": 0.4389534096003149,
                                "weight": 0.4468978450546205
                            }
                        ],
                        "complete": True,
                        "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 4. Temperature=65.764 C; load=20. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                        "winner": "B",
                        "statistics": {
                            "top_weight": 0.4638518878049848,
                            "margin": 0.01695404275036433,
                            "peakedness": 0.19577783170747723,
                            "entropy_bits": 1.3444844002204452
                        },
                        "strategy": "one literal-constrained call per label",
                        "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                    },
                    "selected": 1,
                    "action": "fan 30",
                    "allowed": [
                        0,
                        1,
                        2
                    ],
                    "grammar": "root ::= \"A\" | \"B\" | \"C\"",
                    "output": {
                        "text": "B",
                        "tokens": [
                            {
                                "token": "B",
                                "logprob": -0.7861267400023116,
                                "bytes": [
                                    66
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "B",
                                        "logprob": -0.7861267400023116,
                                        "bytes": [
                                            66
                                        ]
                                    },
                                    {
                                        "token": "C",
                                        "logprob": -0.8233620000120773,
                                        "bytes": [
                                            67
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -2.434247620129265,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "T",
                                        "logprob": -5.051324493908561,
                                        "bytes": [
                                            84
                                        ]
                                    },
                                    {
                                        "token": "6",
                                        "logprob": -5.927264816784538,
                                        "bytes": [
                                            54
                                        ]
                                    }
                                ]
                            }
                        ],
                        "token_count": 1,
                        "logprob": -0.7861267400023116,
                        "path_probability": 0.45560606289487793,
                        "mean_logprob": -0.7861267400023116,
                        "finish_reason": "stop"
                    }
                },
                "one_step_oracle": 30,
                "error": 1.0670000000000002
            },
            {
                "tick": 5,
                "temperature": 58.933,
                "load": 65,
                "fan": 30,
                "next_temperature": 62.276,
                "allowed": [
                    0,
                    30,
                    60
                ],
                "decision": {
                    "measure": {
                        "rows": [
                            {
                                "label": "A",
                                "description": "fan 0",
                                "text": "A",
                                "tokens": [
                                    {
                                        "token": "A",
                                        "logprob": -1.9875713342700476,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8225818628345009,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.0607620233569617,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.9875713342700476,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -3.127488707927274,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -4.219211196330595,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -6.213115310100126,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.769427871135282,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.867462729838896,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -7.210000609782743,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -7.2437673563037395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -7.295641517070341,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.4323755258594035,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.625878905681181,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -7.749969100383329,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -7.793275451091337,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -7.978218650249052,
                                                "bytes": None
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -8.194321250346707,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.237482642558621,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -8.277268027690457,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.325662230876492,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -1.9875713342700476,
                                "path_probability": 0.1370278164106359,
                                "mean_logprob": -1.9875713342700476,
                                "finish_reason": "stop",
                                "raw_probability": 0.1370278164106359,
                                "weight": 0.14853710931441366
                            },
                            {
                                "label": "B",
                                "description": "fan 30",
                                "text": "B",
                                "tokens": [
                                    {
                                        "token": "B",
                                        "logprob": -0.8225818628345009,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8225818628345009,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.0607620233569617,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.9875713342700476,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -3.127488707927274,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -4.219211196330595,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -6.213115310100126,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.769427871135282,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.867462729838896,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -7.210000609782743,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -7.2437673563037395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -7.295641517070341,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.4323755258594035,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.625878905681181,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -7.749969100383329,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -7.793275451091337,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -7.978218650249052,
                                                "bytes": None
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -8.194321250346707,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.237482642558621,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -8.277268027690457,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.325662230876492,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -0.8225818628345009,
                                "path_probability": 0.43929598708570955,
                                "mean_logprob": -0.8225818628345009,
                                "finish_reason": "stop",
                                "raw_probability": 0.43929598708570955,
                                "weight": 0.4761935040954834
                            },
                            {
                                "label": "C",
                                "description": "fan 60",
                                "text": "C",
                                "tokens": [
                                    {
                                        "token": "C",
                                        "logprob": -1.0607620233569617,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8225818628345009,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.0607620233569617,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.9875713342700476,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -3.127488707927274,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -4.219211196330595,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -6.213115310100126,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.769427871135282,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.867462729838896,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -7.210000609782743,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -7.2437673563037395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -7.295641517070341,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.4323755258594035,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.625878905681181,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -7.749969100383329,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -7.793275451091337,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -7.978218650249052,
                                                "bytes": None
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -8.194321250346707,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.237482642558621,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -8.277268027690457,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.325662230876492,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -1.0607620233569617,
                                "path_probability": 0.34619190347479517,
                                "mean_logprob": -1.0607620233569617,
                                "finish_reason": "stop",
                                "raw_probability": 0.34619190347479517,
                                "weight": 0.37526938659010306
                            }
                        ],
                        "complete": True,
                        "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 5. Temperature=58.933 C; load=65. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                        "winner": "B",
                        "statistics": {
                            "top_weight": 0.4761935040954834,
                            "margin": 0.10092411750538033,
                            "peakedness": 0.21429025614322508,
                            "entropy_bits": 1.448980686242837
                        },
                        "strategy": "one literal-constrained call per label",
                        "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                    },
                    "selected": 1,
                    "action": "fan 30",
                    "allowed": [
                        0,
                        1,
                        2
                    ],
                    "grammar": "root ::= \"A\" | \"B\" | \"C\"",
                    "output": {
                        "text": "B",
                        "tokens": [
                            {
                                "token": "B",
                                "logprob": -0.8225818628345009,
                                "bytes": [
                                    66
                                ],
                                "top_logprobs": [
                                    {
                                        "token": "B",
                                        "logprob": -0.8225818628345009,
                                        "bytes": [
                                            66
                                        ]
                                    },
                                    {
                                        "token": "C",
                                        "logprob": -1.0607620233569617,
                                        "bytes": [
                                            67
                                        ]
                                    },
                                    {
                                        "token": "A",
                                        "logprob": -1.9875713342700476,
                                        "bytes": [
                                            65
                                        ]
                                    },
                                    {
                                        "token": "Let",
                                        "logprob": -3.127488707927274,
                                        "bytes": [
                                            76,
                                            101,
                                            116
                                        ]
                                    },
                                    {
                                        "token": "T",
                                        "logprob": -4.219211196330595,
                                        "bytes": [
                                            84
                                        ]
                                    }
                                ]
                            }
                        ],
                        "token_count": 1,
                        "logprob": -0.8225818628345009,
                        "path_probability": 0.43929598708570955,
                        "mean_logprob": -0.8225818628345009,
                        "finish_reason": "stop"
                    }
                },
                "one_step_oracle": 30,
                "error": 2.2760000000000034
            }
        ],
        "baseline": [
            58.9,
            53.744,
            70.194,
            56.886,
            40.811,
            54.479
        ],
        "limit": 85,
        "target": 60,
        "semantics": "Simulated dynamics, exact one-step shield, no model of disturbances or formal closed-loop stability guarantee. The baseline uses hysteresis plus the same shield."
    },
    "lesson": {
        "question": "What happens if we replay the fan commands differently?",
        "rule": "Step the disclosed thermal equation through the same loads. A fan offset is an open-loop counterfactual, not a new model policy.",
        "knob": "Fan offset",
        "default": 0,
        "compare": 20,
        "low": -60,
        "high": 60,
        "integer": False,
        "states": [
            {
                "value": 0,
                "summary": "Mean distance from target: 5.00°C; 0 limit violations.",
                "rows": [
                    {
                        "label": "1",
                        "value": 68.5
                    },
                    {
                        "label": "2",
                        "value": 62.96
                    },
                    {
                        "label": "3",
                        "value": 69.442
                    },
                    {
                        "label": "4",
                        "value": 65.764
                    },
                    {
                        "label": "5",
                        "value": 58.933
                    },
                    {
                        "label": "6",
                        "value": 62.276
                    }
                ],
                "unit": "°C",
                "metrics": {
                    "temperatures": [
                        68.5,
                        62.96,
                        69.442,
                        65.764,
                        58.933,
                        62.276
                    ],
                    "mean_error": 5.001499999999999,
                    "violations": 0
                },
                "note": "Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control."
            },
            {
                "value": 20,
                "summary": "Mean distance from target: 12.10°C; 0 limit violations.",
                "rows": [
                    {
                        "label": "1",
                        "value": 62.1
                    },
                    {
                        "label": "2",
                        "value": 56.816
                    },
                    {
                        "label": "3",
                        "value": 57.143
                    },
                    {
                        "label": "4",
                        "value": 47.557
                    },
                    {
                        "label": "5",
                        "value": 35.055
                    },
                    {
                        "label": "6",
                        "value": 32.953
                    }
                ],
                "unit": "°C",
                "metrics": {
                    "temperatures": [
                        62.1,
                        56.816,
                        57.143,
                        47.557,
                        35.055,
                        32.953
                    ],
                    "mean_error": 12.095999999999998,
                    "violations": 0
                },
                "note": "Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control."
            }
        ],
        "input_excerpt": "",
        "scope": "This panel and its Python calculation reproduce saved measurements. Other page controls are independent views."
    },
    "receipt": {
        "mode": "recorded",
        "requests": 24,
        "summed_request_ms": 13282.60269999737,
        "prompt_tokens": 3796,
        "completion_tokens": 48,
        "calls": [
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 0. Temperature=70.0 C; load=45. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-f0b4b639f3ff468998a7ab66",
                    "object": "chat.completion",
                    "created": 1791082281,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -2.550341077125383,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7512764408949142,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8179077580335861,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.550341077125383,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -6.248403973853899,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.69522327927382,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.907292790687395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.273274846351457,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.621528096473527,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.717767186439348,
                                                "bytes": None
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.820643849647356,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.88039631394179,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.97051853684218,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -9.077261395728899,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -9.102740712440324,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.12904781845839,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -9.271607823646379,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.370233006751848,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.423066563880754,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.619741864478899,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "c",
                                                "logprob": -9.657709546363664,
                                                "bytes": [
                                                    99
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 157,
                        "completion_tokens": 2,
                        "total_tokens": 159,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 157,
                        "prompt_ms": 1733.9,
                        "prompt_per_token_ms": 11.044,
                        "prompt_per_second": 90.5,
                        "predicted_n": 2,
                        "predicted_ms": 62.3,
                        "predicted_per_token_ms": 31.15,
                        "predicted_per_second": 32.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1824.0522000123747,
                "captured_at": "2026-10-04T02:51:24Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 0. Temperature=70.0 C; load=45. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-db80add5f5da4926a3378581",
                    "object": "chat.completion",
                    "created": 1791082283,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.7512764408949142,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7512764408949142,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8179077580335861,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.550341077125383,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -6.248403973853899,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.69522327927382,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.907292790687395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.273274846351457,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.621528096473527,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.717767186439348,
                                                "bytes": None
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.820643849647356,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.88039631394179,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.97051853684218,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -9.077261395728899,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -9.102740712440324,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.12904781845839,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -9.271607823646379,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.370233006751848,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.423066563880754,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.619741864478899,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "c",
                                                "logprob": -9.657709546363664,
                                                "bytes": [
                                                    99
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 157,
                        "completion_tokens": 2,
                        "total_tokens": 159,
                        "prompt_tokens_details": {
                            "cached_tokens": 150
                        }
                    },
                    "timings": {
                        "cache_n": 150,
                        "prompt_n": 7,
                        "prompt_ms": 236.6,
                        "prompt_per_token_ms": 33.8,
                        "prompt_per_second": 29.6,
                        "predicted_n": 2,
                        "predicted_ms": 59.9,
                        "predicted_per_token_ms": 29.95,
                        "predicted_per_second": 33.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 309.01860003359616,
                "captured_at": "2026-10-04T02:51:24Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 0. Temperature=70.0 C; load=45. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"C\""
                },
                "response": {
                    "id": "chatcmpl-74c33869bf504228a944d0dd",
                    "object": "chat.completion",
                    "created": 1791082284,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "C"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "C",
                                        "logprob": -0.8179077580335861,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7512764408949142,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8179077580335861,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.550341077125383,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -6.248403973853899,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.69522327927382,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.907292790687395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.273274846351457,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.621528096473527,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.717767186439348,
                                                "bytes": None
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.820643849647356,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.88039631394179,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.97051853684218,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -9.077261395728899,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -9.102740712440324,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -9.12904781845839,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -9.271607823646379,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.370233006751848,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.423066563880754,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.619741864478899,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "c",
                                                "logprob": -9.657709546363664,
                                                "bytes": [
                                                    99
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 157,
                        "completion_tokens": 2,
                        "total_tokens": 159,
                        "prompt_tokens_details": {
                            "cached_tokens": 150
                        }
                    },
                    "timings": {
                        "cache_n": 150,
                        "prompt_n": 7,
                        "prompt_ms": 236.4,
                        "prompt_per_token_ms": 33.771,
                        "prompt_per_second": 29.6,
                        "predicted_n": 2,
                        "predicted_ms": 63,
                        "predicted_per_token_ms": 31.5,
                        "predicted_per_second": 31.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 312.6445999951102,
                "captured_at": "2026-10-04T02:51:24Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 0. Temperature=70.0 C; load=45. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 5,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\""
                },
                "response": {
                    "id": "chatcmpl-1d04730e67c14ff6bb1517ad",
                    "object": "chat.completion",
                    "created": 1791082284,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.7512764408949142,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7512764408949142,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8179077580335861,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.550341077125383,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -6.248403973853899,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.69522327927382,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 157,
                        "completion_tokens": 2,
                        "total_tokens": 159,
                        "prompt_tokens_details": {
                            "cached_tokens": 150
                        }
                    },
                    "timings": {
                        "cache_n": 150,
                        "prompt_n": 7,
                        "prompt_ms": 234.9,
                        "prompt_per_token_ms": 33.557,
                        "prompt_per_second": 29.8,
                        "predicted_n": 2,
                        "predicted_ms": 58.1,
                        "predicted_per_token_ms": 29.05,
                        "predicted_per_second": 34.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 309.8667000303976,
                "captured_at": "2026-10-04T02:51:25Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 1. Temperature=68.5 C; load=70. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-415f3c9dbdd14dcd8472ab29",
                    "object": "chat.completion",
                    "created": 1791082284,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -2.551958506702714,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "C",
                                                "logprob": -0.6093601638072063,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0322803908579874,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.551958506702714,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.306089823841386,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.354607051014238,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.632190173267656,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.58139461815291,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -8.004173701404863,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.131057208179765,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -8.258840983509355,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.387920802234941,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.480244105457597,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.526527827381425,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.528688853382402,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -8.560599749683671,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.62105125725203,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.658313220142656,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.683956568836503,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.842512553333574,
                                                "bytes": None
                                            },
                                            {
                                                "token": "What",
                                                "logprob": -8.970396464466386,
                                                "bytes": [
                                                    87,
                                                    104,
                                                    97,
                                                    116
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 157,
                        "completion_tokens": 2,
                        "total_tokens": 159,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 157,
                        "prompt_ms": 1137,
                        "prompt_per_token_ms": 7.242,
                        "prompt_per_second": 138.1,
                        "predicted_n": 2,
                        "predicted_ms": 58.9,
                        "predicted_per_token_ms": 29.45,
                        "predicted_per_second": 34,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1212.0940999593586,
                "captured_at": "2026-10-04T02:51:26Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 1. Temperature=68.5 C; load=70. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-fb3edcf0fb6c477eaa6749cd",
                    "object": "chat.completion",
                    "created": 1791082285,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -1.0322803908579874,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "C",
                                                "logprob": -0.6093601638072063,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0322803908579874,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.551958506702714,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.306089823841386,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.354607051014238,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.632190173267656,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.58139461815291,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -8.004173701404863,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.131057208179765,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -8.258840983509355,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.387920802234941,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.480244105457597,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.526527827381425,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.528688853382402,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -8.560599749683671,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.62105125725203,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.658313220142656,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.683956568836503,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.842512553333574,
                                                "bytes": None
                                            },
                                            {
                                                "token": "What",
                                                "logprob": -8.970396464466386,
                                                "bytes": [
                                                    87,
                                                    104,
                                                    97,
                                                    116
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 157,
                        "completion_tokens": 2,
                        "total_tokens": 159,
                        "prompt_tokens_details": {
                            "cached_tokens": 150
                        }
                    },
                    "timings": {
                        "cache_n": 150,
                        "prompt_n": 7,
                        "prompt_ms": 234.6,
                        "prompt_per_token_ms": 33.514,
                        "prompt_per_second": 29.8,
                        "predicted_n": 2,
                        "predicted_ms": 58.7,
                        "predicted_per_token_ms": 29.35,
                        "predicted_per_second": 34.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 310.1535000023432,
                "captured_at": "2026-10-04T02:51:26Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 1. Temperature=68.5 C; load=70. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"C\""
                },
                "response": {
                    "id": "chatcmpl-b8c6262b3d824162a1363d90",
                    "object": "chat.completion",
                    "created": 1791082286,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "C"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "C",
                                        "logprob": -0.6093601638072063,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "C",
                                                "logprob": -0.6093601638072063,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0322803908579874,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.551958506702714,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.306089823841386,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.354607051014238,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.632190173267656,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.58139461815291,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "<",
                                                "logprob": -8.004173701404863,
                                                "bytes": [
                                                    60
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -8.131057208179765,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -8.258840983509355,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.387920802234941,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.480244105457597,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.526527827381425,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.528688853382402,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -8.560599749683671,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.62105125725203,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.658313220142656,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.683956568836503,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -8.842512553333574,
                                                "bytes": None
                                            },
                                            {
                                                "token": "What",
                                                "logprob": -8.970396464466386,
                                                "bytes": [
                                                    87,
                                                    104,
                                                    97,
                                                    116
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 157,
                        "completion_tokens": 2,
                        "total_tokens": 159,
                        "prompt_tokens_details": {
                            "cached_tokens": 150
                        }
                    },
                    "timings": {
                        "cache_n": 150,
                        "prompt_n": 7,
                        "prompt_ms": 234.6,
                        "prompt_per_token_ms": 33.514,
                        "prompt_per_second": 29.8,
                        "predicted_n": 2,
                        "predicted_ms": 59.3,
                        "predicted_per_token_ms": 29.65,
                        "predicted_per_second": 33.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 310.3780000237748,
                "captured_at": "2026-10-04T02:51:27Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 1. Temperature=68.5 C; load=70. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 5,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\""
                },
                "response": {
                    "id": "chatcmpl-bed69f9c53a448e5aa584448",
                    "object": "chat.completion",
                    "created": 1791082286,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "C"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "C",
                                        "logprob": -0.6093601638072063,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "C",
                                                "logprob": -0.6093601638072063,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0322803908579874,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.551958506702714,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.306089823841386,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -5.354607051014238,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 157,
                        "completion_tokens": 2,
                        "total_tokens": 159,
                        "prompt_tokens_details": {
                            "cached_tokens": 150
                        }
                    },
                    "timings": {
                        "cache_n": 150,
                        "prompt_n": 7,
                        "prompt_ms": 233.3,
                        "prompt_per_token_ms": 33.329,
                        "prompt_per_second": 30,
                        "predicted_n": 2,
                        "predicted_ms": 59.5,
                        "predicted_per_token_ms": 29.75,
                        "predicted_per_second": 33.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 313.9115999802016,
                "captured_at": "2026-10-04T02:51:27Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 2. Temperature=62.96 C; load=80. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-781d1e7e018e4d329faaafe0",
                    "object": "chat.completion",
                    "created": 1791082286,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -2.0142460020507884,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8781318815673899,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.126014724584968,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.0142460020507884,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -2.614828124853523,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.5103302153076243,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.7621555479492255,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.463344589086921,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.752624526831061,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.779226318212897,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.881339088293464,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.194600120397956,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -7.229669586035163,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -7.284547820898444,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.535218253942878,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "Calculate",
                                                "logprob": -7.729134574743659,
                                                "bytes": [
                                                    67,
                                                    97,
                                                    108,
                                                    99,
                                                    117,
                                                    108,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -7.856531158300788,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Current",
                                                "logprob": -7.926839843603522,
                                                "bytes": [
                                                    67,
                                                    117,
                                                    114,
                                                    114,
                                                    101,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.032573715063483,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -8.262392059179694,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Fan",
                                                "logprob": -8.288938537451179,
                                                "bytes": [
                                                    70,
                                                    97,
                                                    110
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 158,
                        "completion_tokens": 2,
                        "total_tokens": 160,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 158,
                        "prompt_ms": 1099.8,
                        "prompt_per_token_ms": 6.961,
                        "prompt_per_second": 143.7,
                        "predicted_n": 2,
                        "predicted_ms": 62.4,
                        "predicted_per_token_ms": 31.2,
                        "predicted_per_second": 32.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1186.062699998729,
                "captured_at": "2026-10-04T02:51:28Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 2. Temperature=62.96 C; load=80. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-2cda4c58e7da4a3b96de530a",
                    "object": "chat.completion",
                    "created": 1791082288,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.8781318815673899,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8781318815673899,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.126014724584968,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.0142460020507884,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -2.614828124853523,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.5103302153076243,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.7621555479492255,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.463344589086921,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.752624526831061,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.779226318212897,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.881339088293464,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.194600120397956,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -7.229669586035163,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -7.284547820898444,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.535218253942878,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "Calculate",
                                                "logprob": -7.729134574743659,
                                                "bytes": [
                                                    67,
                                                    97,
                                                    108,
                                                    99,
                                                    117,
                                                    108,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -7.856531158300788,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Current",
                                                "logprob": -7.926839843603522,
                                                "bytes": [
                                                    67,
                                                    117,
                                                    114,
                                                    114,
                                                    101,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.032573715063483,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -8.262392059179694,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Fan",
                                                "logprob": -8.288938537451179,
                                                "bytes": [
                                                    70,
                                                    97,
                                                    110
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 158,
                        "completion_tokens": 2,
                        "total_tokens": 160,
                        "prompt_tokens_details": {
                            "cached_tokens": 151
                        }
                    },
                    "timings": {
                        "cache_n": 151,
                        "prompt_n": 7,
                        "prompt_ms": 226.9,
                        "prompt_per_token_ms": 32.414,
                        "prompt_per_second": 30.9,
                        "predicted_n": 2,
                        "predicted_ms": 59.7,
                        "predicted_per_token_ms": 29.85,
                        "predicted_per_second": 33.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 308.01379994954914,
                "captured_at": "2026-10-04T02:51:28Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 2. Temperature=62.96 C; load=80. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"C\""
                },
                "response": {
                    "id": "chatcmpl-aa4b554bd82c41f8aed090ca",
                    "object": "chat.completion",
                    "created": 1791082288,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "C"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "C",
                                        "logprob": -1.126014724584968,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8781318815673899,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.126014724584968,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.0142460020507884,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -2.614828124853523,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.5103302153076243,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.7621555479492255,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.463344589086921,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.752624526831061,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.779226318212897,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.881339088293464,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.194600120397956,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Looking",
                                                "logprob": -7.229669586035163,
                                                "bytes": [
                                                    76,
                                                    111,
                                                    111,
                                                    107,
                                                    105,
                                                    110,
                                                    103
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -7.284547820898444,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.535218253942878,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "Calculate",
                                                "logprob": -7.729134574743659,
                                                "bytes": [
                                                    67,
                                                    97,
                                                    108,
                                                    99,
                                                    117,
                                                    108,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -7.856531158300788,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Current",
                                                "logprob": -7.926839843603522,
                                                "bytes": [
                                                    67,
                                                    117,
                                                    114,
                                                    114,
                                                    101,
                                                    110,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.032573715063483,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -8.262392059179694,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Fan",
                                                "logprob": -8.288938537451179,
                                                "bytes": [
                                                    70,
                                                    97,
                                                    110
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 158,
                        "completion_tokens": 2,
                        "total_tokens": 160,
                        "prompt_tokens_details": {
                            "cached_tokens": 151
                        }
                    },
                    "timings": {
                        "cache_n": 151,
                        "prompt_n": 7,
                        "prompt_ms": 226,
                        "prompt_per_token_ms": 32.286,
                        "prompt_per_second": 31,
                        "predicted_n": 2,
                        "predicted_ms": 60.6,
                        "predicted_per_token_ms": 30.3,
                        "predicted_per_second": 33,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 302.2724000038579,
                "captured_at": "2026-10-04T02:51:29Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 2. Temperature=62.96 C; load=80. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 5,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\""
                },
                "response": {
                    "id": "chatcmpl-83fa398deae242f29630883a",
                    "object": "chat.completion",
                    "created": 1791082288,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.8781318815673899,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8781318815673899,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.126014724584968,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.0142460020507884,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -2.614828124853523,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.5103302153076243,
                                                "bytes": [
                                                    84
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 158,
                        "completion_tokens": 2,
                        "total_tokens": 160,
                        "prompt_tokens_details": {
                            "cached_tokens": 151
                        }
                    },
                    "timings": {
                        "cache_n": 151,
                        "prompt_n": 7,
                        "prompt_ms": 226,
                        "prompt_per_token_ms": 32.286,
                        "prompt_per_second": 31,
                        "predicted_n": 2,
                        "predicted_ms": 59.8,
                        "predicted_per_token_ms": 29.9,
                        "predicted_per_second": 33.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 305.0653000245802,
                "captured_at": "2026-10-04T02:51:29Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 3. Temperature=69.442 C; load=35. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-d59c081182724eddadfb01a2",
                    "object": "chat.completion",
                    "created": 1791082289,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -2.121065600573081,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -1.1177677947869482,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.1346707183709326,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -1.8598847228875341,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.121065600573081,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.4118017989983738,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.196585162340659,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -5.735079272448081,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.8435778457513035,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.242618067919272,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.346655352770346,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.375350459276694,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -6.695895655809897,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -6.785990222155112,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.022739871202964,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.122409327684897,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -7.164748652636069,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.385038836657065,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -7.427508814989585,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -7.430702670275229,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.439943774401206,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 159,
                        "prompt_ms": 1074.9,
                        "prompt_per_token_ms": 6.76,
                        "prompt_per_second": 147.9,
                        "predicted_n": 2,
                        "predicted_ms": 62.4,
                        "predicted_per_token_ms": 31.2,
                        "predicted_per_second": 32.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1159.64129997883,
                "captured_at": "2026-10-04T02:51:30Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 3. Temperature=69.442 C; load=35. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-19126c26d83646d68749f2c4",
                    "object": "chat.completion",
                    "created": 1791082290,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -1.1177677947869482,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -1.1177677947869482,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.1346707183709326,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -1.8598847228875341,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.121065600573081,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.4118017989983738,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.196585162340659,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -5.735079272448081,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.8435778457513035,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.242618067919272,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.346655352770346,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.375350459276694,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -6.695895655809897,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -6.785990222155112,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.022739871202964,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.122409327684897,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -7.164748652636069,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.385038836657065,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -7.427508814989585,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -7.430702670275229,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.439943774401206,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 152
                        }
                    },
                    "timings": {
                        "cache_n": 152,
                        "prompt_n": 7,
                        "prompt_ms": 232.3,
                        "prompt_per_token_ms": 33.186,
                        "prompt_per_second": 30.1,
                        "predicted_n": 2,
                        "predicted_ms": 58.8,
                        "predicted_per_token_ms": 29.4,
                        "predicted_per_second": 34,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 308.72359999921173,
                "captured_at": "2026-10-04T02:51:30Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 3. Temperature=69.442 C; load=35. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"C\""
                },
                "response": {
                    "id": "chatcmpl-f716b14fa097411e8a967efe",
                    "object": "chat.completion",
                    "created": 1791082290,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "C"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "C",
                                        "logprob": -1.1346707183709326,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -1.1177677947869482,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.1346707183709326,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -1.8598847228875341,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.121065600573081,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.4118017989983738,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.196585162340659,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -5.735079272448081,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -5.8435778457513035,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -6.242618067919272,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.346655352770346,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.375350459276694,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -6.695895655809897,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -6.785990222155112,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.022739871202964,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Given",
                                                "logprob": -7.122409327684897,
                                                "bytes": [
                                                    71,
                                                    105,
                                                    118,
                                                    101,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -7.164748652636069,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.385038836657065,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -7.427508814989585,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -7.430702670275229,
                                                "bytes": [
                                                    49
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -7.439943774401206,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 152
                        }
                    },
                    "timings": {
                        "cache_n": 152,
                        "prompt_n": 7,
                        "prompt_ms": 232.1,
                        "prompt_per_token_ms": 33.157,
                        "prompt_per_second": 30.2,
                        "predicted_n": 2,
                        "predicted_ms": 60.5,
                        "predicted_per_token_ms": 30.25,
                        "predicted_per_second": 33.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 314.47630003094673,
                "captured_at": "2026-10-04T02:51:31Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 3. Temperature=69.442 C; load=35. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 5,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\""
                },
                "response": {
                    "id": "chatcmpl-bbd4f700e923456697c3b14c",
                    "object": "chat.completion",
                    "created": 1791082290,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -1.1177677947869482,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -1.1177677947869482,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.1346707183709326,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -1.8598847228875341,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.121065600573081,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -3.4118017989983738,
                                                "bytes": [
                                                    84
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 152
                        }
                    },
                    "timings": {
                        "cache_n": 152,
                        "prompt_n": 7,
                        "prompt_ms": 231.3,
                        "prompt_per_token_ms": 33.043,
                        "prompt_per_second": 30.3,
                        "predicted_n": 2,
                        "predicted_ms": 59.4,
                        "predicted_per_token_ms": 29.7,
                        "predicted_per_second": 33.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 314.2602000152692,
                "captured_at": "2026-10-04T02:51:31Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 4. Temperature=65.764 C; load=20. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-e9714436932241b6a900d814",
                    "object": "chat.completion",
                    "created": 1791082291,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -2.434247620129265,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7861267400023116,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8233620000120773,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.434247620129265,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.051324493908561,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.927264816784538,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.281457550549186,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.837777740978874,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.508731491589225,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.14678920032946,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.351329453015007,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.580331451916374,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.818483002209343,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.848026878857292,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -8.850444443249382,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "4",
                                                "logprob": -8.907484657787956,
                                                "bytes": [
                                                    52
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.921076424145378,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.973747856640495,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.023187286877311,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.11774695637194,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.151761658215202,
                                                "bytes": [
                                                    49
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 159,
                        "prompt_ms": 1066.4,
                        "prompt_per_token_ms": 6.707,
                        "prompt_per_second": 149.1,
                        "predicted_n": 2,
                        "predicted_ms": 61.9,
                        "predicted_per_token_ms": 30.95,
                        "predicted_per_second": 32.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1157.3138000094332,
                "captured_at": "2026-10-04T02:51:32Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 4. Temperature=65.764 C; load=20. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-398bae5c00c84ea8a414b104",
                    "object": "chat.completion",
                    "created": 1791082292,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.7861267400023116,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7861267400023116,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8233620000120773,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.434247620129265,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.051324493908561,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.927264816784538,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.281457550549186,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.837777740978874,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.508731491589225,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.14678920032946,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.351329453015007,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.580331451916374,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.818483002209343,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.848026878857292,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -8.850444443249382,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "4",
                                                "logprob": -8.907484657787956,
                                                "bytes": [
                                                    52
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.921076424145378,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.973747856640495,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.023187286877311,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.11774695637194,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.151761658215202,
                                                "bytes": [
                                                    49
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 152
                        }
                    },
                    "timings": {
                        "cache_n": 152,
                        "prompt_n": 7,
                        "prompt_ms": 231.5,
                        "prompt_per_token_ms": 33.071,
                        "prompt_per_second": 30.2,
                        "predicted_n": 2,
                        "predicted_ms": 60.6,
                        "predicted_per_token_ms": 30.3,
                        "predicted_per_second": 33,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 306.3261999632232,
                "captured_at": "2026-10-04T02:51:33Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 4. Temperature=65.764 C; load=20. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"C\""
                },
                "response": {
                    "id": "chatcmpl-546c047ce50049fdb7043e25",
                    "object": "chat.completion",
                    "created": 1791082292,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "C"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "C",
                                        "logprob": -0.8233620000120773,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7861267400023116,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8233620000120773,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.434247620129265,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.051324493908561,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.927264816784538,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -6.281457550549186,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -6.837777740978874,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.508731491589225,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -8.14678920032946,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "-",
                                                "logprob": -8.351329453015007,
                                                "bytes": [
                                                    45
                                                ]
                                            },
                                            {
                                                "token": "3",
                                                "logprob": -8.580331451916374,
                                                "bytes": [
                                                    51
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -8.818483002209343,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -8.848026878857292,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -8.850444443249382,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "4",
                                                "logprob": -8.907484657787956,
                                                "bytes": [
                                                    52
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -8.921076424145378,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.973747856640495,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -9.023187286877311,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": " C",
                                                "logprob": -9.11774695637194,
                                                "bytes": [
                                                    32,
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "1",
                                                "logprob": -9.151761658215202,
                                                "bytes": [
                                                    49
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 152
                        }
                    },
                    "timings": {
                        "cache_n": 152,
                        "prompt_n": 7,
                        "prompt_ms": 230.9,
                        "prompt_per_token_ms": 32.986,
                        "prompt_per_second": 30.3,
                        "predicted_n": 2,
                        "predicted_ms": 60.7,
                        "predicted_per_token_ms": 30.35,
                        "predicted_per_second": 32.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 312.2008999926038,
                "captured_at": "2026-10-04T02:51:33Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 4. Temperature=65.764 C; load=20. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 5,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\""
                },
                "response": {
                    "id": "chatcmpl-11e11a73041249d49e92f62b",
                    "object": "chat.completion",
                    "created": 1791082292,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.7861267400023116,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.7861267400023116,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -0.8233620000120773,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -2.434247620129265,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -5.051324493908561,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -5.927264816784538,
                                                "bytes": [
                                                    54
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 152
                        }
                    },
                    "timings": {
                        "cache_n": 152,
                        "prompt_n": 7,
                        "prompt_ms": 230.7,
                        "prompt_per_token_ms": 32.957,
                        "prompt_per_second": 30.3,
                        "predicted_n": 2,
                        "predicted_ms": 60.3,
                        "predicted_per_token_ms": 30.15,
                        "predicted_per_second": 33.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 309.9473000038415,
                "captured_at": "2026-10-04T02:51:33Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 5. Temperature=58.933 C; load=65. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-d31d721e3a5c45cea2bd38eb",
                    "object": "chat.completion",
                    "created": 1791082293,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -1.9875713342700476,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8225818628345009,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.0607620233569617,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.9875713342700476,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -3.127488707927274,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -4.219211196330595,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -6.213115310100126,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.769427871135282,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.867462729838896,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -7.210000609782743,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -7.2437673563037395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -7.295641517070341,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.4323755258594035,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.625878905681181,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -7.749969100383329,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -7.793275451091337,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -7.978218650249052,
                                                "bytes": None
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -8.194321250346707,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.237482642558621,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -8.277268027690457,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.325662230876492,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 159,
                        "prompt_ms": 1063.6,
                        "prompt_per_token_ms": 6.689,
                        "prompt_per_second": 149.5,
                        "predicted_n": 2,
                        "predicted_ms": 61.8,
                        "predicted_per_token_ms": 30.9,
                        "predicted_per_second": 32.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1136.5533000207506,
                "captured_at": "2026-10-04T02:51:34Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 5. Temperature=58.933 C; load=65. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-76003dcf842d451699d02da1",
                    "object": "chat.completion",
                    "created": 1791082294,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.8225818628345009,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8225818628345009,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.0607620233569617,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.9875713342700476,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -3.127488707927274,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -4.219211196330595,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -6.213115310100126,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.769427871135282,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.867462729838896,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -7.210000609782743,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -7.2437673563037395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -7.295641517070341,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.4323755258594035,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.625878905681181,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -7.749969100383329,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -7.793275451091337,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -7.978218650249052,
                                                "bytes": None
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -8.194321250346707,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.237482642558621,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -8.277268027690457,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.325662230876492,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 152
                        }
                    },
                    "timings": {
                        "cache_n": 152,
                        "prompt_n": 7,
                        "prompt_ms": 235.5,
                        "prompt_per_token_ms": 33.643,
                        "prompt_per_second": 29.7,
                        "predicted_n": 2,
                        "predicted_ms": 60.5,
                        "predicted_per_token_ms": 30.25,
                        "predicted_per_second": 33.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 310.9024000004865,
                "captured_at": "2026-10-04T02:51:35Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 5. Temperature=58.933 C; load=65. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"C\""
                },
                "response": {
                    "id": "chatcmpl-0390ca1a87b54659b059bfdb",
                    "object": "chat.completion",
                    "created": 1791082294,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "C"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "C",
                                        "logprob": -1.0607620233569617,
                                        "bytes": [
                                            67
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8225818628345009,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.0607620233569617,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.9875713342700476,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -3.127488707927274,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -4.219211196330595,
                                                "bytes": [
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "5",
                                                "logprob": -6.213115310100126,
                                                "bytes": [
                                                    53
                                                ]
                                            },
                                            {
                                                "token": "Temperature",
                                                "logprob": -6.769427871135282,
                                                "bytes": [
                                                    84,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Next",
                                                "logprob": -6.867462729838896,
                                                "bytes": [
                                                    78,
                                                    101,
                                                    120,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -7.210000609782743,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "0",
                                                "logprob": -7.2437673563037395,
                                                "bytes": [
                                                    48
                                                ]
                                            },
                                            {
                                                "token": "To",
                                                "logprob": -7.295641517070341,
                                                "bytes": [
                                                    84,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "D",
                                                "logprob": -7.4323755258594035,
                                                "bytes": [
                                                    68
                                                ]
                                            },
                                            {
                                                "token": "let",
                                                "logprob": -7.625878905681181,
                                                "bytes": [
                                                    108,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": ".",
                                                "logprob": -7.749969100383329,
                                                "bytes": [
                                                    46
                                                ]
                                            },
                                            {
                                                "token": "Target",
                                                "logprob": -7.793275451091337,
                                                "bytes": [
                                                    84,
                                                    97,
                                                    114,
                                                    103,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -7.978218650249052,
                                                "bytes": None
                                            },
                                            {
                                                "token": "temperature",
                                                "logprob": -8.194321250346707,
                                                "bytes": [
                                                    116,
                                                    101,
                                                    109,
                                                    112,
                                                    101,
                                                    114,
                                                    97,
                                                    116,
                                                    117,
                                                    114,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "6",
                                                "logprob": -8.237482642558621,
                                                "bytes": [
                                                    54
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -8.277268027690457,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -8.325662230876492,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 152
                        }
                    },
                    "timings": {
                        "cache_n": 152,
                        "prompt_n": 7,
                        "prompt_ms": 235.9,
                        "prompt_per_token_ms": 33.7,
                        "prompt_per_second": 29.7,
                        "predicted_n": 2,
                        "predicted_ms": 59.8,
                        "predicted_per_token_ms": 29.9,
                        "predicted_per_second": 33.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 342.7181000006385,
                "captured_at": "2026-10-04T02:51:35Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nTick 5. Temperature=58.933 C; load=65. Fan choices=0,30,60. Target=60 C; hard maximum=85 C. Next temperature=T+0.22*load-0.32*fan-0.04*(T-25).\nQUESTION: Choose a fan setting to approach 60 C without crossing 85 C.\nANSWERS:\nA: fan 0\nB: fan 30\nC: fan 60\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 5,
                    "grammar": "root ::= \"A\" | \"B\" | \"C\""
                },
                "response": {
                    "id": "chatcmpl-ab1e1f489fd14214931958e3",
                    "object": "chat.completion",
                    "created": 1791082295,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.8225818628345009,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.8225818628345009,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -1.0607620233569617,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.9875713342700476,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -3.127488707927274,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "T",
                                                "logprob": -4.219211196330595,
                                                "bytes": [
                                                    84
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 159,
                        "completion_tokens": 2,
                        "total_tokens": 161,
                        "prompt_tokens_details": {
                            "cached_tokens": 152
                        }
                    },
                    "timings": {
                        "cache_n": 152,
                        "prompt_n": 7,
                        "prompt_ms": 234.6,
                        "prompt_per_token_ms": 33.514,
                        "prompt_per_second": 29.8,
                        "predicted_n": 2,
                        "predicted_ms": 60,
                        "predicted_per_token_ms": 30,
                        "predicted_per_second": 33.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 306.0057999682613,
                "captured_at": "2026-10-04T02:51:35Z"
            }
        ]
    },
    "wall_ms": 255.5138999596238,
    "lesson_view": {
        "index": 0,
        "value": 0,
        "scope": "Reproduce the selected question/rule/result panel. Other page dials are independent."
    }
}
import argparse
import copy
import hashlib
import json
import math
import os
import sys
from pathlib import Path
import urllib.error
import urllib.request

"""Small, portable calculations behind the question/rule/result panels.

Standard library only. This exact source is included in every Python download.
Inputs are the captured experiment, never an invented new model response. A knob
changes a disclosed calculation on those inputs; it does not rescore a new prompt.
"""
import itertools
import math
import statistics


def _spec(question, rule, knob, default, compare, low, high, integer=False):
    return dict(question=question, rule=rule, knob=knob, default=default,
                compare=compare, low=low, high=high, integer=integer)


LESSON_SPECS = {
    'choice': _spec('Which ticket queue gets this message?', 'Compare the three saved label scores. Heat flattens their relative weights; it adds no evidence.', 'Reweighting temperature', 1, 2, .1, 3),
    'boolean': _spec('Does this message ask to cancel?', 'Normalize the saved Yes and No scores. A number near one is a strong preference, not proof.', 'Reweighting temperature', 1, 2, .1, 3),
    'score': _spec('How serious is the outage?', 'Multiply each rubric value by its answer weight, then add. The rating comes from the whole distribution.', 'Reweighting temperature', 1, 2, .1, 3),
    'candidates': _spec('Read the failure first, or start changing things?', 'Add token logprobs along each saved path, then sum path mass inside each finite group. A length penalty changes the objective.', 'Length penalty exponent', 0, 1, 0, 1),
    'controller': _spec('May the simulated repair take its next step?', 'Keep only state-legal actions. Hold the recorded action if its relative legal weight falls below the threshold.', 'Required legal-action weight', 0, .999, 0, 1),
    'rerank': _spec('Which sources help explain cancellation?', 'Compute each source’s expected relevance separately, then keep those above the cutoff.', 'Minimum relevance', 0, .9, 0, 1),
    'graph': _spec('Which text links can coexist?', 'Search every small edge subset. Reject cycles and competing attachments, then maximize useful edge weight.', 'Edge cost / threshold', .5, .9, .01, .99),
    'scene': _spec('Which valid drawing best fits the instruction?', 'Average the three saved text probes. Optionally charge for disagreement between them; code still checks geometry.', 'Disagreement penalty', 0, 1, 0, 2),
    'wire': _spec('What did the model assign to this actual token?', 'Exponentiate its raw logprob. Sum only the reported alternatives; their top-N list may omit probability mass.', 'Visible token index (zero-based)', 0, 5, 0, 10000, True),
    'speculation': _spec('Why can a draft be rejected?', 'Compare the proposal head and target verification on the same proposed token. They are different distributions.', 'Proposal position (zero-based)', 0, 2, 0, 10000, True),
    'performance': _spec('What did each API path cost on this setup?', 'Recalculate a latency percentile from the original wall-time samples. Different output tasks remain separate.', 'Latency percentile', 50, 90, 0, 100),
    'samplers': _spec('How much did this recipe change the selected token’s weight?', 'Compare its raw target probability with its post-sampler probability. Read support and entropy from the complete native row.', 'Recorded recipe index (zero-based)', 0, 1, 0, 10000, True),
    'sampler-sandbox': _spec('Can we add heat without admitting implausible tokens?', 'Remove logits below max + log(0.05), then divide the survivors by temperature and normalize.', 'Temperature after Min-P', 1.5, .7, .1, 3),
    'tictactoe': _spec('Did a legal move give away a winnable outcome?', 'Solve the saved position by exhaustive minimax. Compare the best legal outcome with the recorded model move.', 'Recorded turn index (zero-based)', 0, 1, 0, 10000, True),
    'chess': _spec('Did the shortlist favor a mating move?', 'Add the saved label weights attached to code-checked mating moves. The separately generated UCI move uses a different prompt.', 'Shortlist temperature', 1, 3, .1, 3),
    'poker': _spec('Should this hand check or bet?', 'Average exact chip payoffs over the two possible opponent cards using the stated calling policy.', 'Opponent call-rate multiplier', 1, 0, 0, 2),
    'thermal': _spec('What happens if we replay the fan commands differently?', 'Step the disclosed thermal equation through the same loads. A fan offset is an open-loop counterfactual, not a new model policy.', 'Fan offset', 0, 20, -60, 60),
    'scheduler': _spec('How much lateness did this legal schedule cause?', 'Add job durations in the recorded order and check dependencies. Charge for finishing after the adjusted deadline.', 'Deadline shift', 0, -3, -10, 10),
    'context': _spec('Did replacing old text change the current-state answer?', 'Recalculate each saved Yes/No distribution and compare the selected wording with the original append-only prompt.', 'Context variant index (zero-based)', 0, 2, 0, 10000, True),
    'observer': _spec('Which action follows from these three semantic measurements?', 'Apply the same explicit threshold rule to every saved report: inspect, verify, finish, or ask.', 'Decision threshold', .5, .999, 0, 1),
    'calibration': _spec('Does demanding stronger answers leave enough coverage?', 'Recalculate Brier error on all six examples and accuracy only on retained examples. Empty coverage has no accuracy.', 'Required answer weight', .5, 1, .5, 1),
    'information': _spec('Which observation is worth buying?', 'Use the stated sensor likelihoods to compute both Bayesian posteriors and expected entropy reduction.', 'Test index (zero-based)', 0, 1, 0, 10000, True),
    'search': _spec('Which valid scene survives a cost penalty?', 'Subtract the chosen cost charge from each saved semantic weight. Reject invalid geometry before ranking.', 'Cost weight', .1, 1, 0, 1),
    'frontier': _spec('Would faster score transfer matter here?', 'Add assumed forward time, a transfer lower bound, and the measured selector. This is a serial cost sketch.', 'Assumed transfer GB/s', 12, 2, .1, 128),
    'research-map': _spec('What would make this research idea testable?', 'Count the disclosed implementation categories, then reveal one branch’s next gate. A proposal is not a native result.', 'Branch index (zero-based)', 0, 12, 0, 10000, True),
    'pressure': _spec('How much original mass did this boundary throw away?', 'At temperature 1 with pure masking, log Z = raw selected logprob − log(selected masked probability). Pressure is −log Z.', 'Native grammar index (zero-based)', 0, 1, 0, 10000, True),
    'circuit': _spec('Can we compute AND without assuming independence?', 'Start with four joint worlds. Optionally condition on noisy evidence of style, then add worlds for each logical operation.', 'Reliability of observing style', .5, 1, .5, 1),
    'control': _spec('Can preference change while forbidden actions stay forbidden?', 'Normalize log(base) + strength × [log(desired) − log(undesired)] inside the legal set.', 'Control strength', 0, 2, 0, 3),
    'future': _spec('Can a less likely first move have a better future?', 'Weight the root policy by exact future success raised to strength. At strength zero use the base policy.', 'Future-value strength', 0, 1, 0, 2),
    'sensitivity': _spec('Which prompt intervention moves this measurement?', 'Rebuild the central finite-difference matrix. Predict a change in hours, with load fixed at +5 points; preserve the measured holdout error.', 'Change in hours remaining', -1, -2, -2, 2),
    'counterexamples': _spec('Can equivalent algebra confuse the observer?', 'Find the equivalent pair with the largest measured log-odds distance. Evaluate its exact coefficients at the chosen integer.', 'Integer x', 2, -2, -10, 10, True),
}


def normalize_logs(logs):
    finite = [x for x in logs if math.isfinite(x)]
    if not finite:
        raise ValueError('No candidate has positive mass')
    maximum = max(finite)
    weights = [math.exp(x-maximum) if math.isfinite(x) else 0. for x in logs]
    total = math.fsum(weights)
    return [w/total for w in weights]


def weights(rows, temperature=1):
    if any(r.get('logprob') is None for r in rows):
        raise ValueError('A complete label measurement is required; missing top-N entries stay unknown')
    return normalize_logs([r['logprob']/temperature for r in rows])


def entropy(p):
    return -math.fsum(x*math.log2(x) for x in p if x)


def _pick(items, value):
    if not 0 <= value < len(items):
        raise ValueError('Index must be 0..'+str(len(items)-1))
    return items[int(value)]


def _rows(names, values):
    return [dict(label=str(n), value=float(v)) for n,v in zip(names,values)]


def _graph(edges, threshold):
    if len(edges)>12:
        raise ValueError('This exact demonstration supports at most 12 edges')
    best, score = [], 0.
    for bits in itertools.product((False,True), repeat=len(edges)):
        selected=[e for e,yes in zip(edges,bits) if yes]
        out, incoming, captions = {}, set(), set()
        good=True
        for e in selected:
            a,b=e['source'],e['target']
            if a==b:good=False;break
            if e['relation']=='caption':
                if a in captions:good=False;break
                captions.add(a)
            else:
                if a in out or b in incoming:good=False;break
                out[a]=b;incoming.add(b)
        for start in out:
            node,visited=start,set()
            while node in out:
                if node in visited:good=False;break
                visited.add(node);node=out[node]
        utility=math.fsum(e['weight']-threshold for e in selected)
        if good and utility>score:best,score=selected,utility
    return best,score


def _ttt(board, turn):
    lines=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
    for a,b,c in lines:
        if board[a]!='.' and board[a]==board[b]==board[c]:return 1 if board[a]=='X' else -1
    if '.' not in board:return 0
    values=[_ttt(board[:i]+turn+board[i+1:],'O' if turn=='X' else 'X') for i,s in enumerate(board) if s=='.']
    return (max if turn=='X' else min)(values)


def calculate_lesson(name, data, value=None):
    spec=LESSON_SPECS[name]
    v=spec['default'] if value is None else value
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not spec['low']<=v<=spec['high'] or (spec['integer'] and int(v)!=v):
        raise ValueError(f"{spec['knob']} must be {'an integer' if spec['integer'] else 'finite'} in [{spec['low']}, {spec['high']}]")
    rows=[];metrics={};note='Calculation on saved inputs; changing this setting makes no new model request.'
    summary='';unit='weight'
    if name in ('choice','boolean','score'):
        p=weights(data['rows'],v);at=max(range(len(p)),key=p.__getitem__)
        rows=_rows([r['label']+' · '+r.get('description','') for r in data['rows']],p)
        metrics=dict(winner=data['rows'][at]['label'],top_weight=p[at],entropy_bits=entropy(p))
        if name in ('boolean','score'):
            metrics['expected_value']=math.fsum(q*r['value'] for q,r in zip(p,data['rows']))
        summary=f"Answer {metrics['winner']} leads with {p[at]:.2%} of the listed-label weight."
        if name=='score':summary=f"Expected rubric value: {metrics['expected_value']:.4f} on the stated 0–1 scale."
    elif name=='candidates':
        paths=data['paths'];logs=[math.fsum(t['logprob'] for t in r['tokens'])/len(r['tokens'])**v for r in paths]
        p=normalize_logs(logs);names=list(dict.fromkeys(r['group'] for r in paths))
        values=[math.fsum(q for q,r in zip(p,paths) if r['group']==g) for g in names];rows=_rows(names,values)
        metrics=dict(winner=names[values.index(max(values))],group_weights=values)
        summary=metrics['winner']+' carries the most relative group weight.'
        note='Only these emitted token paths, with their saved terminators and no EOS. A nonzero length penalty produces preference scores, not path probability.'
    elif name=='controller':
        labels=data['measure']['rows'];p=weights(labels);legal=[i for i,r in enumerate(labels) if r['allowed']]
        mass=math.fsum(p[i] for i in legal);pick=next(i for i,r in enumerate(labels) if r['action']==data['action'])
        q=p[pick]/mass;held=q<v
        rows=_rows([labels[i]['action'] for i in legal],[p[i]/mass for i in legal])
        metrics=dict(held=held,selected_weight=q,next_state=data['state'] if held else data['next_state'])
        summary=('Hold the action.' if held else 'Apply '+data['action']+'.')+' State: '+metrics['next_state']+'.'
    elif name=='rerank':
        values=[math.fsum(q*r['value'] for q,r in zip(weights(s['measure']['rows']),s['measure']['rows'])) for s in data['sources']]
        rows=_rows([s['id'] for s in data['sources']],values);kept=[r['label'] for r in rows if r['value']>=v]
        metrics=dict(retained=kept,scores=values);summary='Retain '+(', '.join(kept) or 'no sources')+' at this cutoff.'
    elif name=='graph':
        selected,utility=_graph(data['edges'],v);rows=_rows([e['source']+' → '+e['target'] for e in selected],[e['weight']-v for e in selected]);unit='utility'
        metrics=dict(selected=[(e['source'],e['target'],e['relation']) for e in selected],utility=utility)
        summary=f'{len(selected)} compatible links, total utility {utility:.4f}.'
        note='Global code constraints select links; utility is not the probability that the document graph is correct.'
    elif name=='scene':
        valid=[c for c in data['candidates'] if c['valid']];values=[]
        for c in valid:
            p=[weights(x['measure']['rows'])[0] for x in c['vector']]
            values.append(statistics.mean(p)-v*statistics.pvariance(p))
        rows=_rows([c['name'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['name'],utilities=values)
        summary='Retain '+metrics['retained']+' among geometry-valid candidates.'
        note='These are saved text judgments. This calculation cannot see the drawing or measure visual appeal.'
    elif name=='wire':
        entry=_pick(data['entries'],v);p=math.exp(entry['logprob']);top=entry.get('top_logprobs',[])
        rows=_rows([x['token'] for x in top],[math.exp(x['logprob']) for x in top]);unit='raw probability'
        metrics=dict(token=entry['token'],raw_probability=p,reported_top_mass=math.fsum(r['value'] for r in rows))
        summary=f"Token {entry['token']!r}: raw probability {p:.6g}."
        note='This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary.'
    elif name=='speculation':
        window=data['oracle']['example_rejection'];r=_pick(window['proposal'],v)
        rows=_rows(['Draft head','Target verification'],[r['draft_probability'],math.exp(r['target_logprob'])]);unit='probability / distinct heads'
        metrics=dict(token_id=r['token_id'],target_sequence_logprob=math.fsum(x['target_logprob'] for x in window['proposal']),draft_target_logprob_gap=r['draft_logprob']-r['target_logprob'])
        summary=f"Proposal token {r['token_id']}: the two heads differ by {metrics['draft_target_logprob_gap']:.4f} log units."
        note='Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability.'
    elif name=='performance':
        values=[]
        for r in data['rows']:
            xs=sorted(x['wall_ms'] for x in r['runs']);a=(len(xs)-1)*v/100;lo=math.floor(a);hi=math.ceil(a)
            values.append(xs[lo]+(xs[hi]-xs[lo])*(a-lo))
        rows=_rows([r['name'] for r in data['rows']],values);unit='ms';metrics=dict(percentile=v,times_ms=values)
        summary=f'Percentile {v:g}, recalculated from {data["repeats"]} samples per path.'
        note='Small same-setup samples include network and API cost. JSON answers a different task; this is no universal speed ranking.'
    elif name=='samplers':
        run=_pick(data['runs'],v);token=run['tokens'][0];sample=token['strata_sampling']
        raw=math.exp(token['logprob']);post=sample['probability']
        rows=_rows(['Raw target','After recipe'],[raw,post]);unit='selected token probability'
        metrics=dict(recipe=run['name'],support=sample['support'],raw=raw,selected=post,log_weight_change=math.log(post)-token['logprob'],entropy_bits=sample['entropy']/math.log(2))
        summary=f"{run['name']}: {sample['support']} native tokens remain eligible."
        note='Recipes are separate generations. Entropy and support are full-row native measurements; a top-N slice cannot recover them.'
    elif name=='sampler-sandbox':
        cut=max(data['logits'])+math.log(.05);logs=[x/v if x>=cut else -math.inf for x in data['logits']];p=normalize_logs(logs)
        rows=_rows(data['tokens'],p);metrics=dict(support=sum(x>0 for x in p),entropy_bits=entropy(p),probabilities=p)
        summary=f"{metrics['support']} credible tokens survive; entropy {metrics['entropy_bits']:.3f} bits."
        note='All eight logits are synthetic and visible. This is exact finite-row arithmetic, not a new native receipt.'
    elif name=='tictactoe':
        f=_pick(data['frames'],v);b=f['before'];legal=[i for i,c in enumerate(b) if c=='.'];oracle={i:_ttt(b[:i]+'X'+b[i+1:],'O') for i in legal}
        regret=max(oracle.values())-oracle[f['square']];rows=_rows([str(i+1) for i in legal],list(oracle.values()));unit='X outcome: lose −1 / draw 0 / win 1'
        metrics=dict(regret=regret,square=f['square']+1,oracle=oracle);summary=f"Recorded move: square {f['square']+1}; exact outcome regret {regret}."
    elif name=='chess':
        p=weights(data['measure']['rows'],v);mass=math.fsum(q for q,m in zip(p,data['shortlist']) if m['mate'])
        rows=_rows([m['san'] for m in data['shortlist']],p);metrics=dict(mating_shortlist_weight=mass,generated_uci=data['chosen']['text'],generated_mate=data['mate'])
        summary=f'{mass:.2%} of shortlist weight favors mate; the separate UCI generation '+('mated.' if data['mate'] else 'did not mate.')
        note='The saved legal/mate flags came from python-chess. This portable calculation aggregates them; it is not a replacement chess engine.'
    elif name=='poker':
        ranks=['J','Q','K'];rates={c:min(1,max(0,r*v)) for c,r in data['call_rates'].items()};values={}
        for own in ranks:
            opponents=[c for c in ranks if c!=own];sign=lambda c:1 if ranks.index(own)>ranks.index(c) else -1
            values[own]=dict(check=statistics.mean(sign(c) for c in opponents),bet=statistics.mean((1-rates[c])+rates[c]*2*sign(c) for c in opponents))
        rows=_rows([c+' bet − check' for c in ranks],[values[c]['bet']-values[c]['check'] for c in ranks]);unit='expected chips'
        metrics=dict(values=values,call_rates=rates);summary='Bet when the bar is positive; check when it is negative.'
        note='Uniform remaining-card prior and explicitly assumed opponent policy. Answer weights are not hidden-card beliefs or equilibrium probabilities.'
    elif name=='thermal':
        t=data['frames'][0]['temperature'];temperatures=[]
        for f in data['frames']:
            fan=min(60,max(0,f['fan']+v));t=round(t+.22*f['load']-.32*fan-.04*(t-25),3);temperatures.append(t)
        rows=_rows(range(1,len(temperatures)+1),temperatures);unit='°C';metrics=dict(temperatures=temperatures,mean_error=statistics.mean(abs(t-data['target']) for t in temperatures),violations=sum(t>data['limit'] for t in temperatures))
        summary=f"Mean distance from target: {metrics['mean_error']:.2f}°C; {metrics['violations']} limit violations."
        note='Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control.'
    elif name=='scheduler':
        done=set();clock=0;late=[]
        for f in data['frames']:
            j=f['job']
            if not set(j['after'])<=done:raise ValueError('Saved schedule violates dependencies')
            clock+=j['duration'];late.append(max(0,clock-j['deadline']-v));done.add(j['id'])
        rows=_rows([f['job']['id'] for f in data['frames']],late);unit='late time units';metrics=dict(total_lateness=sum(late),finish_time=clock)
        summary=f'Total lateness {sum(late):g}; the same dependency-valid order ends at time {clock}.'
    elif name=='context':
        selected=_pick(data['runs'],v);all_weights=[weights(r['measure']['rows'])[1] for r in data['runs']];p=all_weights[int(v)]
        rows=_rows([r['name'] for r in data['runs']],all_weights);metrics=dict(variant=selected['name'],no_weight=p,delta_from_append=p-all_weights[0])
        summary=f"{selected['name']}: keep-still answer weight {p:.3%}."
        note='Saved prompt interventions, not KV tensor mutation. This calculation compares their recorded measurements.'
    elif name=='observer':
        actions=[];triples=[]
        for f in data['frames']:
            p=[weights(x['measure']['rows'])[0] for x in f['vector']];triples.append(p)
            actions.append('inspect failure' if p[0]>v else 'verify' if p[1]>v else 'finish' if p[2]>v else 'ask')
        rows=_rows(['Fault','Missing check','Verified'],triples[0]);metrics=dict(actions=actions,vectors=triples)
        summary=' → '.join(actions)+'.';note='Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability.'
    elif name=='calibration':
        p=[weights(r['measure']['rows'])[0] for r in data['rows']];truth=[r['truth'] for r in data['rows']];kept=[i for i,q in enumerate(p) if max(q,1-q)>=v]
        brier=statistics.mean((q-y)**2 for q,y in zip(p,truth));accuracy=statistics.mean(int(p[i]>=.5)==truth[i] for i in kept) if kept else None
        rows=_rows([str(i+1) for i in range(len(p))],p);metrics=dict(brier=brier,retained=len(kept),coverage=len(kept)/len(p),accuracy=accuracy)
        summary=f'{len(kept)}/{len(p)} retained; '+(f'{accuracy:.1%} correct in those cases.' if accuracy is not None else 'accuracy is undefined with zero coverage.')
        note='Six disclosed teaching examples, not a held-out calibration benchmark. Brier error still counts every example.'
    elif name=='information':
        t=_pick(data['tests'],v);prior=data['prior'];py=math.fsum(p*l for p,l in zip(prior,t['likelihood']));yes=[p*l/py for p,l in zip(prior,t['likelihood'])];no=[p*(1-l)/(1-py) for p,l in zip(prior,t['likelihood'])]
        gain=entropy(prior)-py*entropy(yes)-(1-py)*entropy(no);rows=_rows(data['faults'],yes)
        metrics=dict(test=t['name'],gain_bits=gain,gain_per_cost=gain/t['cost'],yes=yes,no=no)
        summary=t['name']+f': {gain:.3f} expected bits; {gain/t["cost"]:.3f} bits per cost unit.'
        note='Prior and likelihoods are stated synthetic sensor assumptions. Bars condition on a positive result; no test was actually purchased.'
    elif name=='search':
        valid=[c for c in data['candidates'] if c['valid']];values=[weights(c['measure']['rows'])[0]-v*c['cost']/3 for c in valid]
        rows=_rows([c['id'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['id'],utilities=values)
        summary='Retain '+metrics['retained']+' after charging for cost; invalid geometry is excluded.'
    elif name=='frontier':
        selector=sorted(r['selection_ms'] for r in data['measurements'])[len(data['measurements'])//2];transfer=data['vocabulary']*data['bytes_per_logit']/(v*1e6);total=60+transfer+selector
        rows=_rows(['Assumed forward','Transfer lower bound','Measured host selector'],[60,transfer,selector]);unit='ms'
        metrics=dict(transfer_ms=transfer,serial_ms=total,tokens_per_second=1000/total)
        summary=f'Serial estimate: {total:.3f} ms/token; {1000/total:.2f} tokens/s.'
        note='Forward time is assumed 60 ms. Selector uses the upper-middle measured sample to match the chart. Queue, prefill and network are excluded.'
    elif name=='research-map':
        branch=_pick(data['branches'],v);categories={}
        for b in data['branches']:categories[b['status']]=categories.get(b['status'],0)+1
        rows=_rows(list(categories),list(categories.values()));unit='branches';metrics=dict(branch=branch['name'],gate=branch['gate'],categories=categories)
        summary=branch['name']+': '+branch['gate'];note='This page recomputes an agenda inventory, not an experiment result. Each implemented branch links to its own evidence.'
    elif name=='pressure':
        case=_pick(data['cases'],v);r=case['rows'][0];token=r['token'];q=token['strata_sampling']['probability'];logz=token['logprob']-math.log(q)
        if logz>1e-6:raise ValueError('Pure-mask mass exceeds one')
        z=math.exp(min(0,logz));rows=_rows(['Survived','Removed'],[z,1-z]);unit='original probability mass'
        metrics=dict(grammar=case['name'],mass=z,pressure_nats=-logz,pressure_bits=-logz/math.log(2))
        summary=f"{case['name']}: {z:.4%} survives; pressure {-logz:.4f} nats."
        note='First actual prefix of this native grammar. Exact only for pure masking at temperature 1, not arbitrary sampler recipes or entire grammar languages.'
    elif name=='circuit':
        p=weights(data['cases'][0]['measurement']['rows']);weighted=[p[0]*(1-v),p[1]*(1-v),p[2]*v,p[3]*v];z=math.fsum(weighted);p=[x/z for x in weighted]
        f=p[1]+p[3];s=p[2]+p[3];rows=_rows(['Neither','Facts only','Style only','Both'],p)
        metrics=dict(F=f,S=s,AND=p[3],OR=1-p[0],F_given_S=p[3]/s if s else None,marginal_product=f*s)
        summary=f'Facts AND style: {p[3]:.2%}; multiplying the marginals would give {f*s:.2%}.'
        note='At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world.'
    elif name=='control':
        logs=[math.log(b)+v*(math.log(d)-math.log(u)) if i in data['allowed'] else -math.inf for i,(b,d,u) in enumerate(zip(data['base'],data['desired'],data['undesired']))];p=normalize_logs(logs)
        rows=_rows(list('ABCD'),p);pick=max(range(len(p)),key=p.__getitem__);metrics=dict(probabilities=p,selected=pick,forbidden_mass=math.fsum(p[i] for i in range(len(p)) if i not in data['allowed']))
        summary=f"Action {'ABCD'[pick]} leads; forbidden-action mass stays zero."
        note='Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook.'
    elif name=='future':
        root=weights(data['policy'][0]['rows']);child=weights(data['policy'][2]['rows']);h=[0,child[1]];p=normalize_logs([math.log(r)+(v*math.log(x) if x else -math.inf) if v else math.log(r) for r,x in zip(root,h)])
        rows=_rows(['A: dead end','B: viable route'],p);success=p[1]*child[1];metrics=dict(root_weights=p,exact_h=h,success_root_only=success,base_success=root[1]*child[1])
        summary=f'{p[1]:.2%} chooses B; leaving the next policy unchanged succeeds {success:.2%} of the time.'
        note='Only BB succeeds in this exact two-step toy. Conditioning both steps is different from steering only the root. No native future-value decoder is claimed.'
    elif name=='sensitivity':
        o=data['observations'];zs=[[math.log(p/(1-p)) for p in row['probabilities']] for row in o]
        matrix=[[(zs[2][i]-zs[1][i])/(2*data['epsilon'][0]),(zs[4][i]-zs[3][i])/(2*data['epsilon'][1])] for i in range(3)]
        delta=[r[0]*v+r[1]*5 for r in matrix];rows=_rows(['Urgency','Load','Damage'],delta);unit='predicted log-odds change'
        observed=[zs[6][i]-zs[0][i] for i in range(3)];held=[r[0]*-1+r[1]*5 for r in matrix]
        metrics=dict(matrix=matrix,predicted_delta=delta,holdout_residual=[a-b for a,b in zip(observed,held)])
        summary=f'Predicted urgency shift {delta[0]:+.3f}; the measured −1h/+5 holdout had error {metrics["holdout_residual"][0]:+.3f}.'
        note='The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses.'
    elif name=='counterexamples':
        nodes=data['nodes'];pairs=[]
        for i,a in enumerate(nodes):
            za=[math.log(p/(1-p)) for p in a['p_yes']]
            for j,b in enumerate(nodes[i+1:],i+1):
                if a['coefficients']!=b['coefficients']:continue
                zb=[math.log(p/(1-p)) for p in b['p_yes']];distance=math.sqrt(math.fsum((x-y)**2 for x,y in zip(za,zb)));pairs.append((distance,i,j))
        distance,i,j=max(pairs);a,b=nodes[i],nodes[j];evaluate=lambda c:sum(x*v**k for k,x in enumerate(c))
        rows=_rows([a['expression'],b['expression']],[a['p_yes'][1],b['p_yes'][1]])
        metrics=dict(left=a['expression'],right=b['expression'],margin_distance=distance,left_value=evaluate(a['coefficients']),right_value=evaluate(b['coefficients']))
        summary=f'Equal exact values at x={v:g}: {metrics["left_value"]:g}; observer distance {distance:.3f}.'
        note='Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe.'
    else:
        raise ValueError('No portable calculation for '+name)
    return dict(value=v,summary=summary,rows=rows,unit=unit,metrics=metrics,note=note)


def make_lesson(name, data):
    spec=LESSON_SPECS[name]
    try:
        first=calculate_lesson(name,data)
        compare=spec['compare']
        # An edited run can have fewer tokens/turns than the recorded default.
        lengths={'wire':len(data.get('entries',[])), 'samplers':len(data.get('runs',[])),
                 'tictactoe':len(data.get('frames',[])), 'context':len(data.get('runs',[])),
                 'information':len(data.get('tests',[])), 'research-map':len(data.get('branches',[])),
                 'pressure':len(data.get('cases',[]))}
        if name in lengths:compare=min(compare,lengths[name]-1)
        second=calculate_lesson(name,data,compare)
        context=data.get('prompt','').partition('STATE:\n')[2].partition('\nQUESTION:')[0]
        return dict(**spec,states=[first,second],input_excerpt=context[:320]+('…' if len(context)>320 else ''),scope='This panel and its Python calculation reproduce saved measurements. Other page controls are independent views.')
    except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:
        # A genuinely incomplete score or a tool-only wire response stays usable.
        # Do not turn an unavailable lesson into fabricated measurement data.
        return dict(**spec,states=[],unavailable=str(error),scope='This run has no complete inputs for this calculation. Inspect its exact request and result below.')



def mock_post(request, fixture):
    if request != fixture['request']:
        raise ValueError('No mock matches the edited request. Supply a new fixture or explicitly choose --live-url.')
    return copy.deepcopy(fixture['response'])


def live_post(base_url, request):
    if not base_url.startswith(('http://', 'https://')):
        raise ValueError('--live-url must be an http(s) Strata address')
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('STRATA_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['STRATA_API_KEY']
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    body = json.dumps(request, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base_url.rstrip('/')+'/v1/chat/completions', data=body, headers=headers)
    with opener.open(req, timeout=600) as response:
        wire = response.read().decode('utf-8')
    if request.get('stream'):
        events = [line[5:].strip() for line in wire.splitlines() if line.startswith('data:')]
        if not events or events[-1] != '[DONE]':
            raise ValueError('Stream closed without [DONE]')
        chunks = [json.loads(line) for line in events[:-1]]
        if any('error' in chunk for chunk in chunks):
            raise ValueError('Stream reported an error: '+repr(chunks))
        return {'sse_events': chunks, 'wire': wire}
    reply = json.loads(wire)
    if 'error' in reply:
        raise ValueError('Strata reported an error: '+repr(reply['error']))
    return reply


def summarize(response):
    if 'sse_events' in response:
        return str(len(response['sse_events']))+' SSE events; inspect the saved wire response'
    choice = (response.get('choices') or [{}])[0]
    message = choice.get('message', {})
    text = message.get('content') or json.dumps(message.get('tool_calls') or message, ensure_ascii=False)
    entries = (choice.get('logprobs') or {}).get('content') or []
    if entries:
        text += '\n  First visible token raw probability: '+format(math.exp(entries[0]['logprob']), '.7g')
    return text


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=int, default=1, help='1-based request index (default 1)')
    parser.add_argument('--all', action='store_true', help='Replay every mock in this captured run')
    parser.add_argument('--show', action='store_true', help='Print exact selected HTTP request JSON')
    parser.add_argument('--lesson-only', action='store_true', help='Recalculate the captured question/rule/result panel without printing mocked calls')
    parser.add_argument('--value', type=float, help='Change the panel parameter within its documented bounds; offline calculation only')
    parser.add_argument('--live-url', help='Explicitly send ONE request to your compatible Strata server')
    parser.add_argument('--output', type=Path, help='Write responses and their provenance as JSON')
    args = parser.parse_args()
    if args.all and args.live_url:
        parser.error('--all is offline only; saved dependent requests are not a live adaptive controller')
    if args.live_url and (args.lesson_only or args.value is not None):
        parser.error('Lesson calculations use captured evidence. Do not mix --live-url with --lesson-only or --value.')
    calls = CAPTURED['receipt']['calls']
    print('Strata Control Lab / '+CAPTURED['experiment'])
    print('LIVE selected request' if args.live_url else 'OFFLINE MOCK / recorded responses, no inference or network')
    calculation=None
    if not args.live_url:
        spec=CAPTURED.get('lesson')
        if spec and spec.get('states'):
            knob=args.value if args.value is not None else (CAPTURED.get('lesson_view') or {}).get('value',spec['default'])
            try:calculation=calculate_lesson(CAPTURED['experiment'],CAPTURED['result'],knob)
            except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:parser.error(str(error))
            print('\nQUESTION: '+spec['question']+'\nRULE: '+spec['rule'])
            print(spec['knob']+' = '+str(knob)+f" (allowed {spec['low']}..{spec['high']})")
            print('RESULT: '+calculation['summary'])
            print('BOUNDARY: '+calculation['note'])
            print('Reproduces the selected question/rule/result panel; other page dials are independent.')
            print(json.dumps(calculation,ensure_ascii=True,indent=2))
        elif args.lesson_only or args.value is not None:
            parser.error('This captured run has no complete lesson inputs: '+str((spec or {}).get('unavailable','missing calculation')))
    if args.lesson_only:
        result=dict(mode='offline-calculation',calculation=calculation)
    elif not calls:
        if args.live_url:
            parser.error('This page has no HTTP requests: it is analytical or recorded diagnostic evidence')
        print('No HTTP request, GBNF or JSON output constraint was used by this page.')
        print('The included result is a calculation/diagnostic snapshot, not a new model answer.')
        result = dict(mode='offline-snapshot', result=CAPTURED['result'])
        print(json.dumps(result, ensure_ascii=True, indent=2))
    else:
        indexes = range(len(calls)) if args.all else [args.request-1]
        if any(i < 0 or i >= len(calls) for i in indexes):
            parser.error('Request index must be 1..'+str(len(calls)))
        results = []
        for i in indexes:
            fixture = calls[i]
            request = copy.deepcopy(fixture['request'])  # Edit here to try your own live request.
            if args.show:
                print(json.dumps(request, ensure_ascii=True, indent=2))
            response = live_post(args.live_url, request) if args.live_url else mock_post(request, fixture)
            print('Request '+str(i+1)+' / '+str(len(calls))+': '+summarize(response))
            results.append(dict(request=request, response=response,
                                provenance='live-request' if args.live_url else 'mocked-native-recording'))
        result = dict(mode='live' if args.live_url else 'offline-mock', calls=results)
        print('GBNF and JSON settings are in each request. Use --show to inspect them.')
        print('The saved page result is in CAPTURED["result"]; live responses do not recompute that snapshot.')
    if calculation is not None:result['calculation']=calculation
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
