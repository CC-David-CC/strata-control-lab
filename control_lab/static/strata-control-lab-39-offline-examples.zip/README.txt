STRATA CONTROL LAB — 39 PORTABLE EXAMPLES

Python 3 standard library only. No server, GPU, credentials, packages or network
is needed. Each file includes the exact requests, GBNF/JSON/sampler settings,
recorded replies, page inputs and the calculation from its question/rule/result
panel. Every calculation was run with network operations blocked.

Windows PowerShell:
  py .\strata-choice-example.py
  py .\strata-pressure-example.py --lesson-only --value 1

Ubuntu / Linux:
  python3 ./strata-choice-example.py
  python3 ./strata-pressure-example.py --lesson-only --value 1

Inspect a request:  python strata-scene-example.py --request 1 --show
Replay every mock: python strata-samplers-example.py --all
Save calculation:  python strata-circuit-example.py --lesson-only --output result.json

The default reproduces the starting compact panel. --lesson-only omits verbose
mock responses. --value changes that panel's named, bounded parameter. The script
prints its meaning, valid range, result and limitations. Python contains the
actual arithmetic: this is more than printing a cached conclusion.

Changing a parameter recalculates saved measurements, not new model inference.
Other page sliders and the saved multi-step trace are independent views. A
request edit needs a matching new fixture or an explicit live request. Analytical
pages say when no HTTP request, GBNF or JSON constraint was used.

ONE explicit live request to a compatible Strata server:
  python strata-pressure-example.py --request 1 --live-url http://127.0.0.1:8080
STRATA_API_KEY may supply your configured key; no key is embedded here. --live-url
cannot be combined with --all, --value or --lesson-only. A live selected request
does not run an adaptive controller or recompute the saved page result. No client
tool or shell command is executed. Broken/error SSE streams fail visibly.

The website's Download Python + mocks button captures its currently selected
compact panel. This archive contains the tested starting views. Native receipts
remain distinct from synthetic inputs and user-controlled assumptions. UI motion
illustrates the algorithm; it is not GPU telemetry.

Qualification: docs/applied-evidence/browser/results.json
Rubric: docs/CONTROL_LAB_QUALITY_RUBRIC.md (v1, frozen before grading).
