# -*- coding: utf-8 -*-
"""Downloaded Strata example: Python 3 standard library; offline by default.

Windows: py strata-example.py
Ubuntu:  python3 strata-example.py
Show a request: python strata-example.py --request 1 --show
Replay all recorded calls: python strata-example.py --all
Recalculate the panel: python strata-example.py --lesson-only
Change its knob: python strata-example.py --lesson-only --value NUMBER
Try ONE request live: python strata-example.py --request 1 --live-url http://127.0.0.1:8080
An optional STRATA_API_KEY environment variable supplies authentication.

CAPTURED is inserted above this runner by the page. It contains this exact run,
with requests, GBNF/JSON settings, responses, streaming chunks and the page result.
Mock mode returns those responses; it performs no inference and opens no socket.
Live mode runs only a selected request. It does not execute tools or adapt a saved
multi-step trace to new answers. No captured API key or authorization header exists.
"""
CAPTURED = {
    "experiment": "graph",
    "type": "result",
    "result": {
        "blocks": [
            {
                "id": "B17",
                "location": "page 2, line 4",
                "text": "The engine stops generation when"
            },
            {
                "id": "B18",
                "location": "page 2, line 5",
                "text": "the client disconnects, then drains pending output."
            },
            {
                "id": "B19",
                "location": "page 2, figure 1 caption",
                "text": "Figure 1. A request moves through the engine queue."
            },
            {
                "id": "B20",
                "location": "page 2, paragraph 3",
                "text": "The diagram below shows the request queue and cancellation path."
            }
        ],
        "edges": [
            {
                "source": "B17",
                "target": "B18",
                "relation": "continues",
                "weight": 0.6046520017360183,
                "measure": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Yes, the statement is supported by the state",
                            "value": 1,
                            "text": "A",
                            "tokens": [
                                {
                                    "token": "A",
                                    "logprob": -0.5088750178078288,
                                    "bytes": [
                                        65
                                    ],
                                    "top_logprobs": [
                                        {
                                            "token": "A",
                                            "logprob": -0.5088750178078288,
                                            "bytes": [
                                                65
                                            ]
                                        },
                                        {
                                            "token": "B",
                                            "logprob": -0.9337617212990398,
                                            "bytes": [
                                                66
                                            ]
                                        },
                                        {
                                            "token": "Yes",
                                            "logprob": -6.28617871348654,
                                            "bytes": [
                                                89,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "YES",
                                            "logprob": -7.082244043991911,
                                            "bytes": [
                                                89,
                                                69,
                                                83
                                            ]
                                        },
                                        {
                                            "token": " A",
                                            "logprob": -7.521751528427946,
                                            "bytes": [
                                                32,
                                                65
                                            ]
                                        },
                                        {
                                            "token": " B",
                                            "logprob": -7.911688929245817,
                                            "bytes": [
                                                32,
                                                66
                                            ]
                                        },
                                        {
                                            "token": "Answer",
                                            "logprob": -8.45261109416281,
                                            "bytes": [
                                                65,
                                                110,
                                                115,
                                                119,
                                                101,
                                                114
                                            ]
                                        },
                                        {
                                            "token": "First",
                                            "logprob": -8.9743157679299,
                                            "bytes": [
                                                70,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "NO",
                                            "logprob": -9.129299288437712,
                                            "bytes": [
                                                78,
                                                79
                                            ]
                                        },
                                        {
                                            "token": "Y",
                                            "logprob": -9.129624491379607,
                                            "bytes": [
                                                89
                                            ]
                                        },
                                        {
                                            "token": "FIRST",
                                            "logprob": -9.30538094584738,
                                            "bytes": [
                                                70,
                                                73,
                                                82,
                                                83,
                                                84
                                            ]
                                        },
                                        {
                                            "token": "No",
                                            "logprob": -9.345752840683806,
                                            "bytes": [
                                                78,
                                                111
                                            ]
                                        },
                                        {
                                            "token": "ANS",
                                            "logprob": -9.38680470530783,
                                            "bytes": [
                                                65,
                                                78,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "The",
                                            "logprob": -9.741802340195525,
                                            "bytes": [
                                                84,
                                                104,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "b",
                                            "logprob": -9.765051966355193,
                                            "bytes": [
                                                98
                                            ]
                                        },
                                        {
                                            "token": "yes",
                                            "logprob": -10.461070185349334,
                                            "bytes": [
                                                121,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "Let",
                                            "logprob": -10.718962793991912,
                                            "bytes": [
                                                76,
                                                101,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "[",
                                            "logprob": -10.750735407517302,
                                            "bytes": [
                                                91
                                            ]
                                        },
                                        {
                                            "token": "State",
                                            "logprob": -10.776361590073455,
                                            "bytes": [
                                                83,
                                                116,
                                                97,
                                                116,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "```",
                                            "logprob": -10.822066431687224,
                                            "bytes": [
                                                96,
                                                96,
                                                96
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "token_count": 1,
                            "logprob": -0.5088750178078288,
                            "path_probability": 0.6011715057765193,
                            "mean_logprob": -0.5088750178078288,
                            "finish_reason": "stop",
                            "raw_probability": 0.6011715057765193,
                            "weight": 0.6046520017360183
                        },
                        {
                            "label": "B",
                            "description": "No, the statement is false or not established by the state",
                            "value": 0,
                            "text": "B",
                            "tokens": [
                                {
                                    "token": "B",
                                    "logprob": -0.9337617212990398,
                                    "bytes": [
                                        66
                                    ],
                                    "top_logprobs": [
                                        {
                                            "token": "A",
                                            "logprob": -0.5088750178078288,
                                            "bytes": [
                                                65
                                            ]
                                        },
                                        {
                                            "token": "B",
                                            "logprob": -0.9337617212990398,
                                            "bytes": [
                                                66
                                            ]
                                        },
                                        {
                                            "token": "Yes",
                                            "logprob": -6.28617871348654,
                                            "bytes": [
                                                89,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "YES",
                                            "logprob": -7.082244043991911,
                                            "bytes": [
                                                89,
                                                69,
                                                83
                                            ]
                                        },
                                        {
                                            "token": " A",
                                            "logprob": -7.521751528427946,
                                            "bytes": [
                                                32,
                                                65
                                            ]
                                        },
                                        {
                                            "token": " B",
                                            "logprob": -7.911688929245817,
                                            "bytes": [
                                                32,
                                                66
                                            ]
                                        },
                                        {
                                            "token": "Answer",
                                            "logprob": -8.45261109416281,
                                            "bytes": [
                                                65,
                                                110,
                                                115,
                                                119,
                                                101,
                                                114
                                            ]
                                        },
                                        {
                                            "token": "First",
                                            "logprob": -8.9743157679299,
                                            "bytes": [
                                                70,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "NO",
                                            "logprob": -9.129299288437712,
                                            "bytes": [
                                                78,
                                                79
                                            ]
                                        },
                                        {
                                            "token": "Y",
                                            "logprob": -9.129624491379607,
                                            "bytes": [
                                                89
                                            ]
                                        },
                                        {
                                            "token": "FIRST",
                                            "logprob": -9.30538094584738,
                                            "bytes": [
                                                70,
                                                73,
                                                82,
                                                83,
                                                84
                                            ]
                                        },
                                        {
                                            "token": "No",
                                            "logprob": -9.345752840683806,
                                            "bytes": [
                                                78,
                                                111
                                            ]
                                        },
                                        {
                                            "token": "ANS",
                                            "logprob": -9.38680470530783,
                                            "bytes": [
                                                65,
                                                78,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "The",
                                            "logprob": -9.741802340195525,
                                            "bytes": [
                                                84,
                                                104,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "b",
                                            "logprob": -9.765051966355193,
                                            "bytes": [
                                                98
                                            ]
                                        },
                                        {
                                            "token": "yes",
                                            "logprob": -10.461070185349334,
                                            "bytes": [
                                                121,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "Let",
                                            "logprob": -10.718962793991912,
                                            "bytes": [
                                                76,
                                                101,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "[",
                                            "logprob": -10.750735407517302,
                                            "bytes": [
                                                91
                                            ]
                                        },
                                        {
                                            "token": "State",
                                            "logprob": -10.776361590073455,
                                            "bytes": [
                                                83,
                                                116,
                                                97,
                                                116,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "```",
                                            "logprob": -10.822066431687224,
                                            "bytes": [
                                                96,
                                                96,
                                                96
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "token_count": 1,
                            "logprob": -0.9337617212990398,
                            "path_probability": 0.39307229735403154,
                            "mean_logprob": -0.9337617212990398,
                            "finish_reason": "stop",
                            "raw_probability": 0.39307229735403154,
                            "weight": 0.3953479982639816
                        }
                    ],
                    "complete": True,
                    "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B17): The engine stops generation when\nSECOND (B18): the client disconnects, then drains pending output.\nQUESTION: Does SECOND continue FIRST in reading order?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                    "winner": "A",
                    "statistics": {
                        "top_weight": 0.6046520017360183,
                        "margin": 0.2093040034720367,
                        "peakedness": 0.2093040034720366,
                        "entropy_bits": 0.9681642178197483,
                        "expected_score": 0.6046520017360183,
                        "variance": 0.23904795853264438
                    },
                    "strategy": "one literal-constrained call per label",
                    "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                }
            },
            {
                "source": "B18",
                "target": "B17",
                "relation": "continues",
                "weight": 0.17489802953669778,
                "measure": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Yes, the statement is supported by the state",
                            "value": 1,
                            "text": "A",
                            "tokens": [
                                {
                                    "token": "A",
                                    "logprob": -1.7483801227485696,
                                    "bytes": [
                                        65
                                    ],
                                    "top_logprobs": [
                                        {
                                            "token": "B",
                                            "logprob": -0.19707625922317903,
                                            "bytes": [
                                                66
                                            ]
                                        },
                                        {
                                            "token": "A",
                                            "logprob": -1.7483801227485696,
                                            "bytes": [
                                                65
                                            ]
                                        },
                                        {
                                            "token": " B",
                                            "logprob": -7.305432735053257,
                                            "bytes": [
                                                32,
                                                66
                                            ]
                                        },
                                        {
                                            "token": "First",
                                            "logprob": -7.641808925238804,
                                            "bytes": [
                                                70,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "FIRST",
                                            "logprob": -7.664168773261265,
                                            "bytes": [
                                                70,
                                                73,
                                                82,
                                                83,
                                                84
                                            ]
                                        },
                                        {
                                            "token": " A",
                                            "logprob": -8.24586146887894,
                                            "bytes": [
                                                32,
                                                65
                                            ]
                                        },
                                        {
                                            "token": "Answer",
                                            "logprob": -8.311700282660679,
                                            "bytes": [
                                                65,
                                                110,
                                                115,
                                                119,
                                                101,
                                                114
                                            ]
                                        },
                                        {
                                            "token": "Yes",
                                            "logprob": -8.343012271491245,
                                            "bytes": [
                                                89,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "No",
                                            "logprob": -8.429246364203648,
                                            "bytes": [
                                                78,
                                                111
                                            ]
                                        },
                                        {
                                            "token": "The",
                                            "logprob": -8.507467685309605,
                                            "bytes": [
                                                84,
                                                104,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "NO",
                                            "logprob": -8.576482234564976,
                                            "bytes": [
                                                78,
                                                79
                                            ]
                                        },
                                        {
                                            "token": "YES",
                                            "logprob": -9.073546825019077,
                                            "bytes": [
                                                89,
                                                69,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "b",
                                            "logprob": -9.532520709601597,
                                            "bytes": [
                                                98
                                            ]
                                        },
                                        {
                                            "token": "Question",
                                            "logprob": -9.916147647467808,
                                            "bytes": [
                                                81,
                                                117,
                                                101,
                                                115,
                                                116,
                                                105,
                                                111,
                                                110
                                            ]
                                        },
                                        {
                                            "token": "State",
                                            "logprob": -9.984686313239292,
                                            "bytes": [
                                                83,
                                                116,
                                                97,
                                                116,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "ANS",
                                            "logprob": -10.370468555060581,
                                            "bytes": [
                                                65,
                                                78,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "Let",
                                            "logprob": -10.371466098395542,
                                            "bytes": [
                                                76,
                                                101,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "STATE",
                                            "logprob": -10.411536632147984,
                                            "bytes": [
                                                83,
                                                84,
                                                65,
                                                84,
                                                69
                                            ]
                                        },
                                        {
                                            "token": "first",
                                            "logprob": -10.420393405524448,
                                            "bytes": [
                                                102,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "Y",
                                            "logprob": -10.463148532477573,
                                            "bytes": [
                                                89
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "token_count": 1,
                            "logprob": -1.7483801227485696,
                            "path_probability": 0.17405566402310235,
                            "mean_logprob": -1.7483801227485696,
                            "finish_reason": "stop",
                            "raw_probability": 0.17405566402310235,
                            "weight": 0.17489802953669778
                        },
                        {
                            "label": "B",
                            "description": "No, the statement is false or not established by the state",
                            "value": 0,
                            "text": "B",
                            "tokens": [
                                {
                                    "token": "B",
                                    "logprob": -0.19707625922317903,
                                    "bytes": [
                                        66
                                    ],
                                    "top_logprobs": [
                                        {
                                            "token": "B",
                                            "logprob": -0.19707625922317903,
                                            "bytes": [
                                                66
                                            ]
                                        },
                                        {
                                            "token": "A",
                                            "logprob": -1.7483801227485696,
                                            "bytes": [
                                                65
                                            ]
                                        },
                                        {
                                            "token": " B",
                                            "logprob": -7.305432735053257,
                                            "bytes": [
                                                32,
                                                66
                                            ]
                                        },
                                        {
                                            "token": "First",
                                            "logprob": -7.641808925238804,
                                            "bytes": [
                                                70,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "FIRST",
                                            "logprob": -7.664168773261265,
                                            "bytes": [
                                                70,
                                                73,
                                                82,
                                                83,
                                                84
                                            ]
                                        },
                                        {
                                            "token": " A",
                                            "logprob": -8.24586146887894,
                                            "bytes": [
                                                32,
                                                65
                                            ]
                                        },
                                        {
                                            "token": "Answer",
                                            "logprob": -8.311700282660679,
                                            "bytes": [
                                                65,
                                                110,
                                                115,
                                                119,
                                                101,
                                                114
                                            ]
                                        },
                                        {
                                            "token": "Yes",
                                            "logprob": -8.343012271491245,
                                            "bytes": [
                                                89,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "No",
                                            "logprob": -8.429246364203648,
                                            "bytes": [
                                                78,
                                                111
                                            ]
                                        },
                                        {
                                            "token": "The",
                                            "logprob": -8.507467685309605,
                                            "bytes": [
                                                84,
                                                104,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "NO",
                                            "logprob": -8.576482234564976,
                                            "bytes": [
                                                78,
                                                79
                                            ]
                                        },
                                        {
                                            "token": "YES",
                                            "logprob": -9.073546825019077,
                                            "bytes": [
                                                89,
                                                69,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "b",
                                            "logprob": -9.532520709601597,
                                            "bytes": [
                                                98
                                            ]
                                        },
                                        {
                                            "token": "Question",
                                            "logprob": -9.916147647467808,
                                            "bytes": [
                                                81,
                                                117,
                                                101,
                                                115,
                                                116,
                                                105,
                                                111,
                                                110
                                            ]
                                        },
                                        {
                                            "token": "State",
                                            "logprob": -9.984686313239292,
                                            "bytes": [
                                                83,
                                                116,
                                                97,
                                                116,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "ANS",
                                            "logprob": -10.370468555060581,
                                            "bytes": [
                                                65,
                                                78,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "Let",
                                            "logprob": -10.371466098395542,
                                            "bytes": [
                                                76,
                                                101,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "STATE",
                                            "logprob": -10.411536632147984,
                                            "bytes": [
                                                83,
                                                84,
                                                65,
                                                84,
                                                69
                                            ]
                                        },
                                        {
                                            "token": "first",
                                            "logprob": -10.420393405524448,
                                            "bytes": [
                                                102,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "Y",
                                            "logprob": -10.463148532477573,
                                            "bytes": [
                                                89
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "token_count": 1,
                            "logprob": -0.19707625922317903,
                            "path_probability": 0.8211280123406233,
                            "mean_logprob": -0.19707625922317903,
                            "finish_reason": "stop",
                            "raw_probability": 0.8211280123406233,
                            "weight": 0.8251019704633022
                        }
                    ],
                    "complete": True,
                    "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B18): the client disconnects, then drains pending output.\nSECOND (B17): The engine stops generation when\nQUESTION: Does SECOND continue FIRST in reading order?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                    "winner": "B",
                    "statistics": {
                        "top_weight": 0.8251019704633022,
                        "margin": 0.6502039409266045,
                        "peakedness": 0.6502039409266045,
                        "entropy_bits": 0.6687876711733434,
                        "expected_score": 0.17489802953669778,
                        "variance": 0.14430870880087818
                    },
                    "strategy": "one literal-constrained call per label",
                    "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                }
            },
            {
                "source": "B20",
                "target": "B17",
                "relation": "continues",
                "weight": 0.14561036085602297,
                "measure": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Yes, the statement is supported by the state",
                            "value": 1,
                            "text": "A",
                            "tokens": [
                                {
                                    "token": "A",
                                    "logprob": -1.9289598274142679,
                                    "bytes": [
                                        65
                                    ],
                                    "top_logprobs": [
                                        {
                                            "token": "B",
                                            "logprob": -0.15950677870821311,
                                            "bytes": [
                                                66
                                            ]
                                        },
                                        {
                                            "token": "A",
                                            "logprob": -1.9289598274142679,
                                            "bytes": [
                                                65
                                            ]
                                        },
                                        {
                                            "token": " B",
                                            "logprob": -7.827971439352744,
                                            "bytes": [
                                                32,
                                                66
                                            ]
                                        },
                                        {
                                            "token": "Answer",
                                            "logprob": -8.40346239089083,
                                            "bytes": [
                                                65,
                                                110,
                                                115,
                                                119,
                                                101,
                                                114
                                            ]
                                        },
                                        {
                                            "token": "NO",
                                            "logprob": -8.876252155295127,
                                            "bytes": [
                                                78,
                                                79
                                            ]
                                        },
                                        {
                                            "token": " A",
                                            "logprob": -9.094163875571006,
                                            "bytes": [
                                                32,
                                                65
                                            ]
                                        },
                                        {
                                            "token": "Yes",
                                            "logprob": -9.336996059408897,
                                            "bytes": [
                                                89,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "First",
                                            "logprob": -9.368691425314658,
                                            "bytes": [
                                                70,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "No",
                                            "logprob": -9.474745731344932,
                                            "bytes": [
                                                78,
                                                111
                                            ]
                                        },
                                        {
                                            "token": "YES",
                                            "logprob": -9.577875118246787,
                                            "bytes": [
                                                89,
                                                69,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "The",
                                            "logprob": -9.896506290426963,
                                            "bytes": [
                                                84,
                                                104,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "ANS",
                                            "logprob": -10.11515901564669,
                                            "bytes": [
                                                65,
                                                78,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "FIRST",
                                            "logprob": -10.189204196921104,
                                            "bytes": [
                                                70,
                                                73,
                                                82,
                                                83,
                                                84
                                            ]
                                        },
                                        {
                                            "token": "b",
                                            "logprob": -10.208104114523643,
                                            "bytes": [
                                                98
                                            ]
                                        },
                                        {
                                            "token": "Question",
                                            "logprob": -10.580639820090049,
                                            "bytes": [
                                                81,
                                                117,
                                                101,
                                                115,
                                                116,
                                                105,
                                                111,
                                                110
                                            ]
                                        },
                                        {
                                            "token": "\"B",
                                            "logprob": -10.786612491598838,
                                            "bytes": [
                                                34,
                                                66
                                            ]
                                        },
                                        {
                                            "token": "E",
                                            "logprob": -10.89174364089083,
                                            "bytes": [
                                                69
                                            ]
                                        },
                                        {
                                            "token": "Let",
                                            "logprob": -10.968250255575889,
                                            "bytes": [
                                                76,
                                                101,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "N",
                                            "logprob": -11.044428806296104,
                                            "bytes": [
                                                78
                                            ]
                                        },
                                        {
                                            "token": "Y",
                                            "logprob": -11.05174348830294,
                                            "bytes": [
                                                89
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "token_count": 1,
                            "logprob": -1.9289598274142679,
                            "path_probability": 0.14529925620998785,
                            "mean_logprob": -1.9289598274142679,
                            "finish_reason": "stop",
                            "raw_probability": 0.14529925620998785,
                            "weight": 0.14561036085602297
                        },
                        {
                            "label": "B",
                            "description": "No, the statement is false or not established by the state",
                            "value": 0,
                            "text": "B",
                            "tokens": [
                                {
                                    "token": "B",
                                    "logprob": -0.15950677870821311,
                                    "bytes": [
                                        66
                                    ],
                                    "top_logprobs": [
                                        {
                                            "token": "B",
                                            "logprob": -0.15950677870821311,
                                            "bytes": [
                                                66
                                            ]
                                        },
                                        {
                                            "token": "A",
                                            "logprob": -1.9289598274142679,
                                            "bytes": [
                                                65
                                            ]
                                        },
                                        {
                                            "token": " B",
                                            "logprob": -7.827971439352744,
                                            "bytes": [
                                                32,
                                                66
                                            ]
                                        },
                                        {
                                            "token": "Answer",
                                            "logprob": -8.40346239089083,
                                            "bytes": [
                                                65,
                                                110,
                                                115,
                                                119,
                                                101,
                                                114
                                            ]
                                        },
                                        {
                                            "token": "NO",
                                            "logprob": -8.876252155295127,
                                            "bytes": [
                                                78,
                                                79
                                            ]
                                        },
                                        {
                                            "token": " A",
                                            "logprob": -9.094163875571006,
                                            "bytes": [
                                                32,
                                                65
                                            ]
                                        },
                                        {
                                            "token": "Yes",
                                            "logprob": -9.336996059408897,
                                            "bytes": [
                                                89,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "First",
                                            "logprob": -9.368691425314658,
                                            "bytes": [
                                                70,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "No",
                                            "logprob": -9.474745731344932,
                                            "bytes": [
                                                78,
                                                111
                                            ]
                                        },
                                        {
                                            "token": "YES",
                                            "logprob": -9.577875118246787,
                                            "bytes": [
                                                89,
                                                69,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "The",
                                            "logprob": -9.896506290426963,
                                            "bytes": [
                                                84,
                                                104,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "ANS",
                                            "logprob": -10.11515901564669,
                                            "bytes": [
                                                65,
                                                78,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "FIRST",
                                            "logprob": -10.189204196921104,
                                            "bytes": [
                                                70,
                                                73,
                                                82,
                                                83,
                                                84
                                            ]
                                        },
                                        {
                                            "token": "b",
                                            "logprob": -10.208104114523643,
                                            "bytes": [
                                                98
                                            ]
                                        },
                                        {
                                            "token": "Question",
                                            "logprob": -10.580639820090049,
                                            "bytes": [
                                                81,
                                                117,
                                                101,
                                                115,
                                                116,
                                                105,
                                                111,
                                                110
                                            ]
                                        },
                                        {
                                            "token": "\"B",
                                            "logprob": -10.786612491598838,
                                            "bytes": [
                                                34,
                                                66
                                            ]
                                        },
                                        {
                                            "token": "E",
                                            "logprob": -10.89174364089083,
                                            "bytes": [
                                                69
                                            ]
                                        },
                                        {
                                            "token": "Let",
                                            "logprob": -10.968250255575889,
                                            "bytes": [
                                                76,
                                                101,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "N",
                                            "logprob": -11.044428806296104,
                                            "bytes": [
                                                78
                                            ]
                                        },
                                        {
                                            "token": "Y",
                                            "logprob": -11.05174348830294,
                                            "bytes": [
                                                89
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "token_count": 1,
                            "logprob": -0.15950677870821311,
                            "path_probability": 0.8525641880929712,
                            "mean_logprob": -0.15950677870821311,
                            "finish_reason": "stop",
                            "raw_probability": 0.8525641880929712,
                            "weight": 0.8543896391439769
                        }
                    ],
                    "complete": True,
                    "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B20): The diagram below shows the request queue and cancellation path.\nSECOND (B17): The engine stops generation when\nQUESTION: Does SECOND continue FIRST in reading order?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                    "winner": "B",
                    "statistics": {
                        "top_weight": 0.8543896391439769,
                        "margin": 0.708779278287954,
                        "peakedness": 0.7087792782879538,
                        "entropy_bits": 0.5987453255229449,
                        "expected_score": 0.14561036085602297,
                        "variance": 0.12440798366740176
                    },
                    "strategy": "one literal-constrained call per label",
                    "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                }
            },
            {
                "source": "B19",
                "target": "B20",
                "relation": "caption",
                "weight": 0.648502440160998,
                "measure": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Yes, the statement is supported by the state",
                            "value": 1,
                            "text": "A",
                            "tokens": [
                                {
                                    "token": "A",
                                    "logprob": -0.4355364382293628,
                                    "bytes": [
                                        65
                                    ],
                                    "top_logprobs": [
                                        {
                                            "token": "A",
                                            "logprob": -0.4355364382293628,
                                            "bytes": [
                                                65
                                            ]
                                        },
                                        {
                                            "token": "B",
                                            "logprob": -1.0479994356658862,
                                            "bytes": [
                                                66
                                            ]
                                        },
                                        {
                                            "token": "Yes",
                                            "logprob": -7.666647011044304,
                                            "bytes": [
                                                89,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "YES",
                                            "logprob": -8.123480850460808,
                                            "bytes": [
                                                89,
                                                69,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "NO",
                                            "logprob": -8.931222015621941,
                                            "bytes": [
                                                78,
                                                79
                                            ]
                                        },
                                        {
                                            "token": "FIRST",
                                            "logprob": -9.071210914852898,
                                            "bytes": [
                                                70,
                                                73,
                                                82,
                                                83,
                                                84
                                            ]
                                        },
                                        {
                                            "token": "No",
                                            "logprob": -9.0733385622528,
                                            "bytes": [
                                                78,
                                                111
                                            ]
                                        },
                                        {
                                            "token": "Answer",
                                            "logprob": -9.123073631527703,
                                            "bytes": [
                                                65,
                                                110,
                                                115,
                                                119,
                                                101,
                                                114
                                            ]
                                        },
                                        {
                                            "token": "b",
                                            "logprob": -9.541791015866082,
                                            "bytes": [
                                                98
                                            ]
                                        },
                                        {
                                            "token": "ANS",
                                            "logprob": -9.806229645016472,
                                            "bytes": [
                                                65,
                                                78,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "First",
                                            "logprob": -9.819115692379754,
                                            "bytes": [
                                                70,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "yes",
                                            "logprob": -10.183052116635125,
                                            "bytes": [
                                                121,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "Y",
                                            "logprob": -10.22347169518737,
                                            "bytes": [
                                                89
                                            ]
                                        },
                                        {
                                            "token": "The",
                                            "logprob": -10.239841514828484,
                                            "bytes": [
                                                84,
                                                104,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "E",
                                            "logprob": -10.503139549496453,
                                            "bytes": [
                                                69
                                            ]
                                        },
                                        {
                                            "token": "```",
                                            "logprob": -10.583661133053582,
                                            "bytes": [
                                                96,
                                                96,
                                                96
                                            ]
                                        },
                                        {
                                            "token": "I",
                                            "logprob": -10.705093437435906,
                                            "bytes": [
                                                73
                                            ]
                                        },
                                        {
                                            "token": "Question",
                                            "logprob": -10.741202408077996,
                                            "bytes": [
                                                81,
                                                117,
                                                101,
                                                115,
                                                116,
                                                105,
                                                111,
                                                110
                                            ]
                                        },
                                        {
                                            "token": "a",
                                            "logprob": -10.826670700314324,
                                            "bytes": [
                                                97
                                            ]
                                        },
                                        {
                                            "token": " A",
                                            "logprob": -10.834187561276238,
                                            "bytes": [
                                                32,
                                                65
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "token_count": 1,
                            "logprob": -0.4355364382293628,
                            "path_probability": 0.6469175426798212,
                            "mean_logprob": -0.4355364382293628,
                            "finish_reason": "stop",
                            "raw_probability": 0.6469175426798212,
                            "weight": 0.648502440160998
                        },
                        {
                            "label": "B",
                            "description": "No, the statement is false or not established by the state",
                            "value": 0,
                            "text": "B",
                            "tokens": [
                                {
                                    "token": "B",
                                    "logprob": -1.0479994356658862,
                                    "bytes": [
                                        66
                                    ],
                                    "top_logprobs": [
                                        {
                                            "token": "A",
                                            "logprob": -0.4355364382293628,
                                            "bytes": [
                                                65
                                            ]
                                        },
                                        {
                                            "token": "B",
                                            "logprob": -1.0479994356658862,
                                            "bytes": [
                                                66
                                            ]
                                        },
                                        {
                                            "token": "Yes",
                                            "logprob": -7.666647011044304,
                                            "bytes": [
                                                89,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "YES",
                                            "logprob": -8.123480850460808,
                                            "bytes": [
                                                89,
                                                69,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "NO",
                                            "logprob": -8.931222015621941,
                                            "bytes": [
                                                78,
                                                79
                                            ]
                                        },
                                        {
                                            "token": "FIRST",
                                            "logprob": -9.071210914852898,
                                            "bytes": [
                                                70,
                                                73,
                                                82,
                                                83,
                                                84
                                            ]
                                        },
                                        {
                                            "token": "No",
                                            "logprob": -9.0733385622528,
                                            "bytes": [
                                                78,
                                                111
                                            ]
                                        },
                                        {
                                            "token": "Answer",
                                            "logprob": -9.123073631527703,
                                            "bytes": [
                                                65,
                                                110,
                                                115,
                                                119,
                                                101,
                                                114
                                            ]
                                        },
                                        {
                                            "token": "b",
                                            "logprob": -9.541791015866082,
                                            "bytes": [
                                                98
                                            ]
                                        },
                                        {
                                            "token": "ANS",
                                            "logprob": -9.806229645016472,
                                            "bytes": [
                                                65,
                                                78,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "First",
                                            "logprob": -9.819115692379754,
                                            "bytes": [
                                                70,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "yes",
                                            "logprob": -10.183052116635125,
                                            "bytes": [
                                                121,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "Y",
                                            "logprob": -10.22347169518737,
                                            "bytes": [
                                                89
                                            ]
                                        },
                                        {
                                            "token": "The",
                                            "logprob": -10.239841514828484,
                                            "bytes": [
                                                84,
                                                104,
                                                101
                                            ]
                                        },
                                        {
                                            "token": "E",
                                            "logprob": -10.503139549496453,
                                            "bytes": [
                                                69
                                            ]
                                        },
                                        {
                                            "token": "```",
                                            "logprob": -10.583661133053582,
                                            "bytes": [
                                                96,
                                                96,
                                                96
                                            ]
                                        },
                                        {
                                            "token": "I",
                                            "logprob": -10.705093437435906,
                                            "bytes": [
                                                73
                                            ]
                                        },
                                        {
                                            "token": "Question",
                                            "logprob": -10.741202408077996,
                                            "bytes": [
                                                81,
                                                117,
                                                101,
                                                115,
                                                116,
                                                105,
                                                111,
                                                110
                                            ]
                                        },
                                        {
                                            "token": "a",
                                            "logprob": -10.826670700314324,
                                            "bytes": [
                                                97
                                            ]
                                        },
                                        {
                                            "token": " A",
                                            "logprob": -10.834187561276238,
                                            "bytes": [
                                                32,
                                                65
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "token_count": 1,
                            "logprob": -1.0479994356658862,
                            "path_probability": 0.35063852282891717,
                            "mean_logprob": -1.0479994356658862,
                            "finish_reason": "stop",
                            "raw_probability": 0.35063852282891717,
                            "weight": 0.351497559839002
                        }
                    ],
                    "complete": True,
                    "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B19): Figure 1. A request moves through the engine queue.\nSECOND (B20): The diagram below shows the request queue and cancellation path.\nQUESTION: Does the caption FIRST describe the subject discussed in SECOND?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                    "winner": "A",
                    "statistics": {
                        "top_weight": 0.648502440160998,
                        "margin": 0.297004880321996,
                        "peakedness": 0.297004880321996,
                        "entropy_bits": 0.9353983969499662,
                        "expected_score": 0.648502440160998,
                        "variance": 0.22794702526622918
                    },
                    "strategy": "one literal-constrained call per label",
                    "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                }
            },
            {
                "source": "B19",
                "target": "B17",
                "relation": "caption",
                "weight": 0.18469224963792638,
                "measure": {
                    "rows": [
                        {
                            "label": "A",
                            "description": "Yes, the statement is supported by the state",
                            "value": 1,
                            "text": "A",
                            "tokens": [
                                {
                                    "token": "A",
                                    "logprob": -1.6908572478676906,
                                    "bytes": [
                                        65
                                    ],
                                    "top_logprobs": [
                                        {
                                            "token": "B",
                                            "logprob": -0.20598252252589389,
                                            "bytes": [
                                                66
                                            ]
                                        },
                                        {
                                            "token": "A",
                                            "logprob": -1.6908572478676906,
                                            "bytes": [
                                                65
                                            ]
                                        },
                                        {
                                            "token": "FIRST",
                                            "logprob": -8.483524636783706,
                                            "bytes": [
                                                70,
                                                73,
                                                82,
                                                83,
                                                84
                                            ]
                                        },
                                        {
                                            "token": "No",
                                            "logprob": -8.59033520654689,
                                            "bytes": [
                                                78,
                                                111
                                            ]
                                        },
                                        {
                                            "token": "First",
                                            "logprob": -8.694683389225112,
                                            "bytes": [
                                                70,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "Answer",
                                            "logprob": -8.80643685297023,
                                            "bytes": [
                                                65,
                                                110,
                                                115,
                                                119,
                                                101,
                                                114
                                            ]
                                        },
                                        {
                                            "token": "NO",
                                            "logprob": -9.037979440250503,
                                            "bytes": [
                                                78,
                                                79
                                            ]
                                        },
                                        {
                                            "token": "Does",
                                            "logprob": -9.786819772281753,
                                            "bytes": [
                                                68,
                                                111,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "Yes",
                                            "logprob": -9.877271012821303,
                                            "bytes": [
                                                89,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "Question",
                                            "logprob": -9.932038621463882,
                                            "bytes": [
                                                81,
                                                117,
                                                101,
                                                115,
                                                116,
                                                105,
                                                111,
                                                110
                                            ]
                                        },
                                        {
                                            "token": "The",
                                            "logprob": -10.026750878849136,
                                            "bytes": [
                                                84,
                                                104,
                                                101
                                            ]
                                        },
                                        {
                                            "token": " B",
                                            "logprob": -10.041295365848647,
                                            "bytes": [
                                                32,
                                                66
                                            ]
                                        },
                                        {
                                            "token": "b",
                                            "logprob": -10.30417855218898,
                                            "bytes": [
                                                98
                                            ]
                                        },
                                        {
                                            "token": "ANS",
                                            "logprob": -10.35593064264308,
                                            "bytes": [
                                                65,
                                                78,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "YES",
                                            "logprob": -10.37854035333644,
                                            "bytes": [
                                                89,
                                                69,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "N",
                                            "logprob": -11.074592904605971,
                                            "bytes": [
                                                78
                                            ]
                                        },
                                        {
                                            "token": "Let",
                                            "logprob": -11.115448312320815,
                                            "bytes": [
                                                76,
                                                101,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "a",
                                            "logprob": -11.328472451725112,
                                            "bytes": [
                                                97
                                            ]
                                        },
                                        {
                                            "token": "Y",
                                            "logprob": -11.378302888431655,
                                            "bytes": [
                                                89
                                            ]
                                        },
                                        {
                                            "token": " A",
                                            "logprob": -11.393245057621108,
                                            "bytes": [
                                                32,
                                                65
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "token_count": 1,
                            "logprob": -1.6908572478676906,
                            "path_probability": 0.18436141280442125,
                            "mean_logprob": -1.6908572478676906,
                            "finish_reason": "stop",
                            "raw_probability": 0.18436141280442125,
                            "weight": 0.18469224963792638
                        },
                        {
                            "label": "B",
                            "description": "No, the statement is false or not established by the state",
                            "value": 0,
                            "text": "B",
                            "tokens": [
                                {
                                    "token": "B",
                                    "logprob": -0.20598252252589389,
                                    "bytes": [
                                        66
                                    ],
                                    "top_logprobs": [
                                        {
                                            "token": "B",
                                            "logprob": -0.20598252252589389,
                                            "bytes": [
                                                66
                                            ]
                                        },
                                        {
                                            "token": "A",
                                            "logprob": -1.6908572478676906,
                                            "bytes": [
                                                65
                                            ]
                                        },
                                        {
                                            "token": "FIRST",
                                            "logprob": -8.483524636783706,
                                            "bytes": [
                                                70,
                                                73,
                                                82,
                                                83,
                                                84
                                            ]
                                        },
                                        {
                                            "token": "No",
                                            "logprob": -8.59033520654689,
                                            "bytes": [
                                                78,
                                                111
                                            ]
                                        },
                                        {
                                            "token": "First",
                                            "logprob": -8.694683389225112,
                                            "bytes": [
                                                70,
                                                105,
                                                114,
                                                115,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "Answer",
                                            "logprob": -8.80643685297023,
                                            "bytes": [
                                                65,
                                                110,
                                                115,
                                                119,
                                                101,
                                                114
                                            ]
                                        },
                                        {
                                            "token": "NO",
                                            "logprob": -9.037979440250503,
                                            "bytes": [
                                                78,
                                                79
                                            ]
                                        },
                                        {
                                            "token": "Does",
                                            "logprob": -9.786819772281753,
                                            "bytes": [
                                                68,
                                                111,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "Yes",
                                            "logprob": -9.877271012821303,
                                            "bytes": [
                                                89,
                                                101,
                                                115
                                            ]
                                        },
                                        {
                                            "token": "Question",
                                            "logprob": -9.932038621463882,
                                            "bytes": [
                                                81,
                                                117,
                                                101,
                                                115,
                                                116,
                                                105,
                                                111,
                                                110
                                            ]
                                        },
                                        {
                                            "token": "The",
                                            "logprob": -10.026750878849136,
                                            "bytes": [
                                                84,
                                                104,
                                                101
                                            ]
                                        },
                                        {
                                            "token": " B",
                                            "logprob": -10.041295365848647,
                                            "bytes": [
                                                32,
                                                66
                                            ]
                                        },
                                        {
                                            "token": "b",
                                            "logprob": -10.30417855218898,
                                            "bytes": [
                                                98
                                            ]
                                        },
                                        {
                                            "token": "ANS",
                                            "logprob": -10.35593064264308,
                                            "bytes": [
                                                65,
                                                78,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "YES",
                                            "logprob": -10.37854035333644,
                                            "bytes": [
                                                89,
                                                69,
                                                83
                                            ]
                                        },
                                        {
                                            "token": "N",
                                            "logprob": -11.074592904605971,
                                            "bytes": [
                                                78
                                            ]
                                        },
                                        {
                                            "token": "Let",
                                            "logprob": -11.115448312320815,
                                            "bytes": [
                                                76,
                                                101,
                                                116
                                            ]
                                        },
                                        {
                                            "token": "a",
                                            "logprob": -11.328472451725112,
                                            "bytes": [
                                                97
                                            ]
                                        },
                                        {
                                            "token": "Y",
                                            "logprob": -11.378302888431655,
                                            "bytes": [
                                                89
                                            ]
                                        },
                                        {
                                            "token": " A",
                                            "logprob": -11.393245057621108,
                                            "bytes": [
                                                32,
                                                65
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "token_count": 1,
                            "logprob": -0.20598252252589389,
                            "path_probability": 0.8138473001537364,
                            "mean_logprob": -0.20598252252589389,
                            "finish_reason": "stop",
                            "raw_probability": 0.8138473001537364,
                            "weight": 0.8153077503620737
                        }
                    ],
                    "complete": True,
                    "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B19): Figure 1. A request moves through the engine queue.\nSECOND (B17): The engine stops generation when\nQUESTION: Does the caption FIRST describe the subject discussed in SECOND?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                    "winner": "B",
                    "statistics": {
                        "top_weight": 0.8153077503620737,
                        "margin": 0.6306155007241473,
                        "peakedness": 0.6306155007241474,
                        "entropy_bits": 0.6902350555307964,
                        "expected_score": 0.18469224963792638,
                        "variance": 0.15058102256160824
                    },
                    "strategy": "one literal-constrained call per label",
                    "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                }
            }
        ],
        "solver": {
            "selected": [
                {
                    "source": "B17",
                    "target": "B18",
                    "relation": "continues",
                    "weight": 0.6046520017360183,
                    "measure": {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes, the statement is supported by the state",
                                "value": 1,
                                "text": "A",
                                "tokens": [
                                    {
                                        "token": "A",
                                        "logprob": -0.5088750178078288,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.5088750178078288,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -0.9337617212990398,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -6.28617871348654,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -7.082244043991911,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.521751528427946,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.911688929245817,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.45261109416281,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -8.9743157679299,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -9.129299288437712,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -9.129624491379607,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -9.30538094584738,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.345752840683806,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.38680470530783,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.741802340195525,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.765051966355193,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.461070185349334,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.718962793991912,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -10.750735407517302,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.776361590073455,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -10.822066431687224,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -0.5088750178078288,
                                "path_probability": 0.6011715057765193,
                                "mean_logprob": -0.5088750178078288,
                                "finish_reason": "stop",
                                "raw_probability": 0.6011715057765193,
                                "weight": 0.6046520017360183
                            },
                            {
                                "label": "B",
                                "description": "No, the statement is false or not established by the state",
                                "value": 0,
                                "text": "B",
                                "tokens": [
                                    {
                                        "token": "B",
                                        "logprob": -0.9337617212990398,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.5088750178078288,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -0.9337617212990398,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -6.28617871348654,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -7.082244043991911,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.521751528427946,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.911688929245817,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.45261109416281,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -8.9743157679299,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -9.129299288437712,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -9.129624491379607,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -9.30538094584738,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.345752840683806,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.38680470530783,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.741802340195525,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.765051966355193,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.461070185349334,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.718962793991912,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -10.750735407517302,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.776361590073455,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -10.822066431687224,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -0.9337617212990398,
                                "path_probability": 0.39307229735403154,
                                "mean_logprob": -0.9337617212990398,
                                "finish_reason": "stop",
                                "raw_probability": 0.39307229735403154,
                                "weight": 0.3953479982639816
                            }
                        ],
                        "complete": True,
                        "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B17): The engine stops generation when\nSECOND (B18): the client disconnects, then drains pending output.\nQUESTION: Does SECOND continue FIRST in reading order?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                        "winner": "A",
                        "statistics": {
                            "top_weight": 0.6046520017360183,
                            "margin": 0.2093040034720367,
                            "peakedness": 0.2093040034720366,
                            "entropy_bits": 0.9681642178197483,
                            "expected_score": 0.6046520017360183,
                            "variance": 0.23904795853264438
                        },
                        "strategy": "one literal-constrained call per label",
                        "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                    }
                },
                {
                    "source": "B19",
                    "target": "B20",
                    "relation": "caption",
                    "weight": 0.648502440160998,
                    "measure": {
                        "rows": [
                            {
                                "label": "A",
                                "description": "Yes, the statement is supported by the state",
                                "value": 1,
                                "text": "A",
                                "tokens": [
                                    {
                                        "token": "A",
                                        "logprob": -0.4355364382293628,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.4355364382293628,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0479994356658862,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -7.666647011044304,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -8.123480850460808,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -8.931222015621941,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -9.071210914852898,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.0733385622528,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.123073631527703,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.541791015866082,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.806229645016472,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -9.819115692379754,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.183052116635125,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.22347169518737,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.239841514828484,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.503139549496453,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -10.583661133053582,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -10.705093437435906,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.741202408077996,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.826670700314324,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.834187561276238,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -0.4355364382293628,
                                "path_probability": 0.6469175426798212,
                                "mean_logprob": -0.4355364382293628,
                                "finish_reason": "stop",
                                "raw_probability": 0.6469175426798212,
                                "weight": 0.648502440160998
                            },
                            {
                                "label": "B",
                                "description": "No, the statement is false or not established by the state",
                                "value": 0,
                                "text": "B",
                                "tokens": [
                                    {
                                        "token": "B",
                                        "logprob": -1.0479994356658862,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.4355364382293628,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0479994356658862,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -7.666647011044304,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -8.123480850460808,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -8.931222015621941,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -9.071210914852898,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.0733385622528,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.123073631527703,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.541791015866082,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.806229645016472,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -9.819115692379754,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.183052116635125,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.22347169518737,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.239841514828484,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.503139549496453,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -10.583661133053582,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -10.705093437435906,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.741202408077996,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.826670700314324,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.834187561276238,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "token_count": 1,
                                "logprob": -1.0479994356658862,
                                "path_probability": 0.35063852282891717,
                                "mean_logprob": -1.0479994356658862,
                                "finish_reason": "stop",
                                "raw_probability": 0.35063852282891717,
                                "weight": 0.351497559839002
                            }
                        ],
                        "complete": True,
                        "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B19): Figure 1. A request moves through the engine queue.\nSECOND (B20): The diagram below shows the request queue and cancellation path.\nQUESTION: Does the caption FIRST describe the subject discussed in SECOND?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                        "winner": "A",
                        "statistics": {
                            "top_weight": 0.648502440160998,
                            "margin": 0.297004880321996,
                            "peakedness": 0.297004880321996,
                            "entropy_bits": 0.9353983969499662,
                            "expected_score": 0.648502440160998,
                            "variance": 0.22794702526622918
                        },
                        "strategy": "one literal-constrained call per label",
                        "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                    }
                }
            ],
            "utility": 0.2531544418970163,
            "feasible_subsets": 15,
            "evaluated_subsets": 32,
            "threshold": 0.5,
            "objective": "sum(edge weight - threshold), not a calibrated joint probability"
        },
        "preserved_text": "B17 [page 2, line 4]: The engine stops generation when\nB18 [page 2, line 5]: the client disconnects, then drains pending output.\nB19 [page 2, figure 1 caption]: Figure 1. A request moves through the engine queue.\nB20 [page 2, paragraph 3]: The diagram below shows the request queue and cancellation path."
    },
    "lesson": {
        "question": "Which text links can coexist?",
        "rule": "Search every small edge subset. Reject cycles and competing attachments, then maximize useful edge weight.",
        "knob": "Edge cost / threshold",
        "default": 0.5,
        "compare": 0.9,
        "low": 0.01,
        "high": 0.99,
        "integer": False,
        "states": [
            {
                "value": 0.5,
                "summary": "2 compatible links, total utility 0.2532.",
                "rows": [
                    {
                        "label": "B17 → B18",
                        "value": 0.1046520017360183
                    },
                    {
                        "label": "B19 → B20",
                        "value": 0.148502440160998
                    }
                ],
                "unit": "utility",
                "metrics": {
                    "selected": [
                        [
                            "B17",
                            "B18",
                            "continues"
                        ],
                        [
                            "B19",
                            "B20",
                            "caption"
                        ]
                    ],
                    "utility": 0.2531544418970163
                },
                "note": "Global code constraints select links; utility is not the probability that the document graph is correct."
            },
            {
                "value": 0.9,
                "summary": "0 compatible links, total utility 0.0000.",
                "rows": [],
                "unit": "utility",
                "metrics": {
                    "selected": [],
                    "utility": 0
                },
                "note": "Global code constraints select links; utility is not the probability that the document graph is correct."
            }
        ],
        "input_excerpt": "",
        "scope": "This panel and its Python calculation reproduce saved measurements. Other page controls are independent views."
    },
    "receipt": {
        "mode": "recorded",
        "requests": 10,
        "summed_request_ms": 7005.8359999384265,
        "prompt_tokens": 1174,
        "completion_tokens": 20,
        "calls": [
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B17): The engine stops generation when\nSECOND (B18): the client disconnects, then drains pending output.\nQUESTION: Does SECOND continue FIRST in reading order?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-0efa3a4a218e4c7fab5ecae6",
                    "object": "chat.completion",
                    "created": 1791077972,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.5088750178078288,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.5088750178078288,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -0.9337617212990398,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -6.28617871348654,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -7.082244043991911,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.521751528427946,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.911688929245817,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.45261109416281,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -8.9743157679299,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -9.129299288437712,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -9.129624491379607,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -9.30538094584738,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.345752840683806,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.38680470530783,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.741802340195525,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.765051966355193,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.461070185349334,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.718962793991912,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -10.750735407517302,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.776361590073455,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -10.822066431687224,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 114,
                        "completion_tokens": 2,
                        "total_tokens": 116,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 114,
                        "prompt_ms": 1218,
                        "prompt_per_token_ms": 10.684,
                        "prompt_per_second": 93.6,
                        "predicted_n": 2,
                        "predicted_ms": 65,
                        "predicted_per_token_ms": 32.5,
                        "predicted_per_second": 30.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1323.2641999784391,
                "captured_at": "2026-10-04T01:39:34Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B17): The engine stops generation when\nSECOND (B18): the client disconnects, then drains pending output.\nQUESTION: Does SECOND continue FIRST in reading order?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-b33e2f5315424b0bbb83bacc",
                    "object": "chat.completion",
                    "created": 1791077973,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.9337617212990398,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.5088750178078288,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -0.9337617212990398,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -6.28617871348654,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -7.082244043991911,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.521751528427946,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.911688929245817,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.45261109416281,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -8.9743157679299,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -9.129299288437712,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -9.129624491379607,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -9.30538094584738,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.345752840683806,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.38680470530783,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.741802340195525,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.765051966355193,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.461070185349334,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.718962793991912,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "[",
                                                "logprob": -10.750735407517302,
                                                "bytes": [
                                                    91
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.776361590073455,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -10.822066431687224,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 114,
                        "completion_tokens": 2,
                        "total_tokens": 116,
                        "prompt_tokens_details": {
                            "cached_tokens": 107
                        }
                    },
                    "timings": {
                        "cache_n": 107,
                        "prompt_n": 7,
                        "prompt_ms": 199.2,
                        "prompt_per_token_ms": 28.457,
                        "prompt_per_second": 35.1,
                        "predicted_n": 2,
                        "predicted_ms": 57,
                        "predicted_per_token_ms": 28.5,
                        "predicted_per_second": 35.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 388.60579999163747,
                "captured_at": "2026-10-04T01:39:34Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B18): the client disconnects, then drains pending output.\nSECOND (B17): The engine stops generation when\nQUESTION: Does SECOND continue FIRST in reading order?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-7ad3514764f24deea109cd5e",
                    "object": "chat.completion",
                    "created": 1791077974,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -1.7483801227485696,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.19707625922317903,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.7483801227485696,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.305432735053257,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -7.641808925238804,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -7.664168773261265,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -8.24586146887894,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.311700282660679,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.343012271491245,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -8.429246364203648,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.507467685309605,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -8.576482234564976,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.073546825019077,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.532520709601597,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -9.916147647467808,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -9.984686313239292,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.370468555060581,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.371466098395542,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "STATE",
                                                "logprob": -10.411536632147984,
                                                "bytes": [
                                                    83,
                                                    84,
                                                    65,
                                                    84,
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "first",
                                                "logprob": -10.420393405524448,
                                                "bytes": [
                                                    102,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.463148532477573,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 114,
                        "completion_tokens": 2,
                        "total_tokens": 116,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 114,
                        "prompt_ms": 841.9,
                        "prompt_per_token_ms": 7.385,
                        "prompt_per_second": 135.4,
                        "predicted_n": 2,
                        "predicted_ms": 60.6,
                        "predicted_per_token_ms": 30.3,
                        "predicted_per_second": 33,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 928.3288000151515,
                "captured_at": "2026-10-04T01:39:35Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B18): the client disconnects, then drains pending output.\nSECOND (B17): The engine stops generation when\nQUESTION: Does SECOND continue FIRST in reading order?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-ed7103df2d534e2ea53e0c75",
                    "object": "chat.completion",
                    "created": 1791077975,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.19707625922317903,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.19707625922317903,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.7483801227485696,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.305432735053257,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -7.641808925238804,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -7.664168773261265,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -8.24586146887894,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.311700282660679,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.343012271491245,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -8.429246364203648,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.507467685309605,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -8.576482234564976,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.073546825019077,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.532520709601597,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -9.916147647467808,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -9.984686313239292,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.370468555060581,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.371466098395542,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "STATE",
                                                "logprob": -10.411536632147984,
                                                "bytes": [
                                                    83,
                                                    84,
                                                    65,
                                                    84,
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "first",
                                                "logprob": -10.420393405524448,
                                                "bytes": [
                                                    102,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.463148532477573,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 114,
                        "completion_tokens": 2,
                        "total_tokens": 116,
                        "prompt_tokens_details": {
                            "cached_tokens": 107
                        }
                    },
                    "timings": {
                        "cache_n": 107,
                        "prompt_n": 7,
                        "prompt_ms": 200.4,
                        "prompt_per_token_ms": 28.629,
                        "prompt_per_second": 34.9,
                        "predicted_n": 2,
                        "predicted_ms": 63.9,
                        "predicted_per_token_ms": 31.95,
                        "predicted_per_second": 31.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 292.8725999954622,
                "captured_at": "2026-10-04T01:39:36Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B20): The diagram below shows the request queue and cancellation path.\nSECOND (B17): The engine stops generation when\nQUESTION: Does SECOND continue FIRST in reading order?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-f0e71de084d84f28b17bfe8d",
                    "object": "chat.completion",
                    "created": 1791077975,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -1.9289598274142679,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.15950677870821311,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.9289598274142679,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.827971439352744,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.40346239089083,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -8.876252155295127,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.094163875571006,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -9.336996059408897,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -9.368691425314658,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.474745731344932,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.577875118246787,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.896506290426963,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.11515901564669,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -10.189204196921104,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.208104114523643,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.580639820090049,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.786612491598838,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.89174364089083,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.968250255575889,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.044428806296104,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.05174348830294,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 115,
                        "completion_tokens": 2,
                        "total_tokens": 117,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 115,
                        "prompt_ms": 992.4,
                        "prompt_per_token_ms": 8.63,
                        "prompt_per_second": 115.9,
                        "predicted_n": 2,
                        "predicted_ms": 59.8,
                        "predicted_per_token_ms": 29.9,
                        "predicted_per_second": 33.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1081.9763999897987,
                "captured_at": "2026-10-04T01:39:37Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B20): The diagram below shows the request queue and cancellation path.\nSECOND (B17): The engine stops generation when\nQUESTION: Does SECOND continue FIRST in reading order?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-9c252d21d7de46ac9b5df4c6",
                    "object": "chat.completion",
                    "created": 1791077976,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.15950677870821311,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.15950677870821311,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.9289598274142679,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.827971439352744,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.40346239089083,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -8.876252155295127,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.094163875571006,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -9.336996059408897,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -9.368691425314658,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.474745731344932,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.577875118246787,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.896506290426963,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.11515901564669,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -10.189204196921104,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.208104114523643,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.580639820090049,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.786612491598838,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.89174364089083,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.968250255575889,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.044428806296104,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.05174348830294,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 115,
                        "completion_tokens": 2,
                        "total_tokens": 117,
                        "prompt_tokens_details": {
                            "cached_tokens": 108
                        }
                    },
                    "timings": {
                        "cache_n": 108,
                        "prompt_n": 7,
                        "prompt_ms": 200.4,
                        "prompt_per_token_ms": 28.629,
                        "prompt_per_second": 34.9,
                        "predicted_n": 2,
                        "predicted_ms": 57.5,
                        "predicted_per_token_ms": 28.75,
                        "predicted_per_second": 34.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 286.21300001395866,
                "captured_at": "2026-10-04T01:39:37Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B19): Figure 1. A request moves through the engine queue.\nSECOND (B20): The diagram below shows the request queue and cancellation path.\nQUESTION: Does the caption FIRST describe the subject discussed in SECOND?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-7b204a3776e943d0ae2e99c0",
                    "object": "chat.completion",
                    "created": 1791077976,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.4355364382293628,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.4355364382293628,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0479994356658862,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -7.666647011044304,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -8.123480850460808,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -8.931222015621941,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -9.071210914852898,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.0733385622528,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.123073631527703,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.541791015866082,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.806229645016472,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -9.819115692379754,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.183052116635125,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.22347169518737,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.239841514828484,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.503139549496453,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -10.583661133053582,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -10.705093437435906,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.741202408077996,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.826670700314324,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.834187561276238,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 125,
                        "completion_tokens": 2,
                        "total_tokens": 127,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 125,
                        "prompt_ms": 991.9,
                        "prompt_per_token_ms": 7.935,
                        "prompt_per_second": 126,
                        "predicted_n": 2,
                        "predicted_ms": 63.5,
                        "predicted_per_token_ms": 31.75,
                        "predicted_per_second": 31.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 1088.0784999753814,
                "captured_at": "2026-10-04T01:39:38Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B19): Figure 1. A request moves through the engine queue.\nSECOND (B20): The diagram below shows the request queue and cancellation path.\nQUESTION: Does the caption FIRST describe the subject discussed in SECOND?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-02fa219aa848445d89bb9ad4",
                    "object": "chat.completion",
                    "created": 1791077978,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -1.0479994356658862,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.4355364382293628,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -1.0479994356658862,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -7.666647011044304,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -8.123480850460808,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -8.931222015621941,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -9.071210914852898,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.0733385622528,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.123073631527703,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.541791015866082,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.806229645016472,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -9.819115692379754,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.183052116635125,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.22347169518737,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.239841514828484,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -10.503139549496453,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -10.583661133053582,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -10.705093437435906,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -10.741202408077996,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.826670700314324,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.834187561276238,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 125,
                        "completion_tokens": 2,
                        "total_tokens": 127,
                        "prompt_tokens_details": {
                            "cached_tokens": 118
                        }
                    },
                    "timings": {
                        "cache_n": 118,
                        "prompt_n": 7,
                        "prompt_ms": 213,
                        "prompt_per_token_ms": 30.429,
                        "prompt_per_second": 32.9,
                        "predicted_n": 2,
                        "predicted_ms": 60.1,
                        "predicted_per_token_ms": 30.05,
                        "predicted_per_second": 33.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 341.325199988205,
                "captured_at": "2026-10-04T01:39:38Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B19): Figure 1. A request moves through the engine queue.\nSECOND (B17): The engine stops generation when\nQUESTION: Does the caption FIRST describe the subject discussed in SECOND?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-e02da228a79046a485a20683",
                    "object": "chat.completion",
                    "created": 1791077978,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -1.6908572478676906,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.20598252252589389,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.6908572478676906,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -8.483524636783706,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -8.59033520654689,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -8.694683389225112,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.80643685297023,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -9.037979440250503,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Does",
                                                "logprob": -9.786819772281753,
                                                "bytes": [
                                                    68,
                                                    111,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -9.877271012821303,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -9.932038621463882,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.026750878849136,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -10.041295365848647,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.30417855218898,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.35593064264308,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -10.37854035333644,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.074592904605971,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -11.115448312320815,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.328472451725112,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.378302888431655,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -11.393245057621108,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 119,
                        "completion_tokens": 2,
                        "total_tokens": 121,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 119,
                        "prompt_ms": 849.8,
                        "prompt_per_token_ms": 7.141,
                        "prompt_per_second": 140,
                        "predicted_n": 2,
                        "predicted_ms": 56.4,
                        "predicted_per_token_ms": 28.2,
                        "predicted_per_second": 35.5,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 940.2770999877248,
                "captured_at": "2026-10-04T01:39:39Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nFIRST (B19): Figure 1. A request moves through the engine queue.\nSECOND (B17): The engine stops generation when\nQUESTION: Does the caption FIRST describe the subject discussed in SECOND?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-4f448cf548cc47efb98454a6",
                    "object": "chat.completion",
                    "created": 1791077979,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.20598252252589389,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.20598252252589389,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -1.6908572478676906,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "FIRST",
                                                "logprob": -8.483524636783706,
                                                "bytes": [
                                                    70,
                                                    73,
                                                    82,
                                                    83,
                                                    84
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -8.59033520654689,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "First",
                                                "logprob": -8.694683389225112,
                                                "bytes": [
                                                    70,
                                                    105,
                                                    114,
                                                    115,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.80643685297023,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -9.037979440250503,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Does",
                                                "logprob": -9.786819772281753,
                                                "bytes": [
                                                    68,
                                                    111,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -9.877271012821303,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -9.932038621463882,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.026750878849136,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -10.041295365848647,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.30417855218898,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.35593064264308,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -10.37854035333644,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.074592904605971,
                                                "bytes": [
                                                    78
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -11.115448312320815,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.328472451725112,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.378302888431655,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -11.393245057621108,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 119,
                        "completion_tokens": 2,
                        "total_tokens": 121,
                        "prompt_tokens_details": {
                            "cached_tokens": 112
                        }
                    },
                    "timings": {
                        "cache_n": 112,
                        "prompt_n": 7,
                        "prompt_ms": 196.7,
                        "prompt_per_token_ms": 28.1,
                        "prompt_per_second": 35.6,
                        "predicted_n": 2,
                        "predicted_ms": 59,
                        "predicted_per_token_ms": 29.5,
                        "predicted_per_second": 33.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 334.8944000026677,
                "captured_at": "2026-10-04T01:39:40Z"
            }
        ]
    },
    "wall_ms": 86.19080000789836,
    "lesson_view": {
        "index": 0,
        "value": 0.5,
        "scope": "Reproduce the selected question/rule/result panel. Other page dials are independent."
    }
}
import argparse
import copy
import hashlib
import json
import math
import os
import sys
from pathlib import Path
import urllib.error
import urllib.request

"""Small, portable calculations behind the question/rule/result panels.

Standard library only. This exact source is included in every Python download.
Inputs are the captured experiment, never an invented new model response. A knob
changes a disclosed calculation on those inputs; it does not rescore a new prompt.
"""
import itertools
import math
import statistics


def _spec(question, rule, knob, default, compare, low, high, integer=False):
    return dict(question=question, rule=rule, knob=knob, default=default,
                compare=compare, low=low, high=high, integer=integer)


LESSON_SPECS = {
    'choice': _spec('Which ticket queue gets this message?', 'Compare the three saved label scores. Heat flattens their relative weights; it adds no evidence.', 'Reweighting temperature', 1, 2, .1, 3),
    'boolean': _spec('Does this message ask to cancel?', 'Normalize the saved Yes and No scores. A number near one is a strong preference, not proof.', 'Reweighting temperature', 1, 2, .1, 3),
    'score': _spec('How serious is the outage?', 'Multiply each rubric value by its answer weight, then add. The rating comes from the whole distribution.', 'Reweighting temperature', 1, 2, .1, 3),
    'candidates': _spec('Read the failure first, or start changing things?', 'Add token logprobs along each saved path, then sum path mass inside each finite group. A length penalty changes the objective.', 'Length penalty exponent', 0, 1, 0, 1),
    'controller': _spec('May the simulated repair take its next step?', 'Keep only state-legal actions. Hold the recorded action if its relative legal weight falls below the threshold.', 'Required legal-action weight', 0, .999, 0, 1),
    'rerank': _spec('Which sources help explain cancellation?', 'Compute each source’s expected relevance separately, then keep those above the cutoff.', 'Minimum relevance', 0, .9, 0, 1),
    'graph': _spec('Which text links can coexist?', 'Search every small edge subset. Reject cycles and competing attachments, then maximize useful edge weight.', 'Edge cost / threshold', .5, .9, .01, .99),
    'scene': _spec('Which valid drawing best fits the instruction?', 'Average the three saved text probes. Optionally charge for disagreement between them; code still checks geometry.', 'Disagreement penalty', 0, 1, 0, 2),
    'wire': _spec('What did the model assign to this actual token?', 'Exponentiate its raw logprob. Sum only the reported alternatives; their top-N list may omit probability mass.', 'Visible token index (zero-based)', 0, 5, 0, 10000, True),
    'speculation': _spec('Why can a draft be rejected?', 'Compare the proposal head and target verification on the same proposed token. They are different distributions.', 'Proposal position (zero-based)', 0, 2, 0, 10000, True),
    'performance': _spec('What did each API path cost on this setup?', 'Recalculate a latency percentile from the original wall-time samples. Different output tasks remain separate.', 'Latency percentile', 50, 90, 0, 100),
    'samplers': _spec('How much did this recipe change the selected token’s weight?', 'Compare its raw target probability with its post-sampler probability. Read support and entropy from the complete native row.', 'Recorded recipe index (zero-based)', 0, 1, 0, 10000, True),
    'sampler-sandbox': _spec('Can we add heat without admitting implausible tokens?', 'Remove logits below max + log(0.05), then divide the survivors by temperature and normalize.', 'Temperature after Min-P', 1.5, .7, .1, 3),
    'tictactoe': _spec('Did a legal move give away a winnable outcome?', 'Solve the saved position by exhaustive minimax. Compare the best legal outcome with the recorded model move.', 'Recorded turn index (zero-based)', 0, 1, 0, 10000, True),
    'chess': _spec('Did the shortlist favor a mating move?', 'Add the saved label weights attached to code-checked mating moves. The separately generated UCI move uses a different prompt.', 'Shortlist temperature', 1, 3, .1, 3),
    'poker': _spec('Should this hand check or bet?', 'Average exact chip payoffs over the two possible opponent cards using the stated calling policy.', 'Opponent call-rate multiplier', 1, 0, 0, 2),
    'thermal': _spec('What happens if we replay the fan commands differently?', 'Step the disclosed thermal equation through the same loads. A fan offset is an open-loop counterfactual, not a new model policy.', 'Fan offset', 0, 20, -60, 60),
    'scheduler': _spec('How much lateness did this legal schedule cause?', 'Add job durations in the recorded order and check dependencies. Charge for finishing after the adjusted deadline.', 'Deadline shift', 0, -3, -10, 10),
    'context': _spec('Did replacing old text change the current-state answer?', 'Recalculate each saved Yes/No distribution and compare the selected wording with the original append-only prompt.', 'Context variant index (zero-based)', 0, 2, 0, 10000, True),
    'observer': _spec('Which action follows from these three semantic measurements?', 'Apply the same explicit threshold rule to every saved report: inspect, verify, finish, or ask.', 'Decision threshold', .5, .999, 0, 1),
    'calibration': _spec('Does demanding stronger answers leave enough coverage?', 'Recalculate Brier error on all six examples and accuracy only on retained examples. Empty coverage has no accuracy.', 'Required answer weight', .5, 1, .5, 1),
    'information': _spec('Which observation is worth buying?', 'Use the stated sensor likelihoods to compute both Bayesian posteriors and expected entropy reduction.', 'Test index (zero-based)', 0, 1, 0, 10000, True),
    'search': _spec('Which valid scene survives a cost penalty?', 'Subtract the chosen cost charge from each saved semantic weight. Reject invalid geometry before ranking.', 'Cost weight', .1, 1, 0, 1),
    'frontier': _spec('Would faster score transfer matter here?', 'Add assumed forward time, a transfer lower bound, and the measured selector. This is a serial cost sketch.', 'Assumed transfer GB/s', 12, 2, .1, 128),
    'research-map': _spec('What would make this research idea testable?', 'Count the disclosed implementation categories, then reveal one branch’s next gate. A proposal is not a native result.', 'Branch index (zero-based)', 0, 12, 0, 10000, True),
    'pressure': _spec('How much original mass did this boundary throw away?', 'At temperature 1 with pure masking, log Z = raw selected logprob − log(selected masked probability). Pressure is −log Z.', 'Native grammar index (zero-based)', 0, 1, 0, 10000, True),
    'circuit': _spec('Can we compute AND without assuming independence?', 'Start with four joint worlds. Optionally condition on noisy evidence of style, then add worlds for each logical operation.', 'Reliability of observing style', .5, 1, .5, 1),
    'control': _spec('Can preference change while forbidden actions stay forbidden?', 'Normalize log(base) + strength × [log(desired) − log(undesired)] inside the legal set.', 'Control strength', 0, 2, 0, 3),
    'future': _spec('Can a less likely first move have a better future?', 'Weight the root policy by exact future success raised to strength. At strength zero use the base policy.', 'Future-value strength', 0, 1, 0, 2),
    'sensitivity': _spec('Which prompt intervention moves this measurement?', 'Rebuild the central finite-difference matrix. Predict a change in hours, with load fixed at +5 points; preserve the measured holdout error.', 'Change in hours remaining', -1, -2, -2, 2),
    'counterexamples': _spec('Can equivalent algebra confuse the observer?', 'Find the equivalent pair with the largest measured log-odds distance. Evaluate its exact coefficients at the chosen integer.', 'Integer x', 2, -2, -10, 10, True),
}


def normalize_logs(logs):
    finite = [x for x in logs if math.isfinite(x)]
    if not finite:
        raise ValueError('No candidate has positive mass')
    maximum = max(finite)
    weights = [math.exp(x-maximum) if math.isfinite(x) else 0. for x in logs]
    total = math.fsum(weights)
    return [w/total for w in weights]


def weights(rows, temperature=1):
    if any(r.get('logprob') is None for r in rows):
        raise ValueError('A complete label measurement is required; missing top-N entries stay unknown')
    return normalize_logs([r['logprob']/temperature for r in rows])


def entropy(p):
    return -math.fsum(x*math.log2(x) for x in p if x)


def _pick(items, value):
    if not 0 <= value < len(items):
        raise ValueError('Index must be 0..'+str(len(items)-1))
    return items[int(value)]


def _rows(names, values):
    return [dict(label=str(n), value=float(v)) for n,v in zip(names,values)]


def _graph(edges, threshold):
    if len(edges)>12:
        raise ValueError('This exact demonstration supports at most 12 edges')
    best, score = [], 0.
    for bits in itertools.product((False,True), repeat=len(edges)):
        selected=[e for e,yes in zip(edges,bits) if yes]
        out, incoming, captions = {}, set(), set()
        good=True
        for e in selected:
            a,b=e['source'],e['target']
            if a==b:good=False;break
            if e['relation']=='caption':
                if a in captions:good=False;break
                captions.add(a)
            else:
                if a in out or b in incoming:good=False;break
                out[a]=b;incoming.add(b)
        for start in out:
            node,visited=start,set()
            while node in out:
                if node in visited:good=False;break
                visited.add(node);node=out[node]
        utility=math.fsum(e['weight']-threshold for e in selected)
        if good and utility>score:best,score=selected,utility
    return best,score


def _ttt(board, turn):
    lines=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
    for a,b,c in lines:
        if board[a]!='.' and board[a]==board[b]==board[c]:return 1 if board[a]=='X' else -1
    if '.' not in board:return 0
    values=[_ttt(board[:i]+turn+board[i+1:],'O' if turn=='X' else 'X') for i,s in enumerate(board) if s=='.']
    return (max if turn=='X' else min)(values)


def calculate_lesson(name, data, value=None):
    spec=LESSON_SPECS[name]
    v=spec['default'] if value is None else value
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not spec['low']<=v<=spec['high'] or (spec['integer'] and int(v)!=v):
        raise ValueError(f"{spec['knob']} must be {'an integer' if spec['integer'] else 'finite'} in [{spec['low']}, {spec['high']}]")
    rows=[];metrics={};note='Calculation on saved inputs; changing this setting makes no new model request.'
    summary='';unit='weight'
    if name in ('choice','boolean','score'):
        p=weights(data['rows'],v);at=max(range(len(p)),key=p.__getitem__)
        rows=_rows([r['label']+' · '+r.get('description','') for r in data['rows']],p)
        metrics=dict(winner=data['rows'][at]['label'],top_weight=p[at],entropy_bits=entropy(p))
        if name in ('boolean','score'):
            metrics['expected_value']=math.fsum(q*r['value'] for q,r in zip(p,data['rows']))
        summary=f"Answer {metrics['winner']} leads with {p[at]:.2%} of the listed-label weight."
        if name=='score':summary=f"Expected rubric value: {metrics['expected_value']:.4f} on the stated 0–1 scale."
    elif name=='candidates':
        paths=data['paths'];logs=[math.fsum(t['logprob'] for t in r['tokens'])/len(r['tokens'])**v for r in paths]
        p=normalize_logs(logs);names=list(dict.fromkeys(r['group'] for r in paths))
        values=[math.fsum(q for q,r in zip(p,paths) if r['group']==g) for g in names];rows=_rows(names,values)
        metrics=dict(winner=names[values.index(max(values))],group_weights=values)
        summary=metrics['winner']+' carries the most relative group weight.'
        note='Only these emitted token paths, with their saved terminators and no EOS. A nonzero length penalty produces preference scores, not path probability.'
    elif name=='controller':
        labels=data['measure']['rows'];p=weights(labels);legal=[i for i,r in enumerate(labels) if r['allowed']]
        mass=math.fsum(p[i] for i in legal);pick=next(i for i,r in enumerate(labels) if r['action']==data['action'])
        q=p[pick]/mass;held=q<v
        rows=_rows([labels[i]['action'] for i in legal],[p[i]/mass for i in legal])
        metrics=dict(held=held,selected_weight=q,next_state=data['state'] if held else data['next_state'])
        summary=('Hold the action.' if held else 'Apply '+data['action']+'.')+' State: '+metrics['next_state']+'.'
    elif name=='rerank':
        values=[math.fsum(q*r['value'] for q,r in zip(weights(s['measure']['rows']),s['measure']['rows'])) for s in data['sources']]
        rows=_rows([s['id'] for s in data['sources']],values);kept=[r['label'] for r in rows if r['value']>=v]
        metrics=dict(retained=kept,scores=values);summary='Retain '+(', '.join(kept) or 'no sources')+' at this cutoff.'
    elif name=='graph':
        selected,utility=_graph(data['edges'],v);rows=_rows([e['source']+' → '+e['target'] for e in selected],[e['weight']-v for e in selected]);unit='utility'
        metrics=dict(selected=[(e['source'],e['target'],e['relation']) for e in selected],utility=utility)
        summary=f'{len(selected)} compatible links, total utility {utility:.4f}.'
        note='Global code constraints select links; utility is not the probability that the document graph is correct.'
    elif name=='scene':
        valid=[c for c in data['candidates'] if c['valid']];values=[]
        for c in valid:
            p=[weights(x['measure']['rows'])[0] for x in c['vector']]
            values.append(statistics.mean(p)-v*statistics.pvariance(p))
        rows=_rows([c['name'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['name'],utilities=values)
        summary='Retain '+metrics['retained']+' among geometry-valid candidates.'
        note='These are saved text judgments. This calculation cannot see the drawing or measure visual appeal.'
    elif name=='wire':
        entry=_pick(data['entries'],v);p=math.exp(entry['logprob']);top=entry.get('top_logprobs',[])
        rows=_rows([x['token'] for x in top],[math.exp(x['logprob']) for x in top]);unit='raw probability'
        metrics=dict(token=entry['token'],raw_probability=p,reported_top_mass=math.fsum(r['value'] for r in rows))
        summary=f"Token {entry['token']!r}: raw probability {p:.6g}."
        note='This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary.'
    elif name=='speculation':
        window=data['oracle']['example_rejection'];r=_pick(window['proposal'],v)
        rows=_rows(['Draft head','Target verification'],[r['draft_probability'],math.exp(r['target_logprob'])]);unit='probability / distinct heads'
        metrics=dict(token_id=r['token_id'],target_sequence_logprob=math.fsum(x['target_logprob'] for x in window['proposal']),draft_target_logprob_gap=r['draft_logprob']-r['target_logprob'])
        summary=f"Proposal token {r['token_id']}: the two heads differ by {metrics['draft_target_logprob_gap']:.4f} log units."
        note='Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability.'
    elif name=='performance':
        values=[]
        for r in data['rows']:
            xs=sorted(x['wall_ms'] for x in r['runs']);a=(len(xs)-1)*v/100;lo=math.floor(a);hi=math.ceil(a)
            values.append(xs[lo]+(xs[hi]-xs[lo])*(a-lo))
        rows=_rows([r['name'] for r in data['rows']],values);unit='ms';metrics=dict(percentile=v,times_ms=values)
        summary=f'Percentile {v:g}, recalculated from {data["repeats"]} samples per path.'
        note='Small same-setup samples include network and API cost. JSON answers a different task; this is no universal speed ranking.'
    elif name=='samplers':
        run=_pick(data['runs'],v);token=run['tokens'][0];sample=token['strata_sampling']
        raw=math.exp(token['logprob']);post=sample['probability']
        rows=_rows(['Raw target','After recipe'],[raw,post]);unit='selected token probability'
        metrics=dict(recipe=run['name'],support=sample['support'],raw=raw,selected=post,log_weight_change=math.log(post)-token['logprob'],entropy_bits=sample['entropy']/math.log(2))
        summary=f"{run['name']}: {sample['support']} native tokens remain eligible."
        note='Recipes are separate generations. Entropy and support are full-row native measurements; a top-N slice cannot recover them.'
    elif name=='sampler-sandbox':
        cut=max(data['logits'])+math.log(.05);logs=[x/v if x>=cut else -math.inf for x in data['logits']];p=normalize_logs(logs)
        rows=_rows(data['tokens'],p);metrics=dict(support=sum(x>0 for x in p),entropy_bits=entropy(p),probabilities=p)
        summary=f"{metrics['support']} credible tokens survive; entropy {metrics['entropy_bits']:.3f} bits."
        note='All eight logits are synthetic and visible. This is exact finite-row arithmetic, not a new native receipt.'
    elif name=='tictactoe':
        f=_pick(data['frames'],v);b=f['before'];legal=[i for i,c in enumerate(b) if c=='.'];oracle={i:_ttt(b[:i]+'X'+b[i+1:],'O') for i in legal}
        regret=max(oracle.values())-oracle[f['square']];rows=_rows([str(i+1) for i in legal],list(oracle.values()));unit='X outcome: lose −1 / draw 0 / win 1'
        metrics=dict(regret=regret,square=f['square']+1,oracle=oracle);summary=f"Recorded move: square {f['square']+1}; exact outcome regret {regret}."
    elif name=='chess':
        p=weights(data['measure']['rows'],v);mass=math.fsum(q for q,m in zip(p,data['shortlist']) if m['mate'])
        rows=_rows([m['san'] for m in data['shortlist']],p);metrics=dict(mating_shortlist_weight=mass,generated_uci=data['chosen']['text'],generated_mate=data['mate'])
        summary=f'{mass:.2%} of shortlist weight favors mate; the separate UCI generation '+('mated.' if data['mate'] else 'did not mate.')
        note='The saved legal/mate flags came from python-chess. This portable calculation aggregates them; it is not a replacement chess engine.'
    elif name=='poker':
        ranks=['J','Q','K'];rates={c:min(1,max(0,r*v)) for c,r in data['call_rates'].items()};values={}
        for own in ranks:
            opponents=[c for c in ranks if c!=own];sign=lambda c:1 if ranks.index(own)>ranks.index(c) else -1
            values[own]=dict(check=statistics.mean(sign(c) for c in opponents),bet=statistics.mean((1-rates[c])+rates[c]*2*sign(c) for c in opponents))
        rows=_rows([c+' bet − check' for c in ranks],[values[c]['bet']-values[c]['check'] for c in ranks]);unit='expected chips'
        metrics=dict(values=values,call_rates=rates);summary='Bet when the bar is positive; check when it is negative.'
        note='Uniform remaining-card prior and explicitly assumed opponent policy. Answer weights are not hidden-card beliefs or equilibrium probabilities.'
    elif name=='thermal':
        t=data['frames'][0]['temperature'];temperatures=[]
        for f in data['frames']:
            fan=min(60,max(0,f['fan']+v));t=round(t+.22*f['load']-.32*fan-.04*(t-25),3);temperatures.append(t)
        rows=_rows(range(1,len(temperatures)+1),temperatures);unit='°C';metrics=dict(temperatures=temperatures,mean_error=statistics.mean(abs(t-data['target']) for t in temperatures),violations=sum(t>data['limit'] for t in temperatures))
        summary=f"Mean distance from target: {metrics['mean_error']:.2f}°C; {metrics['violations']} limit violations."
        note='Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control.'
    elif name=='scheduler':
        done=set();clock=0;late=[]
        for f in data['frames']:
            j=f['job']
            if not set(j['after'])<=done:raise ValueError('Saved schedule violates dependencies')
            clock+=j['duration'];late.append(max(0,clock-j['deadline']-v));done.add(j['id'])
        rows=_rows([f['job']['id'] for f in data['frames']],late);unit='late time units';metrics=dict(total_lateness=sum(late),finish_time=clock)
        summary=f'Total lateness {sum(late):g}; the same dependency-valid order ends at time {clock}.'
    elif name=='context':
        selected=_pick(data['runs'],v);all_weights=[weights(r['measure']['rows'])[1] for r in data['runs']];p=all_weights[int(v)]
        rows=_rows([r['name'] for r in data['runs']],all_weights);metrics=dict(variant=selected['name'],no_weight=p,delta_from_append=p-all_weights[0])
        summary=f"{selected['name']}: keep-still answer weight {p:.3%}."
        note='Saved prompt interventions, not KV tensor mutation. This calculation compares their recorded measurements.'
    elif name=='observer':
        actions=[];triples=[]
        for f in data['frames']:
            p=[weights(x['measure']['rows'])[0] for x in f['vector']];triples.append(p)
            actions.append('inspect failure' if p[0]>v else 'verify' if p[1]>v else 'finish' if p[2]>v else 'ask')
        rows=_rows(['Fault','Missing check','Verified'],triples[0]);metrics=dict(actions=actions,vectors=triples)
        summary=' → '.join(actions)+'.';note='Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability.'
    elif name=='calibration':
        p=[weights(r['measure']['rows'])[0] for r in data['rows']];truth=[r['truth'] for r in data['rows']];kept=[i for i,q in enumerate(p) if max(q,1-q)>=v]
        brier=statistics.mean((q-y)**2 for q,y in zip(p,truth));accuracy=statistics.mean(int(p[i]>=.5)==truth[i] for i in kept) if kept else None
        rows=_rows([str(i+1) for i in range(len(p))],p);metrics=dict(brier=brier,retained=len(kept),coverage=len(kept)/len(p),accuracy=accuracy)
        summary=f'{len(kept)}/{len(p)} retained; '+(f'{accuracy:.1%} correct in those cases.' if accuracy is not None else 'accuracy is undefined with zero coverage.')
        note='Six disclosed teaching examples, not a held-out calibration benchmark. Brier error still counts every example.'
    elif name=='information':
        t=_pick(data['tests'],v);prior=data['prior'];py=math.fsum(p*l for p,l in zip(prior,t['likelihood']));yes=[p*l/py for p,l in zip(prior,t['likelihood'])];no=[p*(1-l)/(1-py) for p,l in zip(prior,t['likelihood'])]
        gain=entropy(prior)-py*entropy(yes)-(1-py)*entropy(no);rows=_rows(data['faults'],yes)
        metrics=dict(test=t['name'],gain_bits=gain,gain_per_cost=gain/t['cost'],yes=yes,no=no)
        summary=t['name']+f': {gain:.3f} expected bits; {gain/t["cost"]:.3f} bits per cost unit.'
        note='Prior and likelihoods are stated synthetic sensor assumptions. Bars condition on a positive result; no test was actually purchased.'
    elif name=='search':
        valid=[c for c in data['candidates'] if c['valid']];values=[weights(c['measure']['rows'])[0]-v*c['cost']/3 for c in valid]
        rows=_rows([c['id'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['id'],utilities=values)
        summary='Retain '+metrics['retained']+' after charging for cost; invalid geometry is excluded.'
    elif name=='frontier':
        selector=sorted(r['selection_ms'] for r in data['measurements'])[len(data['measurements'])//2];transfer=data['vocabulary']*data['bytes_per_logit']/(v*1e6);total=60+transfer+selector
        rows=_rows(['Assumed forward','Transfer lower bound','Measured host selector'],[60,transfer,selector]);unit='ms'
        metrics=dict(transfer_ms=transfer,serial_ms=total,tokens_per_second=1000/total)
        summary=f'Serial estimate: {total:.3f} ms/token; {1000/total:.2f} tokens/s.'
        note='Forward time is assumed 60 ms. Selector uses the upper-middle measured sample to match the chart. Queue, prefill and network are excluded.'
    elif name=='research-map':
        branch=_pick(data['branches'],v);categories={}
        for b in data['branches']:categories[b['status']]=categories.get(b['status'],0)+1
        rows=_rows(list(categories),list(categories.values()));unit='branches';metrics=dict(branch=branch['name'],gate=branch['gate'],categories=categories)
        summary=branch['name']+': '+branch['gate'];note='This page recomputes an agenda inventory, not an experiment result. Each implemented branch links to its own evidence.'
    elif name=='pressure':
        case=_pick(data['cases'],v);r=case['rows'][0];token=r['token'];q=token['strata_sampling']['probability'];logz=token['logprob']-math.log(q)
        if logz>1e-6:raise ValueError('Pure-mask mass exceeds one')
        z=math.exp(min(0,logz));rows=_rows(['Survived','Removed'],[z,1-z]);unit='original probability mass'
        metrics=dict(grammar=case['name'],mass=z,pressure_nats=-logz,pressure_bits=-logz/math.log(2))
        summary=f"{case['name']}: {z:.4%} survives; pressure {-logz:.4f} nats."
        note='First actual prefix of this native grammar. Exact only for pure masking at temperature 1, not arbitrary sampler recipes or entire grammar languages.'
    elif name=='circuit':
        p=weights(data['cases'][0]['measurement']['rows']);weighted=[p[0]*(1-v),p[1]*(1-v),p[2]*v,p[3]*v];z=math.fsum(weighted);p=[x/z for x in weighted]
        f=p[1]+p[3];s=p[2]+p[3];rows=_rows(['Neither','Facts only','Style only','Both'],p)
        metrics=dict(F=f,S=s,AND=p[3],OR=1-p[0],F_given_S=p[3]/s if s else None,marginal_product=f*s)
        summary=f'Facts AND style: {p[3]:.2%}; multiplying the marginals would give {f*s:.2%}.'
        note='At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world.'
    elif name=='control':
        logs=[math.log(b)+v*(math.log(d)-math.log(u)) if i in data['allowed'] else -math.inf for i,(b,d,u) in enumerate(zip(data['base'],data['desired'],data['undesired']))];p=normalize_logs(logs)
        rows=_rows(list('ABCD'),p);pick=max(range(len(p)),key=p.__getitem__);metrics=dict(probabilities=p,selected=pick,forbidden_mass=math.fsum(p[i] for i in range(len(p)) if i not in data['allowed']))
        summary=f"Action {'ABCD'[pick]} leads; forbidden-action mass stays zero."
        note='Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook.'
    elif name=='future':
        root=weights(data['policy'][0]['rows']);child=weights(data['policy'][2]['rows']);h=[0,child[1]];p=normalize_logs([math.log(r)+(v*math.log(x) if x else -math.inf) if v else math.log(r) for r,x in zip(root,h)])
        rows=_rows(['A: dead end','B: viable route'],p);success=p[1]*child[1];metrics=dict(root_weights=p,exact_h=h,success_root_only=success,base_success=root[1]*child[1])
        summary=f'{p[1]:.2%} chooses B; leaving the next policy unchanged succeeds {success:.2%} of the time.'
        note='Only BB succeeds in this exact two-step toy. Conditioning both steps is different from steering only the root. No native future-value decoder is claimed.'
    elif name=='sensitivity':
        o=data['observations'];zs=[[math.log(p/(1-p)) for p in row['probabilities']] for row in o]
        matrix=[[(zs[2][i]-zs[1][i])/(2*data['epsilon'][0]),(zs[4][i]-zs[3][i])/(2*data['epsilon'][1])] for i in range(3)]
        delta=[r[0]*v+r[1]*5 for r in matrix];rows=_rows(['Urgency','Load','Damage'],delta);unit='predicted log-odds change'
        observed=[zs[6][i]-zs[0][i] for i in range(3)];held=[r[0]*-1+r[1]*5 for r in matrix]
        metrics=dict(matrix=matrix,predicted_delta=delta,holdout_residual=[a-b for a,b in zip(observed,held)])
        summary=f'Predicted urgency shift {delta[0]:+.3f}; the measured −1h/+5 holdout had error {metrics["holdout_residual"][0]:+.3f}.'
        note='The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses.'
    elif name=='counterexamples':
        nodes=data['nodes'];pairs=[]
        for i,a in enumerate(nodes):
            za=[math.log(p/(1-p)) for p in a['p_yes']]
            for j,b in enumerate(nodes[i+1:],i+1):
                if a['coefficients']!=b['coefficients']:continue
                zb=[math.log(p/(1-p)) for p in b['p_yes']];distance=math.sqrt(math.fsum((x-y)**2 for x,y in zip(za,zb)));pairs.append((distance,i,j))
        distance,i,j=max(pairs);a,b=nodes[i],nodes[j];evaluate=lambda c:sum(x*v**k for k,x in enumerate(c))
        rows=_rows([a['expression'],b['expression']],[a['p_yes'][1],b['p_yes'][1]])
        metrics=dict(left=a['expression'],right=b['expression'],margin_distance=distance,left_value=evaluate(a['coefficients']),right_value=evaluate(b['coefficients']))
        summary=f'Equal exact values at x={v:g}: {metrics["left_value"]:g}; observer distance {distance:.3f}.'
        note='Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe.'
    else:
        raise ValueError('No portable calculation for '+name)
    return dict(value=v,summary=summary,rows=rows,unit=unit,metrics=metrics,note=note)


def make_lesson(name, data):
    spec=LESSON_SPECS[name]
    try:
        first=calculate_lesson(name,data)
        compare=spec['compare']
        # An edited run can have fewer tokens/turns than the recorded default.
        lengths={'wire':len(data.get('entries',[])), 'samplers':len(data.get('runs',[])),
                 'tictactoe':len(data.get('frames',[])), 'context':len(data.get('runs',[])),
                 'information':len(data.get('tests',[])), 'research-map':len(data.get('branches',[])),
                 'pressure':len(data.get('cases',[]))}
        if name in lengths:compare=min(compare,lengths[name]-1)
        second=calculate_lesson(name,data,compare)
        context=data.get('prompt','').partition('STATE:\n')[2].partition('\nQUESTION:')[0]
        return dict(**spec,states=[first,second],input_excerpt=context[:320]+('…' if len(context)>320 else ''),scope='This panel and its Python calculation reproduce saved measurements. Other page controls are independent views.')
    except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:
        # A genuinely incomplete score or a tool-only wire response stays usable.
        # Do not turn an unavailable lesson into fabricated measurement data.
        return dict(**spec,states=[],unavailable=str(error),scope='This run has no complete inputs for this calculation. Inspect its exact request and result below.')



def mock_post(request, fixture):
    if request != fixture['request']:
        raise ValueError('No mock matches the edited request. Supply a new fixture or explicitly choose --live-url.')
    return copy.deepcopy(fixture['response'])


def live_post(base_url, request):
    if not base_url.startswith(('http://', 'https://')):
        raise ValueError('--live-url must be an http(s) Strata address')
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('STRATA_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['STRATA_API_KEY']
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    body = json.dumps(request, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base_url.rstrip('/')+'/v1/chat/completions', data=body, headers=headers)
    with opener.open(req, timeout=600) as response:
        wire = response.read().decode('utf-8')
    if request.get('stream'):
        events = [line[5:].strip() for line in wire.splitlines() if line.startswith('data:')]
        if not events or events[-1] != '[DONE]':
            raise ValueError('Stream closed without [DONE]')
        chunks = [json.loads(line) for line in events[:-1]]
        if any('error' in chunk for chunk in chunks):
            raise ValueError('Stream reported an error: '+repr(chunks))
        return {'sse_events': chunks, 'wire': wire}
    reply = json.loads(wire)
    if 'error' in reply:
        raise ValueError('Strata reported an error: '+repr(reply['error']))
    return reply


def summarize(response):
    if 'sse_events' in response:
        return str(len(response['sse_events']))+' SSE events; inspect the saved wire response'
    choice = (response.get('choices') or [{}])[0]
    message = choice.get('message', {})
    text = message.get('content') or json.dumps(message.get('tool_calls') or message, ensure_ascii=False)
    entries = (choice.get('logprobs') or {}).get('content') or []
    if entries:
        text += '\n  First visible token raw probability: '+format(math.exp(entries[0]['logprob']), '.7g')
    return text


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=int, default=1, help='1-based request index (default 1)')
    parser.add_argument('--all', action='store_true', help='Replay every mock in this captured run')
    parser.add_argument('--show', action='store_true', help='Print exact selected HTTP request JSON')
    parser.add_argument('--lesson-only', action='store_true', help='Recalculate the captured question/rule/result panel without printing mocked calls')
    parser.add_argument('--value', type=float, help='Change the panel parameter within its documented bounds; offline calculation only')
    parser.add_argument('--live-url', help='Explicitly send ONE request to your compatible Strata server')
    parser.add_argument('--output', type=Path, help='Write responses and their provenance as JSON')
    args = parser.parse_args()
    if args.all and args.live_url:
        parser.error('--all is offline only; saved dependent requests are not a live adaptive controller')
    if args.live_url and (args.lesson_only or args.value is not None):
        parser.error('Lesson calculations use captured evidence. Do not mix --live-url with --lesson-only or --value.')
    calls = CAPTURED['receipt']['calls']
    print('Strata Control Lab / '+CAPTURED['experiment'])
    print('LIVE selected request' if args.live_url else 'OFFLINE MOCK / recorded responses, no inference or network')
    calculation=None
    if not args.live_url:
        spec=CAPTURED.get('lesson')
        if spec and spec.get('states'):
            knob=args.value if args.value is not None else (CAPTURED.get('lesson_view') or {}).get('value',spec['default'])
            try:calculation=calculate_lesson(CAPTURED['experiment'],CAPTURED['result'],knob)
            except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:parser.error(str(error))
            print('\nQUESTION: '+spec['question']+'\nRULE: '+spec['rule'])
            print(spec['knob']+' = '+str(knob)+f" (allowed {spec['low']}..{spec['high']})")
            print('RESULT: '+calculation['summary'])
            print('BOUNDARY: '+calculation['note'])
            print('Reproduces the selected question/rule/result panel; other page dials are independent.')
            print(json.dumps(calculation,ensure_ascii=True,indent=2))
        elif args.lesson_only or args.value is not None:
            parser.error('This captured run has no complete lesson inputs: '+str((spec or {}).get('unavailable','missing calculation')))
    if args.lesson_only:
        result=dict(mode='offline-calculation',calculation=calculation)
    elif not calls:
        if args.live_url:
            parser.error('This page has no HTTP requests: it is analytical or recorded diagnostic evidence')
        print('No HTTP request, GBNF or JSON output constraint was used by this page.')
        print('The included result is a calculation/diagnostic snapshot, not a new model answer.')
        result = dict(mode='offline-snapshot', result=CAPTURED['result'])
        print(json.dumps(result, ensure_ascii=True, indent=2))
    else:
        indexes = range(len(calls)) if args.all else [args.request-1]
        if any(i < 0 or i >= len(calls) for i in indexes):
            parser.error('Request index must be 1..'+str(len(calls)))
        results = []
        for i in indexes:
            fixture = calls[i]
            request = copy.deepcopy(fixture['request'])  # Edit here to try your own live request.
            if args.show:
                print(json.dumps(request, ensure_ascii=True, indent=2))
            response = live_post(args.live_url, request) if args.live_url else mock_post(request, fixture)
            print('Request '+str(i+1)+' / '+str(len(calls))+': '+summarize(response))
            results.append(dict(request=request, response=response,
                                provenance='live-request' if args.live_url else 'mocked-native-recording'))
        result = dict(mode='live' if args.live_url else 'offline-mock', calls=results)
        print('GBNF and JSON settings are in each request. Use --show to inspect them.')
        print('The saved page result is in CAPTURED["result"]; live responses do not recompute that snapshot.')
    if calculation is not None:result['calculation']=calculation
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
