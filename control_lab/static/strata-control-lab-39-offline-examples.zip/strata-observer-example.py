# -*- coding: utf-8 -*-
"""Downloaded Strata example: Python 3 standard library; offline by default.

Windows: py strata-example.py
Ubuntu:  python3 strata-example.py
Show a request: python strata-example.py --request 1 --show
Replay all recorded calls: python strata-example.py --all
Recalculate the panel: python strata-example.py --lesson-only
Change its knob: python strata-example.py --lesson-only --value NUMBER
Try ONE request live: python strata-example.py --request 1 --live-url http://127.0.0.1:8080
An optional STRATA_API_KEY environment variable supplies authentication.

CAPTURED is inserted above this runner by the page. It contains this exact run,
with requests, GBNF/JSON settings, responses, streaming chunks and the page result.
Mock mode returns those responses; it performs no inference and opens no socket.
Live mode runs only a selected request. It does not execute tools or adapt a saved
multi-step trace to new answers. No captured API key or authorization header exists.
"""
CAPTURED = {
    "experiment": "observer",
    "type": "result",
    "result": {
        "kind": "observer",
        "frames": [
            {
                "report": "The request timed out. The connection closed. No successful result was returned.",
                "vector": [
                    {
                        "question": "Does the report explicitly establish a failure?",
                        "value": 0.9364452525529215,
                        "measure": {
                            "rows": [
                                {
                                    "label": "A",
                                    "description": "Yes, the statement is supported by the state",
                                    "value": 1,
                                    "text": "A",
                                    "tokens": [
                                        {
                                            "token": "A",
                                            "logprob": -0.068473380434915,
                                            "bytes": [
                                                65
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "A",
                                                    "logprob": -0.068473380434915,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "B",
                                                    "logprob": -2.7586627420071808,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -6.624163192141458,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Yes",
                                                    "logprob": -8.336677115786477,
                                                    "bytes": [
                                                        89,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -8.37905077301304,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "YES",
                                                    "logprob": -9.302680533755227,
                                                    "bytes": [
                                                        89,
                                                        69,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.653117698061868,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -9.911531012881204,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -10.197306197512551,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "\"A",
                                                    "logprob": -10.287832778323098,
                                                    "bytes": [
                                                        34,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.317467254031106,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "Option",
                                                    "logprob": -10.395311873782083,
                                                    "bytes": [
                                                        79,
                                                        112,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -10.531213324892923,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -10.560077231753274,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "yes",
                                                    "logprob": -10.610461753237649,
                                                    "bytes": [
                                                        121,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -11.00886968933384,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "Y",
                                                    "logprob": -11.124192756045266,
                                                    "bytes": [
                                                        89
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -11.453502219546243,
                                                    "bytes": [
                                                        34
                                                    ]
                                                },
                                                {
                                                    "token": "AA",
                                                    "logprob": -11.518188041079446,
                                                    "bytes": [
                                                        65,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "answer",
                                                    "logprob": -11.54788736664097,
                                                    "bytes": [
                                                        97,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -0.068473380434915,
                                    "path_probability": 0.9338183176101565,
                                    "mean_logprob": -0.068473380434915,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.9338183176101565,
                                    "weight": 0.9364452525529215
                                },
                                {
                                    "label": "B",
                                    "description": "No, the statement is false or not established by the state",
                                    "value": 0,
                                    "text": "B",
                                    "tokens": [
                                        {
                                            "token": "B",
                                            "logprob": -2.7586627420071808,
                                            "bytes": [
                                                66
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "A",
                                                    "logprob": -0.068473380434915,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "B",
                                                    "logprob": -2.7586627420071808,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -6.624163192141458,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Yes",
                                                    "logprob": -8.336677115786477,
                                                    "bytes": [
                                                        89,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -8.37905077301304,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "YES",
                                                    "logprob": -9.302680533755227,
                                                    "bytes": [
                                                        89,
                                                        69,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.653117698061868,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -9.911531012881204,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -10.197306197512551,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "\"A",
                                                    "logprob": -10.287832778323098,
                                                    "bytes": [
                                                        34,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.317467254031106,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "Option",
                                                    "logprob": -10.395311873782083,
                                                    "bytes": [
                                                        79,
                                                        112,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -10.531213324892923,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -10.560077231753274,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "yes",
                                                    "logprob": -10.610461753237649,
                                                    "bytes": [
                                                        121,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -11.00886968933384,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "Y",
                                                    "logprob": -11.124192756045266,
                                                    "bytes": [
                                                        89
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -11.453502219546243,
                                                    "bytes": [
                                                        34
                                                    ]
                                                },
                                                {
                                                    "token": "AA",
                                                    "logprob": -11.518188041079446,
                                                    "bytes": [
                                                        65,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "answer",
                                                    "logprob": -11.54788736664097,
                                                    "bytes": [
                                                        97,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -2.7586627420071808,
                                    "path_probability": 0.06337646239902864,
                                    "mean_logprob": -2.7586627420071808,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.06337646239902864,
                                    "weight": 0.06355474744707837
                                }
                            ],
                            "complete": True,
                            "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe request timed out. The connection closed. No successful result was returned.\nQUESTION: Does the report explicitly establish a failure?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                            "winner": "A",
                            "statistics": {
                                "top_weight": 0.9364452525529215,
                                "margin": 0.8728905051058432,
                                "peakedness": 0.8728905051058431,
                                "entropy_bits": 0.34139722491409374,
                                "expected_score": 0.9364452525529215,
                                "variance": 0.05951554152401645
                            },
                            "strategy": "one literal-constrained call per label",
                            "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                        }
                    },
                    {
                        "question": "Is verification missing or unknown?",
                        "value": 0.4587824835192797,
                        "measure": {
                            "rows": [
                                {
                                    "label": "A",
                                    "description": "Yes, the statement is supported by the state",
                                    "value": 1,
                                    "text": "A",
                                    "tokens": [
                                        {
                                            "token": "A",
                                            "logprob": -0.7831351734611951,
                                            "bytes": [
                                                65
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.6178901173088513,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -0.7831351734611951,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -7.5133788563225234,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -7.695231197020766,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Yes",
                                                    "logprob": -8.166902301451918,
                                                    "bytes": [
                                                        89,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -8.516173122069594,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -8.746756312987563,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -8.848210094115492,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -9.155091045043227,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "YES",
                                                    "logprob": -9.664495227477309,
                                                    "bytes": [
                                                        89,
                                                        69,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "I",
                                                    "logprob": -10.062144992491957,
                                                    "bytes": [
                                                        73
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -10.130414722106215,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "a",
                                                    "logprob": -10.176644084594008,
                                                    "bytes": [
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -10.186129329344984,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -10.193773982665297,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -10.209724185607191,
                                                    "bytes": [
                                                        34
                                                    ]
                                                },
                                                {
                                                    "token": "No",
                                                    "logprob": -10.25495695843434,
                                                    "bytes": [
                                                        78,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": "<|im_end|>",
                                                    "logprob": -10.26111864819264,
                                                    "bytes": None
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -10.297484157225844,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "\"A",
                                                    "logprob": -10.341414210936781,
                                                    "bytes": [
                                                        34,
                                                        65
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -0.7831351734611951,
                                    "path_probability": 0.4569710794995509,
                                    "mean_logprob": -0.7831351734611951,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.4569710794995509,
                                    "weight": 0.4587824835192797
                                },
                                {
                                    "label": "B",
                                    "description": "No, the statement is false or not established by the state",
                                    "value": 0,
                                    "text": "B",
                                    "tokens": [
                                        {
                                            "token": "B",
                                            "logprob": -0.6178901173088513,
                                            "bytes": [
                                                66
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.6178901173088513,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -0.7831351734611951,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -7.5133788563225234,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -7.695231197020766,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Yes",
                                                    "logprob": -8.166902301451918,
                                                    "bytes": [
                                                        89,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -8.516173122069594,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -8.746756312987563,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -8.848210094115492,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -9.155091045043227,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "YES",
                                                    "logprob": -9.664495227477309,
                                                    "bytes": [
                                                        89,
                                                        69,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "I",
                                                    "logprob": -10.062144992491957,
                                                    "bytes": [
                                                        73
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -10.130414722106215,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "a",
                                                    "logprob": -10.176644084594008,
                                                    "bytes": [
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -10.186129329344984,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -10.193773982665297,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -10.209724185607191,
                                                    "bytes": [
                                                        34
                                                    ]
                                                },
                                                {
                                                    "token": "No",
                                                    "logprob": -10.25495695843434,
                                                    "bytes": [
                                                        78,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": "<|im_end|>",
                                                    "logprob": -10.26111864819264,
                                                    "bytes": None
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -10.297484157225844,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "\"A",
                                                    "logprob": -10.341414210936781,
                                                    "bytes": [
                                                        34,
                                                        65
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -0.6178901173088513,
                                    "path_probability": 0.5390806354529607,
                                    "mean_logprob": -0.6178901173088513,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.5390806354529607,
                                    "weight": 0.5412175164807204
                                }
                            ],
                            "complete": True,
                            "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe request timed out. The connection closed. No successful result was returned.\nQUESTION: Is verification missing or unknown?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                            "winner": "B",
                            "statistics": {
                                "top_weight": 0.5412175164807204,
                                "margin": 0.08243503296144067,
                                "peakedness": 0.08243503296144072,
                                "entropy_bits": 0.9950924908907808,
                                "expected_score": 0.4587824835192797,
                                "variance": 0.24830111633516155
                            },
                            "strategy": "one literal-constrained call per label",
                            "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                        }
                    },
                    {
                        "question": "Does the report establish a successfully verified result?",
                        "value": 0.003560901259834582,
                        "measure": {
                            "rows": [
                                {
                                    "label": "A",
                                    "description": "Yes, the statement is supported by the state",
                                    "value": 1,
                                    "text": "A",
                                    "tokens": [
                                        {
                                            "token": "A",
                                            "logprob": -5.640049548081963,
                                            "bytes": [
                                                65
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.005875201158134761,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -5.640049548081963,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -7.084914774827569,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "\"B",
                                                    "logprob": -8.842232317857354,
                                                    "bytes": [
                                                        34,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -8.885855288438409,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -9.112585635118096,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -9.115502924851983,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -9.390670390061944,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.490211100511162,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "No",
                                                    "logprob": -9.565073580674737,
                                                    "bytes": [
                                                        78,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": "NO",
                                                    "logprob": -9.636417956285088,
                                                    "bytes": [
                                                        78,
                                                        79
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -10.162175745896905,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -10.250456423692315,
                                                    "bytes": [
                                                        34
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -10.814983935288994,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "Option",
                                                    "logprob": -11.20122870915374,
                                                    "bytes": [
                                                        79,
                                                        112,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -11.306643099717705,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "answer",
                                                    "logprob": -11.354361147813409,
                                                    "bytes": [
                                                        97,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": ".B",
                                                    "logprob": -11.4638868283554,
                                                    "bytes": [
                                                        46,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Question",
                                                    "logprob": -11.642889590196221,
                                                    "bytes": [
                                                        81,
                                                        117,
                                                        101,
                                                        115,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": "I",
                                                    "logprob": -11.709917635850518,
                                                    "bytes": [
                                                        73
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -5.640049548081963,
                                    "path_probability": 0.0035526923727674607,
                                    "mean_logprob": -5.640049548081963,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.0035526923727674607,
                                    "weight": 0.003560901259834582
                                },
                                {
                                    "label": "B",
                                    "description": "No, the statement is false or not established by the state",
                                    "value": 0,
                                    "text": "B",
                                    "tokens": [
                                        {
                                            "token": "B",
                                            "logprob": -0.005875201158134761,
                                            "bytes": [
                                                66
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.005875201158134761,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -5.640049548081963,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -7.084914774827569,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "\"B",
                                                    "logprob": -8.842232317857354,
                                                    "bytes": [
                                                        34,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -8.885855288438409,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -9.112585635118096,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -9.115502924851983,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -9.390670390061944,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.490211100511162,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "No",
                                                    "logprob": -9.565073580674737,
                                                    "bytes": [
                                                        78,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": "NO",
                                                    "logprob": -9.636417956285088,
                                                    "bytes": [
                                                        78,
                                                        79
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -10.162175745896905,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -10.250456423692315,
                                                    "bytes": [
                                                        34
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -10.814983935288994,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "Option",
                                                    "logprob": -11.20122870915374,
                                                    "bytes": [
                                                        79,
                                                        112,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -11.306643099717705,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "answer",
                                                    "logprob": -11.354361147813409,
                                                    "bytes": [
                                                        97,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": ".B",
                                                    "logprob": -11.4638868283554,
                                                    "bytes": [
                                                        46,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Question",
                                                    "logprob": -11.642889590196221,
                                                    "bytes": [
                                                        81,
                                                        117,
                                                        101,
                                                        115,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": "I",
                                                    "logprob": -11.709917635850518,
                                                    "bytes": [
                                                        73
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -0.005875201158134761,
                                    "path_probability": 0.9941420240857556,
                                    "mean_logprob": -0.005875201158134761,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.9941420240857556,
                                    "weight": 0.9964390987401655
                                }
                            ],
                            "complete": True,
                            "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe request timed out. The connection closed. No successful result was returned.\nQUESTION: Does the report establish a successfully verified result?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                            "winner": "B",
                            "statistics": {
                                "top_weight": 0.9964390987401655,
                                "margin": 0.9928781974803309,
                                "peakedness": 0.9928781974803309,
                                "entropy_bits": 0.03409087644387407,
                                "expected_score": 0.003560901259834582,
                                "variance": 0.0035482212420522904
                            },
                            "strategy": "one literal-constrained call per label",
                            "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                        }
                    }
                ],
                "action": "inspect failure"
            },
            {
                "report": "A patch was applied. No test has run. The deployment status is unknown.",
                "vector": [
                    {
                        "question": "Does the report explicitly establish a failure?",
                        "value": 0.007086704885642035,
                        "measure": {
                            "rows": [
                                {
                                    "label": "A",
                                    "description": "Yes, the statement is supported by the state",
                                    "value": 1,
                                    "text": "A",
                                    "tokens": [
                                        {
                                            "token": "A",
                                            "logprob": -4.950335502686561,
                                            "bytes": [
                                                65
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.007912635865271432,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -4.950335502686561,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -8.643431663575232,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -9.741835594239294,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.029411315980017,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -10.346127510132849,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "###",
                                                    "logprob": -10.596807479920447,
                                                    "bytes": [
                                                        35,
                                                        35,
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "NO",
                                                    "logprob": -10.668852806153357,
                                                    "bytes": [
                                                        78,
                                                        79
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -10.875729560914099,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -10.944958686890661,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -10.96589660650736,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "No",
                                                    "logprob": -11.139475822510779,
                                                    "bytes": [
                                                        78,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": "\"B",
                                                    "logprob": -11.45758533483988,
                                                    "bytes": [
                                                        34,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -11.682606697144568,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "Does",
                                                    "logprob": -11.763769149842322,
                                                    "bytes": [
                                                        68,
                                                        111,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "Question",
                                                    "logprob": -11.843193054261267,
                                                    "bytes": [
                                                        81,
                                                        117,
                                                        101,
                                                        115,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -11.860097885193884,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "E",
                                                    "logprob": -11.881146431031286,
                                                    "bytes": [
                                                        69
                                                    ]
                                                },
                                                {
                                                    "token": "State",
                                                    "logprob": -11.932911872925818,
                                                    "bytes": [
                                                        83,
                                                        116,
                                                        97,
                                                        116,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "Y",
                                                    "logprob": -12.062716484131872,
                                                    "bytes": [
                                                        89
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -4.950335502686561,
                                    "path_probability": 0.0070810328249433585,
                                    "mean_logprob": -4.950335502686561,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.0070810328249433585,
                                    "weight": 0.007086704885642035
                                },
                                {
                                    "label": "B",
                                    "description": "No, the statement is false or not established by the state",
                                    "value": 0,
                                    "text": "B",
                                    "tokens": [
                                        {
                                            "token": "B",
                                            "logprob": -0.007912635865271432,
                                            "bytes": [
                                                66
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.007912635865271432,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -4.950335502686561,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -8.643431663575232,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -9.741835594239294,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.029411315980017,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -10.346127510132849,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "###",
                                                    "logprob": -10.596807479920447,
                                                    "bytes": [
                                                        35,
                                                        35,
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "NO",
                                                    "logprob": -10.668852806153357,
                                                    "bytes": [
                                                        78,
                                                        79
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -10.875729560914099,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -10.944958686890661,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -10.96589660650736,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "No",
                                                    "logprob": -11.139475822510779,
                                                    "bytes": [
                                                        78,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": "\"B",
                                                    "logprob": -11.45758533483988,
                                                    "bytes": [
                                                        34,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -11.682606697144568,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "Does",
                                                    "logprob": -11.763769149842322,
                                                    "bytes": [
                                                        68,
                                                        111,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "Question",
                                                    "logprob": -11.843193054261267,
                                                    "bytes": [
                                                        81,
                                                        117,
                                                        101,
                                                        115,
                                                        116,
                                                        105,
                                                        111,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -11.860097885193884,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "E",
                                                    "logprob": -11.881146431031286,
                                                    "bytes": [
                                                        69
                                                    ]
                                                },
                                                {
                                                    "token": "State",
                                                    "logprob": -11.932911872925818,
                                                    "bytes": [
                                                        83,
                                                        116,
                                                        97,
                                                        116,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "Y",
                                                    "logprob": -12.062716484131872,
                                                    "bytes": [
                                                        89
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -0.007912635865271432,
                                    "path_probability": 0.9921185866328716,
                                    "mean_logprob": -0.007912635865271432,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.9921185866328716,
                                    "weight": 0.9929132951143579
                                }
                            ],
                            "complete": True,
                            "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nA patch was applied. No test has run. The deployment status is unknown.\nQUESTION: Does the report explicitly establish a failure?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                            "winner": "B",
                            "statistics": {
                                "top_weight": 0.9929132951143579,
                                "margin": 0.9858265902287159,
                                "peakedness": 0.9858265902287158,
                                "entropy_bits": 0.060791457148738265,
                                "expected_score": 0.007086704885642035,
                                "variance": 0.007036483499505852
                            },
                            "strategy": "one literal-constrained call per label",
                            "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                        }
                    },
                    {
                        "question": "Is verification missing or unknown?",
                        "value": 0.8743398386494632,
                        "measure": {
                            "rows": [
                                {
                                    "label": "A",
                                    "description": "Yes, the statement is supported by the state",
                                    "value": 1,
                                    "text": "A",
                                    "tokens": [
                                        {
                                            "token": "A",
                                            "logprob": -0.13574878732783802,
                                            "bytes": [
                                                65
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "A",
                                                    "logprob": -0.13574878732783802,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "B",
                                                    "logprob": -2.0756367878161193,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Yes",
                                                    "logprob": -8.965496941014361,
                                                    "bytes": [
                                                        89,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -9.11793129007442,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -9.319786949559283,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "YES",
                                                    "logprob": -9.770342750950885,
                                                    "bytes": [
                                                        89,
                                                        69,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.913227005406451,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -9.917073173924518,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -10.225748939915729,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.317932053013873,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "###",
                                                    "logprob": -10.357301636143756,
                                                    "bytes": [
                                                        35,
                                                        35,
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -10.366629524632526,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "a",
                                                    "logprob": -10.537531776829791,
                                                    "bytes": [
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -10.622210426732135,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "AA",
                                                    "logprob": -10.68824379007442,
                                                    "bytes": [
                                                        65,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Y",
                                                    "logprob": -10.843513412877154,
                                                    "bytes": [
                                                        89
                                                    ]
                                                },
                                                {
                                                    "token": "```",
                                                    "logprob": -10.90693561594112,
                                                    "bytes": [
                                                        96,
                                                        96,
                                                        96
                                                    ]
                                                },
                                                {
                                                    "token": "State",
                                                    "logprob": -10.955987854405475,
                                                    "bytes": [
                                                        83,
                                                        116,
                                                        97,
                                                        116,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -10.976818962498736,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "X",
                                                    "logprob": -11.169295235081744,
                                                    "bytes": [
                                                        88
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -0.13574878732783802,
                                    "path_probability": 0.8730619291627022,
                                    "mean_logprob": -0.13574878732783802,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.8730619291627022,
                                    "weight": 0.8743398386494632
                                },
                                {
                                    "label": "B",
                                    "description": "No, the statement is false or not established by the state",
                                    "value": 0,
                                    "text": "B",
                                    "tokens": [
                                        {
                                            "token": "B",
                                            "logprob": -2.0756367878161193,
                                            "bytes": [
                                                66
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "A",
                                                    "logprob": -0.13574878732783802,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "B",
                                                    "logprob": -2.0756367878161193,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Yes",
                                                    "logprob": -8.965496941014361,
                                                    "bytes": [
                                                        89,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -9.11793129007442,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -9.319786949559283,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "YES",
                                                    "logprob": -9.770342750950885,
                                                    "bytes": [
                                                        89,
                                                        69,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.913227005406451,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -9.917073173924518,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -10.225748939915729,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.317932053013873,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "###",
                                                    "logprob": -10.357301636143756,
                                                    "bytes": [
                                                        35,
                                                        35,
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -10.366629524632526,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "a",
                                                    "logprob": -10.537531776829791,
                                                    "bytes": [
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -10.622210426732135,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "AA",
                                                    "logprob": -10.68824379007442,
                                                    "bytes": [
                                                        65,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Y",
                                                    "logprob": -10.843513412877154,
                                                    "bytes": [
                                                        89
                                                    ]
                                                },
                                                {
                                                    "token": "```",
                                                    "logprob": -10.90693561594112,
                                                    "bytes": [
                                                        96,
                                                        96,
                                                        96
                                                    ]
                                                },
                                                {
                                                    "token": "State",
                                                    "logprob": -10.955987854405475,
                                                    "bytes": [
                                                        83,
                                                        116,
                                                        97,
                                                        116,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -10.976818962498736,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "X",
                                                    "logprob": -11.169295235081744,
                                                    "bytes": [
                                                        88
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -2.0756367878161193,
                                    "path_probability": 0.125476500141017,
                                    "mean_logprob": -2.0756367878161193,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.125476500141017,
                                    "weight": 0.12566016135053684
                                }
                            ],
                            "complete": True,
                            "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nA patch was applied. No test has run. The deployment status is unknown.\nQUESTION: Is verification missing or unknown?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                            "winner": "A",
                            "statistics": {
                                "top_weight": 0.8743398386494632,
                                "margin": 0.7486796772989264,
                                "peakedness": 0.7486796772989264,
                                "entropy_bits": 0.545414880477707,
                                "expected_score": 0.8743398386494632,
                                "variance": 0.1098696851998939
                            },
                            "strategy": "one literal-constrained call per label",
                            "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                        }
                    },
                    {
                        "question": "Does the report establish a successfully verified result?",
                        "value": 0.004085117968614179,
                        "measure": {
                            "rows": [
                                {
                                    "label": "A",
                                    "description": "Yes, the statement is supported by the state",
                                    "value": 1,
                                    "text": "A",
                                    "tokens": [
                                        {
                                            "token": "A",
                                            "logprob": -5.502709861273331,
                                            "bytes": [
                                                65
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.006398673529190272,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -5.502709861273331,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -6.766341681952042,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.152915473455948,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -9.341628547186417,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "###",
                                                    "logprob": -9.428332801336808,
                                                    "bytes": [
                                                        35,
                                                        35,
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -9.430854316229386,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -9.714498992437882,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "NO",
                                                    "logprob": -10.03233861493544,
                                                    "bytes": [
                                                        78,
                                                        79
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.067658896917862,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "\"B",
                                                    "logprob": -10.437202926153702,
                                                    "bytes": [
                                                        34,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "No",
                                                    "logprob": -10.453065391058487,
                                                    "bytes": [
                                                        78,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -10.458833213324112,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -10.656481261724991,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -10.855013366217179,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -10.913473601812882,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Does",
                                                    "logprob": -11.152650351995987,
                                                    "bytes": [
                                                        68,
                                                        111,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "answer",
                                                    "logprob": -11.155641074652237,
                                                    "bytes": [
                                                        97,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "State",
                                                    "logprob": -11.267261977667374,
                                                    "bytes": [
                                                        83,
                                                        116,
                                                        97,
                                                        116,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "What",
                                                    "logprob": -11.50784253644423,
                                                    "bytes": [
                                                        87,
                                                        104,
                                                        97,
                                                        116
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -5.502709861273331,
                                    "path_probability": 0.004075711846557788,
                                    "mean_logprob": -5.502709861273331,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.004075711846557788,
                                    "weight": 0.004085117968614179
                                },
                                {
                                    "label": "B",
                                    "description": "No, the statement is false or not established by the state",
                                    "value": 0,
                                    "text": "B",
                                    "tokens": [
                                        {
                                            "token": "B",
                                            "logprob": -0.006398673529190272,
                                            "bytes": [
                                                66
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.006398673529190272,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -5.502709861273331,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -6.766341681952042,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.152915473455948,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -9.341628547186417,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "###",
                                                    "logprob": -9.428332801336808,
                                                    "bytes": [
                                                        35,
                                                        35,
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -9.430854316229386,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -9.714498992437882,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "NO",
                                                    "logprob": -10.03233861493544,
                                                    "bytes": [
                                                        78,
                                                        79
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.067658896917862,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "\"B",
                                                    "logprob": -10.437202926153702,
                                                    "bytes": [
                                                        34,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "No",
                                                    "logprob": -10.453065391058487,
                                                    "bytes": [
                                                        78,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -10.458833213324112,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -10.656481261724991,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -10.855013366217179,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -10.913473601812882,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "Does",
                                                    "logprob": -11.152650351995987,
                                                    "bytes": [
                                                        68,
                                                        111,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "answer",
                                                    "logprob": -11.155641074652237,
                                                    "bytes": [
                                                        97,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "State",
                                                    "logprob": -11.267261977667374,
                                                    "bytes": [
                                                        83,
                                                        116,
                                                        97,
                                                        116,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "What",
                                                    "logprob": -11.50784253644423,
                                                    "bytes": [
                                                        87,
                                                        104,
                                                        97,
                                                        116
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -0.006398673529190272,
                                    "path_probability": 0.993621754388528,
                                    "mean_logprob": -0.006398673529190272,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.993621754388528,
                                    "weight": 0.9959148820313858
                                }
                            ],
                            "complete": True,
                            "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nA patch was applied. No test has run. The deployment status is unknown.\nQUESTION: Does the report establish a successfully verified result?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                            "winner": "B",
                            "statistics": {
                                "top_weight": 0.9959148820313858,
                                "margin": 0.9918297640627716,
                                "peakedness": 0.9918297640627716,
                                "entropy_bits": 0.03829859688671816,
                                "expected_score": 0.004085117968614179,
                                "variance": 0.004068429779796685
                            },
                            "strategy": "one literal-constrained call per label",
                            "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                        }
                    }
                ],
                "action": "verify"
            },
            {
                "report": "The patched service passed its tests and returned the expected result.",
                "vector": [
                    {
                        "question": "Does the report explicitly establish a failure?",
                        "value": 0.006609854782595108,
                        "measure": {
                            "rows": [
                                {
                                    "label": "A",
                                    "description": "Yes, the statement is supported by the state",
                                    "value": 1,
                                    "text": "A",
                                    "tokens": [
                                        {
                                            "token": "A",
                                            "logprob": -5.022276069012823,
                                            "bytes": [
                                                65
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.009714270917119388,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -5.022276069012823,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -6.277296210614385,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "No",
                                                    "logprob": -9.269586707440556,
                                                    "bytes": [
                                                        78,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -9.307409430829228,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.347051764813603,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "\"B",
                                                    "logprob": -9.419615889874638,
                                                    "bytes": [
                                                        34,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -9.48721327909583,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "NO",
                                                    "logprob": -9.589577819195927,
                                                    "bytes": [
                                                        78,
                                                        79
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -10.046176101056279,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -10.0799733651554,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -10.155849601117314,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -10.500536109296025,
                                                    "bytes": [
                                                        34
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -10.675232077923955,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -10.688470984784306,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "###",
                                                    "logprob": -10.7110129846012,
                                                    "bytes": [
                                                        35,
                                                        35,
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "C",
                                                    "logprob": -11.249626303998173,
                                                    "bytes": [
                                                        67
                                                    ]
                                                },
                                                {
                                                    "token": "E",
                                                    "logprob": -11.466429854718388,
                                                    "bytes": [
                                                        69
                                                    ]
                                                },
                                                {
                                                    "token": "\"A",
                                                    "logprob": -11.571822310773076,
                                                    "bytes": [
                                                        34,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "N",
                                                    "logprob": -11.656345511761845,
                                                    "bytes": [
                                                        78
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -5.022276069012823,
                                    "path_probability": 0.006589511445098379,
                                    "mean_logprob": -5.022276069012823,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.006589511445098379,
                                    "weight": 0.006609854782595108
                                },
                                {
                                    "label": "B",
                                    "description": "No, the statement is false or not established by the state",
                                    "value": 0,
                                    "text": "B",
                                    "tokens": [
                                        {
                                            "token": "B",
                                            "logprob": -0.009714270917119388,
                                            "bytes": [
                                                66
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.009714270917119388,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -5.022276069012823,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -6.277296210614385,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "No",
                                                    "logprob": -9.269586707440556,
                                                    "bytes": [
                                                        78,
                                                        111
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -9.307409430829228,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.347051764813603,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "\"B",
                                                    "logprob": -9.419615889874638,
                                                    "bytes": [
                                                        34,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -9.48721327909583,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "NO",
                                                    "logprob": -9.589577819195927,
                                                    "bytes": [
                                                        78,
                                                        79
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -10.046176101056279,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -10.0799733651554,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -10.155849601117314,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -10.500536109296025,
                                                    "bytes": [
                                                        34
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -10.675232077923955,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -10.688470984784306,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "###",
                                                    "logprob": -10.7110129846012,
                                                    "bytes": [
                                                        35,
                                                        35,
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "C",
                                                    "logprob": -11.249626303998173,
                                                    "bytes": [
                                                        67
                                                    ]
                                                },
                                                {
                                                    "token": "E",
                                                    "logprob": -11.466429854718388,
                                                    "bytes": [
                                                        69
                                                    ]
                                                },
                                                {
                                                    "token": "\"A",
                                                    "logprob": -11.571822310773076,
                                                    "bytes": [
                                                        34,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "N",
                                                    "logprob": -11.656345511761845,
                                                    "bytes": [
                                                        78
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -0.009714270917119388,
                                    "path_probability": 0.9903327601984039,
                                    "mean_logprob": -0.009714270917119388,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.9903327601984039,
                                    "weight": 0.993390145217405
                                }
                            ],
                            "complete": True,
                            "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe patched service passed its tests and returned the expected result.\nQUESTION: Does the report explicitly establish a failure?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                            "winner": "B",
                            "statistics": {
                                "top_weight": 0.993390145217405,
                                "margin": 0.9867802904348099,
                                "peakedness": 0.98678029043481,
                                "entropy_bits": 0.05736747303286044,
                                "expected_score": 0.006609854782595108,
                                "variance": 0.0065661646023481126
                            },
                            "strategy": "one literal-constrained call per label",
                            "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                        }
                    },
                    {
                        "question": "Is verification missing or unknown?",
                        "value": 0.04259040792740307,
                        "measure": {
                            "rows": [
                                {
                                    "label": "A",
                                    "description": "Yes, the statement is supported by the state",
                                    "value": 1,
                                    "text": "A",
                                    "tokens": [
                                        {
                                            "token": "A",
                                            "logprob": -3.158609795493446,
                                            "bytes": [
                                                65
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.046007561606727046,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -3.158609795493446,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -6.532503533286414,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -8.74749701015409,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -8.880060601157508,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.146036553305946,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -10.36314814083036,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "\"B",
                                                    "logprob": -10.462223458213172,
                                                    "bytes": [
                                                        34,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.521854805869422,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -10.540288376731239,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -10.58086054317411,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "###",
                                                    "logprob": -11.2417835473245,
                                                    "bytes": [
                                                        35,
                                                        35,
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -11.553495812339149,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "Y",
                                                    "logprob": -11.676466393393836,
                                                    "bytes": [
                                                        89
                                                    ]
                                                },
                                                {
                                                    "token": "Yes",
                                                    "logprob": -11.754751610678992,
                                                    "bytes": [
                                                        89,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "a",
                                                    "logprob": -11.770782875937781,
                                                    "bytes": [
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": "AA",
                                                    "logprob": -11.773175644797645,
                                                    "bytes": [
                                                        65,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -11.788652825278602,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "State",
                                                    "logprob": -11.836090493125281,
                                                    "bytes": [
                                                        83,
                                                        116,
                                                        97,
                                                        116,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -11.84196894161161,
                                                    "bytes": [
                                                        34
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -3.158609795493446,
                                    "path_probability": 0.04248476255340847,
                                    "mean_logprob": -3.158609795493446,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.04248476255340847,
                                    "weight": 0.04259040792740307
                                },
                                {
                                    "label": "B",
                                    "description": "No, the statement is false or not established by the state",
                                    "value": 0,
                                    "text": "B",
                                    "tokens": [
                                        {
                                            "token": "B",
                                            "logprob": -0.046007561606727046,
                                            "bytes": [
                                                66
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "B",
                                                    "logprob": -0.046007561606727046,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "A",
                                                    "logprob": -3.158609795493446,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -6.532503533286414,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -8.74749701015409,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -8.880060601157508,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.146036553305946,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -10.36314814083036,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "\"B",
                                                    "logprob": -10.462223458213172,
                                                    "bytes": [
                                                        34,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.521854805869422,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -10.540288376731239,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -10.58086054317411,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "###",
                                                    "logprob": -11.2417835473245,
                                                    "bytes": [
                                                        35,
                                                        35,
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -11.553495812339149,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "Y",
                                                    "logprob": -11.676466393393836,
                                                    "bytes": [
                                                        89
                                                    ]
                                                },
                                                {
                                                    "token": "Yes",
                                                    "logprob": -11.754751610678992,
                                                    "bytes": [
                                                        89,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "a",
                                                    "logprob": -11.770782875937781,
                                                    "bytes": [
                                                        97
                                                    ]
                                                },
                                                {
                                                    "token": "AA",
                                                    "logprob": -11.773175644797645,
                                                    "bytes": [
                                                        65,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -11.788652825278602,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "State",
                                                    "logprob": -11.836090493125281,
                                                    "bytes": [
                                                        83,
                                                        116,
                                                        97,
                                                        116,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -11.84196894161161,
                                                    "bytes": [
                                                        34
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -0.046007561606727046,
                                    "path_probability": 0.9550347405662923,
                                    "mean_logprob": -0.046007561606727046,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.9550347405662923,
                                    "weight": 0.9574095920725969
                                }
                            ],
                            "complete": True,
                            "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe patched service passed its tests and returned the expected result.\nQUESTION: Is verification missing or unknown?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                            "winner": "B",
                            "statistics": {
                                "top_weight": 0.9574095920725969,
                                "margin": 0.9148191841451938,
                                "peakedness": 0.9148191841451938,
                                "entropy_bits": 0.2540455865547927,
                                "expected_score": 0.04259040792740307,
                                "variance": 0.04077646507998047
                            },
                            "strategy": "one literal-constrained call per label",
                            "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                        }
                    },
                    {
                        "question": "Does the report establish a successfully verified result?",
                        "value": 0.9490624075592526,
                        "measure": {
                            "rows": [
                                {
                                    "label": "A",
                                    "description": "Yes, the statement is supported by the state",
                                    "value": 1,
                                    "text": "A",
                                    "tokens": [
                                        {
                                            "token": "A",
                                            "logprob": -0.058778369872732515,
                                            "bytes": [
                                                65
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "A",
                                                    "logprob": -0.058778369872732515,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "B",
                                                    "logprob": -2.983651721923514,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -5.6050544624020295,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -7.842610919921561,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -8.076795185058279,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "Yes",
                                                    "logprob": -8.077595317809743,
                                                    "bytes": [
                                                        89,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "YES",
                                                    "logprob": -8.707202518432302,
                                                    "bytes": [
                                                        89,
                                                        69,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -9.020505512206716,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.36953028485076,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -9.405973041503591,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -9.621852481811208,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "\"A",
                                                    "logprob": -9.975631320922536,
                                                    "bytes": [
                                                        34,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "yes",
                                                    "logprob": -10.026671970336599,
                                                    "bytes": [
                                                        121,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -10.03348883435027,
                                                    "bytes": [
                                                        34
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -10.037675464599294,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -10.184905612914724,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "State",
                                                    "logprob": -10.312739932983083,
                                                    "bytes": [
                                                        83,
                                                        116,
                                                        97,
                                                        116,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "STATE",
                                                    "logprob": -10.365019405334158,
                                                    "bytes": [
                                                        83,
                                                        84,
                                                        65,
                                                        84,
                                                        69
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.37147768780486,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "ans",
                                                    "logprob": -10.424087131469411,
                                                    "bytes": [
                                                        97,
                                                        110,
                                                        115
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -0.058778369872732515,
                                    "path_probability": 0.9429157245328719,
                                    "mean_logprob": -0.058778369872732515,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.9429157245328719,
                                    "weight": 0.9490624075592526
                                },
                                {
                                    "label": "B",
                                    "description": "No, the statement is false or not established by the state",
                                    "value": 0,
                                    "text": "B",
                                    "tokens": [
                                        {
                                            "token": "B",
                                            "logprob": -2.983651721923514,
                                            "bytes": [
                                                66
                                            ],
                                            "top_logprobs": [
                                                {
                                                    "token": "A",
                                                    "logprob": -0.058778369872732515,
                                                    "bytes": [
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "B",
                                                    "logprob": -2.983651721923514,
                                                    "bytes": [
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": " A",
                                                    "logprob": -5.6050544624020295,
                                                    "bytes": [
                                                        32,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": " B",
                                                    "logprob": -7.842610919921561,
                                                    "bytes": [
                                                        32,
                                                        66
                                                    ]
                                                },
                                                {
                                                    "token": "ANS",
                                                    "logprob": -8.076795185058279,
                                                    "bytes": [
                                                        65,
                                                        78,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "Yes",
                                                    "logprob": -8.077595317809743,
                                                    "bytes": [
                                                        89,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "YES",
                                                    "logprob": -8.707202518432302,
                                                    "bytes": [
                                                        89,
                                                        69,
                                                        83
                                                    ]
                                                },
                                                {
                                                    "token": "#",
                                                    "logprob": -9.020505512206716,
                                                    "bytes": [
                                                        35
                                                    ]
                                                },
                                                {
                                                    "token": "Answer",
                                                    "logprob": -9.36953028485076,
                                                    "bytes": [
                                                        65,
                                                        110,
                                                        115,
                                                        119,
                                                        101,
                                                        114
                                                    ]
                                                },
                                                {
                                                    "token": "The",
                                                    "logprob": -9.405973041503591,
                                                    "bytes": [
                                                        84,
                                                        104,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "**",
                                                    "logprob": -9.621852481811208,
                                                    "bytes": [
                                                        42,
                                                        42
                                                    ]
                                                },
                                                {
                                                    "token": "\"A",
                                                    "logprob": -9.975631320922536,
                                                    "bytes": [
                                                        34,
                                                        65
                                                    ]
                                                },
                                                {
                                                    "token": "yes",
                                                    "logprob": -10.026671970336599,
                                                    "bytes": [
                                                        121,
                                                        101,
                                                        115
                                                    ]
                                                },
                                                {
                                                    "token": "\"",
                                                    "logprob": -10.03348883435027,
                                                    "bytes": [
                                                        34
                                                    ]
                                                },
                                                {
                                                    "token": "Based",
                                                    "logprob": -10.037675464599294,
                                                    "bytes": [
                                                        66,
                                                        97,
                                                        115,
                                                        101,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "token": "b",
                                                    "logprob": -10.184905612914724,
                                                    "bytes": [
                                                        98
                                                    ]
                                                },
                                                {
                                                    "token": "State",
                                                    "logprob": -10.312739932983083,
                                                    "bytes": [
                                                        83,
                                                        116,
                                                        97,
                                                        116,
                                                        101
                                                    ]
                                                },
                                                {
                                                    "token": "STATE",
                                                    "logprob": -10.365019405334158,
                                                    "bytes": [
                                                        83,
                                                        84,
                                                        65,
                                                        84,
                                                        69
                                                    ]
                                                },
                                                {
                                                    "token": "Let",
                                                    "logprob": -10.37147768780486,
                                                    "bytes": [
                                                        76,
                                                        101,
                                                        116
                                                    ]
                                                },
                                                {
                                                    "token": "ans",
                                                    "logprob": -10.424087131469411,
                                                    "bytes": [
                                                        97,
                                                        110,
                                                        115
                                                    ]
                                                }
                                            ]
                                        }
                                    ],
                                    "token_count": 1,
                                    "logprob": -2.983651721923514,
                                    "path_probability": 0.050607690811132165,
                                    "mean_logprob": -2.983651721923514,
                                    "finish_reason": "stop",
                                    "raw_probability": 0.050607690811132165,
                                    "weight": 0.050937592440747276
                                }
                            ],
                            "complete": True,
                            "prompt": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe patched service passed its tests and returned the expected result.\nQUESTION: Does the report establish a successfully verified result?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace.",
                            "winner": "A",
                            "statistics": {
                                "top_weight": 0.9490624075592526,
                                "margin": 0.8981248151185054,
                                "peakedness": 0.8981248151185053,
                                "entropy_bits": 0.2903665102254617,
                                "expected_score": 0.9490624075592526,
                                "variance": 0.048342954117087604
                            },
                            "strategy": "one literal-constrained call per label",
                            "semantics": "Raw label probabilities renormalized across these exact labels; not calibrated truth probabilities."
                        }
                    }
                ],
                "action": "finish"
            }
        ],
        "semantics": "A semantic measurement vector and a disclosed threshold controller. Correlated probes are never multiplied into a claim of joint confidence."
    },
    "lesson": {
        "question": "Which action follows from these three semantic measurements?",
        "rule": "Apply the same explicit threshold rule to every saved report: inspect, verify, finish, or ask.",
        "knob": "Decision threshold",
        "default": 0.5,
        "compare": 0.999,
        "low": 0,
        "high": 1,
        "integer": False,
        "states": [
            {
                "value": 0.5,
                "summary": "inspect failure → verify → finish.",
                "rows": [
                    {
                        "label": "Fault",
                        "value": 0.9364452525529215
                    },
                    {
                        "label": "Missing check",
                        "value": 0.45878248351927964
                    },
                    {
                        "label": "Verified",
                        "value": 0.003560901259834583
                    }
                ],
                "unit": "weight",
                "metrics": {
                    "actions": [
                        "inspect failure",
                        "verify",
                        "finish"
                    ],
                    "vectors": [
                        [
                            0.9364452525529215,
                            0.45878248351927964,
                            0.003560901259834583
                        ],
                        [
                            0.007086704885642036,
                            0.8743398386494632,
                            0.004085117968614182
                        ],
                        [
                            0.006609854782595106,
                            0.04259040792740307,
                            0.9490624075592526
                        ]
                    ]
                },
                "note": "Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability."
            },
            {
                "value": 0.999,
                "summary": "ask → ask → ask.",
                "rows": [
                    {
                        "label": "Fault",
                        "value": 0.9364452525529215
                    },
                    {
                        "label": "Missing check",
                        "value": 0.45878248351927964
                    },
                    {
                        "label": "Verified",
                        "value": 0.003560901259834583
                    }
                ],
                "unit": "weight",
                "metrics": {
                    "actions": [
                        "ask",
                        "ask",
                        "ask"
                    ],
                    "vectors": [
                        [
                            0.9364452525529215,
                            0.45878248351927964,
                            0.003560901259834583
                        ],
                        [
                            0.007086704885642036,
                            0.8743398386494632,
                            0.004085117968614182
                        ],
                        [
                            0.006609854782595106,
                            0.04259040792740307,
                            0.9490624075592526
                        ]
                    ]
                },
                "note": "Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability."
            }
        ],
        "input_excerpt": "",
        "scope": "This panel and its Python calculation reproduce saved measurements. Other page controls are independent views."
    },
    "receipt": {
        "mode": "recorded",
        "requests": 18,
        "summed_request_ms": 10351.263100106735,
        "prompt_tokens": 1800,
        "completion_tokens": 36,
        "calls": [
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe request timed out. The connection closed. No successful result was returned.\nQUESTION: Does the report explicitly establish a failure?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-2dfbfec9b5b34e229638e893",
                    "object": "chat.completion",
                    "created": 1791082308,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.068473380434915,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.068473380434915,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.7586627420071808,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -6.624163192141458,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.336677115786477,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.37905077301304,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.302680533755227,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.653117698061868,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.911531012881204,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.197306197512551,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -10.287832778323098,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.317467254031106,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Option",
                                                "logprob": -10.395311873782083,
                                                "bytes": [
                                                    79,
                                                    112,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.531213324892923,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.560077231753274,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.610461753237649,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -11.00886968933384,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.124192756045266,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -11.453502219546243,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -11.518188041079446,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "answer",
                                                "logprob": -11.54788736664097,
                                                "bytes": [
                                                    97,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 101,
                        "completion_tokens": 2,
                        "total_tokens": 103,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 101,
                        "prompt_ms": 848.7,
                        "prompt_per_token_ms": 8.403,
                        "prompt_per_second": 119,
                        "predicted_n": 2,
                        "predicted_ms": 79,
                        "predicted_per_token_ms": 39.5,
                        "predicted_per_second": 25.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 952.5738999946043,
                "captured_at": "2026-10-04T02:51:50Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe request timed out. The connection closed. No successful result was returned.\nQUESTION: Does the report explicitly establish a failure?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-84b447c8892f4403bc136b60",
                    "object": "chat.completion",
                    "created": 1791082309,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -2.7586627420071808,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.068473380434915,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.7586627420071808,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -6.624163192141458,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.336677115786477,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.37905077301304,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.302680533755227,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.653117698061868,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.911531012881204,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.197306197512551,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -10.287832778323098,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.317467254031106,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Option",
                                                "logprob": -10.395311873782083,
                                                "bytes": [
                                                    79,
                                                    112,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.531213324892923,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.560077231753274,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.610461753237649,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -11.00886968933384,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.124192756045266,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -11.453502219546243,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -11.518188041079446,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "answer",
                                                "logprob": -11.54788736664097,
                                                "bytes": [
                                                    97,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 101,
                        "completion_tokens": 2,
                        "total_tokens": 103,
                        "prompt_tokens_details": {
                            "cached_tokens": 94
                        }
                    },
                    "timings": {
                        "cache_n": 94,
                        "prompt_n": 7,
                        "prompt_ms": 207.9,
                        "prompt_per_token_ms": 29.7,
                        "prompt_per_second": 33.7,
                        "predicted_n": 2,
                        "predicted_ms": 57.8,
                        "predicted_per_token_ms": 28.9,
                        "predicted_per_second": 34.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 288.53720001643524,
                "captured_at": "2026-10-04T02:51:50Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe request timed out. The connection closed. No successful result was returned.\nQUESTION: Is verification missing or unknown?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-c48bca785ccf41ce971306f7",
                    "object": "chat.completion",
                    "created": 1791082310,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.7831351734611951,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.6178901173088513,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -0.7831351734611951,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.5133788563225234,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.695231197020766,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.166902301451918,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.516173122069594,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -8.746756312987563,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.848210094115492,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.155091045043227,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.664495227477309,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -10.062144992491957,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.130414722106215,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.176644084594008,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.186129329344984,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.193773982665297,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -10.209724185607191,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.25495695843434,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -10.26111864819264,
                                                "bytes": None
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.297484157225844,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -10.341414210936781,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 99,
                        "completion_tokens": 2,
                        "total_tokens": 101,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 99,
                        "prompt_ms": 767.4,
                        "prompt_per_token_ms": 7.752,
                        "prompt_per_second": 129,
                        "predicted_n": 2,
                        "predicted_ms": 71.1,
                        "predicted_per_token_ms": 35.55,
                        "predicted_per_second": 28.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 854.5202999957837,
                "captured_at": "2026-10-04T02:51:51Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe request timed out. The connection closed. No successful result was returned.\nQUESTION: Is verification missing or unknown?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-5d6695a8803542fbb392c693",
                    "object": "chat.completion",
                    "created": 1791082311,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.6178901173088513,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.6178901173088513,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -0.7831351734611951,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.5133788563225234,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -7.695231197020766,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.166902301451918,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -8.516173122069594,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -8.746756312987563,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -8.848210094115492,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.155091045043227,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.664495227477309,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -10.062144992491957,
                                                "bytes": [
                                                    73
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.130414722106215,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.176644084594008,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.186129329344984,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.193773982665297,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -10.209724185607191,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.25495695843434,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "<|im_end|>",
                                                "logprob": -10.26111864819264,
                                                "bytes": None
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.297484157225844,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -10.341414210936781,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 99,
                        "completion_tokens": 2,
                        "total_tokens": 101,
                        "prompt_tokens_details": {
                            "cached_tokens": 92
                        }
                    },
                    "timings": {
                        "cache_n": 92,
                        "prompt_n": 7,
                        "prompt_ms": 182.9,
                        "prompt_per_token_ms": 26.129,
                        "prompt_per_second": 38.3,
                        "predicted_n": 2,
                        "predicted_ms": 63.8,
                        "predicted_per_token_ms": 31.9,
                        "predicted_per_second": 31.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 278.3122999826446,
                "captured_at": "2026-10-04T02:51:51Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe request timed out. The connection closed. No successful result was returned.\nQUESTION: Does the report establish a successfully verified result?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-56dc7c240a1347a68425456c",
                    "object": "chat.completion",
                    "created": 1791082311,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -5.640049548081963,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.005875201158134761,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -5.640049548081963,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.084914774827569,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -8.842232317857354,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -8.885855288438409,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.112585635118096,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.115502924851983,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.390670390061944,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.490211100511162,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.565073580674737,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -9.636417956285088,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.162175745896905,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -10.250456423692315,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.814983935288994,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Option",
                                                "logprob": -11.20122870915374,
                                                "bytes": [
                                                    79,
                                                    112,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -11.306643099717705,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "answer",
                                                "logprob": -11.354361147813409,
                                                "bytes": [
                                                    97,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": ".B",
                                                "logprob": -11.4638868283554,
                                                "bytes": [
                                                    46,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -11.642889590196221,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -11.709917635850518,
                                                "bytes": [
                                                    73
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 102,
                        "completion_tokens": 2,
                        "total_tokens": 104,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 102,
                        "prompt_ms": 807.4,
                        "prompt_per_token_ms": 7.916,
                        "prompt_per_second": 126.3,
                        "predicted_n": 2,
                        "predicted_ms": 64.4,
                        "predicted_per_token_ms": 32.2,
                        "predicted_per_second": 31.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 897.2824000520632,
                "captured_at": "2026-10-04T02:51:52Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe request timed out. The connection closed. No successful result was returned.\nQUESTION: Does the report establish a successfully verified result?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-04671e34e617482795744fbf",
                    "object": "chat.completion",
                    "created": 1791082312,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.005875201158134761,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.005875201158134761,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -5.640049548081963,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.084914774827569,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -8.842232317857354,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -8.885855288438409,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.112585635118096,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.115502924851983,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.390670390061944,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.490211100511162,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.565073580674737,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -9.636417956285088,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.162175745896905,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -10.250456423692315,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.814983935288994,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Option",
                                                "logprob": -11.20122870915374,
                                                "bytes": [
                                                    79,
                                                    112,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -11.306643099717705,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "answer",
                                                "logprob": -11.354361147813409,
                                                "bytes": [
                                                    97,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": ".B",
                                                "logprob": -11.4638868283554,
                                                "bytes": [
                                                    46,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -11.642889590196221,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "I",
                                                "logprob": -11.709917635850518,
                                                "bytes": [
                                                    73
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 102,
                        "completion_tokens": 2,
                        "total_tokens": 104,
                        "prompt_tokens_details": {
                            "cached_tokens": 95
                        }
                    },
                    "timings": {
                        "cache_n": 95,
                        "prompt_n": 7,
                        "prompt_ms": 209.7,
                        "prompt_per_token_ms": 29.957,
                        "prompt_per_second": 33.4,
                        "predicted_n": 2,
                        "predicted_ms": 69.3,
                        "predicted_per_token_ms": 34.65,
                        "predicted_per_second": 28.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 291.19150002952665,
                "captured_at": "2026-10-04T02:51:53Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nA patch was applied. No test has run. The deployment status is unknown.\nQUESTION: Does the report explicitly establish a failure?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-5b413a55dce7489bb2a8af6f",
                    "object": "chat.completion",
                    "created": 1791082312,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -4.950335502686561,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.007912635865271432,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.950335502686561,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.643431663575232,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.741835594239294,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.029411315980017,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.346127510132849,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -10.596807479920447,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.668852806153357,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.875729560914099,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.944958686890661,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.96589660650736,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -11.139475822510779,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.45758533483988,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -11.682606697144568,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Does",
                                                "logprob": -11.763769149842322,
                                                "bytes": [
                                                    68,
                                                    111,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -11.843193054261267,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -11.860097885193884,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -11.881146431031286,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -11.932911872925818,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -12.062716484131872,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 102,
                        "completion_tokens": 2,
                        "total_tokens": 104,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 102,
                        "prompt_ms": 826.9,
                        "prompt_per_token_ms": 8.107,
                        "prompt_per_second": 123.4,
                        "predicted_n": 2,
                        "predicted_ms": 65.4,
                        "predicted_per_token_ms": 32.7,
                        "predicted_per_second": 30.6,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 909.8569999914616,
                "captured_at": "2026-10-04T02:51:54Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nA patch was applied. No test has run. The deployment status is unknown.\nQUESTION: Does the report explicitly establish a failure?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-78695086a8734c3d908d40fd",
                    "object": "chat.completion",
                    "created": 1791082313,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.007912635865271432,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.007912635865271432,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -4.950335502686561,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -8.643431663575232,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.741835594239294,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.029411315980017,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -10.346127510132849,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -10.596807479920447,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.668852806153357,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.875729560914099,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.944958686890661,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.96589660650736,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -11.139475822510779,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -11.45758533483988,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -11.682606697144568,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Does",
                                                "logprob": -11.763769149842322,
                                                "bytes": [
                                                    68,
                                                    111,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "Question",
                                                "logprob": -11.843193054261267,
                                                "bytes": [
                                                    81,
                                                    117,
                                                    101,
                                                    115,
                                                    116,
                                                    105,
                                                    111,
                                                    110
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -11.860097885193884,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -11.881146431031286,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -11.932911872925818,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -12.062716484131872,
                                                "bytes": [
                                                    89
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 102,
                        "completion_tokens": 2,
                        "total_tokens": 104,
                        "prompt_tokens_details": {
                            "cached_tokens": 95
                        }
                    },
                    "timings": {
                        "cache_n": 95,
                        "prompt_n": 7,
                        "prompt_ms": 197.9,
                        "prompt_per_token_ms": 28.271,
                        "prompt_per_second": 35.4,
                        "predicted_n": 2,
                        "predicted_ms": 62.6,
                        "predicted_per_token_ms": 31.3,
                        "predicted_per_second": 31.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 274.4041999685578,
                "captured_at": "2026-10-04T02:51:54Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nA patch was applied. No test has run. The deployment status is unknown.\nQUESTION: Is verification missing or unknown?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-97acbd88b3cc4ba29c3383fd",
                    "object": "chat.completion",
                    "created": 1791082313,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.13574878732783802,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.13574878732783802,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.0756367878161193,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.965496941014361,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.11793129007442,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -9.319786949559283,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.770342750950885,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.913227005406451,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.917073173924518,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.225748939915729,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.317932053013873,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -10.357301636143756,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -10.366629524632526,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.537531776829791,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.622210426732135,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.68824379007442,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.843513412877154,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -10.90693561594112,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.955987854405475,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.976818962498736,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -11.169295235081744,
                                                "bytes": [
                                                    88
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 100,
                        "completion_tokens": 2,
                        "total_tokens": 102,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 100,
                        "prompt_ms": 779.1,
                        "prompt_per_token_ms": 7.791,
                        "prompt_per_second": 128.4,
                        "predicted_n": 2,
                        "predicted_ms": 60.6,
                        "predicted_per_token_ms": 30.3,
                        "predicted_per_second": 33,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 869.402899988927,
                "captured_at": "2026-10-04T02:51:55Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nA patch was applied. No test has run. The deployment status is unknown.\nQUESTION: Is verification missing or unknown?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-52c0d00e4c6d4117ac2c9d47",
                    "object": "chat.completion",
                    "created": 1791082314,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -2.0756367878161193,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.13574878732783802,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.0756367878161193,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.965496941014361,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -9.11793129007442,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -9.319786949559283,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -9.770342750950885,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.913227005406451,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.917073173924518,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.225748939915729,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.317932053013873,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -10.357301636143756,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -10.366629524632526,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -10.537531776829791,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.622210426732135,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -10.68824379007442,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -10.843513412877154,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "```",
                                                "logprob": -10.90693561594112,
                                                "bytes": [
                                                    96,
                                                    96,
                                                    96
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.955987854405475,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.976818962498736,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "X",
                                                "logprob": -11.169295235081744,
                                                "bytes": [
                                                    88
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 100,
                        "completion_tokens": 2,
                        "total_tokens": 102,
                        "prompt_tokens_details": {
                            "cached_tokens": 93
                        }
                    },
                    "timings": {
                        "cache_n": 93,
                        "prompt_n": 7,
                        "prompt_ms": 196.6,
                        "prompt_per_token_ms": 28.086,
                        "prompt_per_second": 35.6,
                        "predicted_n": 2,
                        "predicted_ms": 56.6,
                        "predicted_per_token_ms": 28.3,
                        "predicted_per_second": 35.3,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 283.84040005039424,
                "captured_at": "2026-10-04T02:51:55Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nA patch was applied. No test has run. The deployment status is unknown.\nQUESTION: Does the report establish a successfully verified result?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-b96906a4ff6e4ae7b9149ad9",
                    "object": "chat.completion",
                    "created": 1791082314,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -5.502709861273331,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.006398673529190272,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -5.502709861273331,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.766341681952042,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.152915473455948,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.341628547186417,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -9.428332801336808,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.430854316229386,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -9.714498992437882,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.03233861493544,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.067658896917862,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.437202926153702,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.453065391058487,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.458833213324112,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.656481261724991,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.855013366217179,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.913473601812882,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Does",
                                                "logprob": -11.152650351995987,
                                                "bytes": [
                                                    68,
                                                    111,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "answer",
                                                "logprob": -11.155641074652237,
                                                "bytes": [
                                                    97,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -11.267261977667374,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "What",
                                                "logprob": -11.50784253644423,
                                                "bytes": [
                                                    87,
                                                    104,
                                                    97,
                                                    116
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 103,
                        "completion_tokens": 2,
                        "total_tokens": 105,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 103,
                        "prompt_ms": 756.7,
                        "prompt_per_token_ms": 7.347,
                        "prompt_per_second": 136.1,
                        "predicted_n": 2,
                        "predicted_ms": 58.2,
                        "predicted_per_token_ms": 29.1,
                        "predicted_per_second": 34.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 827.0733000244945,
                "captured_at": "2026-10-04T02:51:56Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nA patch was applied. No test has run. The deployment status is unknown.\nQUESTION: Does the report establish a successfully verified result?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-e94670474f5b49d98260f5d3",
                    "object": "chat.completion",
                    "created": 1791082315,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.006398673529190272,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.006398673529190272,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -5.502709861273331,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.766341681952042,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.152915473455948,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -9.341628547186417,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -9.428332801336808,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.430854316229386,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -9.714498992437882,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -10.03233861493544,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.067658896917862,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.437202926153702,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -10.453065391058487,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.458833213324112,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.656481261724991,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.855013366217179,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.913473601812882,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "Does",
                                                "logprob": -11.152650351995987,
                                                "bytes": [
                                                    68,
                                                    111,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "answer",
                                                "logprob": -11.155641074652237,
                                                "bytes": [
                                                    97,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -11.267261977667374,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "What",
                                                "logprob": -11.50784253644423,
                                                "bytes": [
                                                    87,
                                                    104,
                                                    97,
                                                    116
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 103,
                        "completion_tokens": 2,
                        "total_tokens": 105,
                        "prompt_tokens_details": {
                            "cached_tokens": 96
                        }
                    },
                    "timings": {
                        "cache_n": 96,
                        "prompt_n": 7,
                        "prompt_ms": 196.5,
                        "prompt_per_token_ms": 28.071,
                        "prompt_per_second": 35.6,
                        "predicted_n": 2,
                        "predicted_ms": 60.7,
                        "predicted_per_token_ms": 30.35,
                        "predicted_per_second": 32.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 275.0705999787897,
                "captured_at": "2026-10-04T02:51:56Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe patched service passed its tests and returned the expected result.\nQUESTION: Does the report explicitly establish a failure?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-04b14fb0b3a04d8a86937fe3",
                    "object": "chat.completion",
                    "created": 1791082316,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -5.022276069012823,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.009714270917119388,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -5.022276069012823,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.277296210614385,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.269586707440556,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.307409430829228,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.347051764813603,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -9.419615889874638,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.48721327909583,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -9.589577819195927,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.046176101056279,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.0799733651554,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.155849601117314,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -10.500536109296025,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.675232077923955,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.688470984784306,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -10.7110129846012,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -11.249626303998173,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -11.466429854718388,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -11.571822310773076,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.656345511761845,
                                                "bytes": [
                                                    78
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 98,
                        "completion_tokens": 2,
                        "total_tokens": 100,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 98,
                        "prompt_ms": 744.9,
                        "prompt_per_token_ms": 7.601,
                        "prompt_per_second": 131.6,
                        "predicted_n": 2,
                        "predicted_ms": 62.6,
                        "predicted_per_token_ms": 31.3,
                        "predicted_per_second": 31.9,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 844.461600005161,
                "captured_at": "2026-10-04T02:51:57Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe patched service passed its tests and returned the expected result.\nQUESTION: Does the report explicitly establish a failure?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-2be9b2aaa6e547ecb6682b5d",
                    "object": "chat.completion",
                    "created": 1791082316,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.009714270917119388,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.009714270917119388,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -5.022276069012823,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.277296210614385,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "No",
                                                "logprob": -9.269586707440556,
                                                "bytes": [
                                                    78,
                                                    111
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -9.307409430829228,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.347051764813603,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -9.419615889874638,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -9.48721327909583,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "NO",
                                                "logprob": -9.589577819195927,
                                                "bytes": [
                                                    78,
                                                    79
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.046176101056279,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -10.0799733651554,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -10.155849601117314,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -10.500536109296025,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.675232077923955,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.688470984784306,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -10.7110129846012,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "C",
                                                "logprob": -11.249626303998173,
                                                "bytes": [
                                                    67
                                                ]
                                            },
                                            {
                                                "token": "E",
                                                "logprob": -11.466429854718388,
                                                "bytes": [
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -11.571822310773076,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "N",
                                                "logprob": -11.656345511761845,
                                                "bytes": [
                                                    78
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 98,
                        "completion_tokens": 2,
                        "total_tokens": 100,
                        "prompt_tokens_details": {
                            "cached_tokens": 91
                        }
                    },
                    "timings": {
                        "cache_n": 91,
                        "prompt_n": 7,
                        "prompt_ms": 217.1,
                        "prompt_per_token_ms": 31.014,
                        "prompt_per_second": 32.2,
                        "predicted_n": 2,
                        "predicted_ms": 66.5,
                        "predicted_per_token_ms": 33.25,
                        "predicted_per_second": 30.1,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 295.6702999654226,
                "captured_at": "2026-10-04T02:51:57Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe patched service passed its tests and returned the expected result.\nQUESTION: Is verification missing or unknown?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-9362a7c6df134eee8720c4b5",
                    "object": "chat.completion",
                    "created": 1791082317,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -3.158609795493446,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.046007561606727046,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.158609795493446,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.532503533286414,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -8.74749701015409,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.880060601157508,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.146036553305946,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.36314814083036,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.462223458213172,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.521854805869422,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.540288376731239,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.58086054317411,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -11.2417835473245,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -11.553495812339149,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.676466393393836,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -11.754751610678992,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.770782875937781,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -11.773175644797645,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -11.788652825278602,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -11.836090493125281,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -11.84196894161161,
                                                "bytes": [
                                                    34
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 96,
                        "completion_tokens": 2,
                        "total_tokens": 98,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 96,
                        "prompt_ms": 740.1,
                        "prompt_per_token_ms": 7.709,
                        "prompt_per_second": 129.7,
                        "predicted_n": 2,
                        "predicted_ms": 64.9,
                        "predicted_per_token_ms": 32.45,
                        "predicted_per_second": 30.8,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 822.4131000461057,
                "captured_at": "2026-10-04T02:51:58Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe patched service passed its tests and returned the expected result.\nQUESTION: Is verification missing or unknown?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-4333ac1824a243dc860217aa",
                    "object": "chat.completion",
                    "created": 1791082318,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -0.046007561606727046,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "B",
                                                "logprob": -0.046007561606727046,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "A",
                                                "logprob": -3.158609795493446,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -6.532503533286414,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -8.74749701015409,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -8.880060601157508,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.146036553305946,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -10.36314814083036,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "\"B",
                                                "logprob": -10.462223458213172,
                                                "bytes": [
                                                    34,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.521854805869422,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -10.540288376731239,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -10.58086054317411,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "###",
                                                "logprob": -11.2417835473245,
                                                "bytes": [
                                                    35,
                                                    35,
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -11.553495812339149,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "Y",
                                                "logprob": -11.676466393393836,
                                                "bytes": [
                                                    89
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -11.754751610678992,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "a",
                                                "logprob": -11.770782875937781,
                                                "bytes": [
                                                    97
                                                ]
                                            },
                                            {
                                                "token": "AA",
                                                "logprob": -11.773175644797645,
                                                "bytes": [
                                                    65,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -11.788652825278602,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -11.836090493125281,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -11.84196894161161,
                                                "bytes": [
                                                    34
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 96,
                        "completion_tokens": 2,
                        "total_tokens": 98,
                        "prompt_tokens_details": {
                            "cached_tokens": 89
                        }
                    },
                    "timings": {
                        "cache_n": 89,
                        "prompt_n": 7,
                        "prompt_ms": 200,
                        "prompt_per_token_ms": 28.571,
                        "prompt_per_second": 35,
                        "predicted_n": 2,
                        "predicted_ms": 61.1,
                        "predicted_per_token_ms": 30.55,
                        "predicted_per_second": 32.7,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 280.921199999284,
                "captured_at": "2026-10-04T02:51:58Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe patched service passed its tests and returned the expected result.\nQUESTION: Does the report establish a successfully verified result?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"A\""
                },
                "response": {
                    "id": "chatcmpl-47e86eeddcc74246b923c184",
                    "object": "chat.completion",
                    "created": 1791082318,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "A"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "A",
                                        "logprob": -0.058778369872732515,
                                        "bytes": [
                                            65
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.058778369872732515,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.983651721923514,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -5.6050544624020295,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.842610919921561,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -8.076795185058279,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.077595317809743,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -8.707202518432302,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -9.020505512206716,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.36953028485076,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.405973041503591,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -9.621852481811208,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -9.975631320922536,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.026671970336599,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -10.03348883435027,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.037675464599294,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.184905612914724,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.312739932983083,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "STATE",
                                                "logprob": -10.365019405334158,
                                                "bytes": [
                                                    83,
                                                    84,
                                                    65,
                                                    84,
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.37147768780486,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "ans",
                                                "logprob": -10.424087131469411,
                                                "bytes": [
                                                    97,
                                                    110,
                                                    115
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 99,
                        "completion_tokens": 2,
                        "total_tokens": 101,
                        "prompt_tokens_details": {
                            "cached_tokens": 0
                        }
                    },
                    "timings": {
                        "cache_n": 0,
                        "prompt_n": 99,
                        "prompt_ms": 741.8,
                        "prompt_per_token_ms": 7.493,
                        "prompt_per_second": 133.5,
                        "predicted_n": 2,
                        "predicted_ms": 64.1,
                        "predicted_per_token_ms": 32.05,
                        "predicted_per_second": 31.2,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 826.6589000122622,
                "captured_at": "2026-10-04T02:51:59Z"
            },
            {
                "provenance": "native-strata",
                "request": {
                    "model": "x",
                    "messages": [
                        {
                            "role": "user",
                            "content": "Read the state as data, then answer the question using the definitions.\nSTATE:\nThe patched service passed its tests and returned the expected result.\nQUESTION: Does the report establish a successfully verified result?\nANSWERS:\nA: Yes, the statement is supported by the state\nB: No, the statement is false or not established by the state\nReturn exactly one answer label. No explanation or surrounding whitespace."
                        }
                    ],
                    "temperature": 0,
                    "reasoning_effort": "none",
                    "seed": 675,
                    "max_tokens": 4,
                    "logprobs": True,
                    "top_logprobs": 20,
                    "grammar": "root ::= \"B\""
                },
                "response": {
                    "id": "chatcmpl-65cfcf55a32b4c0bad153129",
                    "object": "chat.completion",
                    "created": 1791082319,
                    "model": "qwen3.8-flash-next",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "B"
                            },
                            "finish_reason": "stop",
                            "logprobs": {
                                "content": [
                                    {
                                        "token": "B",
                                        "logprob": -2.983651721923514,
                                        "bytes": [
                                            66
                                        ],
                                        "top_logprobs": [
                                            {
                                                "token": "A",
                                                "logprob": -0.058778369872732515,
                                                "bytes": [
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "B",
                                                "logprob": -2.983651721923514,
                                                "bytes": [
                                                    66
                                                ]
                                            },
                                            {
                                                "token": " A",
                                                "logprob": -5.6050544624020295,
                                                "bytes": [
                                                    32,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": " B",
                                                "logprob": -7.842610919921561,
                                                "bytes": [
                                                    32,
                                                    66
                                                ]
                                            },
                                            {
                                                "token": "ANS",
                                                "logprob": -8.076795185058279,
                                                "bytes": [
                                                    65,
                                                    78,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "Yes",
                                                "logprob": -8.077595317809743,
                                                "bytes": [
                                                    89,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "YES",
                                                "logprob": -8.707202518432302,
                                                "bytes": [
                                                    89,
                                                    69,
                                                    83
                                                ]
                                            },
                                            {
                                                "token": "#",
                                                "logprob": -9.020505512206716,
                                                "bytes": [
                                                    35
                                                ]
                                            },
                                            {
                                                "token": "Answer",
                                                "logprob": -9.36953028485076,
                                                "bytes": [
                                                    65,
                                                    110,
                                                    115,
                                                    119,
                                                    101,
                                                    114
                                                ]
                                            },
                                            {
                                                "token": "The",
                                                "logprob": -9.405973041503591,
                                                "bytes": [
                                                    84,
                                                    104,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "**",
                                                "logprob": -9.621852481811208,
                                                "bytes": [
                                                    42,
                                                    42
                                                ]
                                            },
                                            {
                                                "token": "\"A",
                                                "logprob": -9.975631320922536,
                                                "bytes": [
                                                    34,
                                                    65
                                                ]
                                            },
                                            {
                                                "token": "yes",
                                                "logprob": -10.026671970336599,
                                                "bytes": [
                                                    121,
                                                    101,
                                                    115
                                                ]
                                            },
                                            {
                                                "token": "\"",
                                                "logprob": -10.03348883435027,
                                                "bytes": [
                                                    34
                                                ]
                                            },
                                            {
                                                "token": "Based",
                                                "logprob": -10.037675464599294,
                                                "bytes": [
                                                    66,
                                                    97,
                                                    115,
                                                    101,
                                                    100
                                                ]
                                            },
                                            {
                                                "token": "b",
                                                "logprob": -10.184905612914724,
                                                "bytes": [
                                                    98
                                                ]
                                            },
                                            {
                                                "token": "State",
                                                "logprob": -10.312739932983083,
                                                "bytes": [
                                                    83,
                                                    116,
                                                    97,
                                                    116,
                                                    101
                                                ]
                                            },
                                            {
                                                "token": "STATE",
                                                "logprob": -10.365019405334158,
                                                "bytes": [
                                                    83,
                                                    84,
                                                    65,
                                                    84,
                                                    69
                                                ]
                                            },
                                            {
                                                "token": "Let",
                                                "logprob": -10.37147768780486,
                                                "bytes": [
                                                    76,
                                                    101,
                                                    116
                                                ]
                                            },
                                            {
                                                "token": "ans",
                                                "logprob": -10.424087131469411,
                                                "bytes": [
                                                    97,
                                                    110,
                                                    115
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "refusal": None
                            }
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 99,
                        "completion_tokens": 2,
                        "total_tokens": 101,
                        "prompt_tokens_details": {
                            "cached_tokens": 92
                        }
                    },
                    "timings": {
                        "cache_n": 92,
                        "prompt_n": 7,
                        "prompt_ms": 211.4,
                        "prompt_per_token_ms": 30.2,
                        "prompt_per_second": 33.1,
                        "predicted_n": 2,
                        "predicted_ms": 56.5,
                        "predicted_per_token_ms": 28.25,
                        "predicted_per_second": 35.4,
                        "draft_n": 0,
                        "draft_n_accepted": 0
                    }
                },
                "chunks": [],
                "wall_ms": 279.0720000048168,
                "captured_at": "2026-10-04T02:51:59Z"
            }
        ]
    },
    "wall_ms": 143.48069997504354,
    "lesson_view": {
        "index": 0,
        "value": 0.5,
        "scope": "Reproduce the selected question/rule/result panel. Other page dials are independent."
    }
}
import argparse
import copy
import hashlib
import json
import math
import os
import sys
from pathlib import Path
import urllib.error
import urllib.request

"""Small, portable calculations behind the question/rule/result panels.

Standard library only. This exact source is included in every Python download.
Inputs are the captured experiment, never an invented new model response. A knob
changes a disclosed calculation on those inputs; it does not rescore a new prompt.
"""
import itertools
import math
import statistics


def _spec(question, rule, knob, default, compare, low, high, integer=False):
    return dict(question=question, rule=rule, knob=knob, default=default,
                compare=compare, low=low, high=high, integer=integer)


LESSON_SPECS = {
    'choice': _spec('Which ticket queue gets this message?', 'Compare the three saved label scores. Heat flattens their relative weights; it adds no evidence.', 'Reweighting temperature', 1, 2, .1, 3),
    'boolean': _spec('Does this message ask to cancel?', 'Normalize the saved Yes and No scores. A number near one is a strong preference, not proof.', 'Reweighting temperature', 1, 2, .1, 3),
    'score': _spec('How serious is the outage?', 'Multiply each rubric value by its answer weight, then add. The rating comes from the whole distribution.', 'Reweighting temperature', 1, 2, .1, 3),
    'candidates': _spec('Read the failure first, or start changing things?', 'Add token logprobs along each saved path, then sum path mass inside each finite group. A length penalty changes the objective.', 'Length penalty exponent', 0, 1, 0, 1),
    'controller': _spec('May the simulated repair take its next step?', 'Keep only state-legal actions. Hold the recorded action if its relative legal weight falls below the threshold.', 'Required legal-action weight', 0, .999, 0, 1),
    'rerank': _spec('Which sources help explain cancellation?', 'Compute each source’s expected relevance separately, then keep those above the cutoff.', 'Minimum relevance', 0, .9, 0, 1),
    'graph': _spec('Which text links can coexist?', 'Search every small edge subset. Reject cycles and competing attachments, then maximize useful edge weight.', 'Edge cost / threshold', .5, .9, .01, .99),
    'scene': _spec('Which valid drawing best fits the instruction?', 'Average the three saved text probes. Optionally charge for disagreement between them; code still checks geometry.', 'Disagreement penalty', 0, 1, 0, 2),
    'wire': _spec('What did the model assign to this actual token?', 'Exponentiate its raw logprob. Sum only the reported alternatives; their top-N list may omit probability mass.', 'Visible token index (zero-based)', 0, 5, 0, 10000, True),
    'speculation': _spec('Why can a draft be rejected?', 'Compare the proposal head and target verification on the same proposed token. They are different distributions.', 'Proposal position (zero-based)', 0, 2, 0, 10000, True),
    'performance': _spec('What did each API path cost on this setup?', 'Recalculate a latency percentile from the original wall-time samples. Different output tasks remain separate.', 'Latency percentile', 50, 90, 0, 100),
    'samplers': _spec('How much did this recipe change the selected token’s weight?', 'Compare its raw target probability with its post-sampler probability. Read support and entropy from the complete native row.', 'Recorded recipe index (zero-based)', 0, 1, 0, 10000, True),
    'sampler-sandbox': _spec('Can we add heat without admitting implausible tokens?', 'Remove logits below max + log(0.05), then divide the survivors by temperature and normalize.', 'Temperature after Min-P', 1.5, .7, .1, 3),
    'tictactoe': _spec('Did a legal move give away a winnable outcome?', 'Solve the saved position by exhaustive minimax. Compare the best legal outcome with the recorded model move.', 'Recorded turn index (zero-based)', 0, 1, 0, 10000, True),
    'chess': _spec('Did the shortlist favor a mating move?', 'Add the saved label weights attached to code-checked mating moves. The separately generated UCI move uses a different prompt.', 'Shortlist temperature', 1, 3, .1, 3),
    'poker': _spec('Should this hand check or bet?', 'Average exact chip payoffs over the two possible opponent cards using the stated calling policy.', 'Opponent call-rate multiplier', 1, 0, 0, 2),
    'thermal': _spec('What happens if we replay the fan commands differently?', 'Step the disclosed thermal equation through the same loads. A fan offset is an open-loop counterfactual, not a new model policy.', 'Fan offset', 0, 20, -60, 60),
    'scheduler': _spec('How much lateness did this legal schedule cause?', 'Add job durations in the recorded order and check dependencies. Charge for finishing after the adjusted deadline.', 'Deadline shift', 0, -3, -10, 10),
    'context': _spec('Did replacing old text change the current-state answer?', 'Recalculate each saved Yes/No distribution and compare the selected wording with the original append-only prompt.', 'Context variant index (zero-based)', 0, 2, 0, 10000, True),
    'observer': _spec('Which action follows from these three semantic measurements?', 'Apply the same explicit threshold rule to every saved report: inspect, verify, finish, or ask.', 'Decision threshold', .5, .999, 0, 1),
    'calibration': _spec('Does demanding stronger answers leave enough coverage?', 'Recalculate Brier error on all six examples and accuracy only on retained examples. Empty coverage has no accuracy.', 'Required answer weight', .5, 1, .5, 1),
    'information': _spec('Which observation is worth buying?', 'Use the stated sensor likelihoods to compute both Bayesian posteriors and expected entropy reduction.', 'Test index (zero-based)', 0, 1, 0, 10000, True),
    'search': _spec('Which valid scene survives a cost penalty?', 'Subtract the chosen cost charge from each saved semantic weight. Reject invalid geometry before ranking.', 'Cost weight', .1, 1, 0, 1),
    'frontier': _spec('Would faster score transfer matter here?', 'Add assumed forward time, a transfer lower bound, and the measured selector. This is a serial cost sketch.', 'Assumed transfer GB/s', 12, 2, .1, 128),
    'research-map': _spec('What would make this research idea testable?', 'Count the disclosed implementation categories, then reveal one branch’s next gate. A proposal is not a native result.', 'Branch index (zero-based)', 0, 12, 0, 10000, True),
    'pressure': _spec('How much original mass did this boundary throw away?', 'At temperature 1 with pure masking, log Z = raw selected logprob − log(selected masked probability). Pressure is −log Z.', 'Native grammar index (zero-based)', 0, 1, 0, 10000, True),
    'circuit': _spec('Can we compute AND without assuming independence?', 'Start with four joint worlds. Optionally condition on noisy evidence of style, then add worlds for each logical operation.', 'Reliability of observing style', .5, 1, .5, 1),
    'control': _spec('Can preference change while forbidden actions stay forbidden?', 'Normalize log(base) + strength × [log(desired) − log(undesired)] inside the legal set.', 'Control strength', 0, 2, 0, 3),
    'future': _spec('Can a less likely first move have a better future?', 'Weight the root policy by exact future success raised to strength. At strength zero use the base policy.', 'Future-value strength', 0, 1, 0, 2),
    'sensitivity': _spec('Which prompt intervention moves this measurement?', 'Rebuild the central finite-difference matrix. Predict a change in hours, with load fixed at +5 points; preserve the measured holdout error.', 'Change in hours remaining', -1, -2, -2, 2),
    'counterexamples': _spec('Can equivalent algebra confuse the observer?', 'Find the equivalent pair with the largest measured log-odds distance. Evaluate its exact coefficients at the chosen integer.', 'Integer x', 2, -2, -10, 10, True),
}


def normalize_logs(logs):
    finite = [x for x in logs if math.isfinite(x)]
    if not finite:
        raise ValueError('No candidate has positive mass')
    maximum = max(finite)
    weights = [math.exp(x-maximum) if math.isfinite(x) else 0. for x in logs]
    total = math.fsum(weights)
    return [w/total for w in weights]


def weights(rows, temperature=1):
    if any(r.get('logprob') is None for r in rows):
        raise ValueError('A complete label measurement is required; missing top-N entries stay unknown')
    return normalize_logs([r['logprob']/temperature for r in rows])


def entropy(p):
    return -math.fsum(x*math.log2(x) for x in p if x)


def _pick(items, value):
    if not 0 <= value < len(items):
        raise ValueError('Index must be 0..'+str(len(items)-1))
    return items[int(value)]


def _rows(names, values):
    return [dict(label=str(n), value=float(v)) for n,v in zip(names,values)]


def _graph(edges, threshold):
    if len(edges)>12:
        raise ValueError('This exact demonstration supports at most 12 edges')
    best, score = [], 0.
    for bits in itertools.product((False,True), repeat=len(edges)):
        selected=[e for e,yes in zip(edges,bits) if yes]
        out, incoming, captions = {}, set(), set()
        good=True
        for e in selected:
            a,b=e['source'],e['target']
            if a==b:good=False;break
            if e['relation']=='caption':
                if a in captions:good=False;break
                captions.add(a)
            else:
                if a in out or b in incoming:good=False;break
                out[a]=b;incoming.add(b)
        for start in out:
            node,visited=start,set()
            while node in out:
                if node in visited:good=False;break
                visited.add(node);node=out[node]
        utility=math.fsum(e['weight']-threshold for e in selected)
        if good and utility>score:best,score=selected,utility
    return best,score


def _ttt(board, turn):
    lines=((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))
    for a,b,c in lines:
        if board[a]!='.' and board[a]==board[b]==board[c]:return 1 if board[a]=='X' else -1
    if '.' not in board:return 0
    values=[_ttt(board[:i]+turn+board[i+1:],'O' if turn=='X' else 'X') for i,s in enumerate(board) if s=='.']
    return (max if turn=='X' else min)(values)


def calculate_lesson(name, data, value=None):
    spec=LESSON_SPECS[name]
    v=spec['default'] if value is None else value
    if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not spec['low']<=v<=spec['high'] or (spec['integer'] and int(v)!=v):
        raise ValueError(f"{spec['knob']} must be {'an integer' if spec['integer'] else 'finite'} in [{spec['low']}, {spec['high']}]")
    rows=[];metrics={};note='Calculation on saved inputs; changing this setting makes no new model request.'
    summary='';unit='weight'
    if name in ('choice','boolean','score'):
        p=weights(data['rows'],v);at=max(range(len(p)),key=p.__getitem__)
        rows=_rows([r['label']+' · '+r.get('description','') for r in data['rows']],p)
        metrics=dict(winner=data['rows'][at]['label'],top_weight=p[at],entropy_bits=entropy(p))
        if name in ('boolean','score'):
            metrics['expected_value']=math.fsum(q*r['value'] for q,r in zip(p,data['rows']))
        summary=f"Answer {metrics['winner']} leads with {p[at]:.2%} of the listed-label weight."
        if name=='score':summary=f"Expected rubric value: {metrics['expected_value']:.4f} on the stated 0–1 scale."
    elif name=='candidates':
        paths=data['paths'];logs=[math.fsum(t['logprob'] for t in r['tokens'])/len(r['tokens'])**v for r in paths]
        p=normalize_logs(logs);names=list(dict.fromkeys(r['group'] for r in paths))
        values=[math.fsum(q for q,r in zip(p,paths) if r['group']==g) for g in names];rows=_rows(names,values)
        metrics=dict(winner=names[values.index(max(values))],group_weights=values)
        summary=metrics['winner']+' carries the most relative group weight.'
        note='Only these emitted token paths, with their saved terminators and no EOS. A nonzero length penalty produces preference scores, not path probability.'
    elif name=='controller':
        labels=data['measure']['rows'];p=weights(labels);legal=[i for i,r in enumerate(labels) if r['allowed']]
        mass=math.fsum(p[i] for i in legal);pick=next(i for i,r in enumerate(labels) if r['action']==data['action'])
        q=p[pick]/mass;held=q<v
        rows=_rows([labels[i]['action'] for i in legal],[p[i]/mass for i in legal])
        metrics=dict(held=held,selected_weight=q,next_state=data['state'] if held else data['next_state'])
        summary=('Hold the action.' if held else 'Apply '+data['action']+'.')+' State: '+metrics['next_state']+'.'
    elif name=='rerank':
        values=[math.fsum(q*r['value'] for q,r in zip(weights(s['measure']['rows']),s['measure']['rows'])) for s in data['sources']]
        rows=_rows([s['id'] for s in data['sources']],values);kept=[r['label'] for r in rows if r['value']>=v]
        metrics=dict(retained=kept,scores=values);summary='Retain '+(', '.join(kept) or 'no sources')+' at this cutoff.'
    elif name=='graph':
        selected,utility=_graph(data['edges'],v);rows=_rows([e['source']+' → '+e['target'] for e in selected],[e['weight']-v for e in selected]);unit='utility'
        metrics=dict(selected=[(e['source'],e['target'],e['relation']) for e in selected],utility=utility)
        summary=f'{len(selected)} compatible links, total utility {utility:.4f}.'
        note='Global code constraints select links; utility is not the probability that the document graph is correct.'
    elif name=='scene':
        valid=[c for c in data['candidates'] if c['valid']];values=[]
        for c in valid:
            p=[weights(x['measure']['rows'])[0] for x in c['vector']]
            values.append(statistics.mean(p)-v*statistics.pvariance(p))
        rows=_rows([c['name'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['name'],utilities=values)
        summary='Retain '+metrics['retained']+' among geometry-valid candidates.'
        note='These are saved text judgments. This calculation cannot see the drawing or measure visual appeal.'
    elif name=='wire':
        entry=_pick(data['entries'],v);p=math.exp(entry['logprob']);top=entry.get('top_logprobs',[])
        rows=_rows([x['token'] for x in top],[math.exp(x['logprob']) for x in top]);unit='raw probability'
        metrics=dict(token=entry['token'],raw_probability=p,reported_top_mass=math.fsum(r['value'] for r in rows))
        summary=f"Token {entry['token']!r}: raw probability {p:.6g}."
        note='This is one visible content token at its actual prefix. Reported top-N mass is not the whole vocabulary.'
    elif name=='speculation':
        window=data['oracle']['example_rejection'];r=_pick(window['proposal'],v)
        rows=_rows(['Draft head','Target verification'],[r['draft_probability'],math.exp(r['target_logprob'])]);unit='probability / distinct heads'
        metrics=dict(token_id=r['token_id'],target_sequence_logprob=math.fsum(x['target_logprob'] for x in window['proposal']),draft_target_logprob_gap=r['draft_logprob']-r['target_logprob'])
        summary=f"Proposal token {r['token_id']}: the two heads differ by {metrics['draft_target_logprob_gap']:.4f} log units."
        note='Draft vocabulary and target vocabulary can differ. The gap is a diagnostic, not a calibrated rejection probability.'
    elif name=='performance':
        values=[]
        for r in data['rows']:
            xs=sorted(x['wall_ms'] for x in r['runs']);a=(len(xs)-1)*v/100;lo=math.floor(a);hi=math.ceil(a)
            values.append(xs[lo]+(xs[hi]-xs[lo])*(a-lo))
        rows=_rows([r['name'] for r in data['rows']],values);unit='ms';metrics=dict(percentile=v,times_ms=values)
        summary=f'Percentile {v:g}, recalculated from {data["repeats"]} samples per path.'
        note='Small same-setup samples include network and API cost. JSON answers a different task; this is no universal speed ranking.'
    elif name=='samplers':
        run=_pick(data['runs'],v);token=run['tokens'][0];sample=token['strata_sampling']
        raw=math.exp(token['logprob']);post=sample['probability']
        rows=_rows(['Raw target','After recipe'],[raw,post]);unit='selected token probability'
        metrics=dict(recipe=run['name'],support=sample['support'],raw=raw,selected=post,log_weight_change=math.log(post)-token['logprob'],entropy_bits=sample['entropy']/math.log(2))
        summary=f"{run['name']}: {sample['support']} native tokens remain eligible."
        note='Recipes are separate generations. Entropy and support are full-row native measurements; a top-N slice cannot recover them.'
    elif name=='sampler-sandbox':
        cut=max(data['logits'])+math.log(.05);logs=[x/v if x>=cut else -math.inf for x in data['logits']];p=normalize_logs(logs)
        rows=_rows(data['tokens'],p);metrics=dict(support=sum(x>0 for x in p),entropy_bits=entropy(p),probabilities=p)
        summary=f"{metrics['support']} credible tokens survive; entropy {metrics['entropy_bits']:.3f} bits."
        note='All eight logits are synthetic and visible. This is exact finite-row arithmetic, not a new native receipt.'
    elif name=='tictactoe':
        f=_pick(data['frames'],v);b=f['before'];legal=[i for i,c in enumerate(b) if c=='.'];oracle={i:_ttt(b[:i]+'X'+b[i+1:],'O') for i in legal}
        regret=max(oracle.values())-oracle[f['square']];rows=_rows([str(i+1) for i in legal],list(oracle.values()));unit='X outcome: lose −1 / draw 0 / win 1'
        metrics=dict(regret=regret,square=f['square']+1,oracle=oracle);summary=f"Recorded move: square {f['square']+1}; exact outcome regret {regret}."
    elif name=='chess':
        p=weights(data['measure']['rows'],v);mass=math.fsum(q for q,m in zip(p,data['shortlist']) if m['mate'])
        rows=_rows([m['san'] for m in data['shortlist']],p);metrics=dict(mating_shortlist_weight=mass,generated_uci=data['chosen']['text'],generated_mate=data['mate'])
        summary=f'{mass:.2%} of shortlist weight favors mate; the separate UCI generation '+('mated.' if data['mate'] else 'did not mate.')
        note='The saved legal/mate flags came from python-chess. This portable calculation aggregates them; it is not a replacement chess engine.'
    elif name=='poker':
        ranks=['J','Q','K'];rates={c:min(1,max(0,r*v)) for c,r in data['call_rates'].items()};values={}
        for own in ranks:
            opponents=[c for c in ranks if c!=own];sign=lambda c:1 if ranks.index(own)>ranks.index(c) else -1
            values[own]=dict(check=statistics.mean(sign(c) for c in opponents),bet=statistics.mean((1-rates[c])+rates[c]*2*sign(c) for c in opponents))
        rows=_rows([c+' bet − check' for c in ranks],[values[c]['bet']-values[c]['check'] for c in ranks]);unit='expected chips'
        metrics=dict(values=values,call_rates=rates);summary='Bet when the bar is positive; check when it is negative.'
        note='Uniform remaining-card prior and explicitly assumed opponent policy. Answer weights are not hidden-card beliefs or equilibrium probabilities.'
    elif name=='thermal':
        t=data['frames'][0]['temperature'];temperatures=[]
        for f in data['frames']:
            fan=min(60,max(0,f['fan']+v));t=round(t+.22*f['load']-.32*fan-.04*(t-25),3);temperatures.append(t)
        rows=_rows(range(1,len(temperatures)+1),temperatures);unit='°C';metrics=dict(temperatures=temperatures,mean_error=statistics.mean(abs(t-data['target']) for t in temperatures),violations=sum(t>data['limit'] for t in temperatures))
        summary=f"Mean distance from target: {metrics['mean_error']:.2f}°C; {metrics['violations']} limit violations."
        note='Offset fans are clamped to 0–60; the toy rounds to 0.001°C each step. This replays saved actions without rerunning the shield or model; it may violate the limit. No physical control.'
    elif name=='scheduler':
        done=set();clock=0;late=[]
        for f in data['frames']:
            j=f['job']
            if not set(j['after'])<=done:raise ValueError('Saved schedule violates dependencies')
            clock+=j['duration'];late.append(max(0,clock-j['deadline']-v));done.add(j['id'])
        rows=_rows([f['job']['id'] for f in data['frames']],late);unit='late time units';metrics=dict(total_lateness=sum(late),finish_time=clock)
        summary=f'Total lateness {sum(late):g}; the same dependency-valid order ends at time {clock}.'
    elif name=='context':
        selected=_pick(data['runs'],v);all_weights=[weights(r['measure']['rows'])[1] for r in data['runs']];p=all_weights[int(v)]
        rows=_rows([r['name'] for r in data['runs']],all_weights);metrics=dict(variant=selected['name'],no_weight=p,delta_from_append=p-all_weights[0])
        summary=f"{selected['name']}: keep-still answer weight {p:.3%}."
        note='Saved prompt interventions, not KV tensor mutation. This calculation compares their recorded measurements.'
    elif name=='observer':
        actions=[];triples=[]
        for f in data['frames']:
            p=[weights(x['measure']['rows'])[0] for x in f['vector']];triples.append(p)
            actions.append('inspect failure' if p[0]>v else 'verify' if p[1]>v else 'finish' if p[2]>v else 'ask')
        rows=_rows(['Fault','Missing check','Verified'],triples[0]);metrics=dict(actions=actions,vectors=triples)
        summary=' → '.join(actions)+'.';note='Bars show the first report. The same rule processes all three; correlated probes do not multiply into workflow reliability.'
    elif name=='calibration':
        p=[weights(r['measure']['rows'])[0] for r in data['rows']];truth=[r['truth'] for r in data['rows']];kept=[i for i,q in enumerate(p) if max(q,1-q)>=v]
        brier=statistics.mean((q-y)**2 for q,y in zip(p,truth));accuracy=statistics.mean(int(p[i]>=.5)==truth[i] for i in kept) if kept else None
        rows=_rows([str(i+1) for i in range(len(p))],p);metrics=dict(brier=brier,retained=len(kept),coverage=len(kept)/len(p),accuracy=accuracy)
        summary=f'{len(kept)}/{len(p)} retained; '+(f'{accuracy:.1%} correct in those cases.' if accuracy is not None else 'accuracy is undefined with zero coverage.')
        note='Six disclosed teaching examples, not a held-out calibration benchmark. Brier error still counts every example.'
    elif name=='information':
        t=_pick(data['tests'],v);prior=data['prior'];py=math.fsum(p*l for p,l in zip(prior,t['likelihood']));yes=[p*l/py for p,l in zip(prior,t['likelihood'])];no=[p*(1-l)/(1-py) for p,l in zip(prior,t['likelihood'])]
        gain=entropy(prior)-py*entropy(yes)-(1-py)*entropy(no);rows=_rows(data['faults'],yes)
        metrics=dict(test=t['name'],gain_bits=gain,gain_per_cost=gain/t['cost'],yes=yes,no=no)
        summary=t['name']+f': {gain:.3f} expected bits; {gain/t["cost"]:.3f} bits per cost unit.'
        note='Prior and likelihoods are stated synthetic sensor assumptions. Bars condition on a positive result; no test was actually purchased.'
    elif name=='search':
        valid=[c for c in data['candidates'] if c['valid']];values=[weights(c['measure']['rows'])[0]-v*c['cost']/3 for c in valid]
        rows=_rows([c['id'] for c in valid],values);unit='utility';metrics=dict(retained=valid[values.index(max(values))]['id'],utilities=values)
        summary='Retain '+metrics['retained']+' after charging for cost; invalid geometry is excluded.'
    elif name=='frontier':
        selector=sorted(r['selection_ms'] for r in data['measurements'])[len(data['measurements'])//2];transfer=data['vocabulary']*data['bytes_per_logit']/(v*1e6);total=60+transfer+selector
        rows=_rows(['Assumed forward','Transfer lower bound','Measured host selector'],[60,transfer,selector]);unit='ms'
        metrics=dict(transfer_ms=transfer,serial_ms=total,tokens_per_second=1000/total)
        summary=f'Serial estimate: {total:.3f} ms/token; {1000/total:.2f} tokens/s.'
        note='Forward time is assumed 60 ms. Selector uses the upper-middle measured sample to match the chart. Queue, prefill and network are excluded.'
    elif name=='research-map':
        branch=_pick(data['branches'],v);categories={}
        for b in data['branches']:categories[b['status']]=categories.get(b['status'],0)+1
        rows=_rows(list(categories),list(categories.values()));unit='branches';metrics=dict(branch=branch['name'],gate=branch['gate'],categories=categories)
        summary=branch['name']+': '+branch['gate'];note='This page recomputes an agenda inventory, not an experiment result. Each implemented branch links to its own evidence.'
    elif name=='pressure':
        case=_pick(data['cases'],v);r=case['rows'][0];token=r['token'];q=token['strata_sampling']['probability'];logz=token['logprob']-math.log(q)
        if logz>1e-6:raise ValueError('Pure-mask mass exceeds one')
        z=math.exp(min(0,logz));rows=_rows(['Survived','Removed'],[z,1-z]);unit='original probability mass'
        metrics=dict(grammar=case['name'],mass=z,pressure_nats=-logz,pressure_bits=-logz/math.log(2))
        summary=f"{case['name']}: {z:.4%} survives; pressure {-logz:.4f} nats."
        note='First actual prefix of this native grammar. Exact only for pure masking at temperature 1, not arbitrary sampler recipes or entire grammar languages.'
    elif name=='circuit':
        p=weights(data['cases'][0]['measurement']['rows']);weighted=[p[0]*(1-v),p[1]*(1-v),p[2]*v,p[3]*v];z=math.fsum(weighted);p=[x/z for x in weighted]
        f=p[1]+p[3];s=p[2]+p[3];rows=_rows(['Neither','Facts only','Style only','Both'],p)
        metrics=dict(F=f,S=s,AND=p[3],OR=1-p[0],F_given_S=p[3]/s if s else None,marginal_product=f*s)
        summary=f'Facts AND style: {p[3]:.2%}; multiplying the marginals would give {f*s:.2%}.'
        note='At reliability 0.5 the evidence is uninformative and leaves the native row unchanged. Logical arithmetic is exact relative to that row, not necessarily the world.'
    elif name=='control':
        logs=[math.log(b)+v*(math.log(d)-math.log(u)) if i in data['allowed'] else -math.inf for i,(b,d,u) in enumerate(zip(data['base'],data['desired'],data['undesired']))];p=normalize_logs(logs)
        rows=_rows(list('ABCD'),p);pick=max(range(len(p)),key=p.__getitem__);metrics=dict(probabilities=p,selected=pick,forbidden_mass=math.fsum(p[i] for i in range(len(p)) if i not in data['allowed']))
        summary=f"Action {'ABCD'[pick]} leads; forbidden-action mass stays zero."
        note='Finite-action arithmetic using separately prompted rows of the same model. It is not trained-expert decoding or a native full-vocabulary hook.'
    elif name=='future':
        root=weights(data['policy'][0]['rows']);child=weights(data['policy'][2]['rows']);h=[0,child[1]];p=normalize_logs([math.log(r)+(v*math.log(x) if x else -math.inf) if v else math.log(r) for r,x in zip(root,h)])
        rows=_rows(['A: dead end','B: viable route'],p);success=p[1]*child[1];metrics=dict(root_weights=p,exact_h=h,success_root_only=success,base_success=root[1]*child[1])
        summary=f'{p[1]:.2%} chooses B; leaving the next policy unchanged succeeds {success:.2%} of the time.'
        note='Only BB succeeds in this exact two-step toy. Conditioning both steps is different from steering only the root. No native future-value decoder is claimed.'
    elif name=='sensitivity':
        o=data['observations'];zs=[[math.log(p/(1-p)) for p in row['probabilities']] for row in o]
        matrix=[[(zs[2][i]-zs[1][i])/(2*data['epsilon'][0]),(zs[4][i]-zs[3][i])/(2*data['epsilon'][1])] for i in range(3)]
        delta=[r[0]*v+r[1]*5 for r in matrix];rows=_rows(['Urgency','Load','Damage'],delta);unit='predicted log-odds change'
        observed=[zs[6][i]-zs[0][i] for i in range(3)];held=[r[0]*-1+r[1]*5 for r in matrix]
        metrics=dict(matrix=matrix,predicted_delta=delta,holdout_residual=[a-b for a,b in zip(observed,held)])
        summary=f'Predicted urgency shift {delta[0]:+.3f}; the measured −1h/+5 holdout had error {metrics["holdout_residual"][0]:+.3f}.'
        note='The local linear approximation failed on the measured holdout. Other knob settings are predictions, not newly measured prompt responses.'
    elif name=='counterexamples':
        nodes=data['nodes'];pairs=[]
        for i,a in enumerate(nodes):
            za=[math.log(p/(1-p)) for p in a['p_yes']]
            for j,b in enumerate(nodes[i+1:],i+1):
                if a['coefficients']!=b['coefficients']:continue
                zb=[math.log(p/(1-p)) for p in b['p_yes']];distance=math.sqrt(math.fsum((x-y)**2 for x,y in zip(za,zb)));pairs.append((distance,i,j))
        distance,i,j=max(pairs);a,b=nodes[i],nodes[j];evaluate=lambda c:sum(x*v**k for k,x in enumerate(c))
        rows=_rows([a['expression'],b['expression']],[a['p_yes'][1],b['p_yes'][1]])
        metrics=dict(left=a['expression'],right=b['expression'],margin_distance=distance,left_value=evaluate(a['coefficients']),right_value=evaluate(b['coefficients']))
        summary=f'Equal exact values at x={v:g}: {metrics["left_value"]:g}; observer distance {distance:.3f}.'
        note='Matching canonical coefficients prove equivalence for all integers. Evaluating one x illustrates that proof; it does not establish it. Bars show the nonnegativity probe.'
    else:
        raise ValueError('No portable calculation for '+name)
    return dict(value=v,summary=summary,rows=rows,unit=unit,metrics=metrics,note=note)


def make_lesson(name, data):
    spec=LESSON_SPECS[name]
    try:
        first=calculate_lesson(name,data)
        compare=spec['compare']
        # An edited run can have fewer tokens/turns than the recorded default.
        lengths={'wire':len(data.get('entries',[])), 'samplers':len(data.get('runs',[])),
                 'tictactoe':len(data.get('frames',[])), 'context':len(data.get('runs',[])),
                 'information':len(data.get('tests',[])), 'research-map':len(data.get('branches',[])),
                 'pressure':len(data.get('cases',[]))}
        if name in lengths:compare=min(compare,lengths[name]-1)
        second=calculate_lesson(name,data,compare)
        context=data.get('prompt','').partition('STATE:\n')[2].partition('\nQUESTION:')[0]
        return dict(**spec,states=[first,second],input_excerpt=context[:320]+('…' if len(context)>320 else ''),scope='This panel and its Python calculation reproduce saved measurements. Other page controls are independent views.')
    except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:
        # A genuinely incomplete score or a tool-only wire response stays usable.
        # Do not turn an unavailable lesson into fabricated measurement data.
        return dict(**spec,states=[],unavailable=str(error),scope='This run has no complete inputs for this calculation. Inspect its exact request and result below.')



def mock_post(request, fixture):
    if request != fixture['request']:
        raise ValueError('No mock matches the edited request. Supply a new fixture or explicitly choose --live-url.')
    return copy.deepcopy(fixture['response'])


def live_post(base_url, request):
    if not base_url.startswith(('http://', 'https://')):
        raise ValueError('--live-url must be an http(s) Strata address')
    headers = {'Content-Type': 'application/json'}
    if os.environ.get('STRATA_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['STRATA_API_KEY']
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    body = json.dumps(request, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base_url.rstrip('/')+'/v1/chat/completions', data=body, headers=headers)
    with opener.open(req, timeout=600) as response:
        wire = response.read().decode('utf-8')
    if request.get('stream'):
        events = [line[5:].strip() for line in wire.splitlines() if line.startswith('data:')]
        if not events or events[-1] != '[DONE]':
            raise ValueError('Stream closed without [DONE]')
        chunks = [json.loads(line) for line in events[:-1]]
        if any('error' in chunk for chunk in chunks):
            raise ValueError('Stream reported an error: '+repr(chunks))
        return {'sse_events': chunks, 'wire': wire}
    reply = json.loads(wire)
    if 'error' in reply:
        raise ValueError('Strata reported an error: '+repr(reply['error']))
    return reply


def summarize(response):
    if 'sse_events' in response:
        return str(len(response['sse_events']))+' SSE events; inspect the saved wire response'
    choice = (response.get('choices') or [{}])[0]
    message = choice.get('message', {})
    text = message.get('content') or json.dumps(message.get('tool_calls') or message, ensure_ascii=False)
    entries = (choice.get('logprobs') or {}).get('content') or []
    if entries:
        text += '\n  First visible token raw probability: '+format(math.exp(entries[0]['logprob']), '.7g')
    return text


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=int, default=1, help='1-based request index (default 1)')
    parser.add_argument('--all', action='store_true', help='Replay every mock in this captured run')
    parser.add_argument('--show', action='store_true', help='Print exact selected HTTP request JSON')
    parser.add_argument('--lesson-only', action='store_true', help='Recalculate the captured question/rule/result panel without printing mocked calls')
    parser.add_argument('--value', type=float, help='Change the panel parameter within its documented bounds; offline calculation only')
    parser.add_argument('--live-url', help='Explicitly send ONE request to your compatible Strata server')
    parser.add_argument('--output', type=Path, help='Write responses and their provenance as JSON')
    args = parser.parse_args()
    if args.all and args.live_url:
        parser.error('--all is offline only; saved dependent requests are not a live adaptive controller')
    if args.live_url and (args.lesson_only or args.value is not None):
        parser.error('Lesson calculations use captured evidence. Do not mix --live-url with --lesson-only or --value.')
    calls = CAPTURED['receipt']['calls']
    print('Strata Control Lab / '+CAPTURED['experiment'])
    print('LIVE selected request' if args.live_url else 'OFFLINE MOCK / recorded responses, no inference or network')
    calculation=None
    if not args.live_url:
        spec=CAPTURED.get('lesson')
        if spec and spec.get('states'):
            knob=args.value if args.value is not None else (CAPTURED.get('lesson_view') or {}).get('value',spec['default'])
            try:calculation=calculate_lesson(CAPTURED['experiment'],CAPTURED['result'],knob)
            except (ValueError,KeyError,IndexError,ZeroDivisionError) as error:parser.error(str(error))
            print('\nQUESTION: '+spec['question']+'\nRULE: '+spec['rule'])
            print(spec['knob']+' = '+str(knob)+f" (allowed {spec['low']}..{spec['high']})")
            print('RESULT: '+calculation['summary'])
            print('BOUNDARY: '+calculation['note'])
            print('Reproduces the selected question/rule/result panel; other page dials are independent.')
            print(json.dumps(calculation,ensure_ascii=True,indent=2))
        elif args.lesson_only or args.value is not None:
            parser.error('This captured run has no complete lesson inputs: '+str((spec or {}).get('unavailable','missing calculation')))
    if args.lesson_only:
        result=dict(mode='offline-calculation',calculation=calculation)
    elif not calls:
        if args.live_url:
            parser.error('This page has no HTTP requests: it is analytical or recorded diagnostic evidence')
        print('No HTTP request, GBNF or JSON output constraint was used by this page.')
        print('The included result is a calculation/diagnostic snapshot, not a new model answer.')
        result = dict(mode='offline-snapshot', result=CAPTURED['result'])
        print(json.dumps(result, ensure_ascii=True, indent=2))
    else:
        indexes = range(len(calls)) if args.all else [args.request-1]
        if any(i < 0 or i >= len(calls) for i in indexes):
            parser.error('Request index must be 1..'+str(len(calls)))
        results = []
        for i in indexes:
            fixture = calls[i]
            request = copy.deepcopy(fixture['request'])  # Edit here to try your own live request.
            if args.show:
                print(json.dumps(request, ensure_ascii=True, indent=2))
            response = live_post(args.live_url, request) if args.live_url else mock_post(request, fixture)
            print('Request '+str(i+1)+' / '+str(len(calls))+': '+summarize(response))
            results.append(dict(request=request, response=response,
                                provenance='live-request' if args.live_url else 'mocked-native-recording'))
        result = dict(mode='live' if args.live_url else 'offline-mock', calls=results)
        print('GBNF and JSON settings are in each request. Use --show to inspect them.')
        print('The saved page result is in CAPTURED["result"]; live responses do not recompute that snapshot.')
    if calculation is not None:result['calculation']=calculation
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
